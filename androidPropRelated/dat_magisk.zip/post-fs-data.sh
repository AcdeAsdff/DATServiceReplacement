rnd=$((352))
MODDIR=${0%/*}
touch ${PWD}/${rnd}
su -c sh ${PWD}"/resprop_presents/resprop_"${rnd}".sh" root
su -c sh ${PWD}"/move_version.sh" root
