strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Lenovo TB-7305X"
resetprop -n ro.product.vendor.model "Lenovo TB-7305X"
resetprop -n ro.product.vendor_dlkm.marketname "Lenovo TB-7305X"
resetprop -n ro.product.product.marketname "Lenovo TB-7305X"
resetprop -n ro.product.system.marketname "Lenovo TB-7305X"
resetprop -n ro.product.odm_dlkm.marketname "Lenovo TB-7305X"
resetprop -n ro.product.system_ext.marketname "Lenovo TB-7305X"
resetprop -n ro.product.odm_dlkm.model "Lenovo TB-7305X"
resetprop -n ro.product.system.model "Lenovo TB-7305X"
resetprop -n ro.product.system_ext.model "Lenovo TB-7305X"
resetprop -n ro.product.vendor_dlkm.model "Lenovo TB-7305X"
resetprop -n bluetooth.device.default_name "Lenovo TB-7305X"
resetprop -n ro.product.bootimage.model "Lenovo TB-7305X"
resetprop -n ro.product.vendor.marketname "Lenovo TB-7305X"
resetprop -n ro.product.marketname "Lenovo TB-7305X"
resetprop -n ro.product.odm.model "Lenovo TB-7305X"
resetprop -n ro.product.model "Lenovo TB-7305X"
resetprop -n ro.product.product.model "Lenovo TB-7305X"
resetprop -n ro.product.odm.marketname "Lenovo TB-7305X"
resetprop -n ro.product.vendor.manufacturer "LENOVO"
resetprop -n ro.product.product.manufacturer "LENOVO"
resetprop -n ro.product.bootimage.manufacturer "LENOVO"
resetprop -n ro.product.manufacturer "LENOVO"
resetprop -n ro.product.odm.manufacturer "LENOVO"
resetprop -n ro.product.system.manufacturer "LENOVO"
resetprop -n ro.product.system_ext.manufacturer "LENOVO"
resetprop -n ro.product.vendor_dlkm.manufacturer "LENOVO"
resetprop -n ro.product.vendor.brand "Lenovo"
resetprop -n ro.product.product.brand "Lenovo"
resetprop -n ro.product.vendor_dlkm.brand "Lenovo"
resetprop -n ro.product.system.brand "Lenovo"
resetprop -n ro.product.bootimage.brand "Lenovo"
resetprop -n ro.product.system_ext.brand "Lenovo"
resetprop -n ro.product.odm.brand "Lenovo"
resetprop -n ro.product.odm_dlkm.brand "Lenovo"
resetprop -n ro.product.brand "Lenovo"
resetprop -n ro.vendor_dlkm.build.fingerprint "Lenovo/LenovoTB-7305X/7305X:9/PPR1.180610.011/S100030_190829_ROW:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Lenovo/LenovoTB-7305X/7305X:9/PPR1.180610.011/S100030_190829_ROW:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Lenovo/LenovoTB-7305X/7305X:9/PPR1.180610.011/S100030_190829_ROW:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Lenovo/LenovoTB-7305X/7305X:9/PPR1.180610.011/S100030_190829_ROW:user/release-keys"
resetprop -n ro.system.build.fingerprint "Lenovo/LenovoTB-7305X/7305X:9/PPR1.180610.011/S100030_190829_ROW:user/release-keys"
resetprop -n ro.build.fingerprint "Lenovo/LenovoTB-7305X/7305X:9/PPR1.180610.011/S100030_190829_ROW:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Lenovo/LenovoTB-7305X/7305X:9/PPR1.180610.011/S100030_190829_ROW:user/release-keys"
resetprop -n ro.product.build.fingerprint "Lenovo/LenovoTB-7305X/7305X:9/PPR1.180610.011/S100030_190829_ROW:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Lenovo/LenovoTB-7305X/7305X:9/PPR1.180610.011/S100030_190829_ROW:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=e0f5e86ecc
resetprop -n ro.system.build.version.incremental TB-7305X_S100030_190829_ROW
resetprop -n ro.bootimage.build.version.incremental TB-7305X_S100030_190829_ROW
resetprop -n ro.product.build.version.incremental TB-7305X_S100030_190829_ROW
resetprop -n ro.odm.build.version.incremental TB-7305X_S100030_190829_ROW
resetprop -n ro.vendor_dlkm.build.version.incremental TB-7305X_S100030_190829_ROW
resetprop -n ro.system_ext.build.version.incremental TB-7305X_S100030_190829_ROW
resetprop -n ro.build.version.incremental TB-7305X_S100030_190829_ROW
resetprop -n ro.vendor.build.version.incremental TB-7305X_S100030_190829_ROW
resetprop -n ro.odm.build.id "PPR1.180610.011"
resetprop -n ro.product.build.id "PPR1.180610.011"
resetprop -n ro.bootimage.build.id "PPR1.180610.011"
resetprop -n ro.system_ext.build.id "PPR1.180610.011"
resetprop -n ro.vendor_dlkm.build.id "PPR1.180610.011"
resetprop -n ro.build.id "PPR1.180610.011"
resetprop -n ro.system.build.id "PPR1.180610.011"
resetprop -n ro.vendor.build.id "PPR1.180610.011"
resetprop -n ro.system.build.date "Wed Aug 28 23:20:14 CST 2019"
resetprop -n ro.bootimage.build.date "Wed Aug 28 23:20:14 CST 2019"
resetprop -n ro.product.build.date "Wed Aug 28 23:20:14 CST 2019"
resetprop -n ro.vendor_dlkm.build.date "Wed Aug 28 23:20:14 CST 2019"
resetprop -n ro.system_ext.build.date "Wed Aug 28 23:20:14 CST 2019"
resetprop -n ro.odm.build.date "Wed Aug 28 23:20:14 CST 2019"
resetprop -n ro.build.date "Wed Aug 28 23:20:14 CST 2019"
resetprop -n ro.vendor.build.date "Wed Aug 28 23:20:14 CST 2019"
resetprop -n ro.product.build.date.utc "1567005614"
resetprop -n ro.system_ext.build.date.utc "1567005614"
resetprop -n ro.system.build.date.utc "1567005614"
resetprop -n ro.vendor.build.date.utc "1567005614"
resetprop -n ro.vendor_dlkm.build.date.utc "1567005614"
resetprop -n ro.build.date.utc "1567005614"
resetprop -n ro.bootimage.build.date.utc "1567005614"
resetprop -n ro.odm.build.date.utc "1567005614"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name LenovoTB-7305X
resetprop -n ro.product.odm.name LenovoTB-7305X
resetprop -n ro.product.vendor.name LenovoTB-7305X
resetprop -n ro.product.system.name LenovoTB-7305X
resetprop -n ro.product.name LenovoTB-7305X
resetprop -n ro.product.bootimage.name LenovoTB-7305X
resetprop -n ro.product.vendor_dlkm.name LenovoTB-7305X
resetprop -n ro.product.system_ext.name LenovoTB-7305X
resetprop -n ro.build.flavor full_mt8765_GO-user
randomStr="full_mt8765_GO-user LENOVO PPR1.180610.011 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=b11720b02a54
resetprop -n ro.build.host ${randomStr}
randomStr=d06cddac
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=WLckhH
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=c409ab660c804
randomStr2=7b
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=f1
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "TB-7305X_S100030_190829_ROW"
resetprop -n ro.build.description "full_mt8765_GO-user 9 PPR1.180610.011 10 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "hoperun"
resetprop -n ro.build.host "SER19001"
resetprop -n ro.build.product.backup "7305X"
resetprop -n ro.build.characteristics "tablet"
resetprop -n ro.com.google.acsa "true"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.expect.recovery_id "0x93976e15225cc2817d60488e31715bae986babd1000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-07-05
