strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "ITX-3588J"
resetprop -n ro.product.vendor.model "ITX-3588J"
resetprop -n ro.product.vendor_dlkm.marketname "ITX-3588J"
resetprop -n ro.product.product.marketname "ITX-3588J"
resetprop -n ro.product.system.marketname "ITX-3588J"
resetprop -n ro.product.odm_dlkm.marketname "ITX-3588J"
resetprop -n ro.product.system_ext.marketname "ITX-3588J"
resetprop -n ro.product.odm_dlkm.model "ITX-3588J"
resetprop -n ro.product.system.model "ITX-3588J"
resetprop -n ro.product.system_ext.model "ITX-3588J"
resetprop -n ro.product.vendor_dlkm.model "ITX-3588J"
resetprop -n bluetooth.device.default_name "ITX-3588J"
resetprop -n ro.product.bootimage.model "ITX-3588J"
resetprop -n ro.product.vendor.marketname "ITX-3588J"
resetprop -n ro.product.marketname "ITX-3588J"
resetprop -n ro.product.odm.model "ITX-3588J"
resetprop -n ro.product.model "ITX-3588J"
resetprop -n ro.product.product.model "ITX-3588J"
resetprop -n ro.product.odm.marketname "ITX-3588J"
resetprop -n ro.product.vendor.manufacturer "Firefly"
resetprop -n ro.product.product.manufacturer "Firefly"
resetprop -n ro.product.bootimage.manufacturer "Firefly"
resetprop -n ro.product.manufacturer "Firefly"
resetprop -n ro.product.odm.manufacturer "Firefly"
resetprop -n ro.product.system.manufacturer "Firefly"
resetprop -n ro.product.system_ext.manufacturer "Firefly"
resetprop -n ro.product.vendor_dlkm.manufacturer "Firefly"
resetprop -n ro.product.vendor.brand "Firefly"
resetprop -n ro.product.product.brand "Firefly"
resetprop -n ro.product.vendor_dlkm.brand "Firefly"
resetprop -n ro.product.system.brand "Firefly"
resetprop -n ro.product.bootimage.brand "Firefly"
resetprop -n ro.product.system_ext.brand "Firefly"
resetprop -n ro.product.odm.brand "Firefly"
resetprop -n ro.product.odm_dlkm.brand "Firefly"
resetprop -n ro.product.brand "Firefly"
resetprop -n ro.vendor_dlkm.build.fingerprint "Firefly/rk3588/rk3588:12/SQ1D.211205.016.A5/chenjp03111026:userdebug/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Firefly/rk3588/rk3588:12/SQ1D.211205.016.A5/chenjp03111026:userdebug/release-keys"
resetprop -n ro.vendor.build.fingerprint "Firefly/rk3588/rk3588:12/SQ1D.211205.016.A5/chenjp03111026:userdebug/release-keys"
resetprop -n ro.odm.build.fingerprint "Firefly/rk3588/rk3588:12/SQ1D.211205.016.A5/chenjp03111026:userdebug/release-keys"
resetprop -n ro.system.build.fingerprint "Firefly/rk3588/rk3588:12/SQ1D.211205.016.A5/chenjp03111026:userdebug/release-keys"
resetprop -n ro.build.fingerprint "Firefly/rk3588/rk3588:12/SQ1D.211205.016.A5/chenjp03111026:userdebug/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Firefly/rk3588/rk3588:12/SQ1D.211205.016.A5/chenjp03111026:userdebug/release-keys"
resetprop -n ro.product.build.fingerprint "Firefly/rk3588/rk3588:12/SQ1D.211205.016.A5/chenjp03111026:userdebug/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Firefly/rk3588/rk3588:12/SQ1D.211205.016.A5/chenjp03111026:userdebug/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=a8ace9ddc9
resetprop -n ro.system.build.version.incremental eng.chenjp.20220311.102747
resetprop -n ro.bootimage.build.version.incremental eng.chenjp.20220311.102747
resetprop -n ro.product.build.version.incremental eng.chenjp.20220311.102747
resetprop -n ro.odm.build.version.incremental eng.chenjp.20220311.102747
resetprop -n ro.vendor_dlkm.build.version.incremental eng.chenjp.20220311.102747
resetprop -n ro.system_ext.build.version.incremental eng.chenjp.20220311.102747
resetprop -n ro.build.version.incremental eng.chenjp.20220311.102747
resetprop -n ro.vendor.build.version.incremental eng.chenjp.20220311.102747
resetprop -n ro.odm.build.id "SQ1D.211205.016.A5"
resetprop -n ro.product.build.id "SQ1D.211205.016.A5"
resetprop -n ro.bootimage.build.id "SQ1D.211205.016.A5"
resetprop -n ro.system_ext.build.id "SQ1D.211205.016.A5"
resetprop -n ro.vendor_dlkm.build.id "SQ1D.211205.016.A5"
resetprop -n ro.build.id "SQ1D.211205.016.A5"
resetprop -n ro.system.build.id "SQ1D.211205.016.A5"
resetprop -n ro.vendor.build.id "SQ1D.211205.016.A5"
resetprop -n ro.system.build.date "Fri Mar 11 10:26:06 CST 2022"
resetprop -n ro.bootimage.build.date "Fri Mar 11 10:26:06 CST 2022"
resetprop -n ro.product.build.date "Fri Mar 11 10:26:06 CST 2022"
resetprop -n ro.vendor_dlkm.build.date "Fri Mar 11 10:26:06 CST 2022"
resetprop -n ro.system_ext.build.date "Fri Mar 11 10:26:06 CST 2022"
resetprop -n ro.odm.build.date "Fri Mar 11 10:26:06 CST 2022"
resetprop -n ro.build.date "Fri Mar 11 10:26:06 CST 2022"
resetprop -n ro.vendor.build.date "Fri Mar 11 10:26:06 CST 2022"
resetprop -n ro.product.build.date.utc "1646965566"
resetprop -n ro.system_ext.build.date.utc "1646965566"
resetprop -n ro.system.build.date.utc "1646965566"
resetprop -n ro.vendor.build.date.utc "1646965566"
resetprop -n ro.vendor_dlkm.build.date.utc "1646965566"
resetprop -n ro.build.date.utc "1646965566"
resetprop -n ro.bootimage.build.date.utc "1646965566"
resetprop -n ro.odm.build.date.utc "1646965566"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "userdebug"
resetprop -n ro.system_ext.build.type "userdebug"
resetprop -n ro.vendor_dlkm.build.type "userdebug"
resetprop -n ro.bootimage.build.type "userdebug"
resetprop -n ro.product.build.type "userdebug"
resetprop -n ro.odm.build.type "userdebug"
resetprop -n ro.vendor.build.type "userdebug"
resetprop -n ro.product.product.name rk3588_firefly_itx_3588j
resetprop -n ro.product.odm.name rk3588_firefly_itx_3588j
resetprop -n ro.product.vendor.name rk3588_firefly_itx_3588j
resetprop -n ro.product.system.name rk3588_firefly_itx_3588j
resetprop -n ro.product.name rk3588_firefly_itx_3588j
resetprop -n ro.product.bootimage.name rk3588_firefly_itx_3588j
resetprop -n ro.product.vendor_dlkm.name rk3588_firefly_itx_3588j
resetprop -n ro.product.system_ext.name rk3588_firefly_itx_3588j
resetprop -n ro.build.flavor rk3588_firefly_itx_3588j-userdebug
randomStr="rk3588_firefly_itx_3588j-userdebug Firefly SQ1D.211205.016.A5 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=aafaed515938
resetprop -n ro.build.host ${randomStr}
randomStr=84e1b034
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=uiWcqp
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=ad238a879853c
randomStr2=1d
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=dd
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "eng.chenjp.20220311.102747"
resetprop -n ro.build.description "rk3588_firefly_itx_3588j-userdebug 12 SQ1D.211205.016.A5 eng.chenjp.20220311.102747 release-keys"
resetprop -n ro.build.product.backup "rk3588_firefly_itx_3588j"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "chenjp"
resetprop -n ro.build.host "tchipserver19"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2021-12-05
