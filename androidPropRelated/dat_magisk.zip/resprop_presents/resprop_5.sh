strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "S62 Pro"
resetprop -n ro.product.vendor.model "S62 Pro"
resetprop -n ro.product.vendor_dlkm.marketname "S62 Pro"
resetprop -n ro.product.product.marketname "S62 Pro"
resetprop -n ro.product.system.marketname "S62 Pro"
resetprop -n ro.product.odm_dlkm.marketname "S62 Pro"
resetprop -n ro.product.system_ext.marketname "S62 Pro"
resetprop -n ro.product.odm_dlkm.model "S62 Pro"
resetprop -n ro.product.system.model "S62 Pro"
resetprop -n ro.product.system_ext.model "S62 Pro"
resetprop -n ro.product.vendor_dlkm.model "S62 Pro"
resetprop -n bluetooth.device.default_name "S62 Pro"
resetprop -n ro.product.bootimage.model "S62 Pro"
resetprop -n ro.product.vendor.marketname "S62 Pro"
resetprop -n ro.product.marketname "S62 Pro"
resetprop -n ro.product.odm.model "S62 Pro"
resetprop -n ro.product.model "S62 Pro"
resetprop -n ro.product.product.model "S62 Pro"
resetprop -n ro.product.odm.marketname "S62 Pro"
resetprop -n ro.product.vendor.manufacturer "Cat"
resetprop -n ro.product.product.manufacturer "Cat"
resetprop -n ro.product.bootimage.manufacturer "Cat"
resetprop -n ro.product.manufacturer "Cat"
resetprop -n ro.product.odm.manufacturer "Cat"
resetprop -n ro.product.system.manufacturer "Cat"
resetprop -n ro.product.system_ext.manufacturer "Cat"
resetprop -n ro.product.vendor_dlkm.manufacturer "Cat"
resetprop -n ro.product.vendor.brand "Cat"
resetprop -n ro.product.product.brand "Cat"
resetprop -n ro.product.vendor_dlkm.brand "Cat"
resetprop -n ro.product.system.brand "Cat"
resetprop -n ro.product.bootimage.brand "Cat"
resetprop -n ro.product.system_ext.brand "Cat"
resetprop -n ro.product.odm.brand "Cat"
resetprop -n ro.product.odm_dlkm.brand "Cat"
resetprop -n ro.product.brand "Cat"
resetprop -n ro.vendor_dlkm.build.fingerprint "Cat/S62Pro/S62Pro:11/RKQ1.210406.002/1.015.00:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Cat/S62Pro/S62Pro:11/RKQ1.210406.002/1.015.00:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Cat/S62Pro/S62Pro:11/RKQ1.210406.002/1.015.00:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Cat/S62Pro/S62Pro:11/RKQ1.210406.002/1.015.00:user/release-keys"
resetprop -n ro.system.build.fingerprint "Cat/S62Pro/S62Pro:11/RKQ1.210406.002/1.015.00:user/release-keys"
resetprop -n ro.build.fingerprint "Cat/S62Pro/S62Pro:11/RKQ1.210406.002/1.015.00:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Cat/S62Pro/S62Pro:11/RKQ1.210406.002/1.015.00:user/release-keys"
resetprop -n ro.product.build.fingerprint "Cat/S62Pro/S62Pro:11/RKQ1.210406.002/1.015.00:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Cat/S62Pro/S62Pro:11/RKQ1.210406.002/1.015.00:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=707c2ccc23
resetprop -n ro.system.build.version.incremental 1.015.00
resetprop -n ro.bootimage.build.version.incremental 1.015.00
resetprop -n ro.product.build.version.incremental 1.015.00
resetprop -n ro.odm.build.version.incremental 1.015.00
resetprop -n ro.vendor_dlkm.build.version.incremental 1.015.00
resetprop -n ro.system_ext.build.version.incremental 1.015.00
resetprop -n ro.build.version.incremental 1.015.00
resetprop -n ro.vendor.build.version.incremental 1.015.00
resetprop -n ro.odm.build.id "RKQ1.210406.002"
resetprop -n ro.product.build.id "RKQ1.210406.002"
resetprop -n ro.bootimage.build.id "RKQ1.210406.002"
resetprop -n ro.system_ext.build.id "RKQ1.210406.002"
resetprop -n ro.vendor_dlkm.build.id "RKQ1.210406.002"
resetprop -n ro.build.id "RKQ1.210406.002"
resetprop -n ro.system.build.id "RKQ1.210406.002"
resetprop -n ro.vendor.build.id "RKQ1.210406.002"
resetprop -n ro.system.build.date "Fri Oct 22 19:12:13 CST 2021"
resetprop -n ro.bootimage.build.date "Fri Oct 22 19:12:13 CST 2021"
resetprop -n ro.product.build.date "Fri Oct 22 19:12:13 CST 2021"
resetprop -n ro.vendor_dlkm.build.date "Fri Oct 22 19:12:13 CST 2021"
resetprop -n ro.system_ext.build.date "Fri Oct 22 19:12:13 CST 2021"
resetprop -n ro.odm.build.date "Fri Oct 22 19:12:13 CST 2021"
resetprop -n ro.build.date "Fri Oct 22 19:12:13 CST 2021"
resetprop -n ro.vendor.build.date "Fri Oct 22 19:12:13 CST 2021"
resetprop -n ro.product.build.date.utc "1634901133"
resetprop -n ro.system_ext.build.date.utc "1634901133"
resetprop -n ro.system.build.date.utc "1634901133"
resetprop -n ro.vendor.build.date.utc "1634901133"
resetprop -n ro.vendor_dlkm.build.date.utc "1634901133"
resetprop -n ro.build.date.utc "1634901133"
resetprop -n ro.bootimage.build.date.utc "1634901133"
resetprop -n ro.odm.build.date.utc "1634901133"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name S62Pro
resetprop -n ro.product.odm.name S62Pro
resetprop -n ro.product.vendor.name S62Pro
resetprop -n ro.product.system.name S62Pro
resetprop -n ro.product.name S62Pro
resetprop -n ro.product.bootimage.name S62Pro
resetprop -n ro.product.vendor_dlkm.name S62Pro
resetprop -n ro.product.system_ext.name S62Pro
resetprop -n ro.build.flavor sdm660_64-user
randomStr="sdm660_64-user Cat RKQ1.210406.002 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=d455894d5537
resetprop -n ro.build.host ${randomStr}
randomStr=fa00a699
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=kXMHja
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=06fdf8f680a8e
randomStr2=72
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=13
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1.015.00"
resetprop -n ro.build.description "aeon6580_weg_l_l300-user 5.1 LMY47I 1555741941 release-keys"
resetprop -n ro.build.product.backup "S62Pro"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "rdadmin"
resetprop -n ro.build.host "SYS1Srv"
resetprop -n media.stagefright.enable-player "true"
resetprop -n media.stagefright.enable-http "true"
resetprop -n media.stagefright.enable-aac "true"
resetprop -n media.stagefright.enable-qcp "true"
resetprop -n media.stagefright.enable-scan "true"
resetprop -n media.aac_51_output_enabled "true"
resetprop -n media.settings.xml "/vendor/etc/media_profiles_vendor.xml"
resetprop -n media.stagefright.thumbnail.prefer_hw_codecs "true"
resetprop -n ro.hwui.texture_cache_size "72"
resetprop -n ro.hwui.layer_cache_size "48"
resetprop -n ro.hwui.r_buffer_cache_size "8"
resetprop -n ro.hwui.path_cache_size "32"
resetprop -n ro.hwui.gradient_cache_size "1"
resetprop -n ro.hwui.drop_shadow_cache_size "6"
resetprop -n ro.hwui.texture_cache_flushrate "0.4"
resetprop -n ro.hwui.text_small_cache_width "1024"
resetprop -n ro.hwui.text_small_cache_height "1024"
resetprop -n ro.hwui.text_large_cache_width "2048"
resetprop -n ro.hwui.text_large_cache_height "2048"
resetprop -n ro.com.google.clientidbase "android-bullitt"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2021-11-01
