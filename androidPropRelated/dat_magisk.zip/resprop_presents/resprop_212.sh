strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "A200 Pro"
resetprop -n ro.product.vendor.model "A200 Pro"
resetprop -n ro.product.vendor_dlkm.marketname "A200 Pro"
resetprop -n ro.product.product.marketname "A200 Pro"
resetprop -n ro.product.system.marketname "A200 Pro"
resetprop -n ro.product.odm_dlkm.marketname "A200 Pro"
resetprop -n ro.product.system_ext.marketname "A200 Pro"
resetprop -n ro.product.odm_dlkm.model "A200 Pro"
resetprop -n ro.product.system.model "A200 Pro"
resetprop -n ro.product.system_ext.model "A200 Pro"
resetprop -n ro.product.vendor_dlkm.model "A200 Pro"
resetprop -n bluetooth.device.default_name "A200 Pro"
resetprop -n ro.product.bootimage.model "A200 Pro"
resetprop -n ro.product.vendor.marketname "A200 Pro"
resetprop -n ro.product.marketname "A200 Pro"
resetprop -n ro.product.odm.model "A200 Pro"
resetprop -n ro.product.model "A200 Pro"
resetprop -n ro.product.product.model "A200 Pro"
resetprop -n ro.product.odm.marketname "A200 Pro"
resetprop -n ro.product.vendor.manufacturer "Blackview"
resetprop -n ro.product.product.manufacturer "Blackview"
resetprop -n ro.product.bootimage.manufacturer "Blackview"
resetprop -n ro.product.manufacturer "Blackview"
resetprop -n ro.product.odm.manufacturer "Blackview"
resetprop -n ro.product.system.manufacturer "Blackview"
resetprop -n ro.product.system_ext.manufacturer "Blackview"
resetprop -n ro.product.vendor_dlkm.manufacturer "Blackview"
resetprop -n ro.product.vendor.brand "Blackview"
resetprop -n ro.product.product.brand "Blackview"
resetprop -n ro.product.vendor_dlkm.brand "Blackview"
resetprop -n ro.product.system.brand "Blackview"
resetprop -n ro.product.bootimage.brand "Blackview"
resetprop -n ro.product.system_ext.brand "Blackview"
resetprop -n ro.product.odm.brand "Blackview"
resetprop -n ro.product.odm_dlkm.brand "Blackview"
resetprop -n ro.product.brand "Blackview"
resetprop -n ro.vendor_dlkm.build.fingerprint "Blackview/A200Pro_NEU/A200Pro:13/TP1A.220624.014/65533:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Blackview/A200Pro_NEU/A200Pro:13/TP1A.220624.014/65533:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Blackview/A200Pro_NEU/A200Pro:13/TP1A.220624.014/65533:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Blackview/A200Pro_NEU/A200Pro:13/TP1A.220624.014/65533:user/release-keys"
resetprop -n ro.system.build.fingerprint "Blackview/A200Pro_NEU/A200Pro:13/TP1A.220624.014/65533:user/release-keys"
resetprop -n ro.build.fingerprint "Blackview/A200Pro_NEU/A200Pro:13/TP1A.220624.014/65533:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Blackview/A200Pro_NEU/A200Pro:13/TP1A.220624.014/65533:user/release-keys"
resetprop -n ro.product.build.fingerprint "Blackview/A200Pro_NEU/A200Pro:13/TP1A.220624.014/65533:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Blackview/A200Pro_NEU/A200Pro:13/TP1A.220624.014/65533:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=c2134ec725
resetprop -n ro.system.build.version.incremental 65533
resetprop -n ro.bootimage.build.version.incremental 65533
resetprop -n ro.product.build.version.incremental 65533
resetprop -n ro.odm.build.version.incremental 65533
resetprop -n ro.vendor_dlkm.build.version.incremental 65533
resetprop -n ro.system_ext.build.version.incremental 65533
resetprop -n ro.build.version.incremental 65533
resetprop -n ro.vendor.build.version.incremental 65533
resetprop -n ro.odm.build.id "TP1A.220624.014"
resetprop -n ro.product.build.id "TP1A.220624.014"
resetprop -n ro.bootimage.build.id "TP1A.220624.014"
resetprop -n ro.system_ext.build.id "TP1A.220624.014"
resetprop -n ro.vendor_dlkm.build.id "TP1A.220624.014"
resetprop -n ro.build.id "TP1A.220624.014"
resetprop -n ro.system.build.id "TP1A.220624.014"
resetprop -n ro.vendor.build.id "TP1A.220624.014"
resetprop -n ro.system.build.date "Wed Nov 15 10:19:33 CST 2023"
resetprop -n ro.bootimage.build.date "Wed Nov 15 10:19:33 CST 2023"
resetprop -n ro.product.build.date "Wed Nov 15 10:19:33 CST 2023"
resetprop -n ro.vendor_dlkm.build.date "Wed Nov 15 10:19:33 CST 2023"
resetprop -n ro.system_ext.build.date "Wed Nov 15 10:19:33 CST 2023"
resetprop -n ro.odm.build.date "Wed Nov 15 10:19:33 CST 2023"
resetprop -n ro.build.date "Wed Nov 15 10:19:33 CST 2023"
resetprop -n ro.vendor.build.date "Wed Nov 15 10:19:33 CST 2023"
resetprop -n ro.product.build.date.utc "1700014773"
resetprop -n ro.system_ext.build.date.utc "1700014773"
resetprop -n ro.system.build.date.utc "1700014773"
resetprop -n ro.vendor.build.date.utc "1700014773"
resetprop -n ro.vendor_dlkm.build.date.utc "1700014773"
resetprop -n ro.build.date.utc "1700014773"
resetprop -n ro.bootimage.build.date.utc "1700014773"
resetprop -n ro.odm.build.date.utc "1700014773"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name A200Pro_NEU
resetprop -n ro.product.odm.name A200Pro_NEU
resetprop -n ro.product.vendor.name A200Pro_NEU
resetprop -n ro.product.system.name A200Pro_NEU
resetprop -n ro.product.name A200Pro_NEU
resetprop -n ro.product.bootimage.name A200Pro_NEU
resetprop -n ro.product.vendor_dlkm.name A200Pro_NEU
resetprop -n ro.product.system_ext.name A200Pro_NEU
resetprop -n ro.build.flavor sys_mssi_64_cn_armv82-user
randomStr="sys_mssi_64_cn_armv82-user Blackview TP1A.220624.014 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer Mediatek
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=f1423a61bcdc
resetprop -n ro.build.host ${randomStr}
randomStr=15645286
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=KKkzBh
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=8b33d81b246ac
randomStr2=c8
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=00
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "65533"
resetprop -n ro.build.description "A200_Pro_NEU_M9902A_V1.0_20231115"
resetprop -n ro.build.product.backup "mssi_64_cn_armv82"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "temp1"
resetprop -n ro.build.host "xr"
resetprop -n ro.com.google.clientidbase "android-chinoe"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.mediatek.version.branch "alps-mp-t0.mssi1"
resetprop -n ro.mediatek.version.release "alps-mp-t0.mp1-V11.71"
resetprop -n ro.vendor.mtk_omacp_support "1"
resetprop -n ro.vendor.mtk_flv_playback_support "1"
resetprop -n ro.vendor.mtk_cta_set "1"
resetprop -n ro.vendor.mtk_telephony_add_on_policy "0"
resetprop -n media.stagefright.thumbnail.prefer_hw_codecs "true"
resetprop -n vendor.mtk_thumbnail_optimization "true"
resetprop -n ro.vendor.mtk_power_off_alarm_test "1"
resetprop -n ro.blackview.freeme_manager "1"
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2023-09-05
