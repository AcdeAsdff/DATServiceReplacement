strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "ImPAD_P101"
resetprop -n ro.product.vendor.model "ImPAD_P101"
resetprop -n ro.product.vendor_dlkm.marketname "ImPAD_P101"
resetprop -n ro.product.product.marketname "ImPAD_P101"
resetprop -n ro.product.system.marketname "ImPAD_P101"
resetprop -n ro.product.odm_dlkm.marketname "ImPAD_P101"
resetprop -n ro.product.system_ext.marketname "ImPAD_P101"
resetprop -n ro.product.odm_dlkm.model "ImPAD_P101"
resetprop -n ro.product.system.model "ImPAD_P101"
resetprop -n ro.product.system_ext.model "ImPAD_P101"
resetprop -n ro.product.vendor_dlkm.model "ImPAD_P101"
resetprop -n bluetooth.device.default_name "ImPAD_P101"
resetprop -n ro.product.bootimage.model "ImPAD_P101"
resetprop -n ro.product.vendor.marketname "ImPAD_P101"
resetprop -n ro.product.marketname "ImPAD_P101"
resetprop -n ro.product.odm.model "ImPAD_P101"
resetprop -n ro.product.model "ImPAD_P101"
resetprop -n ro.product.product.model "ImPAD_P101"
resetprop -n ro.product.odm.marketname "ImPAD_P101"
resetprop -n ro.product.vendor.manufacturer "bnd"
resetprop -n ro.product.product.manufacturer "bnd"
resetprop -n ro.product.bootimage.manufacturer "bnd"
resetprop -n ro.product.manufacturer "bnd"
resetprop -n ro.product.odm.manufacturer "bnd"
resetprop -n ro.product.system.manufacturer "bnd"
resetprop -n ro.product.system_ext.manufacturer "bnd"
resetprop -n ro.product.vendor_dlkm.manufacturer "bnd"
resetprop -n ro.product.vendor.brand "Impression"
resetprop -n ro.product.product.brand "Impression"
resetprop -n ro.product.vendor_dlkm.brand "Impression"
resetprop -n ro.product.system.brand "Impression"
resetprop -n ro.product.bootimage.brand "Impression"
resetprop -n ro.product.system_ext.brand "Impression"
resetprop -n ro.product.odm.brand "Impression"
resetprop -n ro.product.odm_dlkm.brand "Impression"
resetprop -n ro.product.brand "Impression"
resetprop -n ro.vendor_dlkm.build.fingerprint "Impression/ImPAD_P101/ImPAD_P101:8.1.0/O11019/1525700820:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Impression/ImPAD_P101/ImPAD_P101:8.1.0/O11019/1525700820:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Impression/ImPAD_P101/ImPAD_P101:8.1.0/O11019/1525700820:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Impression/ImPAD_P101/ImPAD_P101:8.1.0/O11019/1525700820:user/release-keys"
resetprop -n ro.system.build.fingerprint "Impression/ImPAD_P101/ImPAD_P101:8.1.0/O11019/1525700820:user/release-keys"
resetprop -n ro.build.fingerprint "Impression/ImPAD_P101/ImPAD_P101:8.1.0/O11019/1525700820:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Impression/ImPAD_P101/ImPAD_P101:8.1.0/O11019/1525700820:user/release-keys"
resetprop -n ro.product.build.fingerprint "Impression/ImPAD_P101/ImPAD_P101:8.1.0/O11019/1525700820:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Impression/ImPAD_P101/ImPAD_P101:8.1.0/O11019/1525700820:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=2db04efb24
resetprop -n ro.system.build.version.incremental 1525700820
resetprop -n ro.bootimage.build.version.incremental 1525700820
resetprop -n ro.product.build.version.incremental 1525700820
resetprop -n ro.odm.build.version.incremental 1525700820
resetprop -n ro.vendor_dlkm.build.version.incremental 1525700820
resetprop -n ro.system_ext.build.version.incremental 1525700820
resetprop -n ro.build.version.incremental 1525700820
resetprop -n ro.vendor.build.version.incremental 1525700820
resetprop -n ro.odm.build.id "O11019"
resetprop -n ro.product.build.id "O11019"
resetprop -n ro.bootimage.build.id "O11019"
resetprop -n ro.system_ext.build.id "O11019"
resetprop -n ro.vendor_dlkm.build.id "O11019"
resetprop -n ro.build.id "O11019"
resetprop -n ro.system.build.id "O11019"
resetprop -n ro.vendor.build.id "O11019"
resetprop -n ro.system.build.date "2018年 07月 20日 星期五 13:39:40 CST"
resetprop -n ro.bootimage.build.date "2018年 07月 20日 星期五 13:39:40 CST"
resetprop -n ro.product.build.date "2018年 07月 20日 星期五 13:39:40 CST"
resetprop -n ro.vendor_dlkm.build.date "2018年 07月 20日 星期五 13:39:40 CST"
resetprop -n ro.system_ext.build.date "2018年 07月 20日 星期五 13:39:40 CST"
resetprop -n ro.odm.build.date "2018年 07月 20日 星期五 13:39:40 CST"
resetprop -n ro.build.date "2018年 07月 20日 星期五 13:39:40 CST"
resetprop -n ro.vendor.build.date "2018年 07月 20日 星期五 13:39:40 CST"
resetprop -n ro.product.build.date.utc "1532065180"
resetprop -n ro.system_ext.build.date.utc "1532065180"
resetprop -n ro.system.build.date.utc "1532065180"
resetprop -n ro.vendor.build.date.utc "1532065180"
resetprop -n ro.vendor_dlkm.build.date.utc "1532065180"
resetprop -n ro.build.date.utc "1532065180"
resetprop -n ro.bootimage.build.date.utc "1532065180"
resetprop -n ro.odm.build.date.utc "1532065180"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name ImPAD_P101
resetprop -n ro.product.odm.name ImPAD_P101
resetprop -n ro.product.vendor.name ImPAD_P101
resetprop -n ro.product.system.name ImPAD_P101
resetprop -n ro.product.name ImPAD_P101
resetprop -n ro.product.bootimage.name ImPAD_P101
resetprop -n ro.product.vendor_dlkm.name ImPAD_P101
resetprop -n ro.product.system_ext.name ImPAD_P101
resetprop -n ro.build.flavor full_tb8321p2_bsp-user
randomStr="full_tb8321p2_bsp-user bnd O11019 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=ea26abb91edd
resetprop -n ro.build.host ${randomStr}
randomStr=cfc10115
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=ehjwRL
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=16526f384aaea
randomStr2=ae
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=dc
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1525700820"
resetprop -n ro.build.description "ImPADP101-20180720"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "bnd_hxj"
resetprop -n ro.build.host "szbnd-Z10PE-D16-WS"
resetprop -n ro.build.product.backup "ImPAD_P101"
resetprop -n ro.build.characteristics "tablet"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n debug.hwui.render_dirty_regions "false"
resetprop -n ro.expect.recovery_id "0x25998a656875417d061c4eec50bfbde85caf17c1000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-06-05
