strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "GM 9 Pro"
resetprop -n ro.product.vendor.model "GM 9 Pro"
resetprop -n ro.product.vendor_dlkm.marketname "GM 9 Pro"
resetprop -n ro.product.product.marketname "GM 9 Pro"
resetprop -n ro.product.system.marketname "GM 9 Pro"
resetprop -n ro.product.odm_dlkm.marketname "GM 9 Pro"
resetprop -n ro.product.system_ext.marketname "GM 9 Pro"
resetprop -n ro.product.odm_dlkm.model "GM 9 Pro"
resetprop -n ro.product.system.model "GM 9 Pro"
resetprop -n ro.product.system_ext.model "GM 9 Pro"
resetprop -n ro.product.vendor_dlkm.model "GM 9 Pro"
resetprop -n bluetooth.device.default_name "GM 9 Pro"
resetprop -n ro.product.bootimage.model "GM 9 Pro"
resetprop -n ro.product.vendor.marketname "GM 9 Pro"
resetprop -n ro.product.marketname "GM 9 Pro"
resetprop -n ro.product.odm.model "GM 9 Pro"
resetprop -n ro.product.model "GM 9 Pro"
resetprop -n ro.product.product.model "GM 9 Pro"
resetprop -n ro.product.odm.marketname "GM 9 Pro"
resetprop -n ro.product.vendor.manufacturer "GM"
resetprop -n ro.product.product.manufacturer "GM"
resetprop -n ro.product.bootimage.manufacturer "GM"
resetprop -n ro.product.manufacturer "GM"
resetprop -n ro.product.odm.manufacturer "GM"
resetprop -n ro.product.system.manufacturer "GM"
resetprop -n ro.product.system_ext.manufacturer "GM"
resetprop -n ro.product.vendor_dlkm.manufacturer "GM"
resetprop -n ro.product.vendor.brand "GM"
resetprop -n ro.product.product.brand "GM"
resetprop -n ro.product.vendor_dlkm.brand "GM"
resetprop -n ro.product.system.brand "GM"
resetprop -n ro.product.bootimage.brand "GM"
resetprop -n ro.product.system_ext.brand "GM"
resetprop -n ro.product.odm.brand "GM"
resetprop -n ro.product.odm_dlkm.brand "GM"
resetprop -n ro.product.brand "GM"
resetprop -n ro.vendor_dlkm.build.fingerprint "GM/GM9PRO/GM9PRO_sprout:9/QGM5.190530.015/255:userdebug/release-keys"
resetprop -n ro.bootimage.build.fingerprint "GM/GM9PRO/GM9PRO_sprout:9/QGM5.190530.015/255:userdebug/release-keys"
resetprop -n ro.vendor.build.fingerprint "GM/GM9PRO/GM9PRO_sprout:9/QGM5.190530.015/255:userdebug/release-keys"
resetprop -n ro.odm.build.fingerprint "GM/GM9PRO/GM9PRO_sprout:9/QGM5.190530.015/255:userdebug/release-keys"
resetprop -n ro.system.build.fingerprint "GM/GM9PRO/GM9PRO_sprout:9/QGM5.190530.015/255:userdebug/release-keys"
resetprop -n ro.build.fingerprint "GM/GM9PRO/GM9PRO_sprout:9/QGM5.190530.015/255:userdebug/release-keys"
resetprop -n ro.system_ext.build.fingerprint "GM/GM9PRO/GM9PRO_sprout:9/QGM5.190530.015/255:userdebug/release-keys"
resetprop -n ro.product.build.fingerprint "GM/GM9PRO/GM9PRO_sprout:9/QGM5.190530.015/255:userdebug/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "GM/GM9PRO/GM9PRO_sprout:9/QGM5.190530.015/255:userdebug/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=d9b8fd24d4
resetprop -n ro.system.build.version.incremental 5696442
resetprop -n ro.bootimage.build.version.incremental 5696442
resetprop -n ro.product.build.version.incremental 5696442
resetprop -n ro.odm.build.version.incremental 5696442
resetprop -n ro.vendor_dlkm.build.version.incremental 5696442
resetprop -n ro.system_ext.build.version.incremental 5696442
resetprop -n ro.build.version.incremental 5696442
resetprop -n ro.vendor.build.version.incremental 5696442
resetprop -n ro.odm.build.id "QGM5.190530.015"
resetprop -n ro.product.build.id "QGM5.190530.015"
resetprop -n ro.bootimage.build.id "QGM5.190530.015"
resetprop -n ro.system_ext.build.id "QGM5.190530.015"
resetprop -n ro.vendor_dlkm.build.id "QGM5.190530.015"
resetprop -n ro.build.id "QGM5.190530.015"
resetprop -n ro.system.build.id "QGM5.190530.015"
resetprop -n ro.vendor.build.id "QGM5.190530.015"
resetprop -n ro.system.build.date "Fri Jun 28 20:56:20 UTC 2019"
resetprop -n ro.bootimage.build.date "Fri Jun 28 20:56:20 UTC 2019"
resetprop -n ro.product.build.date "Fri Jun 28 20:56:20 UTC 2019"
resetprop -n ro.vendor_dlkm.build.date "Fri Jun 28 20:56:20 UTC 2019"
resetprop -n ro.system_ext.build.date "Fri Jun 28 20:56:20 UTC 2019"
resetprop -n ro.odm.build.date "Fri Jun 28 20:56:20 UTC 2019"
resetprop -n ro.build.date "Fri Jun 28 20:56:20 UTC 2019"
resetprop -n ro.vendor.build.date "Fri Jun 28 20:56:20 UTC 2019"
resetprop -n ro.product.build.date.utc "1561755380"
resetprop -n ro.system_ext.build.date.utc "1561755380"
resetprop -n ro.system.build.date.utc "1561755380"
resetprop -n ro.vendor.build.date.utc "1561755380"
resetprop -n ro.vendor_dlkm.build.date.utc "1561755380"
resetprop -n ro.build.date.utc "1561755380"
resetprop -n ro.bootimage.build.date.utc "1561755380"
resetprop -n ro.odm.build.date.utc "1561755380"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name GM9PRO
resetprop -n ro.product.odm.name GM9PRO
resetprop -n ro.product.vendor.name GM9PRO
resetprop -n ro.product.system.name GM9PRO
resetprop -n ro.product.name GM9PRO
resetprop -n ro.product.bootimage.name GM9PRO
resetprop -n ro.product.vendor_dlkm.name GM9PRO
resetprop -n ro.product.system_ext.name GM9PRO
resetprop -n ro.build.flavor GM9PRO-user
randomStr="GM9PRO-user GM QGM5.190530.015 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=f2012f3a5e5c
resetprop -n ro.build.host ${randomStr}
randomStr=00acec6a
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=WwBskp
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=324a5f1c54a8b
randomStr2=42
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=a2
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "5696442"
resetprop -n ro.build.description "GM9PRO-user 10 QGM5.190530.015 5642755 release-keys"
resetprop -n ro.build.product.backup "GM9PRO"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "gm-build"
resetprop -n ro.build.host "generalmobile"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-07-05
