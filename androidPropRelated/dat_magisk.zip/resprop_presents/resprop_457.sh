strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "itel S665L"
resetprop -n ro.product.vendor.model "itel S665L"
resetprop -n ro.product.vendor_dlkm.marketname "itel S665L"
resetprop -n ro.product.product.marketname "itel S665L"
resetprop -n ro.product.system.marketname "itel S665L"
resetprop -n ro.product.odm_dlkm.marketname "itel S665L"
resetprop -n ro.product.system_ext.marketname "itel S665L"
resetprop -n ro.product.odm_dlkm.model "itel S665L"
resetprop -n ro.product.system.model "itel S665L"
resetprop -n ro.product.system_ext.model "itel S665L"
resetprop -n ro.product.vendor_dlkm.model "itel S665L"
resetprop -n bluetooth.device.default_name "itel S665L"
resetprop -n ro.product.bootimage.model "itel S665L"
resetprop -n ro.product.vendor.marketname "itel S665L"
resetprop -n ro.product.marketname "itel S665L"
resetprop -n ro.product.odm.model "itel S665L"
resetprop -n ro.product.model "itel S665L"
resetprop -n ro.product.product.model "itel S665L"
resetprop -n ro.product.odm.marketname "itel S665L"
resetprop -n ro.product.vendor.manufacturer "ITEL"
resetprop -n ro.product.product.manufacturer "ITEL"
resetprop -n ro.product.bootimage.manufacturer "ITEL"
resetprop -n ro.product.manufacturer "ITEL"
resetprop -n ro.product.odm.manufacturer "ITEL"
resetprop -n ro.product.system.manufacturer "ITEL"
resetprop -n ro.product.system_ext.manufacturer "ITEL"
resetprop -n ro.product.vendor_dlkm.manufacturer "ITEL"
resetprop -n ro.product.vendor.brand "Itel"
resetprop -n ro.product.product.brand "Itel"
resetprop -n ro.product.vendor_dlkm.brand "Itel"
resetprop -n ro.product.system.brand "Itel"
resetprop -n ro.product.bootimage.brand "Itel"
resetprop -n ro.product.system_ext.brand "Itel"
resetprop -n ro.product.odm.brand "Itel"
resetprop -n ro.product.odm_dlkm.brand "Itel"
resetprop -n ro.product.brand "Itel"
resetprop -n ro.vendor_dlkm.build.fingerprint "Itel/S665L-GL/itel-S665L:12/SP1A.210812.016/GL-20230605V352:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Itel/S665L-GL/itel-S665L:12/SP1A.210812.016/GL-20230605V352:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Itel/S665L-GL/itel-S665L:12/SP1A.210812.016/GL-20230605V352:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Itel/S665L-GL/itel-S665L:12/SP1A.210812.016/GL-20230605V352:user/release-keys"
resetprop -n ro.system.build.fingerprint "Itel/S665L-GL/itel-S665L:12/SP1A.210812.016/GL-20230605V352:user/release-keys"
resetprop -n ro.build.fingerprint "Itel/S665L-GL/itel-S665L:12/SP1A.210812.016/GL-20230605V352:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Itel/S665L-GL/itel-S665L:12/SP1A.210812.016/GL-20230605V352:user/release-keys"
resetprop -n ro.product.build.fingerprint "Itel/S665L-GL/itel-S665L:12/SP1A.210812.016/GL-20230605V352:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Itel/S665L-GL/itel-S665L:12/SP1A.210812.016/GL-20230605V352:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=0449a7ded8
resetprop -n ro.system.build.version.incremental GL-20230605V352
resetprop -n ro.bootimage.build.version.incremental GL-20230605V352
resetprop -n ro.product.build.version.incremental GL-20230605V352
resetprop -n ro.odm.build.version.incremental GL-20230605V352
resetprop -n ro.vendor_dlkm.build.version.incremental GL-20230605V352
resetprop -n ro.system_ext.build.version.incremental GL-20230605V352
resetprop -n ro.build.version.incremental GL-20230605V352
resetprop -n ro.vendor.build.version.incremental GL-20230605V352
resetprop -n ro.odm.build.id "SP1A.210812.016"
resetprop -n ro.product.build.id "SP1A.210812.016"
resetprop -n ro.bootimage.build.id "SP1A.210812.016"
resetprop -n ro.system_ext.build.id "SP1A.210812.016"
resetprop -n ro.vendor_dlkm.build.id "SP1A.210812.016"
resetprop -n ro.build.id "SP1A.210812.016"
resetprop -n ro.system.build.id "SP1A.210812.016"
resetprop -n ro.vendor.build.id "SP1A.210812.016"
resetprop -n ro.system.build.date "Mon Jun  5 22:04:08 CST 2023"
resetprop -n ro.bootimage.build.date "Mon Jun  5 22:04:08 CST 2023"
resetprop -n ro.product.build.date "Mon Jun  5 22:04:08 CST 2023"
resetprop -n ro.vendor_dlkm.build.date "Mon Jun  5 22:04:08 CST 2023"
resetprop -n ro.system_ext.build.date "Mon Jun  5 22:04:08 CST 2023"
resetprop -n ro.odm.build.date "Mon Jun  5 22:04:08 CST 2023"
resetprop -n ro.build.date "Mon Jun  5 22:04:08 CST 2023"
resetprop -n ro.vendor.build.date "Mon Jun  5 22:04:08 CST 2023"
resetprop -n ro.product.build.date.utc "1685973848"
resetprop -n ro.system_ext.build.date.utc "1685973848"
resetprop -n ro.system.build.date.utc "1685973848"
resetprop -n ro.vendor.build.date.utc "1685973848"
resetprop -n ro.vendor_dlkm.build.date.utc "1685973848"
resetprop -n ro.build.date.utc "1685973848"
resetprop -n ro.bootimage.build.date.utc "1685973848"
resetprop -n ro.odm.build.date.utc "1685973848"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name S665L-GL
resetprop -n ro.product.odm.name S665L-GL
resetprop -n ro.product.vendor.name S665L-GL
resetprop -n ro.product.system.name S665L-GL
resetprop -n ro.product.name S665L-GL
resetprop -n ro.product.bootimage.name S665L-GL
resetprop -n ro.product.vendor_dlkm.name S665L-GL
resetprop -n ro.product.system_ext.name S665L-GL
resetprop -n ro.build.flavor S665L-user
randomStr="S665L-user ITEL SP1A.210812.016 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=b64ae7a53d69
resetprop -n ro.build.host ${randomStr}
randomStr=4f0c1531
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=OOeBtX
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=35f14f1ddbda6
randomStr2=57
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=69
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "GL-20230605V352"
resetprop -n ro.build.description "S665L-user 12 SP1A.210812.016 360 release-keys"
resetprop -n ro.build.product.backup "S665L"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "buildsrv-ci"
resetprop -n ro.build.host "build-1-16"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2023-05-05
