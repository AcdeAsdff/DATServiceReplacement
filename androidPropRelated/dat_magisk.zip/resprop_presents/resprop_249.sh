strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Hero SE3 Max"
resetprop -n ro.product.vendor.model "Hero SE3 Max"
resetprop -n ro.product.vendor_dlkm.marketname "Hero SE3 Max"
resetprop -n ro.product.product.marketname "Hero SE3 Max"
resetprop -n ro.product.system.marketname "Hero SE3 Max"
resetprop -n ro.product.odm_dlkm.marketname "Hero SE3 Max"
resetprop -n ro.product.system_ext.marketname "Hero SE3 Max"
resetprop -n ro.product.odm_dlkm.model "Hero SE3 Max"
resetprop -n ro.product.system.model "Hero SE3 Max"
resetprop -n ro.product.system_ext.model "Hero SE3 Max"
resetprop -n ro.product.vendor_dlkm.model "Hero SE3 Max"
resetprop -n bluetooth.device.default_name "Hero SE3 Max"
resetprop -n ro.product.bootimage.model "Hero SE3 Max"
resetprop -n ro.product.vendor.marketname "Hero SE3 Max"
resetprop -n ro.product.marketname "Hero SE3 Max"
resetprop -n ro.product.odm.model "Hero SE3 Max"
resetprop -n ro.product.model "Hero SE3 Max"
resetprop -n ro.product.product.model "Hero SE3 Max"
resetprop -n ro.product.odm.marketname "Hero SE3 Max"
resetprop -n ro.product.vendor.manufacturer "Camfone"
resetprop -n ro.product.product.manufacturer "Camfone"
resetprop -n ro.product.bootimage.manufacturer "Camfone"
resetprop -n ro.product.manufacturer "Camfone"
resetprop -n ro.product.odm.manufacturer "Camfone"
resetprop -n ro.product.system.manufacturer "Camfone"
resetprop -n ro.product.system_ext.manufacturer "Camfone"
resetprop -n ro.product.vendor_dlkm.manufacturer "Camfone"
resetprop -n ro.product.vendor.brand "Camfone"
resetprop -n ro.product.product.brand "Camfone"
resetprop -n ro.product.vendor_dlkm.brand "Camfone"
resetprop -n ro.product.system.brand "Camfone"
resetprop -n ro.product.bootimage.brand "Camfone"
resetprop -n ro.product.system_ext.brand "Camfone"
resetprop -n ro.product.odm.brand "Camfone"
resetprop -n ro.product.odm_dlkm.brand "Camfone"
resetprop -n ro.product.brand "Camfone"
resetprop -n ro.vendor_dlkm.build.fingerprint "Camfone/Hero_SE3_Max/Hero_SE3_Max:8.1.0/O11019/1543458028:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Camfone/Hero_SE3_Max/Hero_SE3_Max:8.1.0/O11019/1543458028:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Camfone/Hero_SE3_Max/Hero_SE3_Max:8.1.0/O11019/1543458028:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Camfone/Hero_SE3_Max/Hero_SE3_Max:8.1.0/O11019/1543458028:user/release-keys"
resetprop -n ro.system.build.fingerprint "Camfone/Hero_SE3_Max/Hero_SE3_Max:8.1.0/O11019/1543458028:user/release-keys"
resetprop -n ro.build.fingerprint "Camfone/Hero_SE3_Max/Hero_SE3_Max:8.1.0/O11019/1543458028:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Camfone/Hero_SE3_Max/Hero_SE3_Max:8.1.0/O11019/1543458028:user/release-keys"
resetprop -n ro.product.build.fingerprint "Camfone/Hero_SE3_Max/Hero_SE3_Max:8.1.0/O11019/1543458028:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Camfone/Hero_SE3_Max/Hero_SE3_Max:8.1.0/O11019/1543458028:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=ca9b6d9a93
resetprop -n ro.system.build.version.incremental 1543458028
resetprop -n ro.bootimage.build.version.incremental 1543458028
resetprop -n ro.product.build.version.incremental 1543458028
resetprop -n ro.odm.build.version.incremental 1543458028
resetprop -n ro.vendor_dlkm.build.version.incremental 1543458028
resetprop -n ro.system_ext.build.version.incremental 1543458028
resetprop -n ro.build.version.incremental 1543458028
resetprop -n ro.vendor.build.version.incremental 1543458028
resetprop -n ro.odm.build.id "O11019"
resetprop -n ro.product.build.id "O11019"
resetprop -n ro.bootimage.build.id "O11019"
resetprop -n ro.system_ext.build.id "O11019"
resetprop -n ro.vendor_dlkm.build.id "O11019"
resetprop -n ro.build.id "O11019"
resetprop -n ro.system.build.id "O11019"
resetprop -n ro.vendor.build.id "O11019"
resetprop -n ro.system.build.date "Thu Nov 29 10:20:26 CST 2018"
resetprop -n ro.bootimage.build.date "Thu Nov 29 10:20:26 CST 2018"
resetprop -n ro.product.build.date "Thu Nov 29 10:20:26 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Thu Nov 29 10:20:26 CST 2018"
resetprop -n ro.system_ext.build.date "Thu Nov 29 10:20:26 CST 2018"
resetprop -n ro.odm.build.date "Thu Nov 29 10:20:26 CST 2018"
resetprop -n ro.build.date "Thu Nov 29 10:20:26 CST 2018"
resetprop -n ro.vendor.build.date "Thu Nov 29 10:20:26 CST 2018"
resetprop -n ro.product.build.date.utc "1543458026"
resetprop -n ro.system_ext.build.date.utc "1543458026"
resetprop -n ro.system.build.date.utc "1543458026"
resetprop -n ro.vendor.build.date.utc "1543458026"
resetprop -n ro.vendor_dlkm.build.date.utc "1543458026"
resetprop -n ro.build.date.utc "1543458026"
resetprop -n ro.bootimage.build.date.utc "1543458026"
resetprop -n ro.odm.build.date.utc "1543458026"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name Hero_SE3_Max
resetprop -n ro.product.odm.name Hero_SE3_Max
resetprop -n ro.product.vendor.name Hero_SE3_Max
resetprop -n ro.product.system.name Hero_SE3_Max
resetprop -n ro.product.name Hero_SE3_Max
resetprop -n ro.product.bootimage.name Hero_SE3_Max
resetprop -n ro.product.vendor_dlkm.name Hero_SE3_Max
resetprop -n ro.product.system_ext.name Hero_SE3_Max
resetprop -n ro.build.flavor full_k80hd_bsp_fwv_512m-user
randomStr="full_k80hd_bsp_fwv_512m-user Camfone O11019 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=333a2f7b64b5
resetprop -n ro.build.host ${randomStr}
randomStr=7ae391b6
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=BagDrO
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=6674ae4ab2b6a
randomStr2=ef
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=12
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1543458028"
resetprop -n ro.build.description "full_k80hd_bsp_fwv_512m-user 8.1.0 O11019 1543458028 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "yanglvxiong"
resetprop -n ro.build.host "prize-bs11"
resetprop -n ro.build.product.backup "Hero_SE3_Max"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n debug.hwui.render_dirty_regions "false"
resetprop -n ro.fota.platform "MTK6739_8.1"
resetprop -n ro.fota.oem "boruizhiheng6739_8.1"
resetprop -n ro.fota.type "phone"
resetprop -n ro.fota.app "5"
resetprop -n ro.fota.device "Hero SE3 Max"
resetprop -n ro.fota.version "T2TEM81E.TUG.Camfone.HB.FW.PM.1129.V2.02_20181129-1021"
resetprop -n ro.expect.recovery_id "0x7ad80fb303926d468fbdaa410ae5a4a4e1a3c259000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-10-05
