strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Le Hop"
resetprop -n ro.product.vendor.model "Le Hop"
resetprop -n ro.product.vendor_dlkm.marketname "Le Hop"
resetprop -n ro.product.product.marketname "Le Hop"
resetprop -n ro.product.system.marketname "Le Hop"
resetprop -n ro.product.odm_dlkm.marketname "Le Hop"
resetprop -n ro.product.system_ext.marketname "Le Hop"
resetprop -n ro.product.odm_dlkm.model "Le Hop"
resetprop -n ro.product.system.model "Le Hop"
resetprop -n ro.product.system_ext.model "Le Hop"
resetprop -n ro.product.vendor_dlkm.model "Le Hop"
resetprop -n bluetooth.device.default_name "Le Hop"
resetprop -n ro.product.bootimage.model "Le Hop"
resetprop -n ro.product.vendor.marketname "Le Hop"
resetprop -n ro.product.marketname "Le Hop"
resetprop -n ro.product.odm.model "Le Hop"
resetprop -n ro.product.model "Le Hop"
resetprop -n ro.product.product.model "Le Hop"
resetprop -n ro.product.odm.marketname "Le Hop"
resetprop -n ro.product.vendor.manufacturer "Logicom"
resetprop -n ro.product.product.manufacturer "Logicom"
resetprop -n ro.product.bootimage.manufacturer "Logicom"
resetprop -n ro.product.manufacturer "Logicom"
resetprop -n ro.product.odm.manufacturer "Logicom"
resetprop -n ro.product.system.manufacturer "Logicom"
resetprop -n ro.product.system_ext.manufacturer "Logicom"
resetprop -n ro.product.vendor_dlkm.manufacturer "Logicom"
resetprop -n ro.product.vendor.brand "Logicom"
resetprop -n ro.product.product.brand "Logicom"
resetprop -n ro.product.vendor_dlkm.brand "Logicom"
resetprop -n ro.product.system.brand "Logicom"
resetprop -n ro.product.bootimage.brand "Logicom"
resetprop -n ro.product.system_ext.brand "Logicom"
resetprop -n ro.product.odm.brand "Logicom"
resetprop -n ro.product.odm_dlkm.brand "Logicom"
resetprop -n ro.product.brand "Logicom"
resetprop -n ro.vendor_dlkm.build.fingerprint "Logicom/LeHop/Logicom_LeHop:8.1.0/171019/20180719.3:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Logicom/LeHop/Logicom_LeHop:8.1.0/171019/20180719.3:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Logicom/LeHop/Logicom_LeHop:8.1.0/171019/20180719.3:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Logicom/LeHop/Logicom_LeHop:8.1.0/171019/20180719.3:user/release-keys"
resetprop -n ro.system.build.fingerprint "Logicom/LeHop/Logicom_LeHop:8.1.0/171019/20180719.3:user/release-keys"
resetprop -n ro.build.fingerprint "Logicom/LeHop/Logicom_LeHop:8.1.0/171019/20180719.3:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Logicom/LeHop/Logicom_LeHop:8.1.0/171019/20180719.3:user/release-keys"
resetprop -n ro.product.build.fingerprint "Logicom/LeHop/Logicom_LeHop:8.1.0/171019/20180719.3:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Logicom/LeHop/Logicom_LeHop:8.1.0/171019/20180719.3:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=1117eda228
resetprop -n ro.system.build.version.incremental 29417
resetprop -n ro.bootimage.build.version.incremental 29417
resetprop -n ro.product.build.version.incremental 29417
resetprop -n ro.odm.build.version.incremental 29417
resetprop -n ro.vendor_dlkm.build.version.incremental 29417
resetprop -n ro.system_ext.build.version.incremental 29417
resetprop -n ro.build.version.incremental 29417
resetprop -n ro.vendor.build.version.incremental 29417
resetprop -n ro.odm.build.id "OPM2.171019.012"
resetprop -n ro.product.build.id "OPM2.171019.012"
resetprop -n ro.bootimage.build.id "OPM2.171019.012"
resetprop -n ro.system_ext.build.id "OPM2.171019.012"
resetprop -n ro.vendor_dlkm.build.id "OPM2.171019.012"
resetprop -n ro.build.id "OPM2.171019.012"
resetprop -n ro.system.build.id "OPM2.171019.012"
resetprop -n ro.vendor.build.id "OPM2.171019.012"
resetprop -n ro.system.build.date "Thu Jul 19 17:35:43 CST 2018"
resetprop -n ro.bootimage.build.date "Thu Jul 19 17:35:43 CST 2018"
resetprop -n ro.product.build.date "Thu Jul 19 17:35:43 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Thu Jul 19 17:35:43 CST 2018"
resetprop -n ro.system_ext.build.date "Thu Jul 19 17:35:43 CST 2018"
resetprop -n ro.odm.build.date "Thu Jul 19 17:35:43 CST 2018"
resetprop -n ro.build.date "Thu Jul 19 17:35:43 CST 2018"
resetprop -n ro.vendor.build.date "Thu Jul 19 17:35:43 CST 2018"
resetprop -n ro.product.build.date.utc "1531992943"
resetprop -n ro.system_ext.build.date.utc "1531992943"
resetprop -n ro.system.build.date.utc "1531992943"
resetprop -n ro.vendor.build.date.utc "1531992943"
resetprop -n ro.vendor_dlkm.build.date.utc "1531992943"
resetprop -n ro.build.date.utc "1531992943"
resetprop -n ro.bootimage.build.date.utc "1531992943"
resetprop -n ro.odm.build.date.utc "1531992943"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name LeHop
resetprop -n ro.product.odm.name LeHop
resetprop -n ro.product.vendor.name LeHop
resetprop -n ro.product.system.name LeHop
resetprop -n ro.product.name LeHop
resetprop -n ro.product.bootimage.name LeHop
resetprop -n ro.product.vendor_dlkm.name LeHop
resetprop -n ro.product.system_ext.name LeHop
resetprop -n ro.build.flavor oversea
randomStr="oversea Logicom OPM2.171019.012 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=c283a2df8277
resetprop -n ro.build.host ${randomStr}
randomStr=66f5ded8
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=qJNJSP
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=3b47f1f80f822
randomStr2=dd
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=c4
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "29417"
resetprop -n ro.build.description "LeHop-user 8.1.0 OPM2.171019.012 29417 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "service03"
resetprop -n ro.build.host "hyst03"
resetprop -n ro.build.product.backup "Logicom_LeHop"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.fota.platform "Sprd9832_8.1"
resetprop -n ro.fota.type "phone"
resetprop -n ro.fota.app "5"
resetprop -n ro.fota.oem "huaxr9832_8.1"
resetprop -n ro.fota.device "Le Hop"
resetprop -n ro.fota.version "Logicom_Le Hop_HW03_SW03_20180719_20180719-1738"
resetprop -n ro.expect.recovery_id "0x65a7069cd315459cd27566365f280464d305bb39000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-07-05
