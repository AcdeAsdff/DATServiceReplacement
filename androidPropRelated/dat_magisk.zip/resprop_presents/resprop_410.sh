strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "HLTE202N"
resetprop -n ro.product.vendor.model "HLTE202N"
resetprop -n ro.product.vendor_dlkm.marketname "HLTE202N"
resetprop -n ro.product.product.marketname "HLTE202N"
resetprop -n ro.product.system.marketname "HLTE202N"
resetprop -n ro.product.odm_dlkm.marketname "HLTE202N"
resetprop -n ro.product.system_ext.marketname "HLTE202N"
resetprop -n ro.product.odm_dlkm.model "HLTE202N"
resetprop -n ro.product.system.model "HLTE202N"
resetprop -n ro.product.system_ext.model "HLTE202N"
resetprop -n ro.product.vendor_dlkm.model "HLTE202N"
resetprop -n bluetooth.device.default_name "HLTE202N"
resetprop -n ro.product.bootimage.model "HLTE202N"
resetprop -n ro.product.vendor.marketname "HLTE202N"
resetprop -n ro.product.marketname "HLTE202N"
resetprop -n ro.product.odm.model "HLTE202N"
resetprop -n ro.product.model "HLTE202N"
resetprop -n ro.product.product.model "HLTE202N"
resetprop -n ro.product.odm.marketname "HLTE202N"
resetprop -n ro.product.vendor.manufacturer "Hisense"
resetprop -n ro.product.product.manufacturer "Hisense"
resetprop -n ro.product.bootimage.manufacturer "Hisense"
resetprop -n ro.product.manufacturer "Hisense"
resetprop -n ro.product.odm.manufacturer "Hisense"
resetprop -n ro.product.system.manufacturer "Hisense"
resetprop -n ro.product.system_ext.manufacturer "Hisense"
resetprop -n ro.product.vendor_dlkm.manufacturer "Hisense"
resetprop -n ro.product.vendor.brand "Hisense"
resetprop -n ro.product.product.brand "Hisense"
resetprop -n ro.product.vendor_dlkm.brand "Hisense"
resetprop -n ro.product.system.brand "Hisense"
resetprop -n ro.product.bootimage.brand "Hisense"
resetprop -n ro.product.system_ext.brand "Hisense"
resetprop -n ro.product.odm.brand "Hisense"
resetprop -n ro.product.odm_dlkm.brand "Hisense"
resetprop -n ro.product.brand "Hisense"
resetprop -n ro.vendor_dlkm.build.fingerprint "Hisense/HLTE202N/HLTE202N:9/PKQ1.190504.001/L1657.6.01.02:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Hisense/HLTE202N/HLTE202N:9/PKQ1.190504.001/L1657.6.01.02:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Hisense/HLTE202N/HLTE202N:9/PKQ1.190504.001/L1657.6.01.02:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Hisense/HLTE202N/HLTE202N:9/PKQ1.190504.001/L1657.6.01.02:user/release-keys"
resetprop -n ro.system.build.fingerprint "Hisense/HLTE202N/HLTE202N:9/PKQ1.190504.001/L1657.6.01.02:user/release-keys"
resetprop -n ro.build.fingerprint "Hisense/HLTE202N/HLTE202N:9/PKQ1.190504.001/L1657.6.01.02:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Hisense/HLTE202N/HLTE202N:9/PKQ1.190504.001/L1657.6.01.02:user/release-keys"
resetprop -n ro.product.build.fingerprint "Hisense/HLTE202N/HLTE202N:9/PKQ1.190504.001/L1657.6.01.02:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Hisense/HLTE202N/HLTE202N:9/PKQ1.190504.001/L1657.6.01.02:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=0fa6b41965
resetprop -n ro.system.build.version.incremental L1657.6.01.02
resetprop -n ro.bootimage.build.version.incremental L1657.6.01.02
resetprop -n ro.product.build.version.incremental L1657.6.01.02
resetprop -n ro.odm.build.version.incremental L1657.6.01.02
resetprop -n ro.vendor_dlkm.build.version.incremental L1657.6.01.02
resetprop -n ro.system_ext.build.version.incremental L1657.6.01.02
resetprop -n ro.build.version.incremental L1657.6.01.02
resetprop -n ro.vendor.build.version.incremental L1657.6.01.02
resetprop -n ro.odm.build.id "PKQ1.190504.001"
resetprop -n ro.product.build.id "PKQ1.190504.001"
resetprop -n ro.bootimage.build.id "PKQ1.190504.001"
resetprop -n ro.system_ext.build.id "PKQ1.190504.001"
resetprop -n ro.vendor_dlkm.build.id "PKQ1.190504.001"
resetprop -n ro.build.id "PKQ1.190504.001"
resetprop -n ro.system.build.id "PKQ1.190504.001"
resetprop -n ro.vendor.build.id "PKQ1.190504.001"
resetprop -n ro.system.build.date "Sat May 30 03:45:05 CST 2020"
resetprop -n ro.bootimage.build.date "Sat May 30 03:45:05 CST 2020"
resetprop -n ro.product.build.date "Sat May 30 03:45:05 CST 2020"
resetprop -n ro.vendor_dlkm.build.date "Sat May 30 03:45:05 CST 2020"
resetprop -n ro.system_ext.build.date "Sat May 30 03:45:05 CST 2020"
resetprop -n ro.odm.build.date "Sat May 30 03:45:05 CST 2020"
resetprop -n ro.build.date "Sat May 30 03:45:05 CST 2020"
resetprop -n ro.vendor.build.date "Sat May 30 03:45:05 CST 2020"
resetprop -n ro.product.build.date.utc "1590781505"
resetprop -n ro.system_ext.build.date.utc "1590781505"
resetprop -n ro.system.build.date.utc "1590781505"
resetprop -n ro.vendor.build.date.utc "1590781505"
resetprop -n ro.vendor_dlkm.build.date.utc "1590781505"
resetprop -n ro.build.date.utc "1590781505"
resetprop -n ro.bootimage.build.date.utc "1590781505"
resetprop -n ro.odm.build.date.utc "1590781505"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name HLTE202N
resetprop -n ro.product.odm.name HLTE202N
resetprop -n ro.product.vendor.name HLTE202N
resetprop -n ro.product.system.name HLTE202N
resetprop -n ro.product.name HLTE202N
resetprop -n ro.product.bootimage.name HLTE202N
resetprop -n ro.product.vendor_dlkm.name HLTE202N
resetprop -n ro.product.system_ext.name HLTE202N
resetprop -n ro.build.flavor HLTE202N-user
randomStr="HLTE202N-user Hisense PKQ1.190504.001 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=b79c2d3a4fc0
resetprop -n ro.build.host ${randomStr}
randomStr=ef0b6310
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=FkDCuX
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=0a235d7394788
randomStr2=60
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=82
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "L1657.6.01.02"
resetprop -n ro.build.description "HLTE202N-user 9 PKQ1.190504.001 L1657.6.01.02 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "root"
resetprop -n ro.build.host "hmct-slave"
resetprop -n ro.build.product.backup "HLTE202N"
resetprop -n ro.build.characteristics "nosdcard"
resetprop -n media.msm8956hw "0"
resetprop -n media.aac_51_output_enabled "true"
resetprop -n media.settings.xml "/vendor/etc/media_profiles_vendor.xml"
resetprop -n ro.hwui.texture_cache_size "72"
resetprop -n ro.hwui.layer_cache_size "48"
resetprop -n ro.hwui.r_buffer_cache_size "8"
resetprop -n ro.hwui.path_cache_size "32"
resetprop -n ro.hwui.gradient_cache_size "1"
resetprop -n ro.hwui.drop_shadow_cache_size "6"
resetprop -n ro.hwui.texture_cache_flushrate "0.4"
resetprop -n ro.hwui.text_small_cache_width "1024"
resetprop -n ro.hwui.text_small_cache_height "1024"
resetprop -n ro.hwui.text_large_cache_width "2048"
resetprop -n ro.hwui.text_large_cache_height "2048"
resetprop -n ro.expect.recovery_id "0x52c883cce0c90df40f1ee80ca1d632776191f8d2000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-11-05
