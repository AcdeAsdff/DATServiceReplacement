strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "M10"
resetprop -n ro.product.vendor.model "M10"
resetprop -n ro.product.vendor_dlkm.marketname "M10"
resetprop -n ro.product.product.marketname "M10"
resetprop -n ro.product.system.marketname "M10"
resetprop -n ro.product.odm_dlkm.marketname "M10"
resetprop -n ro.product.system_ext.marketname "M10"
resetprop -n ro.product.odm_dlkm.model "M10"
resetprop -n ro.product.system.model "M10"
resetprop -n ro.product.system_ext.model "M10"
resetprop -n ro.product.vendor_dlkm.model "M10"
resetprop -n bluetooth.device.default_name "M10"
resetprop -n ro.product.bootimage.model "M10"
resetprop -n ro.product.vendor.marketname "M10"
resetprop -n ro.product.marketname "M10"
resetprop -n ro.product.odm.model "M10"
resetprop -n ro.product.model "M10"
resetprop -n ro.product.product.model "M10"
resetprop -n ro.product.odm.marketname "M10"
resetprop -n ro.product.vendor.manufacturer "LEAGOO"
resetprop -n ro.product.product.manufacturer "LEAGOO"
resetprop -n ro.product.bootimage.manufacturer "LEAGOO"
resetprop -n ro.product.manufacturer "LEAGOO"
resetprop -n ro.product.odm.manufacturer "LEAGOO"
resetprop -n ro.product.system.manufacturer "LEAGOO"
resetprop -n ro.product.system_ext.manufacturer "LEAGOO"
resetprop -n ro.product.vendor_dlkm.manufacturer "LEAGOO"
resetprop -n ro.product.vendor.brand "LEAGOO"
resetprop -n ro.product.product.brand "LEAGOO"
resetprop -n ro.product.vendor_dlkm.brand "LEAGOO"
resetprop -n ro.product.system.brand "LEAGOO"
resetprop -n ro.product.bootimage.brand "LEAGOO"
resetprop -n ro.product.system_ext.brand "LEAGOO"
resetprop -n ro.product.odm.brand "LEAGOO"
resetprop -n ro.product.odm_dlkm.brand "LEAGOO"
resetprop -n ro.product.brand "LEAGOO"
resetprop -n ro.vendor_dlkm.build.fingerprint "LEAGOO/M10/M10:8.1.0/O11019/1545731738:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "LEAGOO/M10/M10:8.1.0/O11019/1545731738:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "LEAGOO/M10/M10:8.1.0/O11019/1545731738:user/release-keys"
resetprop -n ro.odm.build.fingerprint "LEAGOO/M10/M10:8.1.0/O11019/1545731738:user/release-keys"
resetprop -n ro.system.build.fingerprint "LEAGOO/M10/M10:8.1.0/O11019/1545731738:user/release-keys"
resetprop -n ro.build.fingerprint "LEAGOO/M10/M10:8.1.0/O11019/1545731738:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "LEAGOO/M10/M10:8.1.0/O11019/1545731738:user/release-keys"
resetprop -n ro.product.build.fingerprint "LEAGOO/M10/M10:8.1.0/O11019/1545731738:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "LEAGOO/M10/M10:8.1.0/O11019/1545731738:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=4afd8ffe8c
resetprop -n ro.system.build.version.incremental 1545731738
resetprop -n ro.bootimage.build.version.incremental 1545731738
resetprop -n ro.product.build.version.incremental 1545731738
resetprop -n ro.odm.build.version.incremental 1545731738
resetprop -n ro.vendor_dlkm.build.version.incremental 1545731738
resetprop -n ro.system_ext.build.version.incremental 1545731738
resetprop -n ro.build.version.incremental 1545731738
resetprop -n ro.vendor.build.version.incremental 1545731738
resetprop -n ro.odm.build.id "O11019"
resetprop -n ro.product.build.id "O11019"
resetprop -n ro.bootimage.build.id "O11019"
resetprop -n ro.system_ext.build.id "O11019"
resetprop -n ro.vendor_dlkm.build.id "O11019"
resetprop -n ro.build.id "O11019"
resetprop -n ro.system.build.id "O11019"
resetprop -n ro.vendor.build.id "O11019"
resetprop -n ro.system.build.date "2019年 02月 19日 星期二 09:14:57 CST"
resetprop -n ro.bootimage.build.date "2019年 02月 19日 星期二 09:14:57 CST"
resetprop -n ro.product.build.date "2019年 02月 19日 星期二 09:14:57 CST"
resetprop -n ro.vendor_dlkm.build.date "2019年 02月 19日 星期二 09:14:57 CST"
resetprop -n ro.system_ext.build.date "2019年 02月 19日 星期二 09:14:57 CST"
resetprop -n ro.odm.build.date "2019年 02月 19日 星期二 09:14:57 CST"
resetprop -n ro.build.date "2019年 02月 19日 星期二 09:14:57 CST"
resetprop -n ro.vendor.build.date "2019年 02月 19日 星期二 09:14:57 CST"
resetprop -n ro.product.build.date.utc "1550538897"
resetprop -n ro.system_ext.build.date.utc "1550538897"
resetprop -n ro.system.build.date.utc "1550538897"
resetprop -n ro.vendor.build.date.utc "1550538897"
resetprop -n ro.vendor_dlkm.build.date.utc "1550538897"
resetprop -n ro.build.date.utc "1550538897"
resetprop -n ro.bootimage.build.date.utc "1550538897"
resetprop -n ro.odm.build.date.utc "1550538897"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name M10
resetprop -n ro.product.odm.name M10
resetprop -n ro.product.vendor.name M10
resetprop -n ro.product.system.name M10
resetprop -n ro.product.name M10
resetprop -n ro.product.bootimage.name M10
resetprop -n ro.product.vendor_dlkm.name M10
resetprop -n ro.product.system_ext.name M10
resetprop -n ro.build.flavor full_bird6739tv1_bsp_1g-user
randomStr="full_bird6739tv1_bsp_1g-user LEAGOO O11019 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=2c1f85406429
resetprop -n ro.build.host ${randomStr}
randomStr=869c657c
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=rxScOc
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=2fd0da8fff2f7
randomStr2=a4
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=56
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1545731738"
resetprop -n ro.build.description "full_bird6739tv1_bsp_1g-user 8.1.0 O11019 1545731738 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "root"
resetprop -n ro.build.host "szby001"
resetprop -n ro.build.product.backup "M10"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.fota.platform "MTK6739_8.1"
resetprop -n ro.fota.type "phone"
resetprop -n ro.fota.app "5"
resetprop -n ro.fota.oem "bird_sz6739_8.1"
resetprop -n ro.fota.device "M10"
resetprop -n ro.fota.version "LEAGOO_M10_OS3.0_E_2019.1.1_20190219-0918"
resetprop -n ro.expect.recovery_id "0xf0c8ee3d44b064897e8eef09db4c7b7905f72ed5000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-11-05
