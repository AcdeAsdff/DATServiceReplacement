strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "SM-A546E"
resetprop -n ro.product.vendor.model "SM-A546E"
resetprop -n ro.product.vendor_dlkm.marketname "SM-A546E"
resetprop -n ro.product.product.marketname "SM-A546E"
resetprop -n ro.product.system.marketname "SM-A546E"
resetprop -n ro.product.odm_dlkm.marketname "SM-A546E"
resetprop -n ro.product.system_ext.marketname "SM-A546E"
resetprop -n ro.product.odm_dlkm.model "SM-A546E"
resetprop -n ro.product.system.model "SM-A546E"
resetprop -n ro.product.system_ext.model "SM-A546E"
resetprop -n ro.product.vendor_dlkm.model "SM-A546E"
resetprop -n bluetooth.device.default_name "SM-A546E"
resetprop -n ro.product.bootimage.model "SM-A546E"
resetprop -n ro.product.vendor.marketname "SM-A546E"
resetprop -n ro.product.marketname "SM-A546E"
resetprop -n ro.product.odm.model "SM-A546E"
resetprop -n ro.product.model "SM-A546E"
resetprop -n ro.product.product.model "SM-A546E"
resetprop -n ro.product.odm.marketname "SM-A546E"
resetprop -n ro.product.vendor.manufacturer "samsung"
resetprop -n ro.product.product.manufacturer "samsung"
resetprop -n ro.product.bootimage.manufacturer "samsung"
resetprop -n ro.product.manufacturer "samsung"
resetprop -n ro.product.odm.manufacturer "samsung"
resetprop -n ro.product.system.manufacturer "samsung"
resetprop -n ro.product.system_ext.manufacturer "samsung"
resetprop -n ro.product.vendor_dlkm.manufacturer "samsung"
resetprop -n ro.product.vendor.brand "samsung"
resetprop -n ro.product.product.brand "samsung"
resetprop -n ro.product.vendor_dlkm.brand "samsung"
resetprop -n ro.product.system.brand "samsung"
resetprop -n ro.product.bootimage.brand "samsung"
resetprop -n ro.product.system_ext.brand "samsung"
resetprop -n ro.product.odm.brand "samsung"
resetprop -n ro.product.odm_dlkm.brand "samsung"
resetprop -n ro.product.brand "samsung"
resetprop -n ro.vendor_dlkm.build.fingerprint "samsung/a54xnsxx/essi:13/TP1A.220624.014/A546EXXS2AWC6:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "samsung/a54xnsxx/essi:13/TP1A.220624.014/A546EXXS2AWC6:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "samsung/a54xnsxx/essi:13/TP1A.220624.014/A546EXXS2AWC6:user/release-keys"
resetprop -n ro.odm.build.fingerprint "samsung/a54xnsxx/essi:13/TP1A.220624.014/A546EXXS2AWC6:user/release-keys"
resetprop -n ro.system.build.fingerprint "samsung/a54xnsxx/essi:13/TP1A.220624.014/A546EXXS2AWC6:user/release-keys"
resetprop -n ro.build.fingerprint "samsung/a54xnsxx/essi:13/TP1A.220624.014/A546EXXS2AWC6:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "samsung/a54xnsxx/essi:13/TP1A.220624.014/A546EXXS2AWC6:user/release-keys"
resetprop -n ro.product.build.fingerprint "samsung/a54xnsxx/essi:13/TP1A.220624.014/A546EXXS2AWC6:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "samsung/a54xnsxx/essi:13/TP1A.220624.014/A546EXXS2AWC6:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=3ec3835320
resetprop -n ro.system.build.version.incremental A546EXXS2AWC6
resetprop -n ro.bootimage.build.version.incremental A546EXXS2AWC6
resetprop -n ro.product.build.version.incremental A546EXXS2AWC6
resetprop -n ro.odm.build.version.incremental A546EXXS2AWC6
resetprop -n ro.vendor_dlkm.build.version.incremental A546EXXS2AWC6
resetprop -n ro.system_ext.build.version.incremental A546EXXS2AWC6
resetprop -n ro.build.version.incremental A546EXXS2AWC6
resetprop -n ro.vendor.build.version.incremental A546EXXS2AWC6
resetprop -n ro.odm.build.id "TP1A.220624.014"
resetprop -n ro.product.build.id "TP1A.220624.014"
resetprop -n ro.bootimage.build.id "TP1A.220624.014"
resetprop -n ro.system_ext.build.id "TP1A.220624.014"
resetprop -n ro.vendor_dlkm.build.id "TP1A.220624.014"
resetprop -n ro.build.id "TP1A.220624.014"
resetprop -n ro.system.build.id "TP1A.220624.014"
resetprop -n ro.vendor.build.id "TP1A.220624.014"
resetprop -n ro.system.build.date "Thu Mar 23 15:35:20 KST 2023"
resetprop -n ro.bootimage.build.date "Thu Mar 23 15:35:20 KST 2023"
resetprop -n ro.product.build.date "Thu Mar 23 15:35:20 KST 2023"
resetprop -n ro.vendor_dlkm.build.date "Thu Mar 23 15:35:20 KST 2023"
resetprop -n ro.system_ext.build.date "Thu Mar 23 15:35:20 KST 2023"
resetprop -n ro.odm.build.date "Thu Mar 23 15:35:20 KST 2023"
resetprop -n ro.build.date "Thu Mar 23 15:35:20 KST 2023"
resetprop -n ro.vendor.build.date "Thu Mar 23 15:35:20 KST 2023"
resetprop -n ro.product.build.date.utc "1679553320"
resetprop -n ro.system_ext.build.date.utc "1679553320"
resetprop -n ro.system.build.date.utc "1679553320"
resetprop -n ro.vendor.build.date.utc "1679553320"
resetprop -n ro.vendor_dlkm.build.date.utc "1679553320"
resetprop -n ro.build.date.utc "1679553320"
resetprop -n ro.bootimage.build.date.utc "1679553320"
resetprop -n ro.odm.build.date.utc "1679553320"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name a54xnsxx
resetprop -n ro.product.odm.name a54xnsxx
resetprop -n ro.product.vendor.name a54xnsxx
resetprop -n ro.product.system.name a54xnsxx
resetprop -n ro.product.name a54xnsxx
resetprop -n ro.product.bootimage.name a54xnsxx
resetprop -n ro.product.vendor_dlkm.name a54xnsxx
resetprop -n ro.product.system_ext.name a54xnsxx
resetprop -n ro.build.flavor a54xnsxx-user
randomStr="a54xnsxx-user samsung TP1A.220624.014 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=1fa01f92dff5
resetprop -n ro.build.host ${randomStr}
randomStr=49d42c6f
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=vFoOGb
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=eda99619535e4
randomStr2=51
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=05
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "A546EXXS2AWC6"
resetprop -n ro.build.description "a54xnsxx-user 13 TP1A.220624.014 A546EXXS2AWC6 release-keys"
resetprop -n ro.build.product.backup "essi"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "dpi"
resetprop -n ro.build.host "21DKG924"
resetprop -n ro.build.characteristics "phone"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2023-04-01
