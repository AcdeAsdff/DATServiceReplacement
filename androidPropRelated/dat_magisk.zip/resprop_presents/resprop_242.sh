strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Aquaris X2"
resetprop -n ro.product.vendor.model "Aquaris X2"
resetprop -n ro.product.vendor_dlkm.marketname "Aquaris X2"
resetprop -n ro.product.product.marketname "Aquaris X2"
resetprop -n ro.product.system.marketname "Aquaris X2"
resetprop -n ro.product.odm_dlkm.marketname "Aquaris X2"
resetprop -n ro.product.system_ext.marketname "Aquaris X2"
resetprop -n ro.product.odm_dlkm.model "Aquaris X2"
resetprop -n ro.product.system.model "Aquaris X2"
resetprop -n ro.product.system_ext.model "Aquaris X2"
resetprop -n ro.product.vendor_dlkm.model "Aquaris X2"
resetprop -n bluetooth.device.default_name "Aquaris X2"
resetprop -n ro.product.bootimage.model "Aquaris X2"
resetprop -n ro.product.vendor.marketname "Aquaris X2"
resetprop -n ro.product.marketname "Aquaris X2"
resetprop -n ro.product.odm.model "Aquaris X2"
resetprop -n ro.product.model "Aquaris X2"
resetprop -n ro.product.product.model "Aquaris X2"
resetprop -n ro.product.odm.marketname "Aquaris X2"
resetprop -n ro.product.vendor.manufacturer "bq"
resetprop -n ro.product.product.manufacturer "bq"
resetprop -n ro.product.bootimage.manufacturer "bq"
resetprop -n ro.product.manufacturer "bq"
resetprop -n ro.product.odm.manufacturer "bq"
resetprop -n ro.product.system.manufacturer "bq"
resetprop -n ro.product.system_ext.manufacturer "bq"
resetprop -n ro.product.vendor_dlkm.manufacturer "bq"
resetprop -n ro.product.vendor.brand "bq"
resetprop -n ro.product.product.brand "bq"
resetprop -n ro.product.vendor_dlkm.brand "bq"
resetprop -n ro.product.system.brand "bq"
resetprop -n ro.product.bootimage.brand "bq"
resetprop -n ro.product.system_ext.brand "bq"
resetprop -n ro.product.odm.brand "bq"
resetprop -n ro.product.odm_dlkm.brand "bq"
resetprop -n ro.product.brand "bq"
resetprop -n ro.vendor_dlkm.build.fingerprint "bq/zangya_bq/zangya_sprout:10/QKQ1.200216.002/617:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "bq/zangya_bq/zangya_sprout:10/QKQ1.200216.002/617:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "bq/zangya_bq/zangya_sprout:10/QKQ1.200216.002/617:user/release-keys"
resetprop -n ro.odm.build.fingerprint "bq/zangya_bq/zangya_sprout:10/QKQ1.200216.002/617:user/release-keys"
resetprop -n ro.system.build.fingerprint "bq/zangya_bq/zangya_sprout:10/QKQ1.200216.002/617:user/release-keys"
resetprop -n ro.build.fingerprint "bq/zangya_bq/zangya_sprout:10/QKQ1.200216.002/617:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "bq/zangya_bq/zangya_sprout:10/QKQ1.200216.002/617:user/release-keys"
resetprop -n ro.product.build.fingerprint "bq/zangya_bq/zangya_sprout:10/QKQ1.200216.002/617:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "bq/zangya_bq/zangya_sprout:10/QKQ1.200216.002/617:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=dbfb708f45
resetprop -n ro.system.build.version.incremental 617
resetprop -n ro.bootimage.build.version.incremental 617
resetprop -n ro.product.build.version.incremental 617
resetprop -n ro.odm.build.version.incremental 617
resetprop -n ro.vendor_dlkm.build.version.incremental 617
resetprop -n ro.system_ext.build.version.incremental 617
resetprop -n ro.build.version.incremental 617
resetprop -n ro.vendor.build.version.incremental 617
resetprop -n ro.odm.build.id "QKQ1.200216.002"
resetprop -n ro.product.build.id "QKQ1.200216.002"
resetprop -n ro.bootimage.build.id "QKQ1.200216.002"
resetprop -n ro.system_ext.build.id "QKQ1.200216.002"
resetprop -n ro.vendor_dlkm.build.id "QKQ1.200216.002"
resetprop -n ro.build.id "QKQ1.200216.002"
resetprop -n ro.system.build.id "QKQ1.200216.002"
resetprop -n ro.vendor.build.id "QKQ1.200216.002"
resetprop -n ro.system.build.date "Wed Sep 23 15:54:58 CEST 2020"
resetprop -n ro.bootimage.build.date "Wed Sep 23 15:54:58 CEST 2020"
resetprop -n ro.product.build.date "Wed Sep 23 15:54:58 CEST 2020"
resetprop -n ro.vendor_dlkm.build.date "Wed Sep 23 15:54:58 CEST 2020"
resetprop -n ro.system_ext.build.date "Wed Sep 23 15:54:58 CEST 2020"
resetprop -n ro.odm.build.date "Wed Sep 23 15:54:58 CEST 2020"
resetprop -n ro.build.date "Wed Sep 23 15:54:58 CEST 2020"
resetprop -n ro.vendor.build.date "Wed Sep 23 15:54:58 CEST 2020"
resetprop -n ro.product.build.date.utc "1600869298"
resetprop -n ro.system_ext.build.date.utc "1600869298"
resetprop -n ro.system.build.date.utc "1600869298"
resetprop -n ro.vendor.build.date.utc "1600869298"
resetprop -n ro.vendor_dlkm.build.date.utc "1600869298"
resetprop -n ro.build.date.utc "1600869298"
resetprop -n ro.bootimage.build.date.utc "1600869298"
resetprop -n ro.odm.build.date.utc "1600869298"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name zangya_bq
resetprop -n ro.product.odm.name zangya_bq
resetprop -n ro.product.vendor.name zangya_bq
resetprop -n ro.product.system.name zangya_bq
resetprop -n ro.product.name zangya_bq
resetprop -n ro.product.bootimage.name zangya_bq
resetprop -n ro.product.vendor_dlkm.name zangya_bq
resetprop -n ro.product.system_ext.name zangya_bq
resetprop -n ro.build.flavor zangya_bq-user
randomStr="zangya_bq-user bq QKQ1.200216.002 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=d5b74469f9fa
resetprop -n ro.build.host ${randomStr}
randomStr=0859a29d
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=GJUDPW
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=a085f2e8db3b3
randomStr2=69
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=87
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "617"
resetprop -n ro.build.description "aeon6580_weg_l_l300-user 5.1 LMY47I 1555741941 release-keys"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "jenkins"
resetprop -n ro.build.host "bqbot8"
resetprop -n media.stagefright.enable-player "true"
resetprop -n media.stagefright.enable-http "true"
resetprop -n media.stagefright.enable-aac "true"
resetprop -n media.stagefright.enable-qcp "true"
resetprop -n media.stagefright.enable-scan "true"
resetprop -n media.aac_51_output_enabled "true"
resetprop -n media.stagefright.thumbnail.prefer_hw_codecs "true"
resetprop -n ro.hwui.texture_cache_size "72"
resetprop -n ro.hwui.layer_cache_size "48"
resetprop -n ro.hwui.r_buffer_cache_size "8"
resetprop -n ro.hwui.path_cache_size "32"
resetprop -n ro.hwui.gradient_cache_size "1"
resetprop -n ro.hwui.drop_shadow_cache_size "6"
resetprop -n ro.hwui.texture_cache_flushrate "0.4"
resetprop -n ro.hwui.text_small_cache_width "1024"
resetprop -n ro.hwui.text_small_cache_height "1024"
resetprop -n ro.hwui.text_large_cache_width "2048"
resetprop -n ro.hwui.text_large_cache_height "2048"
resetprop -n ro.com.google.acsa "true"
resetprop -n ro.com.google.clientidbase "android-bq"
resetprop -n ro.com.google.clientidbase.ms "android-bq-rev2"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2020-10-01
