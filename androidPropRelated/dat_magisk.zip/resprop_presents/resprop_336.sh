strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "TiVo Stream 4K"
resetprop -n ro.product.vendor.model "TiVo Stream 4K"
resetprop -n ro.product.vendor_dlkm.marketname "TiVo Stream 4K"
resetprop -n ro.product.product.marketname "TiVo Stream 4K"
resetprop -n ro.product.system.marketname "TiVo Stream 4K"
resetprop -n ro.product.odm_dlkm.marketname "TiVo Stream 4K"
resetprop -n ro.product.system_ext.marketname "TiVo Stream 4K"
resetprop -n ro.product.odm_dlkm.model "TiVo Stream 4K"
resetprop -n ro.product.system.model "TiVo Stream 4K"
resetprop -n ro.product.system_ext.model "TiVo Stream 4K"
resetprop -n ro.product.vendor_dlkm.model "TiVo Stream 4K"
resetprop -n bluetooth.device.default_name "TiVo Stream 4K"
resetprop -n ro.product.bootimage.model "TiVo Stream 4K"
resetprop -n ro.product.vendor.marketname "TiVo Stream 4K"
resetprop -n ro.product.marketname "TiVo Stream 4K"
resetprop -n ro.product.odm.model "TiVo Stream 4K"
resetprop -n ro.product.model "TiVo Stream 4K"
resetprop -n ro.product.product.model "TiVo Stream 4K"
resetprop -n ro.product.odm.marketname "TiVo Stream 4K"
resetprop -n ro.product.vendor.manufacturer "SEI Robotics"
resetprop -n ro.product.product.manufacturer "SEI Robotics"
resetprop -n ro.product.bootimage.manufacturer "SEI Robotics"
resetprop -n ro.product.manufacturer "SEI Robotics"
resetprop -n ro.product.odm.manufacturer "SEI Robotics"
resetprop -n ro.product.system.manufacturer "SEI Robotics"
resetprop -n ro.product.system_ext.manufacturer "SEI Robotics"
resetprop -n ro.product.vendor_dlkm.manufacturer "SEI Robotics"
resetprop -n ro.product.vendor.brand "eSTREAM4K"
resetprop -n ro.product.product.brand "eSTREAM4K"
resetprop -n ro.product.vendor_dlkm.brand "eSTREAM4K"
resetprop -n ro.product.system.brand "eSTREAM4K"
resetprop -n ro.product.bootimage.brand "eSTREAM4K"
resetprop -n ro.product.system_ext.brand "eSTREAM4K"
resetprop -n ro.product.odm.brand "eSTREAM4K"
resetprop -n ro.product.odm_dlkm.brand "eSTREAM4K"
resetprop -n ro.product.brand "eSTREAM4K"
resetprop -n ro.vendor_dlkm.build.fingerprint "eSTREAM4K/SEI400TV/SEI400TV:9/PI/5222:userdebug/release-keys"
resetprop -n ro.bootimage.build.fingerprint "eSTREAM4K/SEI400TV/SEI400TV:9/PI/5222:userdebug/release-keys"
resetprop -n ro.vendor.build.fingerprint "eSTREAM4K/SEI400TV/SEI400TV:9/PI/5222:userdebug/release-keys"
resetprop -n ro.odm.build.fingerprint "eSTREAM4K/SEI400TV/SEI400TV:9/PI/5222:userdebug/release-keys"
resetprop -n ro.system.build.fingerprint "eSTREAM4K/SEI400TV/SEI400TV:9/PI/5222:userdebug/release-keys"
resetprop -n ro.build.fingerprint "eSTREAM4K/SEI400TV/SEI400TV:9/PI/5222:userdebug/release-keys"
resetprop -n ro.system_ext.build.fingerprint "eSTREAM4K/SEI400TV/SEI400TV:9/PI/5222:userdebug/release-keys"
resetprop -n ro.product.build.fingerprint "eSTREAM4K/SEI400TV/SEI400TV:9/PI/5222:userdebug/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "eSTREAM4K/SEI400TV/SEI400TV:9/PI/5222:userdebug/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=603f3ad366
resetprop -n ro.system.build.version.incremental 5222
resetprop -n ro.bootimage.build.version.incremental 5222
resetprop -n ro.product.build.version.incremental 5222
resetprop -n ro.odm.build.version.incremental 5222
resetprop -n ro.vendor_dlkm.build.version.incremental 5222
resetprop -n ro.system_ext.build.version.incremental 5222
resetprop -n ro.build.version.incremental 5222
resetprop -n ro.vendor.build.version.incremental 5222
resetprop -n ro.odm.build.id "PI"
resetprop -n ro.product.build.id "PI"
resetprop -n ro.bootimage.build.id "PI"
resetprop -n ro.system_ext.build.id "PI"
resetprop -n ro.vendor_dlkm.build.id "PI"
resetprop -n ro.build.id "PI"
resetprop -n ro.system.build.id "PI"
resetprop -n ro.vendor.build.id "PI"
resetprop -n ro.system.build.date "Tue Dec 15 10:21:56 CST 2020"
resetprop -n ro.bootimage.build.date "Tue Dec 15 10:21:56 CST 2020"
resetprop -n ro.product.build.date "Tue Dec 15 10:21:56 CST 2020"
resetprop -n ro.vendor_dlkm.build.date "Tue Dec 15 10:21:56 CST 2020"
resetprop -n ro.system_ext.build.date "Tue Dec 15 10:21:56 CST 2020"
resetprop -n ro.odm.build.date "Tue Dec 15 10:21:56 CST 2020"
resetprop -n ro.build.date "Tue Dec 15 10:21:56 CST 2020"
resetprop -n ro.vendor.build.date "Tue Dec 15 10:21:56 CST 2020"
resetprop -n ro.product.build.date.utc "1607998916"
resetprop -n ro.system_ext.build.date.utc "1607998916"
resetprop -n ro.system.build.date.utc "1607998916"
resetprop -n ro.vendor.build.date.utc "1607998916"
resetprop -n ro.vendor_dlkm.build.date.utc "1607998916"
resetprop -n ro.build.date.utc "1607998916"
resetprop -n ro.bootimage.build.date.utc "1607998916"
resetprop -n ro.odm.build.date.utc "1607998916"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name SEI400TV
resetprop -n ro.product.odm.name SEI400TV
resetprop -n ro.product.vendor.name SEI400TV
resetprop -n ro.product.system.name SEI400TV
resetprop -n ro.product.name SEI400TV
resetprop -n ro.product.bootimage.name SEI400TV
resetprop -n ro.product.vendor_dlkm.name SEI400TV
resetprop -n ro.product.system_ext.name SEI400TV
resetprop -n ro.build.flavor SEI400TV-userdebug
randomStr="SEI400TV-userdebug SEI Robotics PI "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=f73c07cee1a4
resetprop -n ro.build.host ${randomStr}
randomStr=7d81d730
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=Gcfwdf
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=4cc3f887aca30
randomStr2=85
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=53
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "5222"
resetprop -n ro.build.description "SEI400TV-userdebug 9 PI 5222 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "jenkins"
resetprop -n ro.build.host "cts"
resetprop -n ro.build.product.backup "SEI400TV"
resetprop -n ro.build.characteristics "mbx,nosdcard"
resetprop -n ro.expect.recovery_id "0xd372c6de160b8293674a5cd4dd6a67957b56e559000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2020-10-05
