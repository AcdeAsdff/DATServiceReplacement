strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.vendor.model "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.vendor_dlkm.marketname "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.product.marketname "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.system.marketname "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.odm_dlkm.marketname "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.system_ext.marketname "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.odm_dlkm.model "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.system.model "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.system_ext.model "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.vendor_dlkm.model "LINX TRIX 4G LS5041PL"
resetprop -n bluetooth.device.default_name "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.bootimage.model "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.vendor.marketname "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.marketname "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.odm.model "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.model "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.product.model "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.odm.marketname "LINX TRIX 4G LS5041PL"
resetprop -n ro.product.vendor.manufacturer "DIGMA"
resetprop -n ro.product.product.manufacturer "DIGMA"
resetprop -n ro.product.bootimage.manufacturer "DIGMA"
resetprop -n ro.product.manufacturer "DIGMA"
resetprop -n ro.product.odm.manufacturer "DIGMA"
resetprop -n ro.product.system.manufacturer "DIGMA"
resetprop -n ro.product.system_ext.manufacturer "DIGMA"
resetprop -n ro.product.vendor_dlkm.manufacturer "DIGMA"
resetprop -n ro.product.vendor.brand "DIGMA"
resetprop -n ro.product.product.brand "DIGMA"
resetprop -n ro.product.vendor_dlkm.brand "DIGMA"
resetprop -n ro.product.system.brand "DIGMA"
resetprop -n ro.product.bootimage.brand "DIGMA"
resetprop -n ro.product.system_ext.brand "DIGMA"
resetprop -n ro.product.odm.brand "DIGMA"
resetprop -n ro.product.odm_dlkm.brand "DIGMA"
resetprop -n ro.product.brand "DIGMA"
resetprop -n ro.vendor_dlkm.build.fingerprint "DIGMA/LINX_TRIX_4G/LS5041PL:8.1.0/OPM2.171019.012/24521:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "DIGMA/LINX_TRIX_4G/LS5041PL:8.1.0/OPM2.171019.012/24521:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "DIGMA/LINX_TRIX_4G/LS5041PL:8.1.0/OPM2.171019.012/24521:user/release-keys"
resetprop -n ro.odm.build.fingerprint "DIGMA/LINX_TRIX_4G/LS5041PL:8.1.0/OPM2.171019.012/24521:user/release-keys"
resetprop -n ro.system.build.fingerprint "DIGMA/LINX_TRIX_4G/LS5041PL:8.1.0/OPM2.171019.012/24521:user/release-keys"
resetprop -n ro.build.fingerprint "DIGMA/LINX_TRIX_4G/LS5041PL:8.1.0/OPM2.171019.012/24521:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "DIGMA/LINX_TRIX_4G/LS5041PL:8.1.0/OPM2.171019.012/24521:user/release-keys"
resetprop -n ro.product.build.fingerprint "DIGMA/LINX_TRIX_4G/LS5041PL:8.1.0/OPM2.171019.012/24521:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "DIGMA/LINX_TRIX_4G/LS5041PL:8.1.0/OPM2.171019.012/24521:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=dcadc1d218
resetprop -n ro.system.build.version.incremental 24521
resetprop -n ro.bootimage.build.version.incremental 24521
resetprop -n ro.product.build.version.incremental 24521
resetprop -n ro.odm.build.version.incremental 24521
resetprop -n ro.vendor_dlkm.build.version.incremental 24521
resetprop -n ro.system_ext.build.version.incremental 24521
resetprop -n ro.build.version.incremental 24521
resetprop -n ro.vendor.build.version.incremental 24521
resetprop -n ro.odm.build.id "OPM2.171019.012"
resetprop -n ro.product.build.id "OPM2.171019.012"
resetprop -n ro.bootimage.build.id "OPM2.171019.012"
resetprop -n ro.system_ext.build.id "OPM2.171019.012"
resetprop -n ro.vendor_dlkm.build.id "OPM2.171019.012"
resetprop -n ro.build.id "OPM2.171019.012"
resetprop -n ro.system.build.id "OPM2.171019.012"
resetprop -n ro.vendor.build.id "OPM2.171019.012"
resetprop -n ro.system.build.date "Fri Jun 15 21:41:42 HKT 2018"
resetprop -n ro.bootimage.build.date "Fri Jun 15 21:41:42 HKT 2018"
resetprop -n ro.product.build.date "Fri Jun 15 21:41:42 HKT 2018"
resetprop -n ro.vendor_dlkm.build.date "Fri Jun 15 21:41:42 HKT 2018"
resetprop -n ro.system_ext.build.date "Fri Jun 15 21:41:42 HKT 2018"
resetprop -n ro.odm.build.date "Fri Jun 15 21:41:42 HKT 2018"
resetprop -n ro.build.date "Fri Jun 15 21:41:42 HKT 2018"
resetprop -n ro.vendor.build.date "Fri Jun 15 21:41:42 HKT 2018"
resetprop -n ro.product.build.date.utc "1529070102"
resetprop -n ro.system_ext.build.date.utc "1529070102"
resetprop -n ro.system.build.date.utc "1529070102"
resetprop -n ro.vendor.build.date.utc "1529070102"
resetprop -n ro.vendor_dlkm.build.date.utc "1529070102"
resetprop -n ro.build.date.utc "1529070102"
resetprop -n ro.bootimage.build.date.utc "1529070102"
resetprop -n ro.odm.build.date.utc "1529070102"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name LINX_TRIX_4G
resetprop -n ro.product.odm.name LINX_TRIX_4G
resetprop -n ro.product.vendor.name LINX_TRIX_4G
resetprop -n ro.product.system.name LINX_TRIX_4G
resetprop -n ro.product.name LINX_TRIX_4G
resetprop -n ro.product.bootimage.name LINX_TRIX_4G
resetprop -n ro.product.vendor_dlkm.name LINX_TRIX_4G
resetprop -n ro.product.system_ext.name LINX_TRIX_4G
resetprop -n ro.build.flavor oversea
randomStr="oversea DIGMA OPM2.171019.012 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=8782d9090f5f
resetprop -n ro.build.host ${randomStr}
randomStr=8e24bb9b
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=fbNUMd
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=e497bed45ba5c
randomStr2=91
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=45
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "24521"
resetprop -n ro.build.description "sp9850ka_1h10_oversea-user 8.1.0 OPM2.171019.012 24521 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "wangyichun"
resetprop -n ro.build.host "wangyichun"
resetprop -n ro.build.product.backup "sp9850ka_1h10"
resetprop -n ro.build.characteristics "default"
resetprop -n media.settings.xml  " vendor/etc/media_profiles_turnkey.xml"
resetprop -n ro.expect.recovery_id "0x8b67895b4e15eac97e90a6b11a7fc5ae5891e618000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-05-05
