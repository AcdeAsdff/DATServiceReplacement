strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "newton"
resetprop -n ro.product.vendor.model "newton"
resetprop -n ro.product.vendor_dlkm.marketname "newton"
resetprop -n ro.product.product.marketname "newton"
resetprop -n ro.product.system.marketname "newton"
resetprop -n ro.product.odm_dlkm.marketname "newton"
resetprop -n ro.product.system_ext.marketname "newton"
resetprop -n ro.product.odm_dlkm.model "newton"
resetprop -n ro.product.system.model "newton"
resetprop -n ro.product.system_ext.model "newton"
resetprop -n ro.product.vendor_dlkm.model "newton"
resetprop -n bluetooth.device.default_name "newton"
resetprop -n ro.product.bootimage.model "newton"
resetprop -n ro.product.vendor.marketname "newton"
resetprop -n ro.product.marketname "newton"
resetprop -n ro.product.odm.model "newton"
resetprop -n ro.product.model "newton"
resetprop -n ro.product.product.model "newton"
resetprop -n ro.product.odm.marketname "newton"
resetprop -n ro.product.vendor.manufacturer "Amlogic"
resetprop -n ro.product.product.manufacturer "Amlogic"
resetprop -n ro.product.bootimage.manufacturer "Amlogic"
resetprop -n ro.product.manufacturer "Amlogic"
resetprop -n ro.product.odm.manufacturer "Amlogic"
resetprop -n ro.product.system.manufacturer "Amlogic"
resetprop -n ro.product.system_ext.manufacturer "Amlogic"
resetprop -n ro.product.vendor_dlkm.manufacturer "Amlogic"
resetprop -n ro.product.vendor.brand "Amlogic"
resetprop -n ro.product.product.brand "Amlogic"
resetprop -n ro.product.vendor_dlkm.brand "Amlogic"
resetprop -n ro.product.system.brand "Amlogic"
resetprop -n ro.product.bootimage.brand "Amlogic"
resetprop -n ro.product.system_ext.brand "Amlogic"
resetprop -n ro.product.odm.brand "Amlogic"
resetprop -n ro.product.odm_dlkm.brand "Amlogic"
resetprop -n ro.product.brand "Amlogic"
resetprop -n ro.vendor_dlkm.build.fingerprint "Amlogic/newton/newton:10/QT/jie.yuan01031546:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Amlogic/newton/newton:10/QT/jie.yuan01031546:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Amlogic/newton/newton:10/QT/jie.yuan01031546:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Amlogic/newton/newton:10/QT/jie.yuan01031546:user/release-keys"
resetprop -n ro.system.build.fingerprint "Amlogic/newton/newton:10/QT/jie.yuan01031546:user/release-keys"
resetprop -n ro.build.fingerprint "Amlogic/newton/newton:10/QT/jie.yuan01031546:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Amlogic/newton/newton:10/QT/jie.yuan01031546:user/release-keys"
resetprop -n ro.product.build.fingerprint "Amlogic/newton/newton:10/QT/jie.yuan01031546:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Amlogic/newton/newton:10/QT/jie.yuan01031546:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=688727672c
resetprop -n ro.system.build.version.incremental eng.jie.yu.20200103.154728
resetprop -n ro.bootimage.build.version.incremental eng.jie.yu.20200103.154728
resetprop -n ro.product.build.version.incremental eng.jie.yu.20200103.154728
resetprop -n ro.odm.build.version.incremental eng.jie.yu.20200103.154728
resetprop -n ro.vendor_dlkm.build.version.incremental eng.jie.yu.20200103.154728
resetprop -n ro.system_ext.build.version.incremental eng.jie.yu.20200103.154728
resetprop -n ro.build.version.incremental eng.jie.yu.20200103.154728
resetprop -n ro.vendor.build.version.incremental eng.jie.yu.20200103.154728
resetprop -n ro.odm.build.id "QT"
resetprop -n ro.product.build.id "QT"
resetprop -n ro.bootimage.build.id "QT"
resetprop -n ro.system_ext.build.id "QT"
resetprop -n ro.vendor_dlkm.build.id "QT"
resetprop -n ro.build.id "QT"
resetprop -n ro.system.build.id "QT"
resetprop -n ro.vendor.build.id "QT"
resetprop -n ro.system.build.date "Fri Jan  3 15:46:50 CST 2020"
resetprop -n ro.bootimage.build.date "Fri Jan  3 15:46:50 CST 2020"
resetprop -n ro.product.build.date "Fri Jan  3 15:46:50 CST 2020"
resetprop -n ro.vendor_dlkm.build.date "Fri Jan  3 15:46:50 CST 2020"
resetprop -n ro.system_ext.build.date "Fri Jan  3 15:46:50 CST 2020"
resetprop -n ro.odm.build.date "Fri Jan  3 15:46:50 CST 2020"
resetprop -n ro.build.date "Fri Jan  3 15:46:50 CST 2020"
resetprop -n ro.vendor.build.date "Fri Jan  3 15:46:50 CST 2020"
resetprop -n ro.product.build.date.utc "1578037610"
resetprop -n ro.system_ext.build.date.utc "1578037610"
resetprop -n ro.system.build.date.utc "1578037610"
resetprop -n ro.vendor.build.date.utc "1578037610"
resetprop -n ro.vendor_dlkm.build.date.utc "1578037610"
resetprop -n ro.build.date.utc "1578037610"
resetprop -n ro.bootimage.build.date.utc "1578037610"
resetprop -n ro.odm.build.date.utc "1578037610"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name newton
resetprop -n ro.product.odm.name newton
resetprop -n ro.product.vendor.name newton
resetprop -n ro.product.system.name newton
resetprop -n ro.product.name newton
resetprop -n ro.product.bootimage.name newton
resetprop -n ro.product.vendor_dlkm.name newton
resetprop -n ro.product.system_ext.name newton
resetprop -n ro.build.flavor newton-user
randomStr="newton-user Amlogic QT "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=e4b9626c2986
resetprop -n ro.build.host ${randomStr}
randomStr=b667c066
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=jEkRzw
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=4692e26a8a4d1
randomStr2=5f
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=9c
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "eng.jie.yu.20200103.154728"
resetprop -n ro.build.description "newton-user 10 QT eng.jie.yu.20200103.154728 release-keys"
resetprop -n ro.build.product.backup "newton"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "jie.yuan"
resetprop -n ro.build.host "droid06"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-11-05
