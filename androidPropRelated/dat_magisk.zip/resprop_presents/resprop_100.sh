strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "viva"
resetprop -n ro.product.vendor.model "viva"
resetprop -n ro.product.vendor_dlkm.marketname "viva"
resetprop -n ro.product.product.marketname "viva"
resetprop -n ro.product.system.marketname "viva"
resetprop -n ro.product.odm_dlkm.marketname "viva"
resetprop -n ro.product.system_ext.marketname "viva"
resetprop -n ro.product.odm_dlkm.model "viva"
resetprop -n ro.product.system.model "viva"
resetprop -n ro.product.system_ext.model "viva"
resetprop -n ro.product.vendor_dlkm.model "viva"
resetprop -n bluetooth.device.default_name "viva"
resetprop -n ro.product.bootimage.model "viva"
resetprop -n ro.product.vendor.marketname "viva"
resetprop -n ro.product.marketname "viva"
resetprop -n ro.product.odm.model "viva"
resetprop -n ro.product.model "viva"
resetprop -n ro.product.product.model "viva"
resetprop -n ro.product.odm.marketname "viva"
resetprop -n ro.product.vendor.manufacturer "Xiaomi"
resetprop -n ro.product.product.manufacturer "Xiaomi"
resetprop -n ro.product.bootimage.manufacturer "Xiaomi"
resetprop -n ro.product.manufacturer "Xiaomi"
resetprop -n ro.product.odm.manufacturer "Xiaomi"
resetprop -n ro.product.system.manufacturer "Xiaomi"
resetprop -n ro.product.system_ext.manufacturer "Xiaomi"
resetprop -n ro.product.vendor_dlkm.manufacturer "Xiaomi"
resetprop -n ro.product.vendor.brand "Redmi"
resetprop -n ro.product.product.brand "Redmi"
resetprop -n ro.product.vendor_dlkm.brand "Redmi"
resetprop -n ro.product.system.brand "Redmi"
resetprop -n ro.product.bootimage.brand "Redmi"
resetprop -n ro.product.system_ext.brand "Redmi"
resetprop -n ro.product.odm.brand "Redmi"
resetprop -n ro.product.odm_dlkm.brand "Redmi"
resetprop -n ro.product.brand "Redmi"
resetprop -n ro.vendor_dlkm.build.fingerprint "Redmi/viva_id/viva:12/SP1A.210812.016/V13.0.6.0.SGDIDXM:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Redmi/viva_id/viva:12/SP1A.210812.016/V13.0.6.0.SGDIDXM:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Redmi/viva_id/viva:12/SP1A.210812.016/V13.0.6.0.SGDIDXM:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Redmi/viva_id/viva:12/SP1A.210812.016/V13.0.6.0.SGDIDXM:user/release-keys"
resetprop -n ro.system.build.fingerprint "Redmi/viva_id/viva:12/SP1A.210812.016/V13.0.6.0.SGDIDXM:user/release-keys"
resetprop -n ro.build.fingerprint "Redmi/viva_id/viva:12/SP1A.210812.016/V13.0.6.0.SGDIDXM:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Redmi/viva_id/viva:12/SP1A.210812.016/V13.0.6.0.SGDIDXM:user/release-keys"
resetprop -n ro.product.build.fingerprint "Redmi/viva_id/viva:12/SP1A.210812.016/V13.0.6.0.SGDIDXM:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Redmi/viva_id/viva:12/SP1A.210812.016/V13.0.6.0.SGDIDXM:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=18a6594a8a
resetprop -n ro.system.build.version.incremental V13.0.6.0.SGDIDXM
resetprop -n ro.bootimage.build.version.incremental V13.0.6.0.SGDIDXM
resetprop -n ro.product.build.version.incremental V13.0.6.0.SGDIDXM
resetprop -n ro.odm.build.version.incremental V13.0.6.0.SGDIDXM
resetprop -n ro.vendor_dlkm.build.version.incremental V13.0.6.0.SGDIDXM
resetprop -n ro.system_ext.build.version.incremental V13.0.6.0.SGDIDXM
resetprop -n ro.build.version.incremental V13.0.6.0.SGDIDXM
resetprop -n ro.vendor.build.version.incremental V13.0.6.0.SGDIDXM
resetprop -n ro.odm.build.id "SP1A.210812.016"
resetprop -n ro.product.build.id "SP1A.210812.016"
resetprop -n ro.bootimage.build.id "SP1A.210812.016"
resetprop -n ro.system_ext.build.id "SP1A.210812.016"
resetprop -n ro.vendor_dlkm.build.id "SP1A.210812.016"
resetprop -n ro.build.id "SP1A.210812.016"
resetprop -n ro.system.build.id "SP1A.210812.016"
resetprop -n ro.vendor.build.id "SP1A.210812.016"
resetprop -n ro.system.build.date "Fri Feb 10 09:08:47 WIB 2023"
resetprop -n ro.bootimage.build.date "Fri Feb 10 09:08:47 WIB 2023"
resetprop -n ro.product.build.date "Fri Feb 10 09:08:47 WIB 2023"
resetprop -n ro.vendor_dlkm.build.date "Fri Feb 10 09:08:47 WIB 2023"
resetprop -n ro.system_ext.build.date "Fri Feb 10 09:08:47 WIB 2023"
resetprop -n ro.odm.build.date "Fri Feb 10 09:08:47 WIB 2023"
resetprop -n ro.build.date "Fri Feb 10 09:08:47 WIB 2023"
resetprop -n ro.vendor.build.date "Fri Feb 10 09:08:47 WIB 2023"
resetprop -n ro.product.build.date.utc "1675994927"
resetprop -n ro.system_ext.build.date.utc "1675994927"
resetprop -n ro.system.build.date.utc "1675994927"
resetprop -n ro.vendor.build.date.utc "1675994927"
resetprop -n ro.vendor_dlkm.build.date.utc "1675994927"
resetprop -n ro.build.date.utc "1675994927"
resetprop -n ro.bootimage.build.date.utc "1675994927"
resetprop -n ro.odm.build.date.utc "1675994927"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name viva_id
resetprop -n ro.product.odm.name viva_id
resetprop -n ro.product.vendor.name viva_id
resetprop -n ro.product.system.name viva_id
resetprop -n ro.product.name viva_id
resetprop -n ro.product.bootimage.name viva_id
resetprop -n ro.product.vendor_dlkm.name viva_id
resetprop -n ro.product.system_ext.name viva_id
resetprop -n ro.build.flavor viva-user
randomStr="viva-user Xiaomi SP1A.210812.016 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=bfc7ca16c822
resetprop -n ro.build.host ${randomStr}
randomStr=37d437fd
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=lfvuyw
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=2c72a7829d997
randomStr2=bf
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=f4
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "V13.0.6.0.SGDIDXM"
resetprop -n ro.build.description "viva-user 12 SP1A.210812.016 V13.0.6.0.SGDIDXM release-keys"
resetprop -n ro.build.product.backup "viva"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "builder"
resetprop -n ro.build.host "non-pangu-pod-5tjr9"
resetprop -n sys.miui.shutdown.waittime "500"
resetprop -n ro.com.google.clientidbase "android-xiaomi"
resetprop -n ro.miui.has_real_blur "1"
resetprop -n ro.miui.fpstool_enabled "true"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.miui.ui.version.code "13"
resetprop -n ro.miui.ui.version.name "V130"
resetprop -n ro.fota.oem "Xiaomi"
resetprop -n ro.miui.cust_device "viva"
resetprop -n ro.mi.development "false"
resetprop -n ro.miui.pai.preinstall.path "/data/miui/pai/"
resetprop -n ro.miui.has_cust_partition "true"
resetprop -n ro.miui.version.code_time "1675962000"
resetprop -n ro.com.google.ime.themes_dir "/system/etc/gboard_theme"
resetprop -n ro.com.google.ime.theme_file "xiaomi_theme_20171222.zip"
resetprop -n ro.com.google.lens.oem_camera_package "com.android.camera"
resetprop -n ro.com.google.lens.oem_image_package "com.miui.gallery"
resetprop -n ro.miui.remove_uri_80_flag "1"
resetprop -n ro.miui.customized_clientid "2"
resetprop -n ro.miui.pm.install.speedinstall "/data/apk-tmp"
resetprop -n persist.sys.miui_scout_enable "true"
resetprop -n persist.miui.extm.enable "1"
resetprop -n persist.miui.density_v2 "440"
resetprop -n ro.miui.notch "1"
resetprop -n ro.mediatek.version.branch "alps-mp-s0.mssi1.tc8sp-mt6785"
resetprop -n ro.vendor.mtk_omacp_support "1"
resetprop -n ro.vendor.mtk_flv_playback_support "1"
resetprop -n ro.vendor.mtk_cta_set "1"
resetprop -n ro.vendor.mtk_telephony_add_on_policy "0"
resetprop -n media.stagefright.thumbnail.prefer_hw_codecs "true"
resetprop -n vendor.mtk_thumbnail_optimization "true"
resetprop -n ro.lmk.critical_upgrade "true"
resetprop -n ro.lmk.upgrade_pressure "60"
resetprop -n ro.lmk.downgrade_pressure "80"
resetprop -n ro.lmk.use_minfree_levels "true"
resetprop -n ro.lmk.kill_heaviest_task "true"
resetprop -n ro.lmk.extra_medium "400"
resetprop -n ro.lmk.extra_critical "400"
resetprop -n ro.lmk.low "1000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2023-02-01
