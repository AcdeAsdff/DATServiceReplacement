strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "itel A14"
resetprop -n ro.product.vendor.model "itel A14"
resetprop -n ro.product.vendor_dlkm.marketname "itel A14"
resetprop -n ro.product.product.marketname "itel A14"
resetprop -n ro.product.system.marketname "itel A14"
resetprop -n ro.product.odm_dlkm.marketname "itel A14"
resetprop -n ro.product.system_ext.marketname "itel A14"
resetprop -n ro.product.odm_dlkm.model "itel A14"
resetprop -n ro.product.system.model "itel A14"
resetprop -n ro.product.system_ext.model "itel A14"
resetprop -n ro.product.vendor_dlkm.model "itel A14"
resetprop -n bluetooth.device.default_name "itel A14"
resetprop -n ro.product.bootimage.model "itel A14"
resetprop -n ro.product.vendor.marketname "itel A14"
resetprop -n ro.product.marketname "itel A14"
resetprop -n ro.product.odm.model "itel A14"
resetprop -n ro.product.model "itel A14"
resetprop -n ro.product.product.model "itel A14"
resetprop -n ro.product.odm.marketname "itel A14"
resetprop -n ro.product.vendor.manufacturer "itel"
resetprop -n ro.product.product.manufacturer "itel"
resetprop -n ro.product.bootimage.manufacturer "itel"
resetprop -n ro.product.manufacturer "itel"
resetprop -n ro.product.odm.manufacturer "itel"
resetprop -n ro.product.system.manufacturer "itel"
resetprop -n ro.product.system_ext.manufacturer "itel"
resetprop -n ro.product.vendor_dlkm.manufacturer "itel"
resetprop -n ro.product.vendor.brand "Itel"
resetprop -n ro.product.product.brand "Itel"
resetprop -n ro.product.vendor_dlkm.brand "Itel"
resetprop -n ro.product.system.brand "Itel"
resetprop -n ro.product.bootimage.brand "Itel"
resetprop -n ro.product.system_ext.brand "Itel"
resetprop -n ro.product.odm.brand "Itel"
resetprop -n ro.product.odm_dlkm.brand "Itel"
resetprop -n ro.product.brand "Itel"
resetprop -n ro.vendor_dlkm.build.fingerprint "Itel/SA215/itel-A14:8.1.0/OPM2.171019.012/06252253:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Itel/SA215/itel-A14:8.1.0/OPM2.171019.012/06252253:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Itel/SA215/itel-A14:8.1.0/OPM2.171019.012/06252253:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Itel/SA215/itel-A14:8.1.0/OPM2.171019.012/06252253:user/release-keys"
resetprop -n ro.system.build.fingerprint "Itel/SA215/itel-A14:8.1.0/OPM2.171019.012/06252253:user/release-keys"
resetprop -n ro.build.fingerprint "Itel/SA215/itel-A14:8.1.0/OPM2.171019.012/06252253:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Itel/SA215/itel-A14:8.1.0/OPM2.171019.012/06252253:user/release-keys"
resetprop -n ro.product.build.fingerprint "Itel/SA215/itel-A14:8.1.0/OPM2.171019.012/06252253:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Itel/SA215/itel-A14:8.1.0/OPM2.171019.012/06252253:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=b6a629ad1e
resetprop -n ro.system.build.version.incremental 06252253
resetprop -n ro.bootimage.build.version.incremental 06252253
resetprop -n ro.product.build.version.incremental 06252253
resetprop -n ro.odm.build.version.incremental 06252253
resetprop -n ro.vendor_dlkm.build.version.incremental 06252253
resetprop -n ro.system_ext.build.version.incremental 06252253
resetprop -n ro.build.version.incremental 06252253
resetprop -n ro.vendor.build.version.incremental 06252253
resetprop -n ro.odm.build.id "OPM2.171019.012"
resetprop -n ro.product.build.id "OPM2.171019.012"
resetprop -n ro.bootimage.build.id "OPM2.171019.012"
resetprop -n ro.system_ext.build.id "OPM2.171019.012"
resetprop -n ro.vendor_dlkm.build.id "OPM2.171019.012"
resetprop -n ro.build.id "OPM2.171019.012"
resetprop -n ro.system.build.id "OPM2.171019.012"
resetprop -n ro.vendor.build.id "OPM2.171019.012"
resetprop -n ro.system.build.date "Mon Jun 25 22:53:02 CST 2018"
resetprop -n ro.bootimage.build.date "Mon Jun 25 22:53:02 CST 2018"
resetprop -n ro.product.build.date "Mon Jun 25 22:53:02 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Mon Jun 25 22:53:02 CST 2018"
resetprop -n ro.system_ext.build.date "Mon Jun 25 22:53:02 CST 2018"
resetprop -n ro.odm.build.date "Mon Jun 25 22:53:02 CST 2018"
resetprop -n ro.build.date "Mon Jun 25 22:53:02 CST 2018"
resetprop -n ro.vendor.build.date "Mon Jun 25 22:53:02 CST 2018"
resetprop -n ro.product.build.date.utc "1529938382"
resetprop -n ro.system_ext.build.date.utc "1529938382"
resetprop -n ro.system.build.date.utc "1529938382"
resetprop -n ro.vendor.build.date.utc "1529938382"
resetprop -n ro.vendor_dlkm.build.date.utc "1529938382"
resetprop -n ro.build.date.utc "1529938382"
resetprop -n ro.bootimage.build.date.utc "1529938382"
resetprop -n ro.odm.build.date.utc "1529938382"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name SA215
resetprop -n ro.product.odm.name SA215
resetprop -n ro.product.vendor.name SA215
resetprop -n ro.product.system.name SA215
resetprop -n ro.product.name SA215
resetprop -n ro.product.bootimage.name SA215
resetprop -n ro.product.vendor_dlkm.name SA215
resetprop -n ro.product.system_ext.name SA215
resetprop -n ro.build.flavor sp7731e_1h20_native-user
randomStr="sp7731e_1h20_native-user itel OPM2.171019.012 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=117c87c22d9c
resetprop -n ro.build.host ${randomStr}
randomStr=b67ed593
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=BLhelq
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=c1d52fe08c5e9
randomStr2=84
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=2f
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "06252253"
resetprop -n ro.build.description "sp7731e_1h20_native-user 8.1.0 OPM2.171019.012 06252253 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "root"
resetprop -n ro.build.host "innovatech"
resetprop -n ro.build.product.backup "itel A14"
resetprop -n ro.build.characteristics "default"
resetprop -n media.settings.xml  " vendor/etc/media_profiles_turnkey.xml"
resetprop -n ro.expect.recovery_id "0x84101842825496cb4add58655a6614a29e9c38d4000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-06-05
