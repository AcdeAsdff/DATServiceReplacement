strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "moto g power (2022)"
resetprop -n ro.product.vendor.model "moto g power (2022)"
resetprop -n ro.product.vendor_dlkm.marketname "moto g power (2022)"
resetprop -n ro.product.product.marketname "moto g power (2022)"
resetprop -n ro.product.system.marketname "moto g power (2022)"
resetprop -n ro.product.odm_dlkm.marketname "moto g power (2022)"
resetprop -n ro.product.system_ext.marketname "moto g power (2022)"
resetprop -n ro.product.odm_dlkm.model "moto g power (2022)"
resetprop -n ro.product.system.model "moto g power (2022)"
resetprop -n ro.product.system_ext.model "moto g power (2022)"
resetprop -n ro.product.vendor_dlkm.model "moto g power (2022)"
resetprop -n bluetooth.device.default_name "moto g power (2022)"
resetprop -n ro.product.bootimage.model "moto g power (2022)"
resetprop -n ro.product.vendor.marketname "moto g power (2022)"
resetprop -n ro.product.marketname "moto g power (2022)"
resetprop -n ro.product.odm.model "moto g power (2022)"
resetprop -n ro.product.model "moto g power (2022)"
resetprop -n ro.product.product.model "moto g power (2022)"
resetprop -n ro.product.odm.marketname "moto g power (2022)"
resetprop -n ro.product.vendor.manufacturer "motorola"
resetprop -n ro.product.product.manufacturer "motorola"
resetprop -n ro.product.bootimage.manufacturer "motorola"
resetprop -n ro.product.manufacturer "motorola"
resetprop -n ro.product.odm.manufacturer "motorola"
resetprop -n ro.product.system.manufacturer "motorola"
resetprop -n ro.product.system_ext.manufacturer "motorola"
resetprop -n ro.product.vendor_dlkm.manufacturer "motorola"
resetprop -n ro.product.vendor.brand "motorola"
resetprop -n ro.product.product.brand "motorola"
resetprop -n ro.product.vendor_dlkm.brand "motorola"
resetprop -n ro.product.system.brand "motorola"
resetprop -n ro.product.bootimage.brand "motorola"
resetprop -n ro.product.system_ext.brand "motorola"
resetprop -n ro.product.odm.brand "motorola"
resetprop -n ro.product.odm_dlkm.brand "motorola"
resetprop -n ro.product.brand "motorola"
resetprop -n ro.vendor_dlkm.build.fingerprint "motorola/tonga_g/tonga:11/RRQS31.Q3-68-99-2/25a9a:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "motorola/tonga_g/tonga:11/RRQS31.Q3-68-99-2/25a9a:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "motorola/tonga_g/tonga:11/RRQS31.Q3-68-99-2/25a9a:user/release-keys"
resetprop -n ro.odm.build.fingerprint "motorola/tonga_g/tonga:11/RRQS31.Q3-68-99-2/25a9a:user/release-keys"
resetprop -n ro.system.build.fingerprint "motorola/tonga_g/tonga:11/RRQS31.Q3-68-99-2/25a9a:user/release-keys"
resetprop -n ro.build.fingerprint "motorola/tonga_g/tonga:11/RRQS31.Q3-68-99-2/25a9a:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "motorola/tonga_g/tonga:11/RRQS31.Q3-68-99-2/25a9a:user/release-keys"
resetprop -n ro.product.build.fingerprint "motorola/tonga_g/tonga:11/RRQS31.Q3-68-99-2/25a9a:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "motorola/tonga_g/tonga:11/RRQS31.Q3-68-99-2/25a9a:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=ba44bd78f3
resetprop -n ro.system.build.version.incremental 25a9a
resetprop -n ro.bootimage.build.version.incremental 25a9a
resetprop -n ro.product.build.version.incremental 25a9a
resetprop -n ro.odm.build.version.incremental 25a9a
resetprop -n ro.vendor_dlkm.build.version.incremental 25a9a
resetprop -n ro.system_ext.build.version.incremental 25a9a
resetprop -n ro.build.version.incremental 25a9a
resetprop -n ro.vendor.build.version.incremental 25a9a
resetprop -n ro.odm.build.id "RRQS31.Q3-68-99-2"
resetprop -n ro.product.build.id "RRQS31.Q3-68-99-2"
resetprop -n ro.bootimage.build.id "RRQS31.Q3-68-99-2"
resetprop -n ro.system_ext.build.id "RRQS31.Q3-68-99-2"
resetprop -n ro.vendor_dlkm.build.id "RRQS31.Q3-68-99-2"
resetprop -n ro.build.id "RRQS31.Q3-68-99-2"
resetprop -n ro.system.build.id "RRQS31.Q3-68-99-2"
resetprop -n ro.vendor.build.id "RRQS31.Q3-68-99-2"
resetprop -n ro.system.build.date "Sat Mar  5 08:35:22 CST 2022"
resetprop -n ro.bootimage.build.date "Sat Mar  5 08:35:22 CST 2022"
resetprop -n ro.product.build.date "Sat Mar  5 08:35:22 CST 2022"
resetprop -n ro.vendor_dlkm.build.date "Sat Mar  5 08:35:22 CST 2022"
resetprop -n ro.system_ext.build.date "Sat Mar  5 08:35:22 CST 2022"
resetprop -n ro.odm.build.date "Sat Mar  5 08:35:22 CST 2022"
resetprop -n ro.build.date "Sat Mar  5 08:35:22 CST 2022"
resetprop -n ro.vendor.build.date "Sat Mar  5 08:35:22 CST 2022"
resetprop -n ro.product.build.date.utc "1646490922"
resetprop -n ro.system_ext.build.date.utc "1646490922"
resetprop -n ro.system.build.date.utc "1646490922"
resetprop -n ro.vendor.build.date.utc "1646490922"
resetprop -n ro.vendor_dlkm.build.date.utc "1646490922"
resetprop -n ro.build.date.utc "1646490922"
resetprop -n ro.bootimage.build.date.utc "1646490922"
resetprop -n ro.odm.build.date.utc "1646490922"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name tonga_g
resetprop -n ro.product.odm.name tonga_g
resetprop -n ro.product.vendor.name tonga_g
resetprop -n ro.product.system.name tonga_g
resetprop -n ro.product.name tonga_g
resetprop -n ro.product.bootimage.name tonga_g
resetprop -n ro.product.vendor_dlkm.name tonga_g
resetprop -n ro.product.system_ext.name tonga_g
resetprop -n ro.build.flavor tonga_g-user
randomStr="tonga_g-user motorola RRQS31.Q3-68-99-2 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=938b308de093
resetprop -n ro.build.host ${randomStr}
randomStr=ef2cca3a
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=GEvzaU
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=bcadd2805fd4f
randomStr2=a9
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=bb
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "25a9a"
resetprop -n ro.build.description "tonga_g-user 11 RRQS31.Q3-68-99-2 25a9a release-keys"
resetprop -n ro.build.product.backup "tonga"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "hudsoncm"
resetprop -n ro.build.host "ilclbld152"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n media.settings.xml "/vendor/etc/media_profiles_vendor.xml"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2022-03-01
