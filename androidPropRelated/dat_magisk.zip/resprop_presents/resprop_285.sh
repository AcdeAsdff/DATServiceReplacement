strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "DM-B50104"
resetprop -n ro.product.vendor.model "DM-B50104"
resetprop -n ro.product.vendor_dlkm.marketname "DM-B50104"
resetprop -n ro.product.product.marketname "DM-B50104"
resetprop -n ro.product.system.marketname "DM-B50104"
resetprop -n ro.product.odm_dlkm.marketname "DM-B50104"
resetprop -n ro.product.system_ext.marketname "DM-B50104"
resetprop -n ro.product.odm_dlkm.model "DM-B50104"
resetprop -n ro.product.system.model "DM-B50104"
resetprop -n ro.product.system_ext.model "DM-B50104"
resetprop -n ro.product.vendor_dlkm.model "DM-B50104"
resetprop -n bluetooth.device.default_name "DM-B50104"
resetprop -n ro.product.bootimage.model "DM-B50104"
resetprop -n ro.product.vendor.marketname "DM-B50104"
resetprop -n ro.product.marketname "DM-B50104"
resetprop -n ro.product.odm.model "DM-B50104"
resetprop -n ro.product.model "DM-B50104"
resetprop -n ro.product.product.model "DM-B50104"
resetprop -n ro.product.odm.marketname "DM-B50104"
resetprop -n ro.product.vendor.manufacturer "Daria"
resetprop -n ro.product.product.manufacturer "Daria"
resetprop -n ro.product.bootimage.manufacturer "Daria"
resetprop -n ro.product.manufacturer "Daria"
resetprop -n ro.product.odm.manufacturer "Daria"
resetprop -n ro.product.system.manufacturer "Daria"
resetprop -n ro.product.system_ext.manufacturer "Daria"
resetprop -n ro.product.vendor_dlkm.manufacturer "Daria"
resetprop -n ro.product.vendor.brand "Daria"
resetprop -n ro.product.product.brand "Daria"
resetprop -n ro.product.vendor_dlkm.brand "Daria"
resetprop -n ro.product.system.brand "Daria"
resetprop -n ro.product.bootimage.brand "Daria"
resetprop -n ro.product.system_ext.brand "Daria"
resetprop -n ro.product.odm.brand "Daria"
resetprop -n ro.product.odm_dlkm.brand "Daria"
resetprop -n ro.product.brand "Daria"
resetprop -n ro.vendor_dlkm.build.fingerprint "Daria/zahedan/zahedan:13/TQ3A.230901.001/V4.81.1.0.BOND:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Daria/zahedan/zahedan:13/TQ3A.230901.001/V4.81.1.0.BOND:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Daria/zahedan/zahedan:13/TQ3A.230901.001/V4.81.1.0.BOND:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Daria/zahedan/zahedan:13/TQ3A.230901.001/V4.81.1.0.BOND:user/release-keys"
resetprop -n ro.system.build.fingerprint "Daria/zahedan/zahedan:13/TQ3A.230901.001/V4.81.1.0.BOND:user/release-keys"
resetprop -n ro.build.fingerprint "Daria/zahedan/zahedan:13/TQ3A.230901.001/V4.81.1.0.BOND:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Daria/zahedan/zahedan:13/TQ3A.230901.001/V4.81.1.0.BOND:user/release-keys"
resetprop -n ro.product.build.fingerprint "Daria/zahedan/zahedan:13/TQ3A.230901.001/V4.81.1.0.BOND:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Daria/zahedan/zahedan:13/TQ3A.230901.001/V4.81.1.0.BOND:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=3f8935e414
resetprop -n ro.system.build.version.incremental V4.81.1.0.BOND
resetprop -n ro.bootimage.build.version.incremental V4.81.1.0.BOND
resetprop -n ro.product.build.version.incremental V4.81.1.0.BOND
resetprop -n ro.odm.build.version.incremental V4.81.1.0.BOND
resetprop -n ro.vendor_dlkm.build.version.incremental V4.81.1.0.BOND
resetprop -n ro.system_ext.build.version.incremental V4.81.1.0.BOND
resetprop -n ro.build.version.incremental V4.81.1.0.BOND
resetprop -n ro.vendor.build.version.incremental V4.81.1.0.BOND
resetprop -n ro.odm.build.id "TQ3A.230901.001"
resetprop -n ro.product.build.id "TQ3A.230901.001"
resetprop -n ro.bootimage.build.id "TQ3A.230901.001"
resetprop -n ro.system_ext.build.id "TQ3A.230901.001"
resetprop -n ro.vendor_dlkm.build.id "TQ3A.230901.001"
resetprop -n ro.build.id "TQ3A.230901.001"
resetprop -n ro.system.build.id "TQ3A.230901.001"
resetprop -n ro.vendor.build.id "TQ3A.230901.001"
resetprop -n ro.system.build.date "Wed Dec  6 06:56:20 UTC 2023"
resetprop -n ro.bootimage.build.date "Wed Dec  6 06:56:20 UTC 2023"
resetprop -n ro.product.build.date "Wed Dec  6 06:56:20 UTC 2023"
resetprop -n ro.vendor_dlkm.build.date "Wed Dec  6 06:56:20 UTC 2023"
resetprop -n ro.system_ext.build.date "Wed Dec  6 06:56:20 UTC 2023"
resetprop -n ro.odm.build.date "Wed Dec  6 06:56:20 UTC 2023"
resetprop -n ro.build.date "Wed Dec  6 06:56:20 UTC 2023"
resetprop -n ro.vendor.build.date "Wed Dec  6 06:56:20 UTC 2023"
resetprop -n ro.product.build.date.utc "1701845780"
resetprop -n ro.system_ext.build.date.utc "1701845780"
resetprop -n ro.system.build.date.utc "1701845780"
resetprop -n ro.vendor.build.date.utc "1701845780"
resetprop -n ro.vendor_dlkm.build.date.utc "1701845780"
resetprop -n ro.build.date.utc "1701845780"
resetprop -n ro.bootimage.build.date.utc "1701845780"
resetprop -n ro.odm.build.date.utc "1701845780"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name zahedan
resetprop -n ro.product.odm.name zahedan
resetprop -n ro.product.vendor.name zahedan
resetprop -n ro.product.system.name zahedan
resetprop -n ro.product.name zahedan
resetprop -n ro.product.bootimage.name zahedan
resetprop -n ro.product.vendor_dlkm.name zahedan
resetprop -n ro.product.system_ext.name zahedan
resetprop -n ro.build.flavor zahedan-user
randomStr="zahedan-user Daria TQ3A.230901.001 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=092191f98dce
resetprop -n ro.build.host ${randomStr}
randomStr=42ecb1a6
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=aOUpEy
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=67ab0129d10ec
randomStr2=09
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=c5
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "V4.81.1.0.BOND"
resetprop -n ro.build.description "zahedan-user 13 TQ3A.230901.001 V4.81.1.0.BOND release-keys"
resetprop -n ro.build.product.backup "zahedan"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "erfan"
resetprop -n ro.build.host "buildserverdariaostest"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.com.google.clientidbase "android-jimi"
resetprop -n media.recorder.show_manufacturer_and_model "true"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2023-12-01
