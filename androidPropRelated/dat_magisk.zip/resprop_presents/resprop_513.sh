strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "mblu10"
resetprop -n ro.product.vendor.model "mblu10"
resetprop -n ro.product.vendor_dlkm.marketname "mblu10"
resetprop -n ro.product.product.marketname "mblu10"
resetprop -n ro.product.system.marketname "mblu10"
resetprop -n ro.product.odm_dlkm.marketname "mblu10"
resetprop -n ro.product.system_ext.marketname "mblu10"
resetprop -n ro.product.odm_dlkm.model "mblu10"
resetprop -n ro.product.system.model "mblu10"
resetprop -n ro.product.system_ext.model "mblu10"
resetprop -n ro.product.vendor_dlkm.model "mblu10"
resetprop -n bluetooth.device.default_name "mblu10"
resetprop -n ro.product.bootimage.model "mblu10"
resetprop -n ro.product.vendor.marketname "mblu10"
resetprop -n ro.product.marketname "mblu10"
resetprop -n ro.product.odm.model "mblu10"
resetprop -n ro.product.model "mblu10"
resetprop -n ro.product.product.model "mblu10"
resetprop -n ro.product.odm.marketname "mblu10"
resetprop -n ro.product.vendor.manufacturer "ChuangLian"
resetprop -n ro.product.product.manufacturer "ChuangLian"
resetprop -n ro.product.bootimage.manufacturer "ChuangLian"
resetprop -n ro.product.manufacturer "ChuangLian"
resetprop -n ro.product.odm.manufacturer "ChuangLian"
resetprop -n ro.product.system.manufacturer "ChuangLian"
resetprop -n ro.product.system_ext.manufacturer "ChuangLian"
resetprop -n ro.product.vendor_dlkm.manufacturer "ChuangLian"
resetprop -n ro.product.vendor.brand "mblu"
resetprop -n ro.product.product.brand "mblu"
resetprop -n ro.product.vendor_dlkm.brand "mblu"
resetprop -n ro.product.system.brand "mblu"
resetprop -n ro.product.bootimage.brand "mblu"
resetprop -n ro.product.system_ext.brand "mblu"
resetprop -n ro.product.odm.brand "mblu"
resetprop -n ro.product.odm_dlkm.brand "mblu"
resetprop -n ro.product.brand "mblu"
resetprop -n ro.vendor_dlkm.build.fingerprint "ChuangLian/mblu_10_CN/mblu10:11/RP1A.201005.001/2206101530:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "ChuangLian/mblu_10_CN/mblu10:11/RP1A.201005.001/2206101530:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "ChuangLian/mblu_10_CN/mblu10:11/RP1A.201005.001/2206101530:user/release-keys"
resetprop -n ro.odm.build.fingerprint "ChuangLian/mblu_10_CN/mblu10:11/RP1A.201005.001/2206101530:user/release-keys"
resetprop -n ro.system.build.fingerprint "ChuangLian/mblu_10_CN/mblu10:11/RP1A.201005.001/2206101530:user/release-keys"
resetprop -n ro.build.fingerprint "ChuangLian/mblu_10_CN/mblu10:11/RP1A.201005.001/2206101530:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "ChuangLian/mblu_10_CN/mblu10:11/RP1A.201005.001/2206101530:user/release-keys"
resetprop -n ro.product.build.fingerprint "ChuangLian/mblu_10_CN/mblu10:11/RP1A.201005.001/2206101530:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "ChuangLian/mblu_10_CN/mblu10:11/RP1A.201005.001/2206101530:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=89b3c662ce
resetprop -n ro.system.build.version.incremental 2206101530
resetprop -n ro.bootimage.build.version.incremental 2206101530
resetprop -n ro.product.build.version.incremental 2206101530
resetprop -n ro.odm.build.version.incremental 2206101530
resetprop -n ro.vendor_dlkm.build.version.incremental 2206101530
resetprop -n ro.system_ext.build.version.incremental 2206101530
resetprop -n ro.build.version.incremental 2206101530
resetprop -n ro.vendor.build.version.incremental 2206101530
resetprop -n ro.odm.build.id "RP1A.201005.001"
resetprop -n ro.product.build.id "RP1A.201005.001"
resetprop -n ro.bootimage.build.id "RP1A.201005.001"
resetprop -n ro.system_ext.build.id "RP1A.201005.001"
resetprop -n ro.vendor_dlkm.build.id "RP1A.201005.001"
resetprop -n ro.build.id "RP1A.201005.001"
resetprop -n ro.system.build.id "RP1A.201005.001"
resetprop -n ro.vendor.build.id "RP1A.201005.001"
resetprop -n ro.system.build.date "Fri Jun 10 15:27:20 CST 2022"
resetprop -n ro.bootimage.build.date "Fri Jun 10 15:27:20 CST 2022"
resetprop -n ro.product.build.date "Fri Jun 10 15:27:20 CST 2022"
resetprop -n ro.vendor_dlkm.build.date "Fri Jun 10 15:27:20 CST 2022"
resetprop -n ro.system_ext.build.date "Fri Jun 10 15:27:20 CST 2022"
resetprop -n ro.odm.build.date "Fri Jun 10 15:27:20 CST 2022"
resetprop -n ro.build.date "Fri Jun 10 15:27:20 CST 2022"
resetprop -n ro.vendor.build.date "Fri Jun 10 15:27:20 CST 2022"
resetprop -n ro.product.build.date.utc "1654846040"
resetprop -n ro.system_ext.build.date.utc "1654846040"
resetprop -n ro.system.build.date.utc "1654846040"
resetprop -n ro.vendor.build.date.utc "1654846040"
resetprop -n ro.vendor_dlkm.build.date.utc "1654846040"
resetprop -n ro.build.date.utc "1654846040"
resetprop -n ro.bootimage.build.date.utc "1654846040"
resetprop -n ro.odm.build.date.utc "1654846040"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name mblu_10_CN
resetprop -n ro.product.odm.name mblu_10_CN
resetprop -n ro.product.vendor.name mblu_10_CN
resetprop -n ro.product.system.name mblu_10_CN
resetprop -n ro.product.name mblu_10_CN
resetprop -n ro.product.bootimage.name mblu_10_CN
resetprop -n ro.product.vendor_dlkm.name mblu_10_CN
resetprop -n ro.product.system_ext.name mblu_10_CN
resetprop -n ro.build.flavor g2172fua_v1_ga_oj_m01_qd_r_Natv-user
randomStr="g2172fua_v1_ga_oj_m01_qd_r_Natv-user ChuangLian RP1A.201005.001 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=0685f4644fbb
resetprop -n ro.build.host ${randomStr}
randomStr=86773899
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=ZLZYcg
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=ba11b1cf54d7f
randomStr2=7d
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=bc
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "2206101530"
resetprop -n ro.build.description "g2172fua_v1_ga_oj_m01_qd_r_Natv-user 11 RP1A.201005.001 2206101530 release-keys"
resetprop -n ro.build.product.backup "mblu10"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "flyme"
resetprop -n ro.build.host "Mz-KW-Server-N2"
resetprop -n ro.flyme.version.id "Flyme 9.0.4.1A"
resetprop -n ro.meizu.project.id "M2112-9"
resetprop -n ro.product.flyme.model "M2112"
resetprop -n ro.build.flyme.version "9"
resetprop -n ro.build.freemeos_channel_no "HONGXIANGYUAN_HONGXIANGYUAN"
resetprop -n ro.build.freemeos_customer_no "HONGXIANGYUAN"
resetprop -n ro.build.freemeos_customer_br "Droi_g2172fua"
resetprop -n ro.flyme.published "true"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2021-11-01
