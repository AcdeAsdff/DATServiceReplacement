strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Nokia C21 Plus"
resetprop -n ro.product.vendor.model "Nokia C21 Plus"
resetprop -n ro.product.vendor_dlkm.marketname "Nokia C21 Plus"
resetprop -n ro.product.product.marketname "Nokia C21 Plus"
resetprop -n ro.product.system.marketname "Nokia C21 Plus"
resetprop -n ro.product.odm_dlkm.marketname "Nokia C21 Plus"
resetprop -n ro.product.system_ext.marketname "Nokia C21 Plus"
resetprop -n ro.product.odm_dlkm.model "Nokia C21 Plus"
resetprop -n ro.product.system.model "Nokia C21 Plus"
resetprop -n ro.product.system_ext.model "Nokia C21 Plus"
resetprop -n ro.product.vendor_dlkm.model "Nokia C21 Plus"
resetprop -n bluetooth.device.default_name "Nokia C21 Plus"
resetprop -n ro.product.bootimage.model "Nokia C21 Plus"
resetprop -n ro.product.vendor.marketname "Nokia C21 Plus"
resetprop -n ro.product.marketname "Nokia C21 Plus"
resetprop -n ro.product.odm.model "Nokia C21 Plus"
resetprop -n ro.product.model "Nokia C21 Plus"
resetprop -n ro.product.product.model "Nokia C21 Plus"
resetprop -n ro.product.odm.marketname "Nokia C21 Plus"
resetprop -n ro.product.vendor.manufacturer "HMD Global"
resetprop -n ro.product.product.manufacturer "HMD Global"
resetprop -n ro.product.bootimage.manufacturer "HMD Global"
resetprop -n ro.product.manufacturer "HMD Global"
resetprop -n ro.product.odm.manufacturer "HMD Global"
resetprop -n ro.product.system.manufacturer "HMD Global"
resetprop -n ro.product.system_ext.manufacturer "HMD Global"
resetprop -n ro.product.vendor_dlkm.manufacturer "HMD Global"
resetprop -n ro.product.vendor.brand "Nokia"
resetprop -n ro.product.product.brand "Nokia"
resetprop -n ro.product.vendor_dlkm.brand "Nokia"
resetprop -n ro.product.system.brand "Nokia"
resetprop -n ro.product.bootimage.brand "Nokia"
resetprop -n ro.product.system_ext.brand "Nokia"
resetprop -n ro.product.odm.brand "Nokia"
resetprop -n ro.product.odm_dlkm.brand "Nokia"
resetprop -n ro.product.brand "Nokia"
resetprop -n ro.vendor_dlkm.build.fingerprint "Nokia/Hope_00WW/HPE:11/RP1A.201005.001/00WW_1_270:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Nokia/Hope_00WW/HPE:11/RP1A.201005.001/00WW_1_270:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Nokia/Hope_00WW/HPE:11/RP1A.201005.001/00WW_1_270:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Nokia/Hope_00WW/HPE:11/RP1A.201005.001/00WW_1_270:user/release-keys"
resetprop -n ro.system.build.fingerprint "Nokia/Hope_00WW/HPE:11/RP1A.201005.001/00WW_1_270:user/release-keys"
resetprop -n ro.build.fingerprint "Nokia/Hope_00WW/HPE:11/RP1A.201005.001/00WW_1_270:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Nokia/Hope_00WW/HPE:11/RP1A.201005.001/00WW_1_270:user/release-keys"
resetprop -n ro.product.build.fingerprint "Nokia/Hope_00WW/HPE:11/RP1A.201005.001/00WW_1_270:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Nokia/Hope_00WW/HPE:11/RP1A.201005.001/00WW_1_270:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=415c5a8055
resetprop -n ro.system.build.version.incremental 00WW_1_270
resetprop -n ro.bootimage.build.version.incremental 00WW_1_270
resetprop -n ro.product.build.version.incremental 00WW_1_270
resetprop -n ro.odm.build.version.incremental 00WW_1_270
resetprop -n ro.vendor_dlkm.build.version.incremental 00WW_1_270
resetprop -n ro.system_ext.build.version.incremental 00WW_1_270
resetprop -n ro.build.version.incremental 00WW_1_270
resetprop -n ro.vendor.build.version.incremental 00WW_1_270
resetprop -n ro.odm.build.id "RP1A.201005.001"
resetprop -n ro.product.build.id "RP1A.201005.001"
resetprop -n ro.bootimage.build.id "RP1A.201005.001"
resetprop -n ro.system_ext.build.id "RP1A.201005.001"
resetprop -n ro.vendor_dlkm.build.id "RP1A.201005.001"
resetprop -n ro.build.id "RP1A.201005.001"
resetprop -n ro.system.build.id "RP1A.201005.001"
resetprop -n ro.vendor.build.id "RP1A.201005.001"
resetprop -n ro.system.build.date "Sun Apr 23 14:42:53 UTC 2023"
resetprop -n ro.bootimage.build.date "Sun Apr 23 14:42:53 UTC 2023"
resetprop -n ro.product.build.date "Sun Apr 23 14:42:53 UTC 2023"
resetprop -n ro.vendor_dlkm.build.date "Sun Apr 23 14:42:53 UTC 2023"
resetprop -n ro.system_ext.build.date "Sun Apr 23 14:42:53 UTC 2023"
resetprop -n ro.odm.build.date "Sun Apr 23 14:42:53 UTC 2023"
resetprop -n ro.build.date "Sun Apr 23 14:42:53 UTC 2023"
resetprop -n ro.vendor.build.date "Sun Apr 23 14:42:53 UTC 2023"
resetprop -n ro.product.build.date.utc "1682260973"
resetprop -n ro.system_ext.build.date.utc "1682260973"
resetprop -n ro.system.build.date.utc "1682260973"
resetprop -n ro.vendor.build.date.utc "1682260973"
resetprop -n ro.vendor_dlkm.build.date.utc "1682260973"
resetprop -n ro.build.date.utc "1682260973"
resetprop -n ro.bootimage.build.date.utc "1682260973"
resetprop -n ro.odm.build.date.utc "1682260973"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name 19unset
resetprop -n ro.product.odm.name 19unset
resetprop -n ro.product.vendor.name 19unset
resetprop -n ro.product.system.name 19unset
resetprop -n ro.product.name 19unset
resetprop -n ro.product.bootimage.name 19unset
resetprop -n ro.product.vendor_dlkm.name 19unset
resetprop -n ro.product.system_ext.name 19unset
resetprop -n ro.build.flavor T19661AA1_Natv-user
randomStr="T19661AA1_Natv-user HMD Global RP1A.201005.001 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=dba12d4f11db
resetprop -n ro.build.host ${randomStr}
randomStr=cbba8aec
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=wwaoDX
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=59e8315f641cc
randomStr2=f5
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=1a
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "00WW_1_270"
resetprop -n ro.build.description "T19661AA1_Natv-user 11 RP1A.201005.001 16038 release-keys"
resetprop -n ro.build.product.backup "HPE"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "jenkins"
resetprop -n ro.build.host "680e53a218c9"
resetprop -n ro.lmk.critical_upgrade "true"
resetprop -n ro.lmk.upgrade_pressure "40"
resetprop -n ro.lmk.downgrade_pressure "60"
resetprop -n ro.lmk.kill_heaviest_task "false"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2023-03-05
