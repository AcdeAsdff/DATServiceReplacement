strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "h2s"
resetprop -n ro.product.vendor.model "h2s"
resetprop -n ro.product.vendor_dlkm.marketname "h2s"
resetprop -n ro.product.product.marketname "h2s"
resetprop -n ro.product.system.marketname "h2s"
resetprop -n ro.product.odm_dlkm.marketname "h2s"
resetprop -n ro.product.system_ext.marketname "h2s"
resetprop -n ro.product.odm_dlkm.model "h2s"
resetprop -n ro.product.system.model "h2s"
resetprop -n ro.product.system_ext.model "h2s"
resetprop -n ro.product.vendor_dlkm.model "h2s"
resetprop -n bluetooth.device.default_name "h2s"
resetprop -n ro.product.bootimage.model "h2s"
resetprop -n ro.product.vendor.marketname "h2s"
resetprop -n ro.product.marketname "h2s"
resetprop -n ro.product.odm.model "h2s"
resetprop -n ro.product.model "h2s"
resetprop -n ro.product.product.model "h2s"
resetprop -n ro.product.odm.marketname "h2s"
resetprop -n ro.product.vendor.manufacturer "alps"
resetprop -n ro.product.product.manufacturer "alps"
resetprop -n ro.product.bootimage.manufacturer "alps"
resetprop -n ro.product.manufacturer "alps"
resetprop -n ro.product.odm.manufacturer "alps"
resetprop -n ro.product.system.manufacturer "alps"
resetprop -n ro.product.system_ext.manufacturer "alps"
resetprop -n ro.product.vendor_dlkm.manufacturer "alps"
resetprop -n ro.product.vendor.brand "alps"
resetprop -n ro.product.product.brand "alps"
resetprop -n ro.product.vendor_dlkm.brand "alps"
resetprop -n ro.product.system.brand "alps"
resetprop -n ro.product.bootimage.brand "alps"
resetprop -n ro.product.system_ext.brand "alps"
resetprop -n ro.product.odm.brand "alps"
resetprop -n ro.product.odm_dlkm.brand "alps"
resetprop -n ro.product.brand "alps"
resetprop -n ro.vendor_dlkm.build.fingerprint "alps/full_h2s/h2s:10/QP1A.190711.020/2022042707_1.0.0:userdebug/dev-keys"
resetprop -n ro.bootimage.build.fingerprint "alps/full_h2s/h2s:10/QP1A.190711.020/2022042707_1.0.0:userdebug/dev-keys"
resetprop -n ro.vendor.build.fingerprint "alps/full_h2s/h2s:10/QP1A.190711.020/2022042707_1.0.0:userdebug/dev-keys"
resetprop -n ro.odm.build.fingerprint "alps/full_h2s/h2s:10/QP1A.190711.020/2022042707_1.0.0:userdebug/dev-keys"
resetprop -n ro.system.build.fingerprint "alps/full_h2s/h2s:10/QP1A.190711.020/2022042707_1.0.0:userdebug/dev-keys"
resetprop -n ro.build.fingerprint "alps/full_h2s/h2s:10/QP1A.190711.020/2022042707_1.0.0:userdebug/dev-keys"
resetprop -n ro.system_ext.build.fingerprint "alps/full_h2s/h2s:10/QP1A.190711.020/2022042707_1.0.0:userdebug/dev-keys"
resetprop -n ro.product.build.fingerprint "alps/full_h2s/h2s:10/QP1A.190711.020/2022042707_1.0.0:userdebug/dev-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "alps/full_h2s/h2s:10/QP1A.190711.020/2022042707_1.0.0:userdebug/dev-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=d593831fd8
resetprop -n ro.system.build.version.incremental 2022042707_1.0.0
resetprop -n ro.bootimage.build.version.incremental 2022042707_1.0.0
resetprop -n ro.product.build.version.incremental 2022042707_1.0.0
resetprop -n ro.odm.build.version.incremental 2022042707_1.0.0
resetprop -n ro.vendor_dlkm.build.version.incremental 2022042707_1.0.0
resetprop -n ro.system_ext.build.version.incremental 2022042707_1.0.0
resetprop -n ro.build.version.incremental 2022042707_1.0.0
resetprop -n ro.vendor.build.version.incremental 2022042707_1.0.0
resetprop -n ro.odm.build.id "QP1A.190711.020"
resetprop -n ro.product.build.id "QP1A.190711.020"
resetprop -n ro.bootimage.build.id "QP1A.190711.020"
resetprop -n ro.system_ext.build.id "QP1A.190711.020"
resetprop -n ro.vendor_dlkm.build.id "QP1A.190711.020"
resetprop -n ro.build.id "QP1A.190711.020"
resetprop -n ro.system.build.id "QP1A.190711.020"
resetprop -n ro.vendor.build.id "QP1A.190711.020"
resetprop -n ro.system.build.date "Wed Apr 27 07:43:49 CST 2022"
resetprop -n ro.bootimage.build.date "Wed Apr 27 07:43:49 CST 2022"
resetprop -n ro.product.build.date "Wed Apr 27 07:43:49 CST 2022"
resetprop -n ro.vendor_dlkm.build.date "Wed Apr 27 07:43:49 CST 2022"
resetprop -n ro.system_ext.build.date "Wed Apr 27 07:43:49 CST 2022"
resetprop -n ro.odm.build.date "Wed Apr 27 07:43:49 CST 2022"
resetprop -n ro.build.date "Wed Apr 27 07:43:49 CST 2022"
resetprop -n ro.vendor.build.date "Wed Apr 27 07:43:49 CST 2022"
resetprop -n ro.product.build.date.utc "1651016629"
resetprop -n ro.system_ext.build.date.utc "1651016629"
resetprop -n ro.system.build.date.utc "1651016629"
resetprop -n ro.vendor.build.date.utc "1651016629"
resetprop -n ro.vendor_dlkm.build.date.utc "1651016629"
resetprop -n ro.build.date.utc "1651016629"
resetprop -n ro.bootimage.build.date.utc "1651016629"
resetprop -n ro.odm.build.date.utc "1651016629"
resetprop -n ro.product.build.tags "dev-keys"
resetprop -n ro.build.tags "dev-keys"
resetprop -n ro.odm.build.tags "dev-keys"
resetprop -n ro.bootimage.build.tags "dev-keys"
resetprop -n ro.vendor_dlkm.build.tags "dev-keys"
resetprop -n ro.system_ext.build.tags "dev-keys"
resetprop -n ro.vendor.build.tags "dev-keys"
resetprop -n ro.system.build.tags "dev-keys"
resetprop -n ro.system.build.type "userdebug"
resetprop -n ro.system_ext.build.type "userdebug"
resetprop -n ro.vendor_dlkm.build.type "userdebug"
resetprop -n ro.bootimage.build.type "userdebug"
resetprop -n ro.product.build.type "userdebug"
resetprop -n ro.odm.build.type "userdebug"
resetprop -n ro.vendor.build.type "userdebug"
resetprop -n ro.product.product.name h2s
resetprop -n ro.product.odm.name h2s
resetprop -n ro.product.vendor.name h2s
resetprop -n ro.product.system.name h2s
resetprop -n ro.product.name h2s
resetprop -n ro.product.bootimage.name h2s
resetprop -n ro.product.vendor_dlkm.name h2s
resetprop -n ro.product.system_ext.name h2s
resetprop -n ro.build.flavor full_h2s-userdebug
randomStr="full_h2s-userdebug alps QP1A.190711.020 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=6a3c6f6d996e
resetprop -n ro.build.host ${randomStr}
randomStr=bad58b96
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=gCVIpY
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=a4ad17b170489
randomStr2=60
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=f0
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "2022042707_1.0.0"
resetprop -n ro.build.description "full_h2s-userdebug 10 QP1A.190711.020 2022042707_1.0.0 dev-keys"
resetprop -n ro.build.product.backup "h2s"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "smartcm"
resetprop -n ro.build.host "build4"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2021-11-05
