strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "GIONEE S11S"
resetprop -n ro.product.vendor.model "GIONEE S11S"
resetprop -n ro.product.vendor_dlkm.marketname "GIONEE S11S"
resetprop -n ro.product.product.marketname "GIONEE S11S"
resetprop -n ro.product.system.marketname "GIONEE S11S"
resetprop -n ro.product.odm_dlkm.marketname "GIONEE S11S"
resetprop -n ro.product.system_ext.marketname "GIONEE S11S"
resetprop -n ro.product.odm_dlkm.model "GIONEE S11S"
resetprop -n ro.product.system.model "GIONEE S11S"
resetprop -n ro.product.system_ext.model "GIONEE S11S"
resetprop -n ro.product.vendor_dlkm.model "GIONEE S11S"
resetprop -n bluetooth.device.default_name "GIONEE S11S"
resetprop -n ro.product.bootimage.model "GIONEE S11S"
resetprop -n ro.product.vendor.marketname "GIONEE S11S"
resetprop -n ro.product.marketname "GIONEE S11S"
resetprop -n ro.product.odm.model "GIONEE S11S"
resetprop -n ro.product.model "GIONEE S11S"
resetprop -n ro.product.product.model "GIONEE S11S"
resetprop -n ro.product.odm.marketname "GIONEE S11S"
resetprop -n ro.product.vendor.manufacturer "GIONEE"
resetprop -n ro.product.product.manufacturer "GIONEE"
resetprop -n ro.product.bootimage.manufacturer "GIONEE"
resetprop -n ro.product.manufacturer "GIONEE"
resetprop -n ro.product.odm.manufacturer "GIONEE"
resetprop -n ro.product.system.manufacturer "GIONEE"
resetprop -n ro.product.system_ext.manufacturer "GIONEE"
resetprop -n ro.product.vendor_dlkm.manufacturer "GIONEE"
resetprop -n ro.product.vendor.brand "GIONEE"
resetprop -n ro.product.product.brand "GIONEE"
resetprop -n ro.product.vendor_dlkm.brand "GIONEE"
resetprop -n ro.product.system.brand "GIONEE"
resetprop -n ro.product.bootimage.brand "GIONEE"
resetprop -n ro.product.system_ext.brand "GIONEE"
resetprop -n ro.product.odm.brand "GIONEE"
resetprop -n ro.product.odm_dlkm.brand "GIONEE"
resetprop -n ro.product.brand "GIONEE"
resetprop -n ro.vendor_dlkm.build.fingerprint "GIONEE/S11S/GIONEE_SW17G12:7.1.1/N6F26Q/1509594663:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "GIONEE/S11S/GIONEE_SW17G12:7.1.1/N6F26Q/1509594663:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "GIONEE/S11S/GIONEE_SW17G12:7.1.1/N6F26Q/1509594663:user/release-keys"
resetprop -n ro.odm.build.fingerprint "GIONEE/S11S/GIONEE_SW17G12:7.1.1/N6F26Q/1509594663:user/release-keys"
resetprop -n ro.system.build.fingerprint "GIONEE/S11S/GIONEE_SW17G12:7.1.1/N6F26Q/1509594663:user/release-keys"
resetprop -n ro.build.fingerprint "GIONEE/S11S/GIONEE_SW17G12:7.1.1/N6F26Q/1509594663:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "GIONEE/S11S/GIONEE_SW17G12:7.1.1/N6F26Q/1509594663:user/release-keys"
resetprop -n ro.product.build.fingerprint "GIONEE/S11S/GIONEE_SW17G12:7.1.1/N6F26Q/1509594663:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "GIONEE/S11S/GIONEE_SW17G12:7.1.1/N6F26Q/1509594663:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=dd3e2bc216
resetprop -n ro.system.build.version.incremental 1509594663
resetprop -n ro.bootimage.build.version.incremental 1509594663
resetprop -n ro.product.build.version.incremental 1509594663
resetprop -n ro.odm.build.version.incremental 1509594663
resetprop -n ro.vendor_dlkm.build.version.incremental 1509594663
resetprop -n ro.system_ext.build.version.incremental 1509594663
resetprop -n ro.build.version.incremental 1509594663
resetprop -n ro.vendor.build.version.incremental 1509594663
resetprop -n ro.odm.build.id "N6F26Q"
resetprop -n ro.product.build.id "N6F26Q"
resetprop -n ro.bootimage.build.id "N6F26Q"
resetprop -n ro.system_ext.build.id "N6F26Q"
resetprop -n ro.vendor_dlkm.build.id "N6F26Q"
resetprop -n ro.build.id "N6F26Q"
resetprop -n ro.system.build.id "N6F26Q"
resetprop -n ro.vendor.build.id "N6F26Q"
resetprop -n ro.system.build.date "2017年 12月 05日 星期二 12:54:52 CST"
resetprop -n ro.bootimage.build.date "2017年 12月 05日 星期二 12:54:52 CST"
resetprop -n ro.product.build.date "2017年 12月 05日 星期二 12:54:52 CST"
resetprop -n ro.vendor_dlkm.build.date "2017年 12月 05日 星期二 12:54:52 CST"
resetprop -n ro.system_ext.build.date "2017年 12月 05日 星期二 12:54:52 CST"
resetprop -n ro.odm.build.date "2017年 12月 05日 星期二 12:54:52 CST"
resetprop -n ro.build.date "2017年 12月 05日 星期二 12:54:52 CST"
resetprop -n ro.vendor.build.date "2017年 12月 05日 星期二 12:54:52 CST"
resetprop -n ro.product.build.date.utc "1512449692"
resetprop -n ro.system_ext.build.date.utc "1512449692"
resetprop -n ro.system.build.date.utc "1512449692"
resetprop -n ro.vendor.build.date.utc "1512449692"
resetprop -n ro.vendor_dlkm.build.date.utc "1512449692"
resetprop -n ro.build.date.utc "1512449692"
resetprop -n ro.bootimage.build.date.utc "1512449692"
resetprop -n ro.odm.build.date.utc "1512449692"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name S11S
resetprop -n ro.product.odm.name S11S
resetprop -n ro.product.vendor.name S11S
resetprop -n ro.product.system.name S11S
resetprop -n ro.product.name S11S
resetprop -n ro.product.bootimage.name S11S
resetprop -n ro.product.vendor_dlkm.name S11S
resetprop -n ro.product.system_ext.name S11S
resetprop -n ro.build.flavor full_gnsz6758_66_n-user
randomStr="full_gnsz6758_66_n-user GIONEE N6F26Q "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=04fbbac9257c
resetprop -n ro.build.host ${randomStr}
randomStr=372a9d69
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=GzZXVf
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=3a8221c5a4f44
randomStr2=d1
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=3e
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1509594663"
resetprop -n ro.build.description "full_gnsz6758_66_n-user 7.1.1 N6F26Q 1509594663 release-keys"
resetprop -n persist.mtk_ct_volte_support "1"
resetprop -n persist.mtk_dynamic_ims_switch "1"
resetprop -n persist.mtk_epdg_support "1"
resetprop -n persist.mtk_ims_support "1"
resetprop -n persist.mtk_nlp_switch_support "1"
resetprop -n persist.mtk_vilte_support "1"
resetprop -n persist.mtk_viwifi_support "1"
resetprop -n persist.mtk_volte_support "1"
resetprop -n persist.mtk_wfc_support "1"
resetprop -n persist.radio.mtk_dsbp_support "1"
resetprop -n persist.radio.mtk_ps2_rat "W/G"
resetprop -n persist.radio.mtk_ps3_rat "G"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.build.host "COMPILER-27"
resetprop -n ro.build.product.backup "GIONEE_SW17G12"
resetprop -n ro.build.user "android"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.com.google.clientidbase "android-gionee"
resetprop -n ro.mediatek.chip_ver "S01"
resetprop -n ro.mediatek.platform "MT6758"
resetprop -n ro.mediatek.version.branch "alps-mp-n1.mp15"
resetprop -n ro.mediatek.version.release "SW17G12A02_A_T2029"
resetprop -n ro.mediatek.version.sdk "4"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mtk_aal_support "1"
resetprop -n ro.mtk_afw_support "1"
resetprop -n ro.mtk_agps_app "1"
resetprop -n ro.mtk_audio_tuning_tool_ver "V2.2"
resetprop -n ro.mtk_bg_power_saving_ui "1"
resetprop -n ro.mtk_bip_scws "1"
resetprop -n ro.mtk_blulight_def_support "1"
resetprop -n ro.mtk_bt_support "1"
resetprop -n ro.mtk_c2k_support "1"
resetprop -n ro.mtk_cam_img_refocus_support "1"
resetprop -n ro.mtk_cam_lomo_support "1"
resetprop -n ro.mtk_cam_mfb_support "3"
resetprop -n ro.mtk_ct4greg_app "1"
resetprop -n ro.mtk_cta_drm_support "1"
resetprop -n ro.mtk_cta_set "1"
resetprop -n ro.mtk_ctm_flag "1"
resetprop -n ro.mtk_deinterlace_support "1"
resetprop -n ro.mtk_devreg_app "1"
resetprop -n ro.mtk_dhcpv6c_wifi "1"
resetprop -n ro.mtk_dialer_search_support "1"
resetprop -n ro.mtk_dual_mic_support "1"
resetprop -n ro.mtk_eap_sim_aka "1"
resetprop -n ro.mtk_emmc_support "1"
resetprop -n ro.mtk_enable_md1 "1"
resetprop -n ro.mtk_enable_md3 "1"
resetprop -n ro.mtk_external_sim_only_slots "0"
resetprop -n ro.mtk_external_sim_support "1"
resetprop -n ro.mtk_fd_support "1"
resetprop -n ro.mtk_fm_recording_support "1"
resetprop -n ro.mtk_gps_support "1"
resetprop -n ro.mtk_ims_video_call_support "vilte_viwifi"
resetprop -n ro.mtk_is_tablet "0"
resetprop -n ro.mtk_log_hide_gps "0"
resetprop -n ro.mtk_lte_support "1"
resetprop -n ro.mtk_md_direct_tethering "1"
resetprop -n ro.mtk_md_sbp_custom_value "0"
resetprop -n ro.mtk_md_world_mode_support "1"
resetprop -n ro.mtk_microtrust_tee_support "1"
resetprop -n ro.mtk_modem_monitor_support "1"
resetprop -n ro.mtk_multiple_ims_support "1"
resetprop -n ro.mtk_oma_drm_support "1"
resetprop -n ro.mtk_omacp_support "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perfservice_support "1"
resetprop -n ro.mtk_pow_perf_support "1"
resetprop -n ro.mtk_pq_color_mode "1"
resetprop -n ro.mtk_pq_support "2"
resetprop -n ro.mtk_protocol1_rat_config "C/Lf/Lt/W/T/G"
resetprop -n ro.mtk_rebootmeta_support "1"
resetprop -n ro.mtk_ril_mode "c6m_3rild"
resetprop -n ro.mtk_rild_read_imsi "1"
resetprop -n ro.mtk_search_db_support "1"
resetprop -n ro.mtk_send_rr_support "1"
resetprop -n ro.mtk_shared_sdcard "1"
resetprop -n ro.mtk_sim_hot_swap "1"
resetprop -n ro.mtk_sim_hot_swap_common_slot "1"
resetprop -n ro.mtk_slow_motion_support "1"
resetprop -n ro.mtk_soter_support "1"
resetprop -n ro.mtk_system_update_support "1"
resetprop -n ro.mtk_tetheringipv6_support "1"
resetprop -n ro.mtk_vilte_ut_support "0"
resetprop -n ro.mtk_wapi_support "1"
resetprop -n ro.mtk_wappush_support "1"
resetprop -n ro.mtk_wfd_support "1"
resetprop -n ro.mtk_widevine_drm_l3_support "1"
resetprop -n ro.mtk_wifi_mcc_support "1"
resetprop -n ro.mtk_wlan_support "1"
resetprop -n ro.mtk_world_phone_policy "0"
resetprop -n ro.mtk_zsdhdr_support "1"
resetprop -n sys.mtk_md_direct_tether_enable "true"
resetprop -n ro.expect.recovery_id "0x4228150c210db32e5ec812874d0ecf2444ce4f20000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2017-11-05
