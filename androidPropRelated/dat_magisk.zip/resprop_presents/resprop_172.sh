strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "KFQUWI"
resetprop -n ro.product.vendor.model "KFQUWI"
resetprop -n ro.product.vendor_dlkm.marketname "KFQUWI"
resetprop -n ro.product.product.marketname "KFQUWI"
resetprop -n ro.product.system.marketname "KFQUWI"
resetprop -n ro.product.odm_dlkm.marketname "KFQUWI"
resetprop -n ro.product.system_ext.marketname "KFQUWI"
resetprop -n ro.product.odm_dlkm.model "KFQUWI"
resetprop -n ro.product.system.model "KFQUWI"
resetprop -n ro.product.system_ext.model "KFQUWI"
resetprop -n ro.product.vendor_dlkm.model "KFQUWI"
resetprop -n bluetooth.device.default_name "KFQUWI"
resetprop -n ro.product.bootimage.model "KFQUWI"
resetprop -n ro.product.vendor.marketname "KFQUWI"
resetprop -n ro.product.marketname "KFQUWI"
resetprop -n ro.product.odm.model "KFQUWI"
resetprop -n ro.product.model "KFQUWI"
resetprop -n ro.product.product.model "KFQUWI"
resetprop -n ro.product.odm.marketname "KFQUWI"
resetprop -n ro.product.vendor.manufacturer "Amazon"
resetprop -n ro.product.product.manufacturer "Amazon"
resetprop -n ro.product.bootimage.manufacturer "Amazon"
resetprop -n ro.product.manufacturer "Amazon"
resetprop -n ro.product.odm.manufacturer "Amazon"
resetprop -n ro.product.system.manufacturer "Amazon"
resetprop -n ro.product.system_ext.manufacturer "Amazon"
resetprop -n ro.product.vendor_dlkm.manufacturer "Amazon"
resetprop -n ro.product.vendor.brand "Amazon"
resetprop -n ro.product.product.brand "Amazon"
resetprop -n ro.product.vendor_dlkm.brand "Amazon"
resetprop -n ro.product.system.brand "Amazon"
resetprop -n ro.product.bootimage.brand "Amazon"
resetprop -n ro.product.system_ext.brand "Amazon"
resetprop -n ro.product.odm.brand "Amazon"
resetprop -n ro.product.odm_dlkm.brand "Amazon"
resetprop -n ro.product.brand "Amazon"
resetprop -n ro.vendor_dlkm.build.fingerprint "Amazon/quartz/quartz:11/RS8322.2053N/0022045787392:user/amz-p,release-keys"
resetprop -n ro.bootimage.build.fingerprint "Amazon/quartz/quartz:11/RS8322.2053N/0022045787392:user/amz-p,release-keys"
resetprop -n ro.vendor.build.fingerprint "Amazon/quartz/quartz:11/RS8322.2053N/0022045787392:user/amz-p,release-keys"
resetprop -n ro.odm.build.fingerprint "Amazon/quartz/quartz:11/RS8322.2053N/0022045787392:user/amz-p,release-keys"
resetprop -n ro.system.build.fingerprint "Amazon/quartz/quartz:11/RS8322.2053N/0022045787392:user/amz-p,release-keys"
resetprop -n ro.build.fingerprint "Amazon/quartz/quartz:11/RS8322.2053N/0022045787392:user/amz-p,release-keys"
resetprop -n ro.system_ext.build.fingerprint "Amazon/quartz/quartz:11/RS8322.2053N/0022045787392:user/amz-p,release-keys"
resetprop -n ro.product.build.fingerprint "Amazon/quartz/quartz:11/RS8322.2053N/0022045787392:user/amz-p,release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Amazon/quartz/quartz:11/RS8322.2053N/0022045787392:user/amz-p,release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=62adc9dae2
resetprop -n ro.system.build.version.incremental 0022045787524
resetprop -n ro.bootimage.build.version.incremental 0022045787524
resetprop -n ro.product.build.version.incremental 0022045787524
resetprop -n ro.odm.build.version.incremental 0022045787524
resetprop -n ro.vendor_dlkm.build.version.incremental 0022045787524
resetprop -n ro.system_ext.build.version.incremental 0022045787524
resetprop -n ro.build.version.incremental 0022045787524
resetprop -n ro.vendor.build.version.incremental 0022045787524
resetprop -n ro.odm.build.id "RS8322.2053N"
resetprop -n ro.product.build.id "RS8322.2053N"
resetprop -n ro.bootimage.build.id "RS8322.2053N"
resetprop -n ro.system_ext.build.id "RS8322.2053N"
resetprop -n ro.vendor_dlkm.build.id "RS8322.2053N"
resetprop -n ro.build.id "RS8322.2053N"
resetprop -n ro.system.build.id "RS8322.2053N"
resetprop -n ro.vendor.build.id "RS8322.2053N"
resetprop -n ro.system.build.date "Sat Jan 13 10:50:45 UTC 2024"
resetprop -n ro.bootimage.build.date "Sat Jan 13 10:50:45 UTC 2024"
resetprop -n ro.product.build.date "Sat Jan 13 10:50:45 UTC 2024"
resetprop -n ro.vendor_dlkm.build.date "Sat Jan 13 10:50:45 UTC 2024"
resetprop -n ro.system_ext.build.date "Sat Jan 13 10:50:45 UTC 2024"
resetprop -n ro.odm.build.date "Sat Jan 13 10:50:45 UTC 2024"
resetprop -n ro.build.date "Sat Jan 13 10:50:45 UTC 2024"
resetprop -n ro.vendor.build.date "Sat Jan 13 10:50:45 UTC 2024"
resetprop -n ro.product.build.date.utc "1705143045"
resetprop -n ro.system_ext.build.date.utc "1705143045"
resetprop -n ro.system.build.date.utc "1705143045"
resetprop -n ro.vendor.build.date.utc "1705143045"
resetprop -n ro.vendor_dlkm.build.date.utc "1705143045"
resetprop -n ro.build.date.utc "1705143045"
resetprop -n ro.bootimage.build.date.utc "1705143045"
resetprop -n ro.odm.build.date.utc "1705143045"
resetprop -n ro.product.build.tags "amz-p,release-keys"
resetprop -n ro.build.tags "amz-p,release-keys"
resetprop -n ro.odm.build.tags "amz-p,release-keys"
resetprop -n ro.bootimage.build.tags "amz-p,release-keys"
resetprop -n ro.vendor_dlkm.build.tags "amz-p,release-keys"
resetprop -n ro.system_ext.build.tags "amz-p,release-keys"
resetprop -n ro.vendor.build.tags "amz-p,release-keys"
resetprop -n ro.system.build.tags "amz-p,release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name quartz
resetprop -n ro.product.odm.name quartz
resetprop -n ro.product.vendor.name quartz
resetprop -n ro.product.system.name quartz
resetprop -n ro.product.name quartz
resetprop -n ro.product.bootimage.name quartz
resetprop -n ro.product.vendor_dlkm.name quartz
resetprop -n ro.product.system_ext.name quartz
resetprop -n ro.build.flavor quartz-user
randomStr="quartz-user Amazon RS8322.2053N "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=6793083635f1
resetprop -n ro.build.host ${randomStr}
randomStr=434c6af2
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=RprASP
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=ce4295645fa02
randomStr2=2e
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=ec
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "0022045787524"
resetprop -n ro.build.description "quartz-user 11 RS8322.2053N 0022045787392 amz-p,release-keys"
resetprop -n ro.build.product.backup "quartz"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "build"
resetprop -n ro.build.host "c5-ri-1804-use1a-b-18-04-fos8-21"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2020-09-05
