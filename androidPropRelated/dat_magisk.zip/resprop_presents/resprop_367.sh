strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "SHAHIN III"
resetprop -n ro.product.vendor.model "SHAHIN III"
resetprop -n ro.product.vendor_dlkm.marketname "SHAHIN III"
resetprop -n ro.product.product.marketname "SHAHIN III"
resetprop -n ro.product.system.marketname "SHAHIN III"
resetprop -n ro.product.odm_dlkm.marketname "SHAHIN III"
resetprop -n ro.product.system_ext.marketname "SHAHIN III"
resetprop -n ro.product.odm_dlkm.model "SHAHIN III"
resetprop -n ro.product.system.model "SHAHIN III"
resetprop -n ro.product.system_ext.model "SHAHIN III"
resetprop -n ro.product.vendor_dlkm.model "SHAHIN III"
resetprop -n bluetooth.device.default_name "SHAHIN III"
resetprop -n ro.product.bootimage.model "SHAHIN III"
resetprop -n ro.product.vendor.marketname "SHAHIN III"
resetprop -n ro.product.marketname "SHAHIN III"
resetprop -n ro.product.odm.model "SHAHIN III"
resetprop -n ro.product.model "SHAHIN III"
resetprop -n ro.product.product.model "SHAHIN III"
resetprop -n ro.product.odm.marketname "SHAHIN III"
resetprop -n ro.product.vendor.manufacturer "General luxe"
resetprop -n ro.product.product.manufacturer "General luxe"
resetprop -n ro.product.bootimage.manufacturer "General luxe"
resetprop -n ro.product.manufacturer "General luxe"
resetprop -n ro.product.odm.manufacturer "General luxe"
resetprop -n ro.product.system.manufacturer "General luxe"
resetprop -n ro.product.system_ext.manufacturer "General luxe"
resetprop -n ro.product.vendor_dlkm.manufacturer "General luxe"
resetprop -n ro.product.vendor.brand "General_luxe"
resetprop -n ro.product.product.brand "General_luxe"
resetprop -n ro.product.vendor_dlkm.brand "General_luxe"
resetprop -n ro.product.system.brand "General_luxe"
resetprop -n ro.product.bootimage.brand "General_luxe"
resetprop -n ro.product.system_ext.brand "General_luxe"
resetprop -n ro.product.odm.brand "General_luxe"
resetprop -n ro.product.odm_dlkm.brand "General_luxe"
resetprop -n ro.product.brand "General_luxe"
resetprop -n ro.vendor_dlkm.build.fingerprint "General_luxe/Shahin_III/Shahin_III:11/RP1A.200720.011/1642417636:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "General_luxe/Shahin_III/Shahin_III:11/RP1A.200720.011/1642417636:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "General_luxe/Shahin_III/Shahin_III:11/RP1A.200720.011/1642417636:user/release-keys"
resetprop -n ro.odm.build.fingerprint "General_luxe/Shahin_III/Shahin_III:11/RP1A.200720.011/1642417636:user/release-keys"
resetprop -n ro.system.build.fingerprint "General_luxe/Shahin_III/Shahin_III:11/RP1A.200720.011/1642417636:user/release-keys"
resetprop -n ro.build.fingerprint "General_luxe/Shahin_III/Shahin_III:11/RP1A.200720.011/1642417636:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "General_luxe/Shahin_III/Shahin_III:11/RP1A.200720.011/1642417636:user/release-keys"
resetprop -n ro.product.build.fingerprint "General_luxe/Shahin_III/Shahin_III:11/RP1A.200720.011/1642417636:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "General_luxe/Shahin_III/Shahin_III:11/RP1A.200720.011/1642417636:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=9b8245a0cb
resetprop -n ro.system.build.version.incremental 1642417636
resetprop -n ro.bootimage.build.version.incremental 1642417636
resetprop -n ro.product.build.version.incremental 1642417636
resetprop -n ro.odm.build.version.incremental 1642417636
resetprop -n ro.vendor_dlkm.build.version.incremental 1642417636
resetprop -n ro.system_ext.build.version.incremental 1642417636
resetprop -n ro.build.version.incremental 1642417636
resetprop -n ro.vendor.build.version.incremental 1642417636
resetprop -n ro.odm.build.id "RP1A.200720.011"
resetprop -n ro.product.build.id "RP1A.200720.011"
resetprop -n ro.bootimage.build.id "RP1A.200720.011"
resetprop -n ro.system_ext.build.id "RP1A.200720.011"
resetprop -n ro.vendor_dlkm.build.id "RP1A.200720.011"
resetprop -n ro.build.id "RP1A.200720.011"
resetprop -n ro.system.build.id "RP1A.200720.011"
resetprop -n ro.vendor.build.id "RP1A.200720.011"
resetprop -n ro.system.build.date "Mon Jan 17 19:04:36 CST 2022"
resetprop -n ro.bootimage.build.date "Mon Jan 17 19:04:36 CST 2022"
resetprop -n ro.product.build.date "Mon Jan 17 19:04:36 CST 2022"
resetprop -n ro.vendor_dlkm.build.date "Mon Jan 17 19:04:36 CST 2022"
resetprop -n ro.system_ext.build.date "Mon Jan 17 19:04:36 CST 2022"
resetprop -n ro.odm.build.date "Mon Jan 17 19:04:36 CST 2022"
resetprop -n ro.build.date "Mon Jan 17 19:04:36 CST 2022"
resetprop -n ro.vendor.build.date "Mon Jan 17 19:04:36 CST 2022"
resetprop -n ro.product.build.date.utc "1642417476"
resetprop -n ro.system_ext.build.date.utc "1642417476"
resetprop -n ro.system.build.date.utc "1642417476"
resetprop -n ro.vendor.build.date.utc "1642417476"
resetprop -n ro.vendor_dlkm.build.date.utc "1642417476"
resetprop -n ro.build.date.utc "1642417476"
resetprop -n ro.bootimage.build.date.utc "1642417476"
resetprop -n ro.odm.build.date.utc "1642417476"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name Shahin_III
resetprop -n ro.product.odm.name Shahin_III
resetprop -n ro.product.vendor.name Shahin_III
resetprop -n ro.product.system.name Shahin_III
resetprop -n ro.product.name Shahin_III
resetprop -n ro.product.bootimage.name Shahin_III
resetprop -n ro.product.vendor_dlkm.name Shahin_III
resetprop -n ro.product.system_ext.name Shahin_III
resetprop -n ro.build.flavor full_k6833v1_64-user
randomStr="full_k6833v1_64-user General luxe RP1A.200720.011 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=a2d22077dde2
resetprop -n ro.build.host ${randomStr}
randomStr=5a3acd38
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=KLoEFY
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=f9b339a6076cf
randomStr2=18
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=21
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1642417636"
resetprop -n ro.build.description "full_k6833v1_64-user 11 RP1A.200720.011 1642417636 release-keys"
resetprop -n ro.build.product.backup "Shahin_III"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "pri"
resetprop -n ro.build.host "bs"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2021-12-05
