strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "V10"
resetprop -n ro.product.vendor.model "V10"
resetprop -n ro.product.vendor_dlkm.marketname "V10"
resetprop -n ro.product.product.marketname "V10"
resetprop -n ro.product.system.marketname "V10"
resetprop -n ro.product.odm_dlkm.marketname "V10"
resetprop -n ro.product.system_ext.marketname "V10"
resetprop -n ro.product.odm_dlkm.model "V10"
resetprop -n ro.product.system.model "V10"
resetprop -n ro.product.system_ext.model "V10"
resetprop -n ro.product.vendor_dlkm.model "V10"
resetprop -n bluetooth.device.default_name "V10"
resetprop -n ro.product.bootimage.model "V10"
resetprop -n ro.product.vendor.marketname "V10"
resetprop -n ro.product.marketname "V10"
resetprop -n ro.product.odm.model "V10"
resetprop -n ro.product.model "V10"
resetprop -n ro.product.product.model "V10"
resetprop -n ro.product.odm.marketname "V10"
resetprop -n ro.product.vendor.manufacturer "DOOGEE"
resetprop -n ro.product.product.manufacturer "DOOGEE"
resetprop -n ro.product.bootimage.manufacturer "DOOGEE"
resetprop -n ro.product.manufacturer "DOOGEE"
resetprop -n ro.product.odm.manufacturer "DOOGEE"
resetprop -n ro.product.system.manufacturer "DOOGEE"
resetprop -n ro.product.system_ext.manufacturer "DOOGEE"
resetprop -n ro.product.vendor_dlkm.manufacturer "DOOGEE"
resetprop -n ro.product.vendor.brand "DOOGEE"
resetprop -n ro.product.product.brand "DOOGEE"
resetprop -n ro.product.vendor_dlkm.brand "DOOGEE"
resetprop -n ro.product.system.brand "DOOGEE"
resetprop -n ro.product.bootimage.brand "DOOGEE"
resetprop -n ro.product.system_ext.brand "DOOGEE"
resetprop -n ro.product.odm.brand "DOOGEE"
resetprop -n ro.product.odm_dlkm.brand "DOOGEE"
resetprop -n ro.product.brand "DOOGEE"
resetprop -n ro.vendor_dlkm.build.fingerprint "DOOGEE/V10_EEA/V10:11/RP1A.200720.011/1627875578:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "DOOGEE/V10_EEA/V10:11/RP1A.200720.011/1627875578:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "DOOGEE/V10_EEA/V10:11/RP1A.200720.011/1627875578:user/release-keys"
resetprop -n ro.odm.build.fingerprint "DOOGEE/V10_EEA/V10:11/RP1A.200720.011/1627875578:user/release-keys"
resetprop -n ro.system.build.fingerprint "DOOGEE/V10_EEA/V10:11/RP1A.200720.011/1627875578:user/release-keys"
resetprop -n ro.build.fingerprint "DOOGEE/V10_EEA/V10:11/RP1A.200720.011/1627875578:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "DOOGEE/V10_EEA/V10:11/RP1A.200720.011/1627875578:user/release-keys"
resetprop -n ro.product.build.fingerprint "DOOGEE/V10_EEA/V10:11/RP1A.200720.011/1627875578:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "DOOGEE/V10_EEA/V10:11/RP1A.200720.011/1627875578:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=3e2970f19c
resetprop -n ro.system.build.version.incremental 1627875578
resetprop -n ro.bootimage.build.version.incremental 1627875578
resetprop -n ro.product.build.version.incremental 1627875578
resetprop -n ro.odm.build.version.incremental 1627875578
resetprop -n ro.vendor_dlkm.build.version.incremental 1627875578
resetprop -n ro.system_ext.build.version.incremental 1627875578
resetprop -n ro.build.version.incremental 1627875578
resetprop -n ro.vendor.build.version.incremental 1627875578
resetprop -n ro.odm.build.id "RP1A.200720.011"
resetprop -n ro.product.build.id "RP1A.200720.011"
resetprop -n ro.bootimage.build.id "RP1A.200720.011"
resetprop -n ro.system_ext.build.id "RP1A.200720.011"
resetprop -n ro.vendor_dlkm.build.id "RP1A.200720.011"
resetprop -n ro.build.id "RP1A.200720.011"
resetprop -n ro.system.build.id "RP1A.200720.011"
resetprop -n ro.vendor.build.id "RP1A.200720.011"
resetprop -n ro.system.build.date "Tue Aug 17 23:01:01 CST 2021"
resetprop -n ro.bootimage.build.date "Tue Aug 17 23:01:01 CST 2021"
resetprop -n ro.product.build.date "Tue Aug 17 23:01:01 CST 2021"
resetprop -n ro.vendor_dlkm.build.date "Tue Aug 17 23:01:01 CST 2021"
resetprop -n ro.system_ext.build.date "Tue Aug 17 23:01:01 CST 2021"
resetprop -n ro.odm.build.date "Tue Aug 17 23:01:01 CST 2021"
resetprop -n ro.build.date "Tue Aug 17 23:01:01 CST 2021"
resetprop -n ro.vendor.build.date "Tue Aug 17 23:01:01 CST 2021"
resetprop -n ro.product.build.date.utc "1629212461"
resetprop -n ro.system_ext.build.date.utc "1629212461"
resetprop -n ro.system.build.date.utc "1629212461"
resetprop -n ro.vendor.build.date.utc "1629212461"
resetprop -n ro.vendor_dlkm.build.date.utc "1629212461"
resetprop -n ro.build.date.utc "1629212461"
resetprop -n ro.bootimage.build.date.utc "1629212461"
resetprop -n ro.odm.build.date.utc "1629212461"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name V10_EEA
resetprop -n ro.product.odm.name V10_EEA
resetprop -n ro.product.vendor.name V10_EEA
resetprop -n ro.product.system.name V10_EEA
resetprop -n ro.product.name V10_EEA
resetprop -n ro.product.bootimage.name V10_EEA
resetprop -n ro.product.vendor_dlkm.name V10_EEA
resetprop -n ro.product.system_ext.name V10_EEA
resetprop -n ro.build.flavor full_k6833v1_64-user
randomStr="full_k6833v1_64-user DOOGEE RP1A.200720.011 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=9da16c069e97
resetprop -n ro.build.host ${randomStr}
randomStr=4a7a7a12
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=bgGren
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=e7aa7ec8eaebf
randomStr2=9a
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=8b
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1627875578"
resetprop -n ro.build.description "full_k6833v1_64-user 11 RP1A.200720.011 mp3V240 release-keys"
resetprop -n ro.build.product.backup "V10_EEA"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "release"
resetprop -n ro.build.host "ubuntu"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.hct_modify_phone_info "1"
resetprop -n ro.hct_hal_watermark_support "1"
resetprop -n ro.hct_systemui_qs_default "1"
resetprop -n ro.hct_statusbar_style "1"
resetprop -n ro.hct_chlidmode_support "1"
resetprop -n ro.hct_support_reversecharger "1"
resetprop -n ro.hct_gamemode_support "1"
resetprop -n ro.hct_trustkernel_tee_support "1"
resetprop -n ro.hct_support_singlehand "1"
resetprop -n ro.hct_superscreen_support "1"
resetprop -n ro.hct_thermometer_support "1"
resetprop -n ro.hct_thermal_measure_nvram_lid "79"
resetprop -n ro.hct_suport_anr_tools "1"
resetprop -n ro.hct_sos "1"
resetprop -n ro.hct_support_scancode "1"
resetprop -n ro.hct_step_record "1"
resetprop -n ro.hct_smart_key "1"
resetprop -n ro.hct_clock_change_theme "1"
resetprop -n ro.hct_multi_finger_gesture "1"
resetprop -n ro.hct_single_page_launcher3 "1"
resetprop -n ro.hct_system_manager "1"
resetprop -n ro.hct_support_power_save "1"
resetprop -n ro.freeme_freemanager "1"
resetprop -n ro.hct_autostart_manager "1"
resetprop -n ro.hct_clean_onekey "1"
resetprop -n ro.hct_deep_clean "1"
resetprop -n ro.hct_background_clean_memory "1"
resetprop -n ro.hct_camera_support "1"
resetprop -n ro.hct.hct_panorama_support "1"
resetprop -n ro.hct_wide_angle_id "2"
resetprop -n ro.hct_navigation_bar_style "1"
resetprop -n ro.hct_cts_modify "1"
resetprop -n ro.hct_cts_eu_support "1"
resetprop -n ro.hct_lcm_width "720"
resetprop -n ro.hct_lcm_height "1560"
resetprop -n ro.hct_usb_default_mtp "1"
resetprop -n ro.hct_full_folder "false"
resetprop -n ro.hct_locale_system_update "1"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2021-06-05
