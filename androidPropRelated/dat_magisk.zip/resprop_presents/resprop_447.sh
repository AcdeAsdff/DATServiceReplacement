strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "iQOO I1928"
resetprop -n ro.product.vendor.model "iQOO I1928"
resetprop -n ro.product.vendor_dlkm.marketname "iQOO I1928"
resetprop -n ro.product.product.marketname "iQOO I1928"
resetprop -n ro.product.system.marketname "iQOO I1928"
resetprop -n ro.product.odm_dlkm.marketname "iQOO I1928"
resetprop -n ro.product.system_ext.marketname "iQOO I1928"
resetprop -n ro.product.odm_dlkm.model "iQOO I1928"
resetprop -n ro.product.system.model "iQOO I1928"
resetprop -n ro.product.system_ext.model "iQOO I1928"
resetprop -n ro.product.vendor_dlkm.model "iQOO I1928"
resetprop -n bluetooth.device.default_name "iQOO I1928"
resetprop -n ro.product.bootimage.model "iQOO I1928"
resetprop -n ro.product.vendor.marketname "iQOO I1928"
resetprop -n ro.product.marketname "iQOO I1928"
resetprop -n ro.product.odm.model "iQOO I1928"
resetprop -n ro.product.model "iQOO I1928"
resetprop -n ro.product.product.model "iQOO I1928"
resetprop -n ro.product.odm.marketname "iQOO I1928"
resetprop -n ro.product.vendor.manufacturer "vivo"
resetprop -n ro.product.product.manufacturer "vivo"
resetprop -n ro.product.bootimage.manufacturer "vivo"
resetprop -n ro.product.manufacturer "vivo"
resetprop -n ro.product.odm.manufacturer "vivo"
resetprop -n ro.product.system.manufacturer "vivo"
resetprop -n ro.product.system_ext.manufacturer "vivo"
resetprop -n ro.product.vendor_dlkm.manufacturer "vivo"
resetprop -n ro.product.vendor.brand "iQOO"
resetprop -n ro.product.product.brand "iQOO"
resetprop -n ro.product.vendor_dlkm.brand "iQOO"
resetprop -n ro.product.system.brand "iQOO"
resetprop -n ro.product.bootimage.brand "iQOO"
resetprop -n ro.product.system_ext.brand "iQOO"
resetprop -n ro.product.odm.brand "iQOO"
resetprop -n ro.product.odm_dlkm.brand "iQOO"
resetprop -n ro.product.brand "iQOO"
resetprop -n ro.vendor_dlkm.build.fingerprint "iQOO/I1928/I1928:11/RP1A.200709.001/compiler09102241:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "iQOO/I1928/I1928:11/RP1A.200709.001/compiler09102241:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "iQOO/I1928/I1928:11/RP1A.200709.001/compiler09102241:user/release-keys"
resetprop -n ro.odm.build.fingerprint "iQOO/I1928/I1928:11/RP1A.200709.001/compiler09102241:user/release-keys"
resetprop -n ro.system.build.fingerprint "iQOO/I1928/I1928:11/RP1A.200709.001/compiler09102241:user/release-keys"
resetprop -n ro.build.fingerprint "iQOO/I1928/I1928:11/RP1A.200709.001/compiler09102241:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "iQOO/I1928/I1928:11/RP1A.200709.001/compiler09102241:user/release-keys"
resetprop -n ro.product.build.fingerprint "iQOO/I1928/I1928:11/RP1A.200709.001/compiler09102241:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "iQOO/I1928/I1928:11/RP1A.200709.001/compiler09102241:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=a508b16c99
resetprop -n ro.system.build.version.incremental eng.compil.20200910.224136
resetprop -n ro.bootimage.build.version.incremental eng.compil.20200910.224136
resetprop -n ro.product.build.version.incremental eng.compil.20200910.224136
resetprop -n ro.odm.build.version.incremental eng.compil.20200910.224136
resetprop -n ro.vendor_dlkm.build.version.incremental eng.compil.20200910.224136
resetprop -n ro.system_ext.build.version.incremental eng.compil.20200910.224136
resetprop -n ro.build.version.incremental eng.compil.20200910.224136
resetprop -n ro.vendor.build.version.incremental eng.compil.20200910.224136
resetprop -n ro.odm.build.id "RP1A.200709.001"
resetprop -n ro.product.build.id "RP1A.200709.001"
resetprop -n ro.bootimage.build.id "RP1A.200709.001"
resetprop -n ro.system_ext.build.id "RP1A.200709.001"
resetprop -n ro.vendor_dlkm.build.id "RP1A.200709.001"
resetprop -n ro.build.id "RP1A.200709.001"
resetprop -n ro.system.build.id "RP1A.200709.001"
resetprop -n ro.vendor.build.id "RP1A.200709.001"
resetprop -n ro.system.build.date "Thu Sep 10 22:41:36 CST 2020"
resetprop -n ro.bootimage.build.date "Thu Sep 10 22:41:36 CST 2020"
resetprop -n ro.product.build.date "Thu Sep 10 22:41:36 CST 2020"
resetprop -n ro.vendor_dlkm.build.date "Thu Sep 10 22:41:36 CST 2020"
resetprop -n ro.system_ext.build.date "Thu Sep 10 22:41:36 CST 2020"
resetprop -n ro.odm.build.date "Thu Sep 10 22:41:36 CST 2020"
resetprop -n ro.build.date "Thu Sep 10 22:41:36 CST 2020"
resetprop -n ro.vendor.build.date "Thu Sep 10 22:41:36 CST 2020"
resetprop -n ro.product.build.date.utc "1599748896"
resetprop -n ro.system_ext.build.date.utc "1599748896"
resetprop -n ro.system.build.date.utc "1599748896"
resetprop -n ro.vendor.build.date.utc "1599748896"
resetprop -n ro.vendor_dlkm.build.date.utc "1599748896"
resetprop -n ro.build.date.utc "1599748896"
resetprop -n ro.bootimage.build.date.utc "1599748896"
resetprop -n ro.odm.build.date.utc "1599748896"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name qssi
resetprop -n ro.product.odm.name qssi
resetprop -n ro.product.vendor.name qssi
resetprop -n ro.product.system.name qssi
resetprop -n ro.product.name qssi
resetprop -n ro.product.bootimage.name qssi
resetprop -n ro.product.vendor_dlkm.name qssi
resetprop -n ro.product.system_ext.name qssi
resetprop -n ro.build.flavor qssi-user
randomStr="qssi-user vivo RP1A.200709.001 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=60ecc6e7953a
resetprop -n ro.build.host ${randomStr}
randomStr=6e861957
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=dPAFid
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=df5bd57790747
randomStr2=f5
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=fc
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "eng.compil.20200910.224136"
resetprop -n ro.build.description "aeon6580_weg_l_l300-user 5.1 LMY47I 1555741941 release-keys"
resetprop -n ro.build.product.backup "qssi"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "compiler"
resetprop -n ro.build.host "compiler02071207"
resetprop -n ro.vivo.os.build.display.id "Funtouch OS_10.5"
resetprop -n ro.vivo.product.release.name "I1928"
resetprop -n ro.vivo.product.release.model "I1928"
resetprop -n media.stagefright.enable-player "true"
resetprop -n media.stagefright.enable-http "true"
resetprop -n media.stagefright.enable-aac "true"
resetprop -n media.stagefright.enable-qcp "true"
resetprop -n media.stagefright.enable-fma2dp "true"
resetprop -n media.stagefright.enable-scan "true"
resetprop -n media.stagefright.thumbnail.prefer_hw_codecs "true"
resetprop -n media.aac_51_output_enabled "true"
resetprop -n media.settings.xml "/vendor/etc/media_profiles_vendor.xml"
resetprop -n ro.hwui.texture_cache_size "72"
resetprop -n ro.hwui.layer_cache_size "48"
resetprop -n ro.hwui.r_buffer_cache_size "8"
resetprop -n ro.hwui.path_cache_size "32"
resetprop -n ro.hwui.gradient_cache_size "1"
resetprop -n ro.hwui.drop_shadow_cache_size "6"
resetprop -n ro.hwui.texture_cache_flushrate "0.4"
resetprop -n ro.hwui.text_small_cache_width "1024"
resetprop -n ro.hwui.text_small_cache_height "1024"
resetprop -n ro.hwui.text_large_cache_width "2048"
resetprop -n ro.hwui.text_large_cache_height "1024"
resetprop -n ro.lmk.kill_heaviest_task "true"
resetprop -n ro.lmk.kill_timeout_ms "15"
resetprop -n persist.vendor.vivo.qmi.fw.log "1"
resetprop -n persist.vivo.bluetooth.support.aie "1"
resetprop -n persist.vivo.phone.screen_size "60"
resetprop -n persist.vivo.smartkey.enable "true"
resetprop -n persist.vivo.phone.usb_otg "Have_usb_otg"
resetprop -n persist.vivo.check_fast_charge "1"
resetprop -n persist.vivo.enable_fast_charge "1"
resetprop -n persist.vivo.charge.version "1"
resetprop -n persist.vivo.disable_chg_switch "1"
resetprop -n persist.vivo.calling_state "0"
resetprop -n persist.vivo.phone.panel_type "Amoled"
resetprop -n persist.vivo.phone.super_lcd "false"
resetprop -n persist.system.vivo.enable_color_mode_id "0"
resetprop -n persist.vivo.phone.fps_default "1"
resetprop -n persist.vivo.phone.fps_max "60"
resetprop -n persist.vivo.displayp3.support "1"
resetprop -n persist.vivo.weixin_calling_state "0"
resetprop -n ro.vivo.oem.support "yes"
resetprop -n persist.vivo.radio.type.list "TDD-LTE,FDD-LTE,CDMA2000,WCDMA,GSM"
resetprop -n ro.vivo.lcm.xhd "FHD_20_9"
resetprop -n persist.vivo.support_close_gp "1"
resetprop -n ro.vivo.lte.voice.type "CSFB"
resetprop -n ro.vivo.net.entry "no"
resetprop -n ro.vivo.op.entry "no"
resetprop -n ro.vivo.hardware.version "PD1955F_EXMA"
resetprop -n ro.vivo.product.solution "QCOM"
resetprop -n ro.vivo.product.platform "SM8250"
resetprop -n ro.vivo.board.version "MA"
resetprop -n ro.vivo.os.name "Funtouch"
resetprop -n ro.vivo.os.version "11.5"
resetprop -n ro.vivo.build.version.sdk "1"
resetprop -n persist.vivo.support.wallet.icon "true"
resetprop -n ro.vivo.rom.style "vigour"
resetprop -n ro.vivo.product.overseas "yes"
resetprop -n ro.vivo.system.product.version "PD1955F_EX_A_20.09.101"
resetprop -n ro.vivo.system.hardware.version "PD1955F_EXMA"
resetprop -n ro.vivo.product.series "IQOO"
resetprop -n ro.vivo.product.res.series "VIVO1"
resetprop -n persist.vivo.face.assistant "0"
resetprop -n persist.system.vivo.face.unlock.strong "1"
resetprop -n persist.system.vivo.face.unlock.convenience.scheme "0"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2020-09-01
