strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Lenovo A6600a40"
resetprop -n ro.product.vendor.model "Lenovo A6600a40"
resetprop -n ro.product.vendor_dlkm.marketname "Lenovo A6600a40"
resetprop -n ro.product.product.marketname "Lenovo A6600a40"
resetprop -n ro.product.system.marketname "Lenovo A6600a40"
resetprop -n ro.product.odm_dlkm.marketname "Lenovo A6600a40"
resetprop -n ro.product.system_ext.marketname "Lenovo A6600a40"
resetprop -n ro.product.odm_dlkm.model "Lenovo A6600a40"
resetprop -n ro.product.system.model "Lenovo A6600a40"
resetprop -n ro.product.system_ext.model "Lenovo A6600a40"
resetprop -n ro.product.vendor_dlkm.model "Lenovo A6600a40"
resetprop -n bluetooth.device.default_name "Lenovo A6600a40"
resetprop -n ro.product.bootimage.model "Lenovo A6600a40"
resetprop -n ro.product.vendor.marketname "Lenovo A6600a40"
resetprop -n ro.product.marketname "Lenovo A6600a40"
resetprop -n ro.product.odm.model "Lenovo A6600a40"
resetprop -n ro.product.model "Lenovo A6600a40"
resetprop -n ro.product.product.model "Lenovo A6600a40"
resetprop -n ro.product.odm.marketname "Lenovo A6600a40"
resetprop -n ro.product.vendor.manufacturer "LENOVO"
resetprop -n ro.product.product.manufacturer "LENOVO"
resetprop -n ro.product.bootimage.manufacturer "LENOVO"
resetprop -n ro.product.manufacturer "LENOVO"
resetprop -n ro.product.odm.manufacturer "LENOVO"
resetprop -n ro.product.system.manufacturer "LENOVO"
resetprop -n ro.product.system_ext.manufacturer "LENOVO"
resetprop -n ro.product.vendor_dlkm.manufacturer "LENOVO"
resetprop -n ro.product.vendor.brand "Lenovo"
resetprop -n ro.product.product.brand "Lenovo"
resetprop -n ro.product.vendor_dlkm.brand "Lenovo"
resetprop -n ro.product.system.brand "Lenovo"
resetprop -n ro.product.bootimage.brand "Lenovo"
resetprop -n ro.product.system_ext.brand "Lenovo"
resetprop -n ro.product.odm.brand "Lenovo"
resetprop -n ro.product.odm_dlkm.brand "Lenovo"
resetprop -n ro.product.brand "Lenovo"
resetprop -n ro.vendor_dlkm.build.fingerprint "Lenovo/A6600a40/A6600a40:6.0/MRA58K/A6600a40_S305_170109_ROW:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Lenovo/A6600a40/A6600a40:6.0/MRA58K/A6600a40_S305_170109_ROW:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Lenovo/A6600a40/A6600a40:6.0/MRA58K/A6600a40_S305_170109_ROW:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Lenovo/A6600a40/A6600a40:6.0/MRA58K/A6600a40_S305_170109_ROW:user/release-keys"
resetprop -n ro.system.build.fingerprint "Lenovo/A6600a40/A6600a40:6.0/MRA58K/A6600a40_S305_170109_ROW:user/release-keys"
resetprop -n ro.build.fingerprint "Lenovo/A6600a40/A6600a40:6.0/MRA58K/A6600a40_S305_170109_ROW:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Lenovo/A6600a40/A6600a40:6.0/MRA58K/A6600a40_S305_170109_ROW:user/release-keys"
resetprop -n ro.product.build.fingerprint "Lenovo/A6600a40/A6600a40:6.0/MRA58K/A6600a40_S305_170109_ROW:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Lenovo/A6600a40/A6600a40:6.0/MRA58K/A6600a40_S305_170109_ROW:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=8108fd8daf
resetprop -n ro.system.build.version.incremental A6600a40_S305_170109_ROW
resetprop -n ro.bootimage.build.version.incremental A6600a40_S305_170109_ROW
resetprop -n ro.product.build.version.incremental A6600a40_S305_170109_ROW
resetprop -n ro.odm.build.version.incremental A6600a40_S305_170109_ROW
resetprop -n ro.vendor_dlkm.build.version.incremental A6600a40_S305_170109_ROW
resetprop -n ro.system_ext.build.version.incremental A6600a40_S305_170109_ROW
resetprop -n ro.build.version.incremental A6600a40_S305_170109_ROW
resetprop -n ro.vendor.build.version.incremental A6600a40_S305_170109_ROW
resetprop -n ro.odm.build.id "MRA58K"
resetprop -n ro.product.build.id "MRA58K"
resetprop -n ro.bootimage.build.id "MRA58K"
resetprop -n ro.system_ext.build.id "MRA58K"
resetprop -n ro.vendor_dlkm.build.id "MRA58K"
resetprop -n ro.build.id "MRA58K"
resetprop -n ro.system.build.id "MRA58K"
resetprop -n ro.vendor.build.id "MRA58K"
resetprop -n ro.system.build.date "Mon Jan  9 17:54:07 CST 2017"
resetprop -n ro.bootimage.build.date "Mon Jan  9 17:54:07 CST 2017"
resetprop -n ro.product.build.date "Mon Jan  9 17:54:07 CST 2017"
resetprop -n ro.vendor_dlkm.build.date "Mon Jan  9 17:54:07 CST 2017"
resetprop -n ro.system_ext.build.date "Mon Jan  9 17:54:07 CST 2017"
resetprop -n ro.odm.build.date "Mon Jan  9 17:54:07 CST 2017"
resetprop -n ro.build.date "Mon Jan  9 17:54:07 CST 2017"
resetprop -n ro.vendor.build.date "Mon Jan  9 17:54:07 CST 2017"
resetprop -n ro.product.build.date.utc "1483955647"
resetprop -n ro.system_ext.build.date.utc "1483955647"
resetprop -n ro.system.build.date.utc "1483955647"
resetprop -n ro.vendor.build.date.utc "1483955647"
resetprop -n ro.vendor_dlkm.build.date.utc "1483955647"
resetprop -n ro.build.date.utc "1483955647"
resetprop -n ro.bootimage.build.date.utc "1483955647"
resetprop -n ro.odm.build.date.utc "1483955647"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name A6600a40
resetprop -n ro.product.odm.name A6600a40
resetprop -n ro.product.vendor.name A6600a40
resetprop -n ro.product.system.name A6600a40
resetprop -n ro.product.name A6600a40
resetprop -n ro.product.bootimage.name A6600a40
resetprop -n ro.product.vendor_dlkm.name A6600a40
resetprop -n ro.product.system_ext.name A6600a40
resetprop -n ro.build.flavor full_lcsh6735m_35u_m-user
randomStr="full_lcsh6735m_35u_m-user LENOVO MRA58K "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=e7bdf994557d
resetprop -n ro.build.host ${randomStr}
randomStr=220a2343
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=DXnwqG
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=a39f35ae02178
randomStr2=30
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=0b
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "A6600a40_S305_170109_ROW"
resetprop -n ro.build.description "full_lcsh6735m_35u_m-user 6.0 MRA58K 1483955365 release-keys"
resetprop -n ro.com.google.clientidbase "alps-full_lcsh6735m_35u_m-{country}"
resetprop -n ro.com.google.clientidbase.ms "alps-full_lcsh6735m_35u_m-{country}"
resetprop -n ro.com.google.clientidbase.yt "alps-full_lcsh6735m_35u_m-{country}"
resetprop -n ro.com.google.clientidbase.am "alps-full_lcsh6735m_35u_m-{country}"
resetprop -n ro.com.google.clientidbase.gmm "alps-full_lcsh6735m_35u_m-{country}"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "jenkins"
resetprop -n ro.build.host "glsrv4"
resetprop -n ro.build.product.backup "A6600a40"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.mediatek.chip_ver "S01"
resetprop -n ro.mediatek.version.release "alps-mp-m0.mp1-V2.39.1_lcsh6735m.35u.m_P79"
resetprop -n ro.mediatek.platform "MT6735"
resetprop -n ro.mediatek.gemini_support "true"
resetprop -n ro.mediatek.version.branch "alps-mp-m0.mp1"
resetprop -n ro.mediatek.version.sdk "4"
resetprop -n ro.com.google.gmsversion "6.0_r6"
resetprop -n ro.mtk_gemini_support "1"
resetprop -n ro.mtk_audio_profiles "1"
resetprop -n ro.mtk_audenh_support "1"
resetprop -n ro.mtk_besloudness_support "1"
resetprop -n ro.mtk_bessurround_support "1"
resetprop -n ro.mtk_bt_support "1"
resetprop -n ro.mtk_wappush_support "1"
resetprop -n ro.mtk_agps_app "1"
resetprop -n ro.mtk_audio_tuning_tool_ver "V1"
resetprop -n ro.mtk_wlan_support "1"
resetprop -n ro.mtk_ipo_support "1"
resetprop -n ro.mtk_gps_support "1"
resetprop -n ro.mtk_omacp_support "1"
resetprop -n ro.mtk_search_db_support "1"
resetprop -n ro.mtk_dialer_search_support "1"
resetprop -n ro.mtk_dhcpv6c_wifi "1"
resetprop -n ro.mtk_fd_support "1"
resetprop -n ro.mtk_oma_drm_support "1"
resetprop -n ro.mtk_widevine_drm_l3_support "1"
resetprop -n ro.mtk_eap_sim_aka "1"
resetprop -n ro.mtk_fm_recording_support "1"
resetprop -n ro.mtk_audio_ape_support "1"
resetprop -n ro.mtk_flv_playback_support "1"
resetprop -n ro.mtk_send_rr_support "1"
resetprop -n ro.mtk_emmc_support "1"
resetprop -n ro.mtk_tetheringipv6_support "1"
resetprop -n ro.mtk_shared_sdcard "1"
resetprop -n ro.mtk_enable_md1 "1"
resetprop -n ro.mtk_flight_mode_power_off_md "1"
resetprop -n ro.mtk_pq_support "2"
resetprop -n ro.mtk_miravision_image_dc "1"
resetprop -n ro.mtk_wifi_mcc_support "1"
resetprop -n ro.mtk_sim_hot_swap "1"
resetprop -n ro.mtk_thumbnail_play_support "1"
resetprop -n ro.mtk_bip_scws "1"
resetprop -n ro.mtk_multisim_ringtone "1"
resetprop -n ro.mtk_world_phone_policy "0"
resetprop -n ro.mtk_perfservice_support "1"
resetprop -n ro.mtk_mobile_management "1"
resetprop -n ro.mtk_antibricking_level "2"
resetprop -n ro.mtk_cam_mfb_support "0"
resetprop -n ro.mtk_lte_support "1"
resetprop -n ro.mtk_safemedia_support "1"
resetprop -n ro.mtk_rild_read_imsi "1"
resetprop -n ro.mtk_passpoint_r1_support "1"
resetprop -n ro.mtk_bg_power_saving_support "1"
resetprop -n ro.mtk_bg_power_saving_ui "1"
resetprop -n ro.mtk_dual_mic_support "0"
resetprop -n ro.mtk_is_tablet "0"
resetprop -n ro.mtk_ims_support "1"
resetprop -n ro.mtk_volte_support "1"
resetprop -n persist.radio.mtk_dsbp_support "1"
resetprop -n persist.mtk_dynamic_ims_switch "0"
resetprop -n ro.mediatek.project.path "device/lcsh/lcsh6735m_35u_m"
resetprop -n ro.mtk_md_sbp_custom_value "0"
resetprop -n ro.expect.recovery_id "0x58fe5f53216ef3f960511bfc7473375c46f1ed1c000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2016-12-05
