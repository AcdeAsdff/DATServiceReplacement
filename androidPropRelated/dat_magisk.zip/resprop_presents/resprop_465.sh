strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "JHSD200"
resetprop -n ro.product.vendor.model "JHSD200"
resetprop -n ro.product.vendor_dlkm.marketname "JHSD200"
resetprop -n ro.product.product.marketname "JHSD200"
resetprop -n ro.product.system.marketname "JHSD200"
resetprop -n ro.product.odm_dlkm.marketname "JHSD200"
resetprop -n ro.product.system_ext.marketname "JHSD200"
resetprop -n ro.product.odm_dlkm.model "JHSD200"
resetprop -n ro.product.system.model "JHSD200"
resetprop -n ro.product.system_ext.model "JHSD200"
resetprop -n ro.product.vendor_dlkm.model "JHSD200"
resetprop -n bluetooth.device.default_name "JHSD200"
resetprop -n ro.product.bootimage.model "JHSD200"
resetprop -n ro.product.vendor.marketname "JHSD200"
resetprop -n ro.product.marketname "JHSD200"
resetprop -n ro.product.odm.model "JHSD200"
resetprop -n ro.product.model "JHSD200"
resetprop -n ro.product.product.model "JHSD200"
resetprop -n ro.product.odm.marketname "JHSD200"
resetprop -n ro.product.vendor.manufacturer "Droidlogic"
resetprop -n ro.product.product.manufacturer "Droidlogic"
resetprop -n ro.product.bootimage.manufacturer "Droidlogic"
resetprop -n ro.product.manufacturer "Droidlogic"
resetprop -n ro.product.odm.manufacturer "Droidlogic"
resetprop -n ro.product.system.manufacturer "Droidlogic"
resetprop -n ro.product.system_ext.manufacturer "Droidlogic"
resetprop -n ro.product.vendor_dlkm.manufacturer "Droidlogic"
resetprop -n ro.product.vendor.brand "Jio"
resetprop -n ro.product.product.brand "Jio"
resetprop -n ro.product.vendor_dlkm.brand "Jio"
resetprop -n ro.product.system.brand "Jio"
resetprop -n ro.product.bootimage.brand "Jio"
resetprop -n ro.product.system_ext.brand "Jio"
resetprop -n ro.product.odm.brand "Jio"
resetprop -n ro.product.odm_dlkm.brand "Jio"
resetprop -n ro.product.brand "Jio"
resetprop -n ro.vendor_dlkm.build.fingerprint "Jio/franklin/franklin:9/5.7.1/20210619:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Jio/franklin/franklin:9/5.7.1/20210619:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Jio/franklin/franklin:9/5.7.1/20210619:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Jio/franklin/franklin:9/5.7.1/20210619:user/release-keys"
resetprop -n ro.system.build.fingerprint "Jio/franklin/franklin:9/5.7.1/20210619:user/release-keys"
resetprop -n ro.build.fingerprint "Jio/franklin/franklin:9/5.7.1/20210619:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Jio/franklin/franklin:9/5.7.1/20210619:user/release-keys"
resetprop -n ro.product.build.fingerprint "Jio/franklin/franklin:9/5.7.1/20210619:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Jio/franklin/franklin:9/5.7.1/20210619:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=6eb4fdbfd5
resetprop -n ro.system.build.version.incremental 20210619
resetprop -n ro.bootimage.build.version.incremental 20210619
resetprop -n ro.product.build.version.incremental 20210619
resetprop -n ro.odm.build.version.incremental 20210619
resetprop -n ro.vendor_dlkm.build.version.incremental 20210619
resetprop -n ro.system_ext.build.version.incremental 20210619
resetprop -n ro.build.version.incremental 20210619
resetprop -n ro.vendor.build.version.incremental 20210619
resetprop -n ro.odm.build.id "5.7.1"
resetprop -n ro.product.build.id "5.7.1"
resetprop -n ro.bootimage.build.id "5.7.1"
resetprop -n ro.system_ext.build.id "5.7.1"
resetprop -n ro.vendor_dlkm.build.id "5.7.1"
resetprop -n ro.build.id "5.7.1"
resetprop -n ro.system.build.id "5.7.1"
resetprop -n ro.vendor.build.id "5.7.1"
resetprop -n ro.system.build.date "Sat Jun 19 18:03:59 UTC 2021"
resetprop -n ro.bootimage.build.date "Sat Jun 19 18:03:59 UTC 2021"
resetprop -n ro.product.build.date "Sat Jun 19 18:03:59 UTC 2021"
resetprop -n ro.vendor_dlkm.build.date "Sat Jun 19 18:03:59 UTC 2021"
resetprop -n ro.system_ext.build.date "Sat Jun 19 18:03:59 UTC 2021"
resetprop -n ro.odm.build.date "Sat Jun 19 18:03:59 UTC 2021"
resetprop -n ro.build.date "Sat Jun 19 18:03:59 UTC 2021"
resetprop -n ro.vendor.build.date "Sat Jun 19 18:03:59 UTC 2021"
resetprop -n ro.product.build.date.utc "1624125839"
resetprop -n ro.system_ext.build.date.utc "1624125839"
resetprop -n ro.system.build.date.utc "1624125839"
resetprop -n ro.vendor.build.date.utc "1624125839"
resetprop -n ro.vendor_dlkm.build.date.utc "1624125839"
resetprop -n ro.build.date.utc "1624125839"
resetprop -n ro.bootimage.build.date.utc "1624125839"
resetprop -n ro.odm.build.date.utc "1624125839"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name franklin
resetprop -n ro.product.odm.name franklin
resetprop -n ro.product.vendor.name franklin
resetprop -n ro.product.system.name franklin
resetprop -n ro.product.name franklin
resetprop -n ro.product.bootimage.name franklin
resetprop -n ro.product.vendor_dlkm.name franklin
resetprop -n ro.product.system_ext.name franklin
resetprop -n ro.build.flavor franklin-user
randomStr="franklin-user Droidlogic 5.7.1 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=c457a5ef1142
resetprop -n ro.build.host ${randomStr}
randomStr=c927aaf6
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=QHKbpF
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=b5bcc9cf45ddb
randomStr2=f2
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=03
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "20210619"
resetprop -n ro.build.description "franklin-user 9 5.7.1 20210619 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "iwj-jio"
resetprop -n ro.build.host "31573d0d5634"
resetprop -n ro.build.product.backup "franklin"
resetprop -n ro.build.characteristics "mbx,nosdcard"
resetprop -n ro.expect.recovery_id "0xd09ad8e5f0b9e774ee9666fa05d722f772e47850000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2020-12-01
