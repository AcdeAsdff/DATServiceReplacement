strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "pissarro"
resetprop -n ro.product.vendor.model "pissarro"
resetprop -n ro.product.vendor_dlkm.marketname "pissarro"
resetprop -n ro.product.product.marketname "pissarro"
resetprop -n ro.product.system.marketname "pissarro"
resetprop -n ro.product.odm_dlkm.marketname "pissarro"
resetprop -n ro.product.system_ext.marketname "pissarro"
resetprop -n ro.product.odm_dlkm.model "pissarro"
resetprop -n ro.product.system.model "pissarro"
resetprop -n ro.product.system_ext.model "pissarro"
resetprop -n ro.product.vendor_dlkm.model "pissarro"
resetprop -n bluetooth.device.default_name "pissarro"
resetprop -n ro.product.bootimage.model "pissarro"
resetprop -n ro.product.vendor.marketname "pissarro"
resetprop -n ro.product.marketname "pissarro"
resetprop -n ro.product.odm.model "pissarro"
resetprop -n ro.product.model "pissarro"
resetprop -n ro.product.product.model "pissarro"
resetprop -n ro.product.odm.marketname "pissarro"
resetprop -n ro.product.vendor.manufacturer "Xiaomi"
resetprop -n ro.product.product.manufacturer "Xiaomi"
resetprop -n ro.product.bootimage.manufacturer "Xiaomi"
resetprop -n ro.product.manufacturer "Xiaomi"
resetprop -n ro.product.odm.manufacturer "Xiaomi"
resetprop -n ro.product.system.manufacturer "Xiaomi"
resetprop -n ro.product.system_ext.manufacturer "Xiaomi"
resetprop -n ro.product.vendor_dlkm.manufacturer "Xiaomi"
resetprop -n ro.product.vendor.brand "Redmi"
resetprop -n ro.product.product.brand "Redmi"
resetprop -n ro.product.vendor_dlkm.brand "Redmi"
resetprop -n ro.product.system.brand "Redmi"
resetprop -n ro.product.bootimage.brand "Redmi"
resetprop -n ro.product.system_ext.brand "Redmi"
resetprop -n ro.product.odm.brand "Redmi"
resetprop -n ro.product.odm_dlkm.brand "Redmi"
resetprop -n ro.product.brand "Redmi"
resetprop -n ro.vendor_dlkm.build.fingerprint "Redmi/pissarro/pissarro:11/RP1A.200720.011/V12.5.5.0.RKTCNXM:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Redmi/pissarro/pissarro:11/RP1A.200720.011/V12.5.5.0.RKTCNXM:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Redmi/pissarro/pissarro:11/RP1A.200720.011/V12.5.5.0.RKTCNXM:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Redmi/pissarro/pissarro:11/RP1A.200720.011/V12.5.5.0.RKTCNXM:user/release-keys"
resetprop -n ro.system.build.fingerprint "Redmi/pissarro/pissarro:11/RP1A.200720.011/V12.5.5.0.RKTCNXM:user/release-keys"
resetprop -n ro.build.fingerprint "Redmi/pissarro/pissarro:11/RP1A.200720.011/V12.5.5.0.RKTCNXM:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Redmi/pissarro/pissarro:11/RP1A.200720.011/V12.5.5.0.RKTCNXM:user/release-keys"
resetprop -n ro.product.build.fingerprint "Redmi/pissarro/pissarro:11/RP1A.200720.011/V12.5.5.0.RKTCNXM:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Redmi/pissarro/pissarro:11/RP1A.200720.011/V12.5.5.0.RKTCNXM:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=30c8e7c425
resetprop -n ro.system.build.version.incremental V12.5.5.0.RKTCNXM
resetprop -n ro.bootimage.build.version.incremental V12.5.5.0.RKTCNXM
resetprop -n ro.product.build.version.incremental V12.5.5.0.RKTCNXM
resetprop -n ro.odm.build.version.incremental V12.5.5.0.RKTCNXM
resetprop -n ro.vendor_dlkm.build.version.incremental V12.5.5.0.RKTCNXM
resetprop -n ro.system_ext.build.version.incremental V12.5.5.0.RKTCNXM
resetprop -n ro.build.version.incremental V12.5.5.0.RKTCNXM
resetprop -n ro.vendor.build.version.incremental V12.5.5.0.RKTCNXM
resetprop -n ro.odm.build.id "RP1A.200720.011"
resetprop -n ro.product.build.id "RP1A.200720.011"
resetprop -n ro.bootimage.build.id "RP1A.200720.011"
resetprop -n ro.system_ext.build.id "RP1A.200720.011"
resetprop -n ro.vendor_dlkm.build.id "RP1A.200720.011"
resetprop -n ro.build.id "RP1A.200720.011"
resetprop -n ro.system.build.id "RP1A.200720.011"
resetprop -n ro.vendor.build.id "RP1A.200720.011"
resetprop -n ro.system.build.date "Wed Oct 27 00:07:34 CST 2021"
resetprop -n ro.bootimage.build.date "Wed Oct 27 00:07:34 CST 2021"
resetprop -n ro.product.build.date "Wed Oct 27 00:07:34 CST 2021"
resetprop -n ro.vendor_dlkm.build.date "Wed Oct 27 00:07:34 CST 2021"
resetprop -n ro.system_ext.build.date "Wed Oct 27 00:07:34 CST 2021"
resetprop -n ro.odm.build.date "Wed Oct 27 00:07:34 CST 2021"
resetprop -n ro.build.date "Wed Oct 27 00:07:34 CST 2021"
resetprop -n ro.vendor.build.date "Wed Oct 27 00:07:34 CST 2021"
resetprop -n ro.product.build.date.utc "1635264454"
resetprop -n ro.system_ext.build.date.utc "1635264454"
resetprop -n ro.system.build.date.utc "1635264454"
resetprop -n ro.vendor.build.date.utc "1635264454"
resetprop -n ro.vendor_dlkm.build.date.utc "1635264454"
resetprop -n ro.build.date.utc "1635264454"
resetprop -n ro.bootimage.build.date.utc "1635264454"
resetprop -n ro.odm.build.date.utc "1635264454"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name pissarro
resetprop -n ro.product.odm.name pissarro
resetprop -n ro.product.vendor.name pissarro
resetprop -n ro.product.system.name pissarro
resetprop -n ro.product.name pissarro
resetprop -n ro.product.bootimage.name pissarro
resetprop -n ro.product.vendor_dlkm.name pissarro
resetprop -n ro.product.system_ext.name pissarro
resetprop -n ro.build.flavor pissarro-user
randomStr="pissarro-user Xiaomi RP1A.200720.011 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=c3822639acb1
resetprop -n ro.build.host ${randomStr}
randomStr=34e8e12b
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=ZZKZoY
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=da5d16d6124ac
randomStr2=ef
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=1d
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "V12.5.5.0.RKTCNXM"
resetprop -n ro.build.description "pissarro-user 11 RP1A.200720.011 V12.5.5.0.RKTCNXM release-keys"
resetprop -n ro.build.product.backup "pissarro"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "builder"
resetprop -n ro.build.host "m1-xm-ota-bd009.bj.idc.xiaomi.com"
resetprop -n ro.miui.pm.install.buffer.size "49152"
resetprop -n persist.miui.extm.enable "1"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.mi.development "false"
resetprop -n ro.miui.version.code_time "1635177600"
resetprop -n ro.miui.has_gmscore "1"
resetprop -n ro.miui.restrict_imei "1"
resetprop -n ro.miui.ui.version.code "12"
resetprop -n ro.miui.ui.version.name "V125"
resetprop -n ro.miui.has_security_keyboard "1"
resetprop -n ro.miui.support_miui_ime_bottom "1"
resetprop -n ro.miui.remove_uri_80_flag "1"
resetprop -n ro.fota.oem "Xiaomi"
resetprop -n ro.miui.pm.movedtodata.apps "com.google.android.apps.photos,com.google.android.apps.docs,com.google.android.music,com.google.android.videos,com.google.android.apps.tachyon"
resetprop -n persist.sys.miui_animator_sched.bigcores "6-7"
resetprop -n persist.sys.miui_animator_sched.sched_threads "2"
resetprop -n ro.miui.notch "1"
resetprop -n persist.miui.density_v2 "440"
resetprop -n ro.miui.ui.fonttype "mipro"
resetprop -n ro.miui.ui.font.theme_apply "true"
resetprop -n ro.miui.ui.font.animation "disable"
resetprop -n ro.miui.ui.font.version "2"
resetprop -n ro.miui.ui.font.mi_font_path "/system/fonts/MiSansVF.ttf"
resetprop -n sys.miui.shutdown.waittime "500"
resetprop -n persist.sys.miui_scout_enable "true"
resetprop -n ro.miui.has_handy_mode_sf "1"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2021-10-01
