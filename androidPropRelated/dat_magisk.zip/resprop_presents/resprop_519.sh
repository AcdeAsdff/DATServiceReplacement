strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "16 X"
resetprop -n ro.product.vendor.model "16 X"
resetprop -n ro.product.vendor_dlkm.marketname "16 X"
resetprop -n ro.product.product.marketname "16 X"
resetprop -n ro.product.system.marketname "16 X"
resetprop -n ro.product.odm_dlkm.marketname "16 X"
resetprop -n ro.product.system_ext.marketname "16 X"
resetprop -n ro.product.odm_dlkm.model "16 X"
resetprop -n ro.product.system.model "16 X"
resetprop -n ro.product.system_ext.model "16 X"
resetprop -n ro.product.vendor_dlkm.model "16 X"
resetprop -n bluetooth.device.default_name "16 X"
resetprop -n ro.product.bootimage.model "16 X"
resetprop -n ro.product.vendor.marketname "16 X"
resetprop -n ro.product.marketname "16 X"
resetprop -n ro.product.odm.model "16 X"
resetprop -n ro.product.model "16 X"
resetprop -n ro.product.product.model "16 X"
resetprop -n ro.product.odm.marketname "16 X"
resetprop -n ro.product.vendor.manufacturer "Meizu"
resetprop -n ro.product.product.manufacturer "Meizu"
resetprop -n ro.product.bootimage.manufacturer "Meizu"
resetprop -n ro.product.manufacturer "Meizu"
resetprop -n ro.product.odm.manufacturer "Meizu"
resetprop -n ro.product.system.manufacturer "Meizu"
resetprop -n ro.product.system_ext.manufacturer "Meizu"
resetprop -n ro.product.vendor_dlkm.manufacturer "Meizu"
resetprop -n ro.product.vendor.brand "Meizu"
resetprop -n ro.product.product.brand "Meizu"
resetprop -n ro.product.vendor_dlkm.brand "Meizu"
resetprop -n ro.product.system.brand "Meizu"
resetprop -n ro.product.bootimage.brand "Meizu"
resetprop -n ro.product.system_ext.brand "Meizu"
resetprop -n ro.product.odm.brand "Meizu"
resetprop -n ro.product.odm_dlkm.brand "Meizu"
resetprop -n ro.product.brand "Meizu"
resetprop -n ro.vendor_dlkm.build.fingerprint "Meizu/meizu_16X_CN/16X:8.1.0/OPM1.171019.026/1572938190:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Meizu/meizu_16X_CN/16X:8.1.0/OPM1.171019.026/1572938190:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Meizu/meizu_16X_CN/16X:8.1.0/OPM1.171019.026/1572938190:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Meizu/meizu_16X_CN/16X:8.1.0/OPM1.171019.026/1572938190:user/release-keys"
resetprop -n ro.system.build.fingerprint "Meizu/meizu_16X_CN/16X:8.1.0/OPM1.171019.026/1572938190:user/release-keys"
resetprop -n ro.build.fingerprint "Meizu/meizu_16X_CN/16X:8.1.0/OPM1.171019.026/1572938190:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Meizu/meizu_16X_CN/16X:8.1.0/OPM1.171019.026/1572938190:user/release-keys"
resetprop -n ro.product.build.fingerprint "Meizu/meizu_16X_CN/16X:8.1.0/OPM1.171019.026/1572938190:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Meizu/meizu_16X_CN/16X:8.1.0/OPM1.171019.026/1572938190:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=5c1d799662
resetprop -n ro.system.build.version.incremental 1572938190
resetprop -n ro.bootimage.build.version.incremental 1572938190
resetprop -n ro.product.build.version.incremental 1572938190
resetprop -n ro.odm.build.version.incremental 1572938190
resetprop -n ro.vendor_dlkm.build.version.incremental 1572938190
resetprop -n ro.system_ext.build.version.incremental 1572938190
resetprop -n ro.build.version.incremental 1572938190
resetprop -n ro.vendor.build.version.incremental 1572938190
resetprop -n ro.odm.build.id "OPM1.171019.026"
resetprop -n ro.product.build.id "OPM1.171019.026"
resetprop -n ro.bootimage.build.id "OPM1.171019.026"
resetprop -n ro.system_ext.build.id "OPM1.171019.026"
resetprop -n ro.vendor_dlkm.build.id "OPM1.171019.026"
resetprop -n ro.build.id "OPM1.171019.026"
resetprop -n ro.system.build.id "OPM1.171019.026"
resetprop -n ro.vendor.build.id "OPM1.171019.026"
resetprop -n ro.system.build.date "Mon Dec 23 00:57:02 CST 2019"
resetprop -n ro.bootimage.build.date "Mon Dec 23 00:57:02 CST 2019"
resetprop -n ro.product.build.date "Mon Dec 23 00:57:02 CST 2019"
resetprop -n ro.vendor_dlkm.build.date "Mon Dec 23 00:57:02 CST 2019"
resetprop -n ro.system_ext.build.date "Mon Dec 23 00:57:02 CST 2019"
resetprop -n ro.odm.build.date "Mon Dec 23 00:57:02 CST 2019"
resetprop -n ro.build.date "Mon Dec 23 00:57:02 CST 2019"
resetprop -n ro.vendor.build.date "Mon Dec 23 00:57:02 CST 2019"
resetprop -n ro.product.build.date.utc "1577033822"
resetprop -n ro.system_ext.build.date.utc "1577033822"
resetprop -n ro.system.build.date.utc "1577033822"
resetprop -n ro.vendor.build.date.utc "1577033822"
resetprop -n ro.vendor_dlkm.build.date.utc "1577033822"
resetprop -n ro.build.date.utc "1577033822"
resetprop -n ro.bootimage.build.date.utc "1577033822"
resetprop -n ro.odm.build.date.utc "1577033822"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name meizu_16X_CN
resetprop -n ro.product.odm.name meizu_16X_CN
resetprop -n ro.product.vendor.name meizu_16X_CN
resetprop -n ro.product.system.name meizu_16X_CN
resetprop -n ro.product.name meizu_16X_CN
resetprop -n ro.product.bootimage.name meizu_16X_CN
resetprop -n ro.product.vendor_dlkm.name meizu_16X_CN
resetprop -n ro.product.system_ext.name meizu_16X_CN
resetprop -n ro.build.flavor sdm710-user
randomStr="sdm710-user Meizu OPM1.171019.026 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=baa223656b95
resetprop -n ro.build.host ${randomStr}
randomStr=305fb280
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=MGxXdA
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=f900afc57457e
randomStr2=92
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=55
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1572938190"
resetprop -n ro.build.description "meizu_16X_CN-user 8.1.0 OPM1.171019.026 1572938190 release-keys"
resetprop -n ro.meizu.build.spt "0"
resetprop -n ro.build.host "Mz-Builder-L19"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "flyme"
resetprop -n ro.build.characteristics "nosdcard"
resetprop -n ro.meizu.product.model "16X"
resetprop -n ro.build.product.backup "meizu_16X_CN"
resetprop -n ro.meizu.carrier.model "M872Q"
resetprop -n ro.flyme.version.id "Flyme 8.19.12.23 daily"
resetprop -n ro.meizu.project.id "M1872-8"
resetprop -n ro.product.flyme.model "M1872"
resetprop -n ro.build.flyme.version "8"
resetprop -n ro.flyme.published  " true"
resetprop -n ro.flyme.ctsbackup  " false"
resetprop -n ro.meizu.build.number "201912230058"
resetprop -n ro.meizu.upgrade.encrypt "1"
resetprop -n media.stagefright.enable-player "true"
resetprop -n media.stagefright.enable-http "true"
resetprop -n media.stagefright.enable-aac "true"
resetprop -n media.stagefright.enable-qcp "true"
resetprop -n media.stagefright.enable-fma2dp "true"
resetprop -n media.stagefright.enable-scan "true"
resetprop -n media.aac_51_output_enabled "true"
resetprop -n media.settings.xml "/vendor/etc/media_profiles_vendor.xml"
resetprop -n ro.hwui.texture_cache_size "72"
resetprop -n ro.hwui.layer_cache_size "48"
resetprop -n ro.hwui.r_buffer_cache_size "8"
resetprop -n ro.hwui.path_cache_size "32"
resetprop -n ro.hwui.gradient_cache_size "1"
resetprop -n ro.hwui.drop_shadow_cache_size "6"
resetprop -n ro.hwui.texture_cache_flushrate "0.4"
resetprop -n ro.hwui.text_small_cache_width "1024"
resetprop -n ro.hwui.text_small_cache_height "1024"
resetprop -n ro.hwui.text_large_cache_width "2048"
resetprop -n ro.hwui.text_large_cache_height "4096"
resetprop -n ro.expect.recovery_id "0xbd99f760146ff64ccd62183544b97e2848e30a79000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-11-01
