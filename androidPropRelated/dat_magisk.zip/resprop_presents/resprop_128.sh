strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Y10G001S4M_EEA"
resetprop -n ro.product.vendor.model "Y10G001S4M_EEA"
resetprop -n ro.product.vendor_dlkm.marketname "Y10G001S4M_EEA"
resetprop -n ro.product.product.marketname "Y10G001S4M_EEA"
resetprop -n ro.product.system.marketname "Y10G001S4M_EEA"
resetprop -n ro.product.odm_dlkm.marketname "Y10G001S4M_EEA"
resetprop -n ro.product.system_ext.marketname "Y10G001S4M_EEA"
resetprop -n ro.product.odm_dlkm.model "Y10G001S4M_EEA"
resetprop -n ro.product.system.model "Y10G001S4M_EEA"
resetprop -n ro.product.system_ext.model "Y10G001S4M_EEA"
resetprop -n ro.product.vendor_dlkm.model "Y10G001S4M_EEA"
resetprop -n bluetooth.device.default_name "Y10G001S4M_EEA"
resetprop -n ro.product.bootimage.model "Y10G001S4M_EEA"
resetprop -n ro.product.vendor.marketname "Y10G001S4M_EEA"
resetprop -n ro.product.marketname "Y10G001S4M_EEA"
resetprop -n ro.product.odm.model "Y10G001S4M_EEA"
resetprop -n ro.product.model "Y10G001S4M_EEA"
resetprop -n ro.product.product.model "Y10G001S4M_EEA"
resetprop -n ro.product.odm.marketname "Y10G001S4M_EEA"
resetprop -n ro.product.vendor.manufacturer "alps"
resetprop -n ro.product.product.manufacturer "alps"
resetprop -n ro.product.bootimage.manufacturer "alps"
resetprop -n ro.product.manufacturer "alps"
resetprop -n ro.product.odm.manufacturer "alps"
resetprop -n ro.product.system.manufacturer "alps"
resetprop -n ro.product.system_ext.manufacturer "alps"
resetprop -n ro.product.vendor_dlkm.manufacturer "alps"
resetprop -n ro.product.vendor.brand "UNOWHY"
resetprop -n ro.product.product.brand "UNOWHY"
resetprop -n ro.product.vendor_dlkm.brand "UNOWHY"
resetprop -n ro.product.system.brand "UNOWHY"
resetprop -n ro.product.bootimage.brand "UNOWHY"
resetprop -n ro.product.system_ext.brand "UNOWHY"
resetprop -n ro.product.odm.brand "UNOWHY"
resetprop -n ro.product.odm_dlkm.brand "UNOWHY"
resetprop -n ro.product.brand "UNOWHY"
resetprop -n ro.vendor_dlkm.build.fingerprint "UNOWHY/Y10G001S4M_EEA/Y10G001S4M:9/PPR1.180610.011/1564163634:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "UNOWHY/Y10G001S4M_EEA/Y10G001S4M:9/PPR1.180610.011/1564163634:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "UNOWHY/Y10G001S4M_EEA/Y10G001S4M:9/PPR1.180610.011/1564163634:user/release-keys"
resetprop -n ro.odm.build.fingerprint "UNOWHY/Y10G001S4M_EEA/Y10G001S4M:9/PPR1.180610.011/1564163634:user/release-keys"
resetprop -n ro.system.build.fingerprint "UNOWHY/Y10G001S4M_EEA/Y10G001S4M:9/PPR1.180610.011/1564163634:user/release-keys"
resetprop -n ro.build.fingerprint "UNOWHY/Y10G001S4M_EEA/Y10G001S4M:9/PPR1.180610.011/1564163634:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "UNOWHY/Y10G001S4M_EEA/Y10G001S4M:9/PPR1.180610.011/1564163634:user/release-keys"
resetprop -n ro.product.build.fingerprint "UNOWHY/Y10G001S4M_EEA/Y10G001S4M:9/PPR1.180610.011/1564163634:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "UNOWHY/Y10G001S4M_EEA/Y10G001S4M:9/PPR1.180610.011/1564163634:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=c66b085919
resetprop -n ro.system.build.version.incremental 1564163634
resetprop -n ro.bootimage.build.version.incremental 1564163634
resetprop -n ro.product.build.version.incremental 1564163634
resetprop -n ro.odm.build.version.incremental 1564163634
resetprop -n ro.vendor_dlkm.build.version.incremental 1564163634
resetprop -n ro.system_ext.build.version.incremental 1564163634
resetprop -n ro.build.version.incremental 1564163634
resetprop -n ro.vendor.build.version.incremental 1564163634
resetprop -n ro.odm.build.id "PPR1.180610.011"
resetprop -n ro.product.build.id "PPR1.180610.011"
resetprop -n ro.bootimage.build.id "PPR1.180610.011"
resetprop -n ro.system_ext.build.id "PPR1.180610.011"
resetprop -n ro.vendor_dlkm.build.id "PPR1.180610.011"
resetprop -n ro.build.id "PPR1.180610.011"
resetprop -n ro.system.build.id "PPR1.180610.011"
resetprop -n ro.vendor.build.id "PPR1.180610.011"
resetprop -n ro.system.build.date "Fri Jul 26 17:43:37 UTC 2019"
resetprop -n ro.bootimage.build.date "Fri Jul 26 17:43:37 UTC 2019"
resetprop -n ro.product.build.date "Fri Jul 26 17:43:37 UTC 2019"
resetprop -n ro.vendor_dlkm.build.date "Fri Jul 26 17:43:37 UTC 2019"
resetprop -n ro.system_ext.build.date "Fri Jul 26 17:43:37 UTC 2019"
resetprop -n ro.odm.build.date "Fri Jul 26 17:43:37 UTC 2019"
resetprop -n ro.build.date "Fri Jul 26 17:43:37 UTC 2019"
resetprop -n ro.vendor.build.date "Fri Jul 26 17:43:37 UTC 2019"
resetprop -n ro.product.build.date.utc "1564163017"
resetprop -n ro.system_ext.build.date.utc "1564163017"
resetprop -n ro.system.build.date.utc "1564163017"
resetprop -n ro.vendor.build.date.utc "1564163017"
resetprop -n ro.vendor_dlkm.build.date.utc "1564163017"
resetprop -n ro.build.date.utc "1564163017"
resetprop -n ro.bootimage.build.date.utc "1564163017"
resetprop -n ro.odm.build.date.utc "1564163017"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name Y10G001S4M_EEA
resetprop -n ro.product.odm.name Y10G001S4M_EEA
resetprop -n ro.product.vendor.name Y10G001S4M_EEA
resetprop -n ro.product.system.name Y10G001S4M_EEA
resetprop -n ro.product.name Y10G001S4M_EEA
resetprop -n ro.product.bootimage.name Y10G001S4M_EEA
resetprop -n ro.product.vendor_dlkm.name Y10G001S4M_EEA
resetprop -n ro.product.system_ext.name Y10G001S4M_EEA
resetprop -n ro.build.flavor full_unowhy_k1002-user
randomStr="full_unowhy_k1002-user alps PPR1.180610.011 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=27e01aa5d6f0
resetprop -n ro.build.host ${randomStr}
randomStr=939bcf96
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=byGzxL
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=3b1af423d093f
randomStr2=be
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=86
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1564163634"
resetprop -n ro.build.description "full_unowhy_k1002-user 9 PPR1.180610.011 user.xmlyz.1564163634 release-keys"
resetprop -n ro.build.product.backup "unowhy_k1002"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "xmlyz"
resetprop -n ro.build.host "buildserver"
resetprop -n ro.build.characteristics "tablet"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n debug.hwui.render_dirty_regions "false"
resetprop -n ro.expect.recovery_id "0x144566dcbb59ef8a9a58869a5cbcd238abe6aad8000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-07-05
