strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "N210"
resetprop -n ro.product.vendor.model "N210"
resetprop -n ro.product.vendor_dlkm.marketname "N210"
resetprop -n ro.product.product.marketname "N210"
resetprop -n ro.product.system.marketname "N210"
resetprop -n ro.product.odm_dlkm.marketname "N210"
resetprop -n ro.product.system_ext.marketname "N210"
resetprop -n ro.product.odm_dlkm.model "N210"
resetprop -n ro.product.system.model "N210"
resetprop -n ro.product.system_ext.model "N210"
resetprop -n ro.product.vendor_dlkm.model "N210"
resetprop -n bluetooth.device.default_name "N210"
resetprop -n ro.product.bootimage.model "N210"
resetprop -n ro.product.vendor.marketname "N210"
resetprop -n ro.product.marketname "N210"
resetprop -n ro.product.odm.model "N210"
resetprop -n ro.product.model "N210"
resetprop -n ro.product.product.model "N210"
resetprop -n ro.product.odm.marketname "N210"
resetprop -n ro.product.vendor.manufacturer "DEXP"
resetprop -n ro.product.product.manufacturer "DEXP"
resetprop -n ro.product.bootimage.manufacturer "DEXP"
resetprop -n ro.product.manufacturer "DEXP"
resetprop -n ro.product.odm.manufacturer "DEXP"
resetprop -n ro.product.system.manufacturer "DEXP"
resetprop -n ro.product.system_ext.manufacturer "DEXP"
resetprop -n ro.product.vendor_dlkm.manufacturer "DEXP"
resetprop -n ro.product.vendor.brand "DEXP"
resetprop -n ro.product.product.brand "DEXP"
resetprop -n ro.product.vendor_dlkm.brand "DEXP"
resetprop -n ro.product.system.brand "DEXP"
resetprop -n ro.product.bootimage.brand "DEXP"
resetprop -n ro.product.system_ext.brand "DEXP"
resetprop -n ro.product.odm.brand "DEXP"
resetprop -n ro.product.odm_dlkm.brand "DEXP"
resetprop -n ro.product.brand "DEXP"
resetprop -n ro.vendor_dlkm.build.fingerprint "DEXP/N210/N210:8.1.0/OPM2.171019.012/43319:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "DEXP/N210/N210:8.1.0/OPM2.171019.012/43319:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "DEXP/N210/N210:8.1.0/OPM2.171019.012/43319:user/release-keys"
resetprop -n ro.odm.build.fingerprint "DEXP/N210/N210:8.1.0/OPM2.171019.012/43319:user/release-keys"
resetprop -n ro.system.build.fingerprint "DEXP/N210/N210:8.1.0/OPM2.171019.012/43319:user/release-keys"
resetprop -n ro.build.fingerprint "DEXP/N210/N210:8.1.0/OPM2.171019.012/43319:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "DEXP/N210/N210:8.1.0/OPM2.171019.012/43319:user/release-keys"
resetprop -n ro.product.build.fingerprint "DEXP/N210/N210:8.1.0/OPM2.171019.012/43319:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "DEXP/N210/N210:8.1.0/OPM2.171019.012/43319:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=9002800423
resetprop -n ro.system.build.version.incremental 43319
resetprop -n ro.bootimage.build.version.incremental 43319
resetprop -n ro.product.build.version.incremental 43319
resetprop -n ro.odm.build.version.incremental 43319
resetprop -n ro.vendor_dlkm.build.version.incremental 43319
resetprop -n ro.system_ext.build.version.incremental 43319
resetprop -n ro.build.version.incremental 43319
resetprop -n ro.vendor.build.version.incremental 43319
resetprop -n ro.odm.build.id "OPM2.171019.012"
resetprop -n ro.product.build.id "OPM2.171019.012"
resetprop -n ro.bootimage.build.id "OPM2.171019.012"
resetprop -n ro.system_ext.build.id "OPM2.171019.012"
resetprop -n ro.vendor_dlkm.build.id "OPM2.171019.012"
resetprop -n ro.build.id "OPM2.171019.012"
resetprop -n ro.system.build.id "OPM2.171019.012"
resetprop -n ro.vendor.build.id "OPM2.171019.012"
resetprop -n ro.system.build.date "Wed Oct 24 19:13:02 CST 2018"
resetprop -n ro.bootimage.build.date "Wed Oct 24 19:13:02 CST 2018"
resetprop -n ro.product.build.date "Wed Oct 24 19:13:02 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Wed Oct 24 19:13:02 CST 2018"
resetprop -n ro.system_ext.build.date "Wed Oct 24 19:13:02 CST 2018"
resetprop -n ro.odm.build.date "Wed Oct 24 19:13:02 CST 2018"
resetprop -n ro.build.date "Wed Oct 24 19:13:02 CST 2018"
resetprop -n ro.vendor.build.date "Wed Oct 24 19:13:02 CST 2018"
resetprop -n ro.product.build.date.utc "1540379582"
resetprop -n ro.system_ext.build.date.utc "1540379582"
resetprop -n ro.system.build.date.utc "1540379582"
resetprop -n ro.vendor.build.date.utc "1540379582"
resetprop -n ro.vendor_dlkm.build.date.utc "1540379582"
resetprop -n ro.build.date.utc "1540379582"
resetprop -n ro.bootimage.build.date.utc "1540379582"
resetprop -n ro.odm.build.date.utc "1540379582"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name N210
resetprop -n ro.product.odm.name N210
resetprop -n ro.product.vendor.name N210
resetprop -n ro.product.system.name N210
resetprop -n ro.product.name N210
resetprop -n ro.product.bootimage.name N210
resetprop -n ro.product.vendor_dlkm.name N210
resetprop -n ro.product.system_ext.name N210
resetprop -n ro.build.flavor oversea
randomStr="oversea DEXP OPM2.171019.012 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=5087874cbef8
resetprop -n ro.build.host ${randomStr}
randomStr=220ed0f7
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=nSIqWq
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=56f48b184bcec
randomStr2=30
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=b9
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "43319"
resetprop -n ro.build.description "s1072e_2g-user 8.1.0 OPM2.171019.012 43319 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "lxj"
resetprop -n ro.build.host "ubuntuR730"
resetprop -n ro.build.product.backup "N210"
resetprop -n ro.build.characteristics "tablet"
resetprop -n ro.fota.platform "Sprd9832_8.1"
resetprop -n ro.fota.type "phone"
resetprop -n ro.fota.app "5"
resetprop -n ro.fota.oem "incartech9832_8.1"
resetprop -n ro.fota.device "N210"
resetprop -n ro.fota.version "N210_T1_181024_20181024-1918"
resetprop -n ro.expect.recovery_id "0x337c1873c24f955df8ed900c0f7293dbe6d36c4d000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-09-05
