strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.vendor.model "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.vendor_dlkm.marketname "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.product.marketname "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.system.marketname "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.odm_dlkm.marketname "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.system_ext.marketname "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.odm_dlkm.model "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.system.model "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.system_ext.model "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.vendor_dlkm.model "k63v1us_64_bsp_na_cxp"
resetprop -n bluetooth.device.default_name "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.bootimage.model "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.vendor.marketname "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.marketname "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.odm.model "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.model "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.product.model "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.odm.marketname "k63v1us_64_bsp_na_cxp"
resetprop -n ro.product.vendor.manufacturer "alps"
resetprop -n ro.product.product.manufacturer "alps"
resetprop -n ro.product.bootimage.manufacturer "alps"
resetprop -n ro.product.manufacturer "alps"
resetprop -n ro.product.odm.manufacturer "alps"
resetprop -n ro.product.system.manufacturer "alps"
resetprop -n ro.product.system_ext.manufacturer "alps"
resetprop -n ro.product.vendor_dlkm.manufacturer "alps"
resetprop -n ro.product.vendor.brand "alps"
resetprop -n ro.product.product.brand "alps"
resetprop -n ro.product.vendor_dlkm.brand "alps"
resetprop -n ro.product.system.brand "alps"
resetprop -n ro.product.bootimage.brand "alps"
resetprop -n ro.product.system_ext.brand "alps"
resetprop -n ro.product.odm.brand "alps"
resetprop -n ro.product.odm_dlkm.brand "alps"
resetprop -n ro.product.brand "alps"
resetprop -n ro.vendor_dlkm.build.fingerprint "alps/full_k63v1us_64_bsp_na_cxp/k63v1us_64_bsp:8.1.0/O11019/1534824801:userdebug/dev-keys"
resetprop -n ro.bootimage.build.fingerprint "alps/full_k63v1us_64_bsp_na_cxp/k63v1us_64_bsp:8.1.0/O11019/1534824801:userdebug/dev-keys"
resetprop -n ro.vendor.build.fingerprint "alps/full_k63v1us_64_bsp_na_cxp/k63v1us_64_bsp:8.1.0/O11019/1534824801:userdebug/dev-keys"
resetprop -n ro.odm.build.fingerprint "alps/full_k63v1us_64_bsp_na_cxp/k63v1us_64_bsp:8.1.0/O11019/1534824801:userdebug/dev-keys"
resetprop -n ro.system.build.fingerprint "alps/full_k63v1us_64_bsp_na_cxp/k63v1us_64_bsp:8.1.0/O11019/1534824801:userdebug/dev-keys"
resetprop -n ro.build.fingerprint "alps/full_k63v1us_64_bsp_na_cxp/k63v1us_64_bsp:8.1.0/O11019/1534824801:userdebug/dev-keys"
resetprop -n ro.system_ext.build.fingerprint "alps/full_k63v1us_64_bsp_na_cxp/k63v1us_64_bsp:8.1.0/O11019/1534824801:userdebug/dev-keys"
resetprop -n ro.product.build.fingerprint "alps/full_k63v1us_64_bsp_na_cxp/k63v1us_64_bsp:8.1.0/O11019/1534824801:userdebug/dev-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "alps/full_k63v1us_64_bsp_na_cxp/k63v1us_64_bsp:8.1.0/O11019/1534824801:userdebug/dev-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=04ec163e5b
resetprop -n ro.system.build.version.incremental 1534824801
resetprop -n ro.bootimage.build.version.incremental 1534824801
resetprop -n ro.product.build.version.incremental 1534824801
resetprop -n ro.odm.build.version.incremental 1534824801
resetprop -n ro.vendor_dlkm.build.version.incremental 1534824801
resetprop -n ro.system_ext.build.version.incremental 1534824801
resetprop -n ro.build.version.incremental 1534824801
resetprop -n ro.vendor.build.version.incremental 1534824801
resetprop -n ro.odm.build.id "O11019"
resetprop -n ro.product.build.id "O11019"
resetprop -n ro.bootimage.build.id "O11019"
resetprop -n ro.system_ext.build.id "O11019"
resetprop -n ro.vendor_dlkm.build.id "O11019"
resetprop -n ro.build.id "O11019"
resetprop -n ro.system.build.id "O11019"
resetprop -n ro.vendor.build.id "O11019"
resetprop -n ro.system.build.date "Tue Aug 21 12:13:14 CST 2018"
resetprop -n ro.bootimage.build.date "Tue Aug 21 12:13:14 CST 2018"
resetprop -n ro.product.build.date "Tue Aug 21 12:13:14 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Tue Aug 21 12:13:14 CST 2018"
resetprop -n ro.system_ext.build.date "Tue Aug 21 12:13:14 CST 2018"
resetprop -n ro.odm.build.date "Tue Aug 21 12:13:14 CST 2018"
resetprop -n ro.build.date "Tue Aug 21 12:13:14 CST 2018"
resetprop -n ro.vendor.build.date "Tue Aug 21 12:13:14 CST 2018"
resetprop -n ro.product.build.date.utc "1534824794"
resetprop -n ro.system_ext.build.date.utc "1534824794"
resetprop -n ro.system.build.date.utc "1534824794"
resetprop -n ro.vendor.build.date.utc "1534824794"
resetprop -n ro.vendor_dlkm.build.date.utc "1534824794"
resetprop -n ro.build.date.utc "1534824794"
resetprop -n ro.bootimage.build.date.utc "1534824794"
resetprop -n ro.odm.build.date.utc "1534824794"
resetprop -n ro.product.build.tags "dev-keys"
resetprop -n ro.build.tags "dev-keys"
resetprop -n ro.odm.build.tags "dev-keys"
resetprop -n ro.bootimage.build.tags "dev-keys"
resetprop -n ro.vendor_dlkm.build.tags "dev-keys"
resetprop -n ro.system_ext.build.tags "dev-keys"
resetprop -n ro.vendor.build.tags "dev-keys"
resetprop -n ro.system.build.tags "dev-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name full_k63v1us_64_bsp_na_cxp
resetprop -n ro.product.odm.name full_k63v1us_64_bsp_na_cxp
resetprop -n ro.product.vendor.name full_k63v1us_64_bsp_na_cxp
resetprop -n ro.product.system.name full_k63v1us_64_bsp_na_cxp
resetprop -n ro.product.name full_k63v1us_64_bsp_na_cxp
resetprop -n ro.product.bootimage.name full_k63v1us_64_bsp_na_cxp
resetprop -n ro.product.vendor_dlkm.name full_k63v1us_64_bsp_na_cxp
resetprop -n ro.product.system_ext.name full_k63v1us_64_bsp_na_cxp
resetprop -n ro.build.flavor full_k63v1us_64_bsp_na_cxp-userdebug
randomStr="full_k63v1us_64_bsp_na_cxp-userdebug alps O11019 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=51190f983975
resetprop -n ro.build.host ${randomStr}
randomStr=fda67c9c
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=QKSNEX
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=c83edc742b06d
randomStr2=a3
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=ec
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1534824801"
resetprop -n ro.build.description "full_k63v1us_64_bsp_na_cxp-userdebug 8.1.0 O11019 1534824801 dev-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "yusubm"
resetprop -n ro.build.host "mbjswrdlsf9-63490505"
resetprop -n ro.build.product.backup "k63v1us_64_bsp"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.expect.recovery_id "0x20c52d9e8707aedf06e7e744fd34dc4dfe3f769d000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-08-05
