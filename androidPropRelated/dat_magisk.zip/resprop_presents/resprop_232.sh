strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "TYH232U"
resetprop -n ro.product.vendor.model "TYH232U"
resetprop -n ro.product.vendor_dlkm.marketname "TYH232U"
resetprop -n ro.product.product.marketname "TYH232U"
resetprop -n ro.product.system.marketname "TYH232U"
resetprop -n ro.product.odm_dlkm.marketname "TYH232U"
resetprop -n ro.product.system_ext.marketname "TYH232U"
resetprop -n ro.product.odm_dlkm.model "TYH232U"
resetprop -n ro.product.system.model "TYH232U"
resetprop -n ro.product.system_ext.model "TYH232U"
resetprop -n ro.product.vendor_dlkm.model "TYH232U"
resetprop -n bluetooth.device.default_name "TYH232U"
resetprop -n ro.product.bootimage.model "TYH232U"
resetprop -n ro.product.vendor.marketname "TYH232U"
resetprop -n ro.product.marketname "TYH232U"
resetprop -n ro.product.odm.model "TYH232U"
resetprop -n ro.product.model "TYH232U"
resetprop -n ro.product.product.model "TYH232U"
resetprop -n ro.product.odm.marketname "TYH232U"
resetprop -n ro.product.vendor.manufacturer "ChinaTelecom"
resetprop -n ro.product.product.manufacturer "ChinaTelecom"
resetprop -n ro.product.bootimage.manufacturer "ChinaTelecom"
resetprop -n ro.product.manufacturer "ChinaTelecom"
resetprop -n ro.product.odm.manufacturer "ChinaTelecom"
resetprop -n ro.product.system.manufacturer "ChinaTelecom"
resetprop -n ro.product.system_ext.manufacturer "ChinaTelecom"
resetprop -n ro.product.vendor_dlkm.manufacturer "ChinaTelecom"
resetprop -n ro.product.vendor.brand "Bodun"
resetprop -n ro.product.product.brand "Bodun"
resetprop -n ro.product.vendor_dlkm.brand "Bodun"
resetprop -n ro.product.system.brand "Bodun"
resetprop -n ro.product.bootimage.brand "Bodun"
resetprop -n ro.product.system_ext.brand "Bodun"
resetprop -n ro.product.odm.brand "Bodun"
resetprop -n ro.product.odm_dlkm.brand "Bodun"
resetprop -n ro.product.brand "Bodun"
resetprop -n ro.vendor_dlkm.build.fingerprint "ChinaTelecom/TURING/TURING:11/RP1A.201005.001/1695577094:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "ChinaTelecom/TURING/TURING:11/RP1A.201005.001/1695577094:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "ChinaTelecom/TURING/TURING:11/RP1A.201005.001/1695577094:user/release-keys"
resetprop -n ro.odm.build.fingerprint "ChinaTelecom/TURING/TURING:11/RP1A.201005.001/1695577094:user/release-keys"
resetprop -n ro.system.build.fingerprint "ChinaTelecom/TURING/TURING:11/RP1A.201005.001/1695577094:user/release-keys"
resetprop -n ro.build.fingerprint "ChinaTelecom/TURING/TURING:11/RP1A.201005.001/1695577094:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "ChinaTelecom/TURING/TURING:11/RP1A.201005.001/1695577094:user/release-keys"
resetprop -n ro.product.build.fingerprint "ChinaTelecom/TURING/TURING:11/RP1A.201005.001/1695577094:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "ChinaTelecom/TURING/TURING:11/RP1A.201005.001/1695577094:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=07fee38a2d
resetprop -n ro.system.build.version.incremental 1695577094
resetprop -n ro.bootimage.build.version.incremental 1695577094
resetprop -n ro.product.build.version.incremental 1695577094
resetprop -n ro.odm.build.version.incremental 1695577094
resetprop -n ro.vendor_dlkm.build.version.incremental 1695577094
resetprop -n ro.system_ext.build.version.incremental 1695577094
resetprop -n ro.build.version.incremental 1695577094
resetprop -n ro.vendor.build.version.incremental 1695577094
resetprop -n ro.odm.build.id "RP1A.201005.001"
resetprop -n ro.product.build.id "RP1A.201005.001"
resetprop -n ro.bootimage.build.id "RP1A.201005.001"
resetprop -n ro.system_ext.build.id "RP1A.201005.001"
resetprop -n ro.vendor_dlkm.build.id "RP1A.201005.001"
resetprop -n ro.build.id "RP1A.201005.001"
resetprop -n ro.system.build.id "RP1A.201005.001"
resetprop -n ro.vendor.build.id "RP1A.201005.001"
resetprop -n ro.system.build.date "Mon Sep 25 01:58:47 CST 2023"
resetprop -n ro.bootimage.build.date "Mon Sep 25 01:58:47 CST 2023"
resetprop -n ro.product.build.date "Mon Sep 25 01:58:47 CST 2023"
resetprop -n ro.vendor_dlkm.build.date "Mon Sep 25 01:58:47 CST 2023"
resetprop -n ro.system_ext.build.date "Mon Sep 25 01:58:47 CST 2023"
resetprop -n ro.odm.build.date "Mon Sep 25 01:58:47 CST 2023"
resetprop -n ro.build.date "Mon Sep 25 01:58:47 CST 2023"
resetprop -n ro.vendor.build.date "Mon Sep 25 01:58:47 CST 2023"
resetprop -n ro.product.build.date.utc "1695578327"
resetprop -n ro.system_ext.build.date.utc "1695578327"
resetprop -n ro.system.build.date.utc "1695578327"
resetprop -n ro.vendor.build.date.utc "1695578327"
resetprop -n ro.vendor_dlkm.build.date.utc "1695578327"
resetprop -n ro.build.date.utc "1695578327"
resetprop -n ro.bootimage.build.date.utc "1695578327"
resetprop -n ro.odm.build.date.utc "1695578327"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name TURING
resetprop -n ro.product.odm.name TURING
resetprop -n ro.product.vendor.name TURING
resetprop -n ro.product.system.name TURING
resetprop -n ro.product.name TURING
resetprop -n ro.product.bootimage.name TURING
resetprop -n ro.product.vendor_dlkm.name TURING
resetprop -n ro.product.system_ext.name TURING
resetprop -n ro.build.flavor ums9620_2h10_ctcc-user
randomStr="ums9620_2h10_ctcc-user ChinaTelecom RP1A.201005.001 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=deed17182dac
resetprop -n ro.build.host ${randomStr}
randomStr=0ba4f46b
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=zeZCoq
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=dbf0268999057
randomStr2=3b
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=7c
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1695577094"
resetprop -n ro.build.description "ums9620_2h10_ctcc-user 11 RP1A.201005.001 1695577094 release-keys"
resetprop -n ro.build.product.backup "ums9620_2h10"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "flyme"
resetprop -n ro.build.host "Mz-Builder-L29"
resetprop -n ro.flyme.version.id "TYH 9.23.9.25 daily"
resetprop -n ro.meizu.project.id "S8201-9"
resetprop -n ro.product.flyme.model "S8201"
resetprop -n ro.build.flyme.version "9"
resetprop -n ro.flyme.published "true"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2022-11-05
