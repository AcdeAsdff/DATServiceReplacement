strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "E940-2766-00"
resetprop -n ro.product.vendor.model "E940-2766-00"
resetprop -n ro.product.vendor_dlkm.marketname "E940-2766-00"
resetprop -n ro.product.product.marketname "E940-2766-00"
resetprop -n ro.product.system.marketname "E940-2766-00"
resetprop -n ro.product.odm_dlkm.marketname "E940-2766-00"
resetprop -n ro.product.system_ext.marketname "E940-2766-00"
resetprop -n ro.product.odm_dlkm.model "E940-2766-00"
resetprop -n ro.product.system.model "E940-2766-00"
resetprop -n ro.product.system_ext.model "E940-2766-00"
resetprop -n ro.product.vendor_dlkm.model "E940-2766-00"
resetprop -n bluetooth.device.default_name "E940-2766-00"
resetprop -n ro.product.bootimage.model "E940-2766-00"
resetprop -n ro.product.vendor.marketname "E940-2766-00"
resetprop -n ro.product.marketname "E940-2766-00"
resetprop -n ro.product.odm.model "E940-2766-00"
resetprop -n ro.product.model "E940-2766-00"
resetprop -n ro.product.product.model "E940-2766-00"
resetprop -n ro.product.odm.marketname "E940-2766-00"
resetprop -n ro.product.vendor.manufacturer "Gigaset"
resetprop -n ro.product.product.manufacturer "Gigaset"
resetprop -n ro.product.bootimage.manufacturer "Gigaset"
resetprop -n ro.product.manufacturer "Gigaset"
resetprop -n ro.product.odm.manufacturer "Gigaset"
resetprop -n ro.product.system.manufacturer "Gigaset"
resetprop -n ro.product.system_ext.manufacturer "Gigaset"
resetprop -n ro.product.vendor_dlkm.manufacturer "Gigaset"
resetprop -n ro.product.vendor.brand "Gigaset"
resetprop -n ro.product.product.brand "Gigaset"
resetprop -n ro.product.vendor_dlkm.brand "Gigaset"
resetprop -n ro.product.system.brand "Gigaset"
resetprop -n ro.product.bootimage.brand "Gigaset"
resetprop -n ro.product.system_ext.brand "Gigaset"
resetprop -n ro.product.odm.brand "Gigaset"
resetprop -n ro.product.odm_dlkm.brand "Gigaset"
resetprop -n ro.product.brand "Gigaset"
resetprop -n ro.vendor_dlkm.build.fingerprint "Gigaset/GS3_EEA/GS3:10/QP1A.190711.020/202302210925:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Gigaset/GS3_EEA/GS3:10/QP1A.190711.020/202302210925:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Gigaset/GS3_EEA/GS3:10/QP1A.190711.020/202302210925:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Gigaset/GS3_EEA/GS3:10/QP1A.190711.020/202302210925:user/release-keys"
resetprop -n ro.system.build.fingerprint "Gigaset/GS3_EEA/GS3:10/QP1A.190711.020/202302210925:user/release-keys"
resetprop -n ro.build.fingerprint "Gigaset/GS3_EEA/GS3:10/QP1A.190711.020/202302210925:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Gigaset/GS3_EEA/GS3:10/QP1A.190711.020/202302210925:user/release-keys"
resetprop -n ro.product.build.fingerprint "Gigaset/GS3_EEA/GS3:10/QP1A.190711.020/202302210925:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Gigaset/GS3_EEA/GS3:10/QP1A.190711.020/202302210925:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=ca83b752b7
resetprop -n ro.system.build.version.incremental 202302210925
resetprop -n ro.bootimage.build.version.incremental 202302210925
resetprop -n ro.product.build.version.incremental 202302210925
resetprop -n ro.odm.build.version.incremental 202302210925
resetprop -n ro.vendor_dlkm.build.version.incremental 202302210925
resetprop -n ro.system_ext.build.version.incremental 202302210925
resetprop -n ro.build.version.incremental 202302210925
resetprop -n ro.vendor.build.version.incremental 202302210925
resetprop -n ro.odm.build.id "QP1A.190711.020"
resetprop -n ro.product.build.id "QP1A.190711.020"
resetprop -n ro.bootimage.build.id "QP1A.190711.020"
resetprop -n ro.system_ext.build.id "QP1A.190711.020"
resetprop -n ro.vendor_dlkm.build.id "QP1A.190711.020"
resetprop -n ro.build.id "QP1A.190711.020"
resetprop -n ro.system.build.id "QP1A.190711.020"
resetprop -n ro.vendor.build.id "QP1A.190711.020"
resetprop -n ro.system.build.date "Tue Feb 21 13:38:21 CST 2023"
resetprop -n ro.bootimage.build.date "Tue Feb 21 13:38:21 CST 2023"
resetprop -n ro.product.build.date "Tue Feb 21 13:38:21 CST 2023"
resetprop -n ro.vendor_dlkm.build.date "Tue Feb 21 13:38:21 CST 2023"
resetprop -n ro.system_ext.build.date "Tue Feb 21 13:38:21 CST 2023"
resetprop -n ro.odm.build.date "Tue Feb 21 13:38:21 CST 2023"
resetprop -n ro.build.date "Tue Feb 21 13:38:21 CST 2023"
resetprop -n ro.vendor.build.date "Tue Feb 21 13:38:21 CST 2023"
resetprop -n ro.product.build.date.utc "1676957901"
resetprop -n ro.system_ext.build.date.utc "1676957901"
resetprop -n ro.system.build.date.utc "1676957901"
resetprop -n ro.vendor.build.date.utc "1676957901"
resetprop -n ro.vendor_dlkm.build.date.utc "1676957901"
resetprop -n ro.build.date.utc "1676957901"
resetprop -n ro.bootimage.build.date.utc "1676957901"
resetprop -n ro.odm.build.date.utc "1676957901"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name GS3_EEA
resetprop -n ro.product.odm.name GS3_EEA
resetprop -n ro.product.vendor.name GS3_EEA
resetprop -n ro.product.system.name GS3_EEA
resetprop -n ro.product.name GS3_EEA
resetprop -n ro.product.bootimage.name GS3_EEA
resetprop -n ro.product.vendor_dlkm.name GS3_EEA
resetprop -n ro.product.system_ext.name GS3_EEA
resetprop -n ro.build.flavor full_yk673v6_lwg62_64-user
randomStr="full_yk673v6_lwg62_64-user Gigaset QP1A.190711.020 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=201cbbe054a8
resetprop -n ro.build.host ${randomStr}
randomStr=de78fa73
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=rumQeY
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=770a560eb2658
randomStr2=aa
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=3e
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "202302210925"
resetprop -n ro.build.description "full_yk673v6_lwg62_64-user 10 QP1A.190711.020 p1k61v164bspP53 release-keys"
resetprop -n ro.build.product.backup "GS3"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "fcl"
resetprop -n ro.build.host "server"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.fota.platform "MTK6762_10.0"
resetprop -n ro.fota.type "phone"
resetprop -n ro.fota.app "5"
resetprop -n ro.fota.battery "30"
resetprop -n ro.fota.hide.shake "1"
resetprop -n ro.fota.oem "waterworld86762_10.0"
resetprop -n ro.fota.device "E940-2766-00"
resetprop -n ro.fota.version "E940-2766-00_10.0_V30_20230221_20230221-1444"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2023-02-05
