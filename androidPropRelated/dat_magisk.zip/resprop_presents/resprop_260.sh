strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Allure M3"
resetprop -n ro.product.vendor.model "Allure M3"
resetprop -n ro.product.vendor_dlkm.marketname "Allure M3"
resetprop -n ro.product.product.marketname "Allure M3"
resetprop -n ro.product.system.marketname "Allure M3"
resetprop -n ro.product.odm_dlkm.marketname "Allure M3"
resetprop -n ro.product.system_ext.marketname "Allure M3"
resetprop -n ro.product.odm_dlkm.model "Allure M3"
resetprop -n ro.product.system.model "Allure M3"
resetprop -n ro.product.system_ext.model "Allure M3"
resetprop -n ro.product.vendor_dlkm.model "Allure M3"
resetprop -n bluetooth.device.default_name "Allure M3"
resetprop -n ro.product.bootimage.model "Allure M3"
resetprop -n ro.product.vendor.marketname "Allure M3"
resetprop -n ro.product.marketname "Allure M3"
resetprop -n ro.product.odm.model "Allure M3"
resetprop -n ro.product.model "Allure M3"
resetprop -n ro.product.product.model "Allure M3"
resetprop -n ro.product.odm.marketname "Allure M3"
resetprop -n ro.product.vendor.manufacturer "SPA Condor Electronics"
resetprop -n ro.product.product.manufacturer "SPA Condor Electronics"
resetprop -n ro.product.bootimage.manufacturer "SPA Condor Electronics"
resetprop -n ro.product.manufacturer "SPA Condor Electronics"
resetprop -n ro.product.odm.manufacturer "SPA Condor Electronics"
resetprop -n ro.product.system.manufacturer "SPA Condor Electronics"
resetprop -n ro.product.system_ext.manufacturer "SPA Condor Electronics"
resetprop -n ro.product.vendor_dlkm.manufacturer "SPA Condor Electronics"
resetprop -n ro.product.vendor.brand "Condor"
resetprop -n ro.product.product.brand "Condor"
resetprop -n ro.product.vendor_dlkm.brand "Condor"
resetprop -n ro.product.system.brand "Condor"
resetprop -n ro.product.bootimage.brand "Condor"
resetprop -n ro.product.system_ext.brand "Condor"
resetprop -n ro.product.odm.brand "Condor"
resetprop -n ro.product.odm_dlkm.brand "Condor"
resetprop -n ro.product.brand "Condor"
resetprop -n ro.vendor_dlkm.build.fingerprint "Condor/Allure_M3/Allure_M3:8.1.0/O11019/1540462721:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Condor/Allure_M3/Allure_M3:8.1.0/O11019/1540462721:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Condor/Allure_M3/Allure_M3:8.1.0/O11019/1540462721:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Condor/Allure_M3/Allure_M3:8.1.0/O11019/1540462721:user/release-keys"
resetprop -n ro.system.build.fingerprint "Condor/Allure_M3/Allure_M3:8.1.0/O11019/1540462721:user/release-keys"
resetprop -n ro.build.fingerprint "Condor/Allure_M3/Allure_M3:8.1.0/O11019/1540462721:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Condor/Allure_M3/Allure_M3:8.1.0/O11019/1540462721:user/release-keys"
resetprop -n ro.product.build.fingerprint "Condor/Allure_M3/Allure_M3:8.1.0/O11019/1540462721:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Condor/Allure_M3/Allure_M3:8.1.0/O11019/1540462721:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=7c89daaec3
resetprop -n ro.system.build.version.incremental 1540462721
resetprop -n ro.bootimage.build.version.incremental 1540462721
resetprop -n ro.product.build.version.incremental 1540462721
resetprop -n ro.odm.build.version.incremental 1540462721
resetprop -n ro.vendor_dlkm.build.version.incremental 1540462721
resetprop -n ro.system_ext.build.version.incremental 1540462721
resetprop -n ro.build.version.incremental 1540462721
resetprop -n ro.vendor.build.version.incremental 1540462721
resetprop -n ro.odm.build.id "O11019"
resetprop -n ro.product.build.id "O11019"
resetprop -n ro.bootimage.build.id "O11019"
resetprop -n ro.system_ext.build.id "O11019"
resetprop -n ro.vendor_dlkm.build.id "O11019"
resetprop -n ro.build.id "O11019"
resetprop -n ro.system.build.id "O11019"
resetprop -n ro.vendor.build.id "O11019"
resetprop -n ro.system.build.date "Thu Oct 25 18:18:40 CST 2018"
resetprop -n ro.bootimage.build.date "Thu Oct 25 18:18:40 CST 2018"
resetprop -n ro.product.build.date "Thu Oct 25 18:18:40 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Thu Oct 25 18:18:40 CST 2018"
resetprop -n ro.system_ext.build.date "Thu Oct 25 18:18:40 CST 2018"
resetprop -n ro.odm.build.date "Thu Oct 25 18:18:40 CST 2018"
resetprop -n ro.build.date "Thu Oct 25 18:18:40 CST 2018"
resetprop -n ro.vendor.build.date "Thu Oct 25 18:18:40 CST 2018"
resetprop -n ro.product.build.date.utc "1540462720"
resetprop -n ro.system_ext.build.date.utc "1540462720"
resetprop -n ro.system.build.date.utc "1540462720"
resetprop -n ro.vendor.build.date.utc "1540462720"
resetprop -n ro.vendor_dlkm.build.date.utc "1540462720"
resetprop -n ro.build.date.utc "1540462720"
resetprop -n ro.bootimage.build.date.utc "1540462720"
resetprop -n ro.odm.build.date.utc "1540462720"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name Allure_M3
resetprop -n ro.product.odm.name Allure_M3
resetprop -n ro.product.vendor.name Allure_M3
resetprop -n ro.product.system.name Allure_M3
resetprop -n ro.product.name Allure_M3
resetprop -n ro.product.bootimage.name Allure_M3
resetprop -n ro.product.vendor_dlkm.name Allure_M3
resetprop -n ro.product.system_ext.name Allure_M3
resetprop -n ro.build.flavor full_k71v1_64_bsp-user
randomStr="full_k71v1_64_bsp-user SPA Condor Electronics O11019 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=083e75c76bb3
resetprop -n ro.build.host ${randomStr}
randomStr=fd87153f
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=NnCJCP
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=a76ccead07f8b
randomStr2=f2
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=55
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1540462721"
resetprop -n ro.build.description "full_k71v1_64_bsp-user 8.1.0 O11019 1540462721 release-keys"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.build.host "buildrpc05"
resetprop -n ro.build.product.backup "Allure_M3"
resetprop -n ro.build.user "android"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.com.google.acsa "true"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.expect.recovery_id "0x4f05a3438a4a17b3b13fea7dc332a7f069e277e5000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-10-05
