strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "vivo 2026"
resetprop -n ro.product.vendor.model "vivo 2026"
resetprop -n ro.product.vendor_dlkm.marketname "vivo 2026"
resetprop -n ro.product.product.marketname "vivo 2026"
resetprop -n ro.product.system.marketname "vivo 2026"
resetprop -n ro.product.odm_dlkm.marketname "vivo 2026"
resetprop -n ro.product.system_ext.marketname "vivo 2026"
resetprop -n ro.product.odm_dlkm.model "vivo 2026"
resetprop -n ro.product.system.model "vivo 2026"
resetprop -n ro.product.system_ext.model "vivo 2026"
resetprop -n ro.product.vendor_dlkm.model "vivo 2026"
resetprop -n bluetooth.device.default_name "vivo 2026"
resetprop -n ro.product.bootimage.model "vivo 2026"
resetprop -n ro.product.vendor.marketname "vivo 2026"
resetprop -n ro.product.marketname "vivo 2026"
resetprop -n ro.product.odm.model "vivo 2026"
resetprop -n ro.product.model "vivo 2026"
resetprop -n ro.product.product.model "vivo 2026"
resetprop -n ro.product.odm.marketname "vivo 2026"
resetprop -n ro.product.vendor.manufacturer "vivo"
resetprop -n ro.product.product.manufacturer "vivo"
resetprop -n ro.product.bootimage.manufacturer "vivo"
resetprop -n ro.product.manufacturer "vivo"
resetprop -n ro.product.odm.manufacturer "vivo"
resetprop -n ro.product.system.manufacturer "vivo"
resetprop -n ro.product.system_ext.manufacturer "vivo"
resetprop -n ro.product.vendor_dlkm.manufacturer "vivo"
resetprop -n ro.product.vendor.brand "vivo"
resetprop -n ro.product.product.brand "vivo"
resetprop -n ro.product.vendor_dlkm.brand "vivo"
resetprop -n ro.product.system.brand "vivo"
resetprop -n ro.product.bootimage.brand "vivo"
resetprop -n ro.product.system_ext.brand "vivo"
resetprop -n ro.product.odm.brand "vivo"
resetprop -n ro.product.odm_dlkm.brand "vivo"
resetprop -n ro.product.brand "vivo"
resetprop -n ro.vendor_dlkm.build.fingerprint "vivo/2026/2026:10/QP1A.190711.020/compiler01122029:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "vivo/2026/2026:10/QP1A.190711.020/compiler01122029:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "vivo/2026/2026:10/QP1A.190711.020/compiler01122029:user/release-keys"
resetprop -n ro.odm.build.fingerprint "vivo/2026/2026:10/QP1A.190711.020/compiler01122029:user/release-keys"
resetprop -n ro.system.build.fingerprint "vivo/2026/2026:10/QP1A.190711.020/compiler01122029:user/release-keys"
resetprop -n ro.build.fingerprint "vivo/2026/2026:10/QP1A.190711.020/compiler01122029:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "vivo/2026/2026:10/QP1A.190711.020/compiler01122029:user/release-keys"
resetprop -n ro.product.build.fingerprint "vivo/2026/2026:10/QP1A.190711.020/compiler01122029:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "vivo/2026/2026:10/QP1A.190711.020/compiler01122029:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=6fd8dd61bc
resetprop -n ro.system.build.version.incremental compiler01122029
resetprop -n ro.bootimage.build.version.incremental compiler01122029
resetprop -n ro.product.build.version.incremental compiler01122029
resetprop -n ro.odm.build.version.incremental compiler01122029
resetprop -n ro.vendor_dlkm.build.version.incremental compiler01122029
resetprop -n ro.system_ext.build.version.incremental compiler01122029
resetprop -n ro.build.version.incremental compiler01122029
resetprop -n ro.vendor.build.version.incremental compiler01122029
resetprop -n ro.odm.build.id "QP1A.190711.020"
resetprop -n ro.product.build.id "QP1A.190711.020"
resetprop -n ro.bootimage.build.id "QP1A.190711.020"
resetprop -n ro.system_ext.build.id "QP1A.190711.020"
resetprop -n ro.vendor_dlkm.build.id "QP1A.190711.020"
resetprop -n ro.build.id "QP1A.190711.020"
resetprop -n ro.system.build.id "QP1A.190711.020"
resetprop -n ro.vendor.build.id "QP1A.190711.020"
resetprop -n ro.system.build.date "Tue Jan 12 20:48:44 CST 2021"
resetprop -n ro.bootimage.build.date "Tue Jan 12 20:48:44 CST 2021"
resetprop -n ro.product.build.date "Tue Jan 12 20:48:44 CST 2021"
resetprop -n ro.vendor_dlkm.build.date "Tue Jan 12 20:48:44 CST 2021"
resetprop -n ro.system_ext.build.date "Tue Jan 12 20:48:44 CST 2021"
resetprop -n ro.odm.build.date "Tue Jan 12 20:48:44 CST 2021"
resetprop -n ro.build.date "Tue Jan 12 20:48:44 CST 2021"
resetprop -n ro.vendor.build.date "Tue Jan 12 20:48:44 CST 2021"
resetprop -n ro.product.build.date.utc "1610455724"
resetprop -n ro.system_ext.build.date.utc "1610455724"
resetprop -n ro.system.build.date.utc "1610455724"
resetprop -n ro.vendor.build.date.utc "1610455724"
resetprop -n ro.vendor_dlkm.build.date.utc "1610455724"
resetprop -n ro.build.date.utc "1610455724"
resetprop -n ro.bootimage.build.date.utc "1610455724"
resetprop -n ro.odm.build.date.utc "1610455724"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name full_k65v1_64_bsp
resetprop -n ro.product.odm.name full_k65v1_64_bsp
resetprop -n ro.product.vendor.name full_k65v1_64_bsp
resetprop -n ro.product.system.name full_k65v1_64_bsp
resetprop -n ro.product.name full_k65v1_64_bsp
resetprop -n ro.product.bootimage.name full_k65v1_64_bsp
resetprop -n ro.product.vendor_dlkm.name full_k65v1_64_bsp
resetprop -n ro.product.system_ext.name full_k65v1_64_bsp
resetprop -n ro.build.flavor full_k65v1_64_bsp-user
randomStr="full_k65v1_64_bsp-user vivo QP1A.190711.020 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=07c6907fbd3e
resetprop -n ro.build.host ${randomStr}
randomStr=702dd781
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=pmHQli
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=aaade750cac19
randomStr2=bf
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=98
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "compiler01122029"
resetprop -n ro.build.description "full_k65v1_64_bsp-user 10 QP1A.190711.020 compiler01122029 release-keys"
resetprop -n ro.build.product.backup "k65v1_64_bsp"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "compiler"
resetprop -n ro.build.host "comsz01078160"
resetprop -n ro.vivo.os.build.display.id "Funtouch OS 11 Global"
resetprop -n ro.vivo.product.release.name "2026"
resetprop -n ro.vivo.product.release.model "2026"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n persist.vivo.unsupport_spaced_unlock "false"
resetprop -n persist.vivo.proxcovernotice "screen_full"
resetprop -n persist.vivo.displayp3.support "0"
resetprop -n persist.vivo.phone.panel_type "tft"
resetprop -n persist.vivo.motion_raise2wake "enable"
resetprop -n persist.vivo.compass.no_return "true"
resetprop -n persist.vivo.check_fast_charge "0"
resetprop -n persist.vivo.enable_fast_charge "0"
resetprop -n persist.vivo.charge.version "0"
resetprop -n persist.vivo.phone.sarpower "Have_sarpower"
resetprop -n persist.vivo.new_three_finger_gesture "true"
resetprop -n persist.vivo.sar "0.87;0.55"
resetprop -n persist.vivo.phone.wfd "Have_wfd"
resetprop -n persist.vivo.mtk.networkstate_tcp_parameter.enable "true"
resetprop -n persist.vivo.phone.screen_size "60"
resetprop -n persist.vivo.smartkey.enable "true"
resetprop -n persist.vivo.phone.usb_otg "Have_usb_otg"
resetprop -n persist.vivo.phone.num_battery "Have_battery_percentage"
resetprop -n persist.vivo.disable_chg_switch "1"
resetprop -n persist.vivo.calling_state "0"
resetprop -n persist.vivo.camera4k_state "0"
resetprop -n persist.vivo.camera_state "0"
resetprop -n persist.vivo.weixin_calling_state "0"
resetprop -n persist.vivo.phone.super_lcd "false"
resetprop -n persist.system.vivo.enable_color_mode_id "0"
resetprop -n persist.vivo.phone.fps_default "1"
resetprop -n persist.vivo.phone.fps_max "60"
resetprop -n persist.vivo.nfc.cardreadft "1"
resetprop -n persist.vivo.opensluri.support "1"
resetprop -n persist.vivo.feiyu.enable "true"
resetprop -n ro.persist.vivo.sar "0.87;0.55"
resetprop -n ro.com.google.clientidbase "android-vivo"
resetprop -n ro.com.google.clientidbase.ms "android-vivo-rev1"
resetprop -n ro.com.google.clientidbase.cr "android-vivo"
resetprop -n ro.com.google.ime.number_row "true"
resetprop -n ro.com.google.rlzbrandcode "VIVO"
resetprop -n ro.vivo.media.subtitle_support "true"
resetprop -n ro.vivo.oem.support "yes"
resetprop -n persist.vivo.radio.type.list "WCDMA,TDD-LTE,FDD-LTE,GSM"
resetprop -n ro.vivo.lcm.xhd "HD_19x5_9"
resetprop -n persist.vivo.support_close_gp "1"
resetprop -n ro.vivo.lte.voice.type "CSFB"
resetprop -n ro.vivo.net.entry "no"
resetprop -n ro.vivo.op.entry "no"
resetprop -n ro.vivo.hardware.version "PD2036F_EXMA"
resetprop -n ro.vivo.product.solution "MTK"
resetprop -n ro.vivo.product.platform "MTK6765"
resetprop -n ro.vivo.board.version "MA"
resetprop -n ro.vivo.os.name "vos"
resetprop -n ro.vivo.os.version "11.0"
resetprop -n ro.vivo.rom "vos_2.0"
resetprop -n ro.vivo.rom.version "vos_2.0"
resetprop -n ro.vivo.build.version.sdk "1"
resetprop -n persist.vivo.support.wallet.icon "true"
resetprop -n ro.vivo.rom.style "vigour"
resetprop -n ro.vivo.product.overseas "yes"
resetprop -n ro.vivo.system.product.version "PD2036F_EX_A_1.10.2"
resetprop -n ro.vivo.system.hardware.version "PD2036F_EXMA"
resetprop -n ro.vivo.product.series "Y"
resetprop -n persist.vivo.face.assistant "0"
resetprop -n persist.system.vivo.face.unlock.strong "1"
resetprop -n persist.system.vivo.face.unlock.convenience.scheme "0"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2020-11-01
