strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Archos 70d Titanium"
resetprop -n ro.product.vendor.model "Archos 70d Titanium"
resetprop -n ro.product.vendor_dlkm.marketname "Archos 70d Titanium"
resetprop -n ro.product.product.marketname "Archos 70d Titanium"
resetprop -n ro.product.system.marketname "Archos 70d Titanium"
resetprop -n ro.product.odm_dlkm.marketname "Archos 70d Titanium"
resetprop -n ro.product.system_ext.marketname "Archos 70d Titanium"
resetprop -n ro.product.odm_dlkm.model "Archos 70d Titanium"
resetprop -n ro.product.system.model "Archos 70d Titanium"
resetprop -n ro.product.system_ext.model "Archos 70d Titanium"
resetprop -n ro.product.vendor_dlkm.model "Archos 70d Titanium"
resetprop -n bluetooth.device.default_name "Archos 70d Titanium"
resetprop -n ro.product.bootimage.model "Archos 70d Titanium"
resetprop -n ro.product.vendor.marketname "Archos 70d Titanium"
resetprop -n ro.product.marketname "Archos 70d Titanium"
resetprop -n ro.product.odm.model "Archos 70d Titanium"
resetprop -n ro.product.model "Archos 70d Titanium"
resetprop -n ro.product.product.model "Archos 70d Titanium"
resetprop -n ro.product.odm.marketname "Archos 70d Titanium"
resetprop -n ro.product.vendor.manufacturer "Archos"
resetprop -n ro.product.product.manufacturer "Archos"
resetprop -n ro.product.bootimage.manufacturer "Archos"
resetprop -n ro.product.manufacturer "Archos"
resetprop -n ro.product.odm.manufacturer "Archos"
resetprop -n ro.product.system.manufacturer "Archos"
resetprop -n ro.product.system_ext.manufacturer "Archos"
resetprop -n ro.product.vendor_dlkm.manufacturer "Archos"
resetprop -n ro.product.vendor.brand "archos"
resetprop -n ro.product.product.brand "archos"
resetprop -n ro.product.vendor_dlkm.brand "archos"
resetprop -n ro.product.system.brand "archos"
resetprop -n ro.product.bootimage.brand "archos"
resetprop -n ro.product.system_ext.brand "archos"
resetprop -n ro.product.odm.brand "archos"
resetprop -n ro.product.odm_dlkm.brand "archos"
resetprop -n ro.product.brand "archos"
resetprop -n ro.vendor_dlkm.build.fingerprint "archos/MTKAC70DTI/ac70dti:7.0/NRD90M/20170602.033254:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "archos/MTKAC70DTI/ac70dti:7.0/NRD90M/20170602.033254:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "archos/MTKAC70DTI/ac70dti:7.0/NRD90M/20170602.033254:user/release-keys"
resetprop -n ro.odm.build.fingerprint "archos/MTKAC70DTI/ac70dti:7.0/NRD90M/20170602.033254:user/release-keys"
resetprop -n ro.system.build.fingerprint "archos/MTKAC70DTI/ac70dti:7.0/NRD90M/20170602.033254:user/release-keys"
resetprop -n ro.build.fingerprint "archos/MTKAC70DTI/ac70dti:7.0/NRD90M/20170602.033254:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "archos/MTKAC70DTI/ac70dti:7.0/NRD90M/20170602.033254:user/release-keys"
resetprop -n ro.product.build.fingerprint "archos/MTKAC70DTI/ac70dti:7.0/NRD90M/20170602.033254:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "archos/MTKAC70DTI/ac70dti:7.0/NRD90M/20170602.033254:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=c0cd27856d
resetprop -n ro.system.build.version.incremental 20170602.033254
resetprop -n ro.bootimage.build.version.incremental 20170602.033254
resetprop -n ro.product.build.version.incremental 20170602.033254
resetprop -n ro.odm.build.version.incremental 20170602.033254
resetprop -n ro.vendor_dlkm.build.version.incremental 20170602.033254
resetprop -n ro.system_ext.build.version.incremental 20170602.033254
resetprop -n ro.build.version.incremental 20170602.033254
resetprop -n ro.vendor.build.version.incremental 20170602.033254
resetprop -n ro.odm.build.id "NRD90M"
resetprop -n ro.product.build.id "NRD90M"
resetprop -n ro.bootimage.build.id "NRD90M"
resetprop -n ro.system_ext.build.id "NRD90M"
resetprop -n ro.vendor_dlkm.build.id "NRD90M"
resetprop -n ro.build.id "NRD90M"
resetprop -n ro.system.build.id "NRD90M"
resetprop -n ro.vendor.build.id "NRD90M"
resetprop -n ro.system.build.date "Fri Jun  2 03:32:54 UTC 2017"
resetprop -n ro.bootimage.build.date "Fri Jun  2 03:32:54 UTC 2017"
resetprop -n ro.product.build.date "Fri Jun  2 03:32:54 UTC 2017"
resetprop -n ro.vendor_dlkm.build.date "Fri Jun  2 03:32:54 UTC 2017"
resetprop -n ro.system_ext.build.date "Fri Jun  2 03:32:54 UTC 2017"
resetprop -n ro.odm.build.date "Fri Jun  2 03:32:54 UTC 2017"
resetprop -n ro.build.date "Fri Jun  2 03:32:54 UTC 2017"
resetprop -n ro.vendor.build.date "Fri Jun  2 03:32:54 UTC 2017"
resetprop -n ro.product.build.date.utc "1496374374"
resetprop -n ro.system_ext.build.date.utc "1496374374"
resetprop -n ro.system.build.date.utc "1496374374"
resetprop -n ro.vendor.build.date.utc "1496374374"
resetprop -n ro.vendor_dlkm.build.date.utc "1496374374"
resetprop -n ro.build.date.utc "1496374374"
resetprop -n ro.bootimage.build.date.utc "1496374374"
resetprop -n ro.odm.build.date.utc "1496374374"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name MTKAC70DTI
resetprop -n ro.product.odm.name MTKAC70DTI
resetprop -n ro.product.vendor.name MTKAC70DTI
resetprop -n ro.product.system.name MTKAC70DTI
resetprop -n ro.product.name MTKAC70DTI
resetprop -n ro.product.bootimage.name MTKAC70DTI
resetprop -n ro.product.vendor_dlkm.name MTKAC70DTI
resetprop -n ro.product.system_ext.name MTKAC70DTI
resetprop -n ro.build.flavor full_along8163_tb_n-user
randomStr="full_along8163_tb_n-user Archos NRD90M "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=904644dd77a9
resetprop -n ro.build.host ${randomStr}
randomStr=d87a975d
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=KyNzNR
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=cce36ff9f0651
randomStr2=0e
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=b8
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "20170602.033254"
resetprop -n ro.build.description "MTKAC70DTI-user 7.0 NRD90M 20170602.033254 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "rel"
resetprop -n ro.build.host "liujm"
resetprop -n ro.build.product.backup "along8163_tb_n"
resetprop -n ro.build.characteristics "tablet"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n debug.hwui.render_dirty_regions "false"
resetprop -n ro.mediatek.chip_ver "S01"
resetprop -n ro.mediatek.platform "MT8163"
resetprop -n ro.mtk_key_manager_kb_path "1"
resetprop -n ro.mtk_protocol1_rat_config "no"
resetprop -n ro.mtk_support_mp2_playback "1"
resetprop -n ro.mtk_audio_alac_support "1"
resetprop -n ro.mediatek.version.branch "alps-mp-n0.mp102"
resetprop -n ro.mediatek.version.release "alps-mp-n0.mp102-V2.10.1_along8163.tb.n_P2"
resetprop -n ro.mediatek.version.sdk "4"
resetprop -n ro.com.google.gmsversion "7.0_r7"
resetprop -n ro.com.google.clientidbase "android-archos"
resetprop -n ro.mtk_besloudness_support "1"
resetprop -n ro.mtk_wapi_support "1"
resetprop -n ro.mtk_bt_support "1"
resetprop -n ro.mtk_wappush_support "1"
resetprop -n ro.mtk_audio_tuning_tool_ver "V1"
resetprop -n ro.mtk_matv_analog_support "1"
resetprop -n ro.mtk_wlan_support "1"
resetprop -n ro.mtk_gps_support "1"
resetprop -n ro.mtk_search_db_support "1"
resetprop -n ro.mtk_dialer_search_support "1"
resetprop -n ro.mtk_dhcpv6c_wifi "1"
resetprop -n ro.mtk_oma_drm_support "1"
resetprop -n ro.mtk_cta_drm_support "1"
resetprop -n ro.mtk_widevine_drm_l3_support "1"
resetprop -n ro.mtk_audio_ape_support "1"
resetprop -n ro.mtk_wmv_playback_support "1"
resetprop -n ro.mtk_send_rr_support "1"
resetprop -n ro.mtk_emmc_support "1"
resetprop -n ro.mtk_tetheringipv6_support "1"
resetprop -n ro.mtk_shared_sdcard "1"
resetprop -n ro.mtk_flight_mode_power_off_md "1"
resetprop -n ro.mtk_pq_support "2"
resetprop -n ro.mtk_pq_color_mode "1"
resetprop -n ro.mtk_wfd_support "1"
resetprop -n ro.mtk_wifi_mcc_support "1"
resetprop -n ro.mtk_bip_scws "1"
resetprop -n ro.mtk_wfd_hdcp_tx_support "1"
resetprop -n ro.mtk_wfd_hdcp_rx_support "1"
resetprop -n ro.mtk_world_phone_policy "0"
resetprop -n ro.mtk_perfservice_support "1"
resetprop -n ro.mtk_owner_sdcard_support "1"
resetprop -n ro.mtk_owner_sim_support "1"
resetprop -n ro.mtk_cta_set "1"
resetprop -n ro.mtk_multi_patition "1"
resetprop -n ro.mtk_key_manager_support "1"
resetprop -n ro.mtk_cam_mfb_support "3"
resetprop -n ro.mtk_cam_cfb "1"
resetprop -n ro.mtk_external_sim_only_slots "0"
resetprop -n ro.mtk_bg_power_saving_support "1"
resetprop -n ro.mtk_bg_power_saving_ui "1"
resetprop -n ro.mtk_dual_mic_support "0"
resetprop -n ro.mtk_is_tablet "1"
resetprop -n ro.mediatek.project.path "device/along/along8163_tb_n"
resetprop -n ro.mtk_sec_video_path_support "1"
resetprop -n ro.mtk_deinterlace_support "1"
resetprop -n persist.radio.mtk_ps2_rat "G"
resetprop -n persist.radio.mtk_ps3_rat "G"
resetprop -n ro.mtk_multiwindow "1"
resetprop -n ro.expect.recovery_id "0x8f04f916992e15c92da31436bbda86f52563508a000000000000000000000000"
resetprop -n ro.com.google.apphider "on"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2017-05-01
