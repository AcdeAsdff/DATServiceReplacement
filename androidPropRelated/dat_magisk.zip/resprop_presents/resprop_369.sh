strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "ZX70"
resetprop -n ro.product.vendor.model "ZX70"
resetprop -n ro.product.vendor_dlkm.marketname "ZX70"
resetprop -n ro.product.product.marketname "ZX70"
resetprop -n ro.product.system.marketname "ZX70"
resetprop -n ro.product.odm_dlkm.marketname "ZX70"
resetprop -n ro.product.system_ext.marketname "ZX70"
resetprop -n ro.product.odm_dlkm.model "ZX70"
resetprop -n ro.product.system.model "ZX70"
resetprop -n ro.product.system_ext.model "ZX70"
resetprop -n ro.product.vendor_dlkm.model "ZX70"
resetprop -n bluetooth.device.default_name "ZX70"
resetprop -n ro.product.bootimage.model "ZX70"
resetprop -n ro.product.vendor.marketname "ZX70"
resetprop -n ro.product.marketname "ZX70"
resetprop -n ro.product.odm.model "ZX70"
resetprop -n ro.product.model "ZX70"
resetprop -n ro.product.product.model "ZX70"
resetprop -n ro.product.odm.marketname "ZX70"
resetprop -n ro.product.vendor.manufacturer "Getac"
resetprop -n ro.product.product.manufacturer "Getac"
resetprop -n ro.product.bootimage.manufacturer "Getac"
resetprop -n ro.product.manufacturer "Getac"
resetprop -n ro.product.odm.manufacturer "Getac"
resetprop -n ro.product.system.manufacturer "Getac"
resetprop -n ro.product.system_ext.manufacturer "Getac"
resetprop -n ro.product.vendor_dlkm.manufacturer "Getac"
resetprop -n ro.product.vendor.brand "Getac"
resetprop -n ro.product.product.brand "Getac"
resetprop -n ro.product.vendor_dlkm.brand "Getac"
resetprop -n ro.product.system.brand "Getac"
resetprop -n ro.product.bootimage.brand "Getac"
resetprop -n ro.product.system_ext.brand "Getac"
resetprop -n ro.product.odm.brand "Getac"
resetprop -n ro.product.odm_dlkm.brand "Getac"
resetprop -n ro.product.brand "Getac"
resetprop -n ro.vendor_dlkm.build.fingerprint "Getac/zx70/zx70:7.1.1/NMF27D/66:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Getac/zx70/zx70:7.1.1/NMF27D/66:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Getac/zx70/zx70:7.1.1/NMF27D/66:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Getac/zx70/zx70:7.1.1/NMF27D/66:user/release-keys"
resetprop -n ro.system.build.fingerprint "Getac/zx70/zx70:7.1.1/NMF27D/66:user/release-keys"
resetprop -n ro.build.fingerprint "Getac/zx70/zx70:7.1.1/NMF27D/66:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Getac/zx70/zx70:7.1.1/NMF27D/66:user/release-keys"
resetprop -n ro.product.build.fingerprint "Getac/zx70/zx70:7.1.1/NMF27D/66:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Getac/zx70/zx70:7.1.1/NMF27D/66:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=82c54d1d0e
resetprop -n ro.system.build.version.incremental userdebug.builder.20200907.091214
resetprop -n ro.bootimage.build.version.incremental userdebug.builder.20200907.091214
resetprop -n ro.product.build.version.incremental userdebug.builder.20200907.091214
resetprop -n ro.odm.build.version.incremental userdebug.builder.20200907.091214
resetprop -n ro.vendor_dlkm.build.version.incremental userdebug.builder.20200907.091214
resetprop -n ro.system_ext.build.version.incremental userdebug.builder.20200907.091214
resetprop -n ro.build.version.incremental userdebug.builder.20200907.091214
resetprop -n ro.vendor.build.version.incremental userdebug.builder.20200907.091214
resetprop -n ro.odm.build.id "NMF27D"
resetprop -n ro.product.build.id "NMF27D"
resetprop -n ro.bootimage.build.id "NMF27D"
resetprop -n ro.system_ext.build.id "NMF27D"
resetprop -n ro.vendor_dlkm.build.id "NMF27D"
resetprop -n ro.build.id "NMF27D"
resetprop -n ro.system.build.id "NMF27D"
resetprop -n ro.vendor.build.id "NMF27D"
resetprop -n ro.system.build.date "Mon Sep  7 09:12:14 CST 2020"
resetprop -n ro.bootimage.build.date "Mon Sep  7 09:12:14 CST 2020"
resetprop -n ro.product.build.date "Mon Sep  7 09:12:14 CST 2020"
resetprop -n ro.vendor_dlkm.build.date "Mon Sep  7 09:12:14 CST 2020"
resetprop -n ro.system_ext.build.date "Mon Sep  7 09:12:14 CST 2020"
resetprop -n ro.odm.build.date "Mon Sep  7 09:12:14 CST 2020"
resetprop -n ro.build.date "Mon Sep  7 09:12:14 CST 2020"
resetprop -n ro.vendor.build.date "Mon Sep  7 09:12:14 CST 2020"
resetprop -n ro.product.build.date.utc "1599441134"
resetprop -n ro.system_ext.build.date.utc "1599441134"
resetprop -n ro.system.build.date.utc "1599441134"
resetprop -n ro.vendor.build.date.utc "1599441134"
resetprop -n ro.vendor_dlkm.build.date.utc "1599441134"
resetprop -n ro.build.date.utc "1599441134"
resetprop -n ro.bootimage.build.date.utc "1599441134"
resetprop -n ro.odm.build.date.utc "1599441134"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name zx70
resetprop -n ro.product.odm.name zx70
resetprop -n ro.product.vendor.name zx70
resetprop -n ro.product.system.name zx70
resetprop -n ro.product.name zx70
resetprop -n ro.product.bootimage.name zx70
resetprop -n ro.product.vendor_dlkm.name zx70
resetprop -n ro.product.system_ext.name zx70
resetprop -n ro.build.flavor zx70-userdebug
randomStr="zx70-userdebug Getac NMF27D "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=bcaef47742cb
resetprop -n ro.build.host ${randomStr}
randomStr=00a2c9d7
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=GKcFGB
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=b819660e7d9cb
randomStr2=3b
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=23
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "userdebug.builder.20200907.091214"
resetprop -n ro.build.description "zx70-userdebug 7.1.1 NMF27D userdebug.builder.20200907.091214 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "builder"
resetprop -n ro.build.host "d14714184bac"
resetprop -n ro.build.product.backup "zx70"
resetprop -n ro.build.characteristics "tablet"
resetprop -n ro.com.google.gmsversion "7.1_r8"
resetprop -n ro.com.google.clientidbase "android-getac"
resetprop -n ro.com.google.apphider "on"
resetprop -n ro.expect.recovery_id "0xd1d79959374074a99cfe50aa26f8b38b43c4512a000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-10-01
