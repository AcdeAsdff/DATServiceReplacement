strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Unknown / HRP"
resetprop -n ro.product.vendor.model "Unknown / HRP"
resetprop -n ro.product.vendor_dlkm.marketname "Unknown / HRP"
resetprop -n ro.product.product.marketname "Unknown / HRP"
resetprop -n ro.product.system.marketname "Unknown / HRP"
resetprop -n ro.product.odm_dlkm.marketname "Unknown / HRP"
resetprop -n ro.product.system_ext.marketname "Unknown / HRP"
resetprop -n ro.product.odm_dlkm.model "Unknown / HRP"
resetprop -n ro.product.system.model "Unknown / HRP"
resetprop -n ro.product.system_ext.model "Unknown / HRP"
resetprop -n ro.product.vendor_dlkm.model "Unknown / HRP"
resetprop -n bluetooth.device.default_name "Unknown / HRP"
resetprop -n ro.product.bootimage.model "Unknown / HRP"
resetprop -n ro.product.vendor.marketname "Unknown / HRP"
resetprop -n ro.product.marketname "Unknown / HRP"
resetprop -n ro.product.odm.model "Unknown / HRP"
resetprop -n ro.product.model "Unknown / HRP"
resetprop -n ro.product.product.model "Unknown / HRP"
resetprop -n ro.product.odm.marketname "Unknown / HRP"
resetprop -n ro.product.vendor.manufacturer "FIH"
resetprop -n ro.product.product.manufacturer "FIH"
resetprop -n ro.product.bootimage.manufacturer "FIH"
resetprop -n ro.product.manufacturer "FIH"
resetprop -n ro.product.odm.manufacturer "FIH"
resetprop -n ro.product.system.manufacturer "FIH"
resetprop -n ro.product.system_ext.manufacturer "FIH"
resetprop -n ro.product.vendor_dlkm.manufacturer "FIH"
resetprop -n ro.product.vendor.brand "FIH"
resetprop -n ro.product.product.brand "FIH"
resetprop -n ro.product.vendor_dlkm.brand "FIH"
resetprop -n ro.product.system.brand "FIH"
resetprop -n ro.product.bootimage.brand "FIH"
resetprop -n ro.product.system_ext.brand "FIH"
resetprop -n ro.product.odm.brand "FIH"
resetprop -n ro.product.odm_dlkm.brand "FIH"
resetprop -n ro.product.brand "FIH"
resetprop -n ro.vendor_dlkm.build.fingerprint "FIH/HRP_0001_FIH/HRP:7.1.1/NMF26F/0001_0_00Y:userdebug/dev-keys"
resetprop -n ro.bootimage.build.fingerprint "FIH/HRP_0001_FIH/HRP:7.1.1/NMF26F/0001_0_00Y:userdebug/dev-keys"
resetprop -n ro.vendor.build.fingerprint "FIH/HRP_0001_FIH/HRP:7.1.1/NMF26F/0001_0_00Y:userdebug/dev-keys"
resetprop -n ro.odm.build.fingerprint "FIH/HRP_0001_FIH/HRP:7.1.1/NMF26F/0001_0_00Y:userdebug/dev-keys"
resetprop -n ro.system.build.fingerprint "FIH/HRP_0001_FIH/HRP:7.1.1/NMF26F/0001_0_00Y:userdebug/dev-keys"
resetprop -n ro.build.fingerprint "FIH/HRP_0001_FIH/HRP:7.1.1/NMF26F/0001_0_00Y:userdebug/dev-keys"
resetprop -n ro.system_ext.build.fingerprint "FIH/HRP_0001_FIH/HRP:7.1.1/NMF26F/0001_0_00Y:userdebug/dev-keys"
resetprop -n ro.product.build.fingerprint "FIH/HRP_0001_FIH/HRP:7.1.1/NMF26F/0001_0_00Y:userdebug/dev-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "FIH/HRP_0001_FIH/HRP:7.1.1/NMF26F/0001_0_00Y:userdebug/dev-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=88a82f1516
resetprop -n ro.system.build.version.incremental 0001_0_00Y
resetprop -n ro.bootimage.build.version.incremental 0001_0_00Y
resetprop -n ro.product.build.version.incremental 0001_0_00Y
resetprop -n ro.odm.build.version.incremental 0001_0_00Y
resetprop -n ro.vendor_dlkm.build.version.incremental 0001_0_00Y
resetprop -n ro.system_ext.build.version.incremental 0001_0_00Y
resetprop -n ro.build.version.incremental 0001_0_00Y
resetprop -n ro.vendor.build.version.incremental 0001_0_00Y
resetprop -n ro.odm.build.id "NMF26F"
resetprop -n ro.product.build.id "NMF26F"
resetprop -n ro.bootimage.build.id "NMF26F"
resetprop -n ro.system_ext.build.id "NMF26F"
resetprop -n ro.vendor_dlkm.build.id "NMF26F"
resetprop -n ro.build.id "NMF26F"
resetprop -n ro.system.build.id "NMF26F"
resetprop -n ro.vendor.build.id "NMF26F"
resetprop -n ro.system.build.date "Thu Jul 27 00:41:34 CST 2017"
resetprop -n ro.bootimage.build.date "Thu Jul 27 00:41:34 CST 2017"
resetprop -n ro.product.build.date "Thu Jul 27 00:41:34 CST 2017"
resetprop -n ro.vendor_dlkm.build.date "Thu Jul 27 00:41:34 CST 2017"
resetprop -n ro.system_ext.build.date "Thu Jul 27 00:41:34 CST 2017"
resetprop -n ro.odm.build.date "Thu Jul 27 00:41:34 CST 2017"
resetprop -n ro.build.date "Thu Jul 27 00:41:34 CST 2017"
resetprop -n ro.vendor.build.date "Thu Jul 27 00:41:34 CST 2017"
resetprop -n ro.product.build.date.utc "1501087294"
resetprop -n ro.system_ext.build.date.utc "1501087294"
resetprop -n ro.system.build.date.utc "1501087294"
resetprop -n ro.vendor.build.date.utc "1501087294"
resetprop -n ro.vendor_dlkm.build.date.utc "1501087294"
resetprop -n ro.build.date.utc "1501087294"
resetprop -n ro.bootimage.build.date.utc "1501087294"
resetprop -n ro.odm.build.date.utc "1501087294"
resetprop -n ro.product.build.tags "dev-keys"
resetprop -n ro.build.tags "dev-keys"
resetprop -n ro.odm.build.tags "dev-keys"
resetprop -n ro.bootimage.build.tags "dev-keys"
resetprop -n ro.vendor_dlkm.build.tags "dev-keys"
resetprop -n ro.system_ext.build.tags "dev-keys"
resetprop -n ro.vendor.build.tags "dev-keys"
resetprop -n ro.system.build.tags "dev-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name HRP_0001_FIH
resetprop -n ro.product.odm.name HRP_0001_FIH
resetprop -n ro.product.vendor.name HRP_0001_FIH
resetprop -n ro.product.system.name HRP_0001_FIH
resetprop -n ro.product.name HRP_0001_FIH
resetprop -n ro.product.bootimage.name HRP_0001_FIH
resetprop -n ro.product.vendor_dlkm.name HRP_0001_FIH
resetprop -n ro.product.system_ext.name HRP_0001_FIH
resetprop -n ro.build.flavor HRP_0001_FIH-userdebug
randomStr="HRP_0001_FIH-userdebug FIH NMF26F "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=a32648a06b74
resetprop -n ro.build.host ${randomStr}
randomStr=0e4254a6
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=ZfUtWE
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=3791fb45977c8
randomStr2=f5
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=98
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "0001_0_00Y"
resetprop -n ro.build.description "HRP_0001_FIH-userdebug 7.1.1 NMF26F 0001_0_00Y dev-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "hsinkoyu"
resetprop -n ro.build.host "fih7004"
resetprop -n ro.build.product.backup "HRP"
resetprop -n ro.build.characteristics "default"
resetprop -n media.stagefright.enable-player "true"
resetprop -n media.stagefright.enable-http "true"
resetprop -n media.stagefright.enable-aac "true"
resetprop -n media.stagefright.enable-qcp "true"
resetprop -n media.stagefright.enable-scan "true"
resetprop -n media.aac_51_output_enabled "true"
resetprop -n ro.hwui.texture_cache_size "72"
resetprop -n ro.hwui.layer_cache_size "48"
resetprop -n ro.hwui.r_buffer_cache_size "8"
resetprop -n ro.hwui.path_cache_size "32"
resetprop -n ro.hwui.gradient_cache_size "1"
resetprop -n ro.hwui.drop_shadow_cache_size "6"
resetprop -n ro.hwui.texture_cache_flushrate "0.4"
resetprop -n ro.hwui.text_small_cache_width "1024"
resetprop -n ro.hwui.text_small_cache_height "1024"
resetprop -n ro.hwui.text_large_cache_width "2048"
resetprop -n ro.hwui.text_large_cache_height "1024"
resetprop -n ro.com.google.gmsversion "7.1_r4"
resetprop -n ro.com.google.clientidbase "android-fih"
resetprop -n ro.expect.recovery_id "0xb1ee399bf3771486f23a4d7e89463fcd76c0ebb4000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2016-12-05
