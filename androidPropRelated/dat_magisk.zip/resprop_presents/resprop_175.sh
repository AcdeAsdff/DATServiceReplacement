strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "AFTSSS"
resetprop -n ro.product.vendor.model "AFTSSS"
resetprop -n ro.product.vendor_dlkm.marketname "AFTSSS"
resetprop -n ro.product.product.marketname "AFTSSS"
resetprop -n ro.product.system.marketname "AFTSSS"
resetprop -n ro.product.odm_dlkm.marketname "AFTSSS"
resetprop -n ro.product.system_ext.marketname "AFTSSS"
resetprop -n ro.product.odm_dlkm.model "AFTSSS"
resetprop -n ro.product.system.model "AFTSSS"
resetprop -n ro.product.system_ext.model "AFTSSS"
resetprop -n ro.product.vendor_dlkm.model "AFTSSS"
resetprop -n bluetooth.device.default_name "AFTSSS"
resetprop -n ro.product.bootimage.model "AFTSSS"
resetprop -n ro.product.vendor.marketname "AFTSSS"
resetprop -n ro.product.marketname "AFTSSS"
resetprop -n ro.product.odm.model "AFTSSS"
resetprop -n ro.product.model "AFTSSS"
resetprop -n ro.product.product.model "AFTSSS"
resetprop -n ro.product.odm.marketname "AFTSSS"
resetprop -n ro.product.vendor.manufacturer "Amazon"
resetprop -n ro.product.product.manufacturer "Amazon"
resetprop -n ro.product.bootimage.manufacturer "Amazon"
resetprop -n ro.product.manufacturer "Amazon"
resetprop -n ro.product.odm.manufacturer "Amazon"
resetprop -n ro.product.system.manufacturer "Amazon"
resetprop -n ro.product.system_ext.manufacturer "Amazon"
resetprop -n ro.product.vendor_dlkm.manufacturer "Amazon"
resetprop -n ro.product.vendor.brand "Amazon"
resetprop -n ro.product.product.brand "Amazon"
resetprop -n ro.product.vendor_dlkm.brand "Amazon"
resetprop -n ro.product.system.brand "Amazon"
resetprop -n ro.product.bootimage.brand "Amazon"
resetprop -n ro.product.system_ext.brand "Amazon"
resetprop -n ro.product.odm.brand "Amazon"
resetprop -n ro.product.odm_dlkm.brand "Amazon"
resetprop -n ro.product.brand "Amazon"
resetprop -n ro.vendor_dlkm.build.fingerprint "Amazon/sheldonp/sheldonp:7.0/PS7234/2042N:user/amz-p,release-keys"
resetprop -n ro.bootimage.build.fingerprint "Amazon/sheldonp/sheldonp:7.0/PS7234/2042N:user/amz-p,release-keys"
resetprop -n ro.vendor.build.fingerprint "Amazon/sheldonp/sheldonp:7.0/PS7234/2042N:user/amz-p,release-keys"
resetprop -n ro.odm.build.fingerprint "Amazon/sheldonp/sheldonp:7.0/PS7234/2042N:user/amz-p,release-keys"
resetprop -n ro.system.build.fingerprint "Amazon/sheldonp/sheldonp:7.0/PS7234/2042N:user/amz-p,release-keys"
resetprop -n ro.build.fingerprint "Amazon/sheldonp/sheldonp:7.0/PS7234/2042N:user/amz-p,release-keys"
resetprop -n ro.system_ext.build.fingerprint "Amazon/sheldonp/sheldonp:7.0/PS7234/2042N:user/amz-p,release-keys"
resetprop -n ro.product.build.fingerprint "Amazon/sheldonp/sheldonp:7.0/PS7234/2042N:user/amz-p,release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Amazon/sheldonp/sheldonp:7.0/PS7234/2042N:user/amz-p,release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=50162b9ac6
resetprop -n ro.system.build.version.incremental 0020166736516
resetprop -n ro.bootimage.build.version.incremental 0020166736516
resetprop -n ro.product.build.version.incremental 0020166736516
resetprop -n ro.odm.build.version.incremental 0020166736516
resetprop -n ro.vendor_dlkm.build.version.incremental 0020166736516
resetprop -n ro.system_ext.build.version.incremental 0020166736516
resetprop -n ro.build.version.incremental 0020166736516
resetprop -n ro.vendor.build.version.incremental 0020166736516
resetprop -n ro.odm.build.id "PS7234"
resetprop -n ro.product.build.id "PS7234"
resetprop -n ro.bootimage.build.id "PS7234"
resetprop -n ro.system_ext.build.id "PS7234"
resetprop -n ro.vendor_dlkm.build.id "PS7234"
resetprop -n ro.build.id "PS7234"
resetprop -n ro.system.build.id "PS7234"
resetprop -n ro.vendor.build.id "PS7234"
resetprop -n ro.system.build.date "Fri May 21 23:56:11 UTC 2021"
resetprop -n ro.bootimage.build.date "Fri May 21 23:56:11 UTC 2021"
resetprop -n ro.product.build.date "Fri May 21 23:56:11 UTC 2021"
resetprop -n ro.vendor_dlkm.build.date "Fri May 21 23:56:11 UTC 2021"
resetprop -n ro.system_ext.build.date "Fri May 21 23:56:11 UTC 2021"
resetprop -n ro.odm.build.date "Fri May 21 23:56:11 UTC 2021"
resetprop -n ro.build.date "Fri May 21 23:56:11 UTC 2021"
resetprop -n ro.vendor.build.date "Fri May 21 23:56:11 UTC 2021"
resetprop -n ro.product.build.date.utc "1621641371"
resetprop -n ro.system_ext.build.date.utc "1621641371"
resetprop -n ro.system.build.date.utc "1621641371"
resetprop -n ro.vendor.build.date.utc "1621641371"
resetprop -n ro.vendor_dlkm.build.date.utc "1621641371"
resetprop -n ro.build.date.utc "1621641371"
resetprop -n ro.bootimage.build.date.utc "1621641371"
resetprop -n ro.odm.build.date.utc "1621641371"
resetprop -n ro.product.build.tags "amz-p,release-keys"
resetprop -n ro.build.tags "amz-p,release-keys"
resetprop -n ro.odm.build.tags "amz-p,release-keys"
resetprop -n ro.bootimage.build.tags "amz-p,release-keys"
resetprop -n ro.vendor_dlkm.build.tags "amz-p,release-keys"
resetprop -n ro.system_ext.build.tags "amz-p,release-keys"
resetprop -n ro.vendor.build.tags "amz-p,release-keys"
resetprop -n ro.system.build.tags "amz-p,release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name sheldonp
resetprop -n ro.product.odm.name sheldonp
resetprop -n ro.product.vendor.name sheldonp
resetprop -n ro.product.system.name sheldonp
resetprop -n ro.product.name sheldonp
resetprop -n ro.product.bootimage.name sheldonp
resetprop -n ro.product.vendor_dlkm.name sheldonp
resetprop -n ro.product.system_ext.name sheldonp
resetprop -n ro.build.flavor sheldonp-user
randomStr="sheldonp-user Amazon PS7234 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=8a5236ee79ef
resetprop -n ro.build.host ${randomStr}
randomStr=a2e015a3
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=ybQMtz
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=296fbd7a66e5c
randomStr2=47
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=10
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "0020166736516"
resetprop -n ro.build.description "sheldonp-user 7.0 PS7234 2042 amz-p,release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "build"
resetprop -n ro.build.host "i3-ri-14-use1a-b-54"
resetprop -n ro.build.product.backup "sheldonp"
resetprop -n ro.build.characteristics "tv"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_box_audio_support "1"
resetprop -n ro.mtk_alps_box_support "1"
resetprop -n ro.mtk_alps_ethernet_ext "1"
resetprop -n ro.mtk_sec_video_path_support "1"
resetprop -n ro.hwui.texture_cache_size "48.0"
resetprop -n ro.hwui.texture_cache_flushrate "0.4"
resetprop -n ro.hwui.layer_cache_size "32.0"
resetprop -n ro.hwui.drop_shadow_cache_size "4.0"
resetprop -n ro.hwui.path_cache_size "16.0"
resetprop -n ro.hwui.r_buffer_cache_size "4.0"
resetprop -n ro.hwui.text_small_cache_height "512"
resetprop -n ro.expect.recovery_id "0x41dd7aef0eeca6fbf26ad8c2521f41fda3d5ed36000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-10-05
