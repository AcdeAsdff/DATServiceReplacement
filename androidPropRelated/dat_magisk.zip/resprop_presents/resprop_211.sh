strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "SHARK KLE-A0"
resetprop -n ro.product.vendor.model "SHARK KLE-A0"
resetprop -n ro.product.vendor_dlkm.marketname "SHARK KLE-A0"
resetprop -n ro.product.product.marketname "SHARK KLE-A0"
resetprop -n ro.product.system.marketname "SHARK KLE-A0"
resetprop -n ro.product.odm_dlkm.marketname "SHARK KLE-A0"
resetprop -n ro.product.system_ext.marketname "SHARK KLE-A0"
resetprop -n ro.product.odm_dlkm.model "SHARK KLE-A0"
resetprop -n ro.product.system.model "SHARK KLE-A0"
resetprop -n ro.product.system_ext.model "SHARK KLE-A0"
resetprop -n ro.product.vendor_dlkm.model "SHARK KLE-A0"
resetprop -n bluetooth.device.default_name "SHARK KLE-A0"
resetprop -n ro.product.bootimage.model "SHARK KLE-A0"
resetprop -n ro.product.vendor.marketname "SHARK KLE-A0"
resetprop -n ro.product.marketname "SHARK KLE-A0"
resetprop -n ro.product.odm.model "SHARK KLE-A0"
resetprop -n ro.product.model "SHARK KLE-A0"
resetprop -n ro.product.product.model "SHARK KLE-A0"
resetprop -n ro.product.odm.marketname "SHARK KLE-A0"
resetprop -n ro.product.vendor.manufacturer "blackshark"
resetprop -n ro.product.product.manufacturer "blackshark"
resetprop -n ro.product.bootimage.manufacturer "blackshark"
resetprop -n ro.product.manufacturer "blackshark"
resetprop -n ro.product.odm.manufacturer "blackshark"
resetprop -n ro.product.system.manufacturer "blackshark"
resetprop -n ro.product.system_ext.manufacturer "blackshark"
resetprop -n ro.product.vendor_dlkm.manufacturer "blackshark"
resetprop -n ro.product.vendor.brand "blackshark"
resetprop -n ro.product.product.brand "blackshark"
resetprop -n ro.product.vendor_dlkm.brand "blackshark"
resetprop -n ro.product.system.brand "blackshark"
resetprop -n ro.product.bootimage.brand "blackshark"
resetprop -n ro.product.system_ext.brand "blackshark"
resetprop -n ro.product.odm.brand "blackshark"
resetprop -n ro.product.odm_dlkm.brand "blackshark"
resetprop -n ro.product.brand "blackshark"
resetprop -n ro.vendor_dlkm.build.fingerprint "blackshark/KLE-A0/klein:10/KLEN2011100CN00MQ3/V11.0.4.0.JOYUI:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "blackshark/KLE-A0/klein:10/KLEN2011100CN00MQ3/V11.0.4.0.JOYUI:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "blackshark/KLE-A0/klein:10/KLEN2011100CN00MQ3/V11.0.4.0.JOYUI:user/release-keys"
resetprop -n ro.odm.build.fingerprint "blackshark/KLE-A0/klein:10/KLEN2011100CN00MQ3/V11.0.4.0.JOYUI:user/release-keys"
resetprop -n ro.system.build.fingerprint "blackshark/KLE-A0/klein:10/KLEN2011100CN00MQ3/V11.0.4.0.JOYUI:user/release-keys"
resetprop -n ro.build.fingerprint "blackshark/KLE-A0/klein:10/KLEN2011100CN00MQ3/V11.0.4.0.JOYUI:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "blackshark/KLE-A0/klein:10/KLEN2011100CN00MQ3/V11.0.4.0.JOYUI:user/release-keys"
resetprop -n ro.product.build.fingerprint "blackshark/KLE-A0/klein:10/KLEN2011100CN00MQ3/V11.0.4.0.JOYUI:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "blackshark/KLE-A0/klein:10/KLEN2011100CN00MQ3/V11.0.4.0.JOYUI:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=8290d305ee
resetprop -n ro.system.build.version.incremental V11.0.4.0.JOYUI
resetprop -n ro.bootimage.build.version.incremental V11.0.4.0.JOYUI
resetprop -n ro.product.build.version.incremental V11.0.4.0.JOYUI
resetprop -n ro.odm.build.version.incremental V11.0.4.0.JOYUI
resetprop -n ro.vendor_dlkm.build.version.incremental V11.0.4.0.JOYUI
resetprop -n ro.system_ext.build.version.incremental V11.0.4.0.JOYUI
resetprop -n ro.build.version.incremental V11.0.4.0.JOYUI
resetprop -n ro.vendor.build.version.incremental V11.0.4.0.JOYUI
resetprop -n ro.odm.build.id "KLEN2011100CN00MQ3"
resetprop -n ro.product.build.id "KLEN2011100CN00MQ3"
resetprop -n ro.bootimage.build.id "KLEN2011100CN00MQ3"
resetprop -n ro.system_ext.build.id "KLEN2011100CN00MQ3"
resetprop -n ro.vendor_dlkm.build.id "KLEN2011100CN00MQ3"
resetprop -n ro.build.id "KLEN2011100CN00MQ3"
resetprop -n ro.system.build.id "KLEN2011100CN00MQ3"
resetprop -n ro.vendor.build.id "KLEN2011100CN00MQ3"
resetprop -n ro.system.build.date "Tue Nov 10 19:17:02 CST 2020"
resetprop -n ro.bootimage.build.date "Tue Nov 10 19:17:02 CST 2020"
resetprop -n ro.product.build.date "Tue Nov 10 19:17:02 CST 2020"
resetprop -n ro.vendor_dlkm.build.date "Tue Nov 10 19:17:02 CST 2020"
resetprop -n ro.system_ext.build.date "Tue Nov 10 19:17:02 CST 2020"
resetprop -n ro.odm.build.date "Tue Nov 10 19:17:02 CST 2020"
resetprop -n ro.build.date "Tue Nov 10 19:17:02 CST 2020"
resetprop -n ro.vendor.build.date "Tue Nov 10 19:17:02 CST 2020"
resetprop -n ro.product.build.date.utc "1605007022"
resetprop -n ro.system_ext.build.date.utc "1605007022"
resetprop -n ro.system.build.date.utc "1605007022"
resetprop -n ro.vendor.build.date.utc "1605007022"
resetprop -n ro.vendor_dlkm.build.date.utc "1605007022"
resetprop -n ro.build.date.utc "1605007022"
resetprop -n ro.bootimage.build.date.utc "1605007022"
resetprop -n ro.odm.build.date.utc "1605007022"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name KLE-A0
resetprop -n ro.product.odm.name KLE-A0
resetprop -n ro.product.vendor.name KLE-A0
resetprop -n ro.product.system.name KLE-A0
resetprop -n ro.product.name KLE-A0
resetprop -n ro.product.bootimage.name KLE-A0
resetprop -n ro.product.vendor_dlkm.name KLE-A0
resetprop -n ro.product.system_ext.name KLE-A0
resetprop -n ro.build.flavor qssi-user
randomStr="qssi-user blackshark KLEN2011100CN00MQ3 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=f3a09d744adb
resetprop -n ro.build.host ${randomStr}
randomStr=0024f429
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=BuRxxw
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=819585c4b0ed4
randomStr2=89
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=4e
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "V11.0.4.0.JOYUI"
resetprop -n ro.build.description "aeon6580_weg_l_l300-user 5.1 LMY47I 1555741941 release-keys"
resetprop -n ro.build.product.backup "qssi"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "buildfarm"
resetprop -n ro.build.host "bf-01"
resetprop -n ro.com.google.acsa "true"
resetprop -n media.stagefright.enable-player "true"
resetprop -n media.stagefright.enable-http "true"
resetprop -n media.stagefright.enable-aac "true"
resetprop -n media.stagefright.enable-qcp "true"
resetprop -n media.stagefright.enable-fma2dp "true"
resetprop -n media.stagefright.enable-scan "true"
resetprop -n media.stagefright.thumbnail.prefer_hw_codecs "true"
resetprop -n media.settings.xml "/vendor/etc/media_profiles_vendor.xml"
resetprop -n media.aac_51_output_enabled "true"
resetprop -n ro.hwui.texture_cache_size "72"
resetprop -n ro.hwui.layer_cache_size "48"
resetprop -n ro.hwui.r_buffer_cache_size "8"
resetprop -n ro.hwui.path_cache_size "32"
resetprop -n ro.hwui.gradient_cache_size "1"
resetprop -n ro.hwui.drop_shadow_cache_size "6"
resetprop -n ro.hwui.texture_cache_flushrate "0.4"
resetprop -n ro.hwui.text_small_cache_width "1024"
resetprop -n ro.hwui.text_small_cache_height "1024"
resetprop -n ro.hwui.text_large_cache_width "2048"
resetprop -n ro.hwui.text_large_cache_height "1024"
resetprop -n ro.com.google.clientidbase "android-xiaomi"
resetprop -n ro.miui.has_gmscore "1"
resetprop -n ro.miui.restrict_imei "1"
resetprop -n ro.miui.build.region "cn"
resetprop -n ro.miui.ui.version.code "10"
resetprop -n ro.miui.ui.version.name "V12"
resetprop -n ro.miui.has_security_keyboard "1"
resetprop -n ro.miui.support_miui_ime_bottom "1"
resetprop -n ro.fota.oem "Xiaomi"
resetprop -n ro.miui.pm.movedtodata.apps "com.google.android.apps.photos,com.google.android.apps.docs,com.google.android.music,com.google.android.videos,com.google.android.apps.tachyon"
resetprop -n persist.miui.density_v2 "440"
resetprop -n ro.miui.ui.fonttype "mipro"
resetprop -n ro.miui.ui.font.theme_apply "true"
resetprop -n sys.miui.shutdown.waittime "500"
resetprop -n ro.miui.has_real_blur "1"
resetprop -n ro.miui.has_handy_mode_sf "1"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2020-09-01
