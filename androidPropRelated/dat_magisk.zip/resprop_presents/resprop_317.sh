strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.vendor.model "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.vendor_dlkm.marketname "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.product.marketname "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.system.marketname "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.odm_dlkm.marketname "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.system_ext.marketname "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.odm_dlkm.model "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.system.model "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.system_ext.model "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.vendor_dlkm.model "Plane 1572N 3G PS1187MG"
resetprop -n bluetooth.device.default_name "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.bootimage.model "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.vendor.marketname "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.marketname "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.odm.model "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.model "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.product.model "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.odm.marketname "Plane 1572N 3G PS1187MG"
resetprop -n ro.product.vendor.manufacturer "DIGMA"
resetprop -n ro.product.product.manufacturer "DIGMA"
resetprop -n ro.product.bootimage.manufacturer "DIGMA"
resetprop -n ro.product.manufacturer "DIGMA"
resetprop -n ro.product.odm.manufacturer "DIGMA"
resetprop -n ro.product.system.manufacturer "DIGMA"
resetprop -n ro.product.system_ext.manufacturer "DIGMA"
resetprop -n ro.product.vendor_dlkm.manufacturer "DIGMA"
resetprop -n ro.product.vendor.brand "DIGMA"
resetprop -n ro.product.product.brand "DIGMA"
resetprop -n ro.product.vendor_dlkm.brand "DIGMA"
resetprop -n ro.product.system.brand "DIGMA"
resetprop -n ro.product.bootimage.brand "DIGMA"
resetprop -n ro.product.system_ext.brand "DIGMA"
resetprop -n ro.product.odm.brand "DIGMA"
resetprop -n ro.product.odm_dlkm.brand "DIGMA"
resetprop -n ro.product.brand "DIGMA"
resetprop -n ro.vendor_dlkm.build.fingerprint "DIGMA/Plane_1572N_3G/PS1187MG:7.0/NRD90M/1518006799:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "DIGMA/Plane_1572N_3G/PS1187MG:7.0/NRD90M/1518006799:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "DIGMA/Plane_1572N_3G/PS1187MG:7.0/NRD90M/1518006799:user/release-keys"
resetprop -n ro.odm.build.fingerprint "DIGMA/Plane_1572N_3G/PS1187MG:7.0/NRD90M/1518006799:user/release-keys"
resetprop -n ro.system.build.fingerprint "DIGMA/Plane_1572N_3G/PS1187MG:7.0/NRD90M/1518006799:user/release-keys"
resetprop -n ro.build.fingerprint "DIGMA/Plane_1572N_3G/PS1187MG:7.0/NRD90M/1518006799:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "DIGMA/Plane_1572N_3G/PS1187MG:7.0/NRD90M/1518006799:user/release-keys"
resetprop -n ro.product.build.fingerprint "DIGMA/Plane_1572N_3G/PS1187MG:7.0/NRD90M/1518006799:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "DIGMA/Plane_1572N_3G/PS1187MG:7.0/NRD90M/1518006799:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=4a6737cfb7
resetprop -n ro.system.build.version.incremental 1518006799
resetprop -n ro.bootimage.build.version.incremental 1518006799
resetprop -n ro.product.build.version.incremental 1518006799
resetprop -n ro.odm.build.version.incremental 1518006799
resetprop -n ro.vendor_dlkm.build.version.incremental 1518006799
resetprop -n ro.system_ext.build.version.incremental 1518006799
resetprop -n ro.build.version.incremental 1518006799
resetprop -n ro.vendor.build.version.incremental 1518006799
resetprop -n ro.odm.build.id "NRD90M"
resetprop -n ro.product.build.id "NRD90M"
resetprop -n ro.bootimage.build.id "NRD90M"
resetprop -n ro.system_ext.build.id "NRD90M"
resetprop -n ro.vendor_dlkm.build.id "NRD90M"
resetprop -n ro.build.id "NRD90M"
resetprop -n ro.system.build.id "NRD90M"
resetprop -n ro.vendor.build.id "NRD90M"
resetprop -n ro.system.build.date "Wed Feb  7 20:32:09 CST 2018"
resetprop -n ro.bootimage.build.date "Wed Feb  7 20:32:09 CST 2018"
resetprop -n ro.product.build.date "Wed Feb  7 20:32:09 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Wed Feb  7 20:32:09 CST 2018"
resetprop -n ro.system_ext.build.date "Wed Feb  7 20:32:09 CST 2018"
resetprop -n ro.odm.build.date "Wed Feb  7 20:32:09 CST 2018"
resetprop -n ro.build.date "Wed Feb  7 20:32:09 CST 2018"
resetprop -n ro.vendor.build.date "Wed Feb  7 20:32:09 CST 2018"
resetprop -n ro.product.build.date.utc "1518006729"
resetprop -n ro.system_ext.build.date.utc "1518006729"
resetprop -n ro.system.build.date.utc "1518006729"
resetprop -n ro.vendor.build.date.utc "1518006729"
resetprop -n ro.vendor_dlkm.build.date.utc "1518006729"
resetprop -n ro.build.date.utc "1518006729"
resetprop -n ro.bootimage.build.date.utc "1518006729"
resetprop -n ro.odm.build.date.utc "1518006729"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name Plane_1572N_3G
resetprop -n ro.product.odm.name Plane_1572N_3G
resetprop -n ro.product.vendor.name Plane_1572N_3G
resetprop -n ro.product.system.name Plane_1572N_3G
resetprop -n ro.product.name Plane_1572N_3G
resetprop -n ro.product.bootimage.name Plane_1572N_3G
resetprop -n ro.product.vendor_dlkm.name Plane_1572N_3G
resetprop -n ro.product.system_ext.name Plane_1572N_3G
resetprop -n ro.build.flavor Plane_1572N_3G-user
randomStr="Plane_1572N_3G-user DIGMA NRD90M "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=13bc09fbd7af
resetprop -n ro.build.host ${randomStr}
randomStr=8f5ec5c7
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=ncGXbb
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=3bb82ff82c264
randomStr2=a8
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=b4
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1518006799"
resetprop -n ro.build.description "Plane_1572N_3G-user 7.0 NRD90M 1518006799 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "chenxs"
resetprop -n ro.build.host "mid-svr6"
resetprop -n ro.build.product.backup "PS1187MG"
resetprop -n ro.build.characteristics "tablet"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n debug.hwui.render_dirty_regions "false"
resetprop -n ro.mediatek.chip_ver "S01"
resetprop -n ro.mediatek.platform "MT6580"
resetprop -n ro.mtk_protocol1_rat_config "W/G"
resetprop -n ro.mtk_support_mp2_playback "1"
resetprop -n ro.mtk_audio_alac_support "1"
resetprop -n ro.mediatek.version.branch "alps-mp-n0.mp2"
resetprop -n ro.mediatek.version.release "alps-mp-n0.mp2-V1.23.1_mt8321.tb.n_P70"
resetprop -n ro.mediatek.version.sdk "4"
resetprop -n ro.com.google.gmsversion "7.0_r13"
resetprop -n ro.com.google.clientidbase "android-merlion"
resetprop -n ro.mtk_besloudness_support "1"
resetprop -n ro.mtk_bt_support "1"
resetprop -n ro.mtk_wappush_support "1"
resetprop -n ro.mtk_agps_app "1"
resetprop -n ro.mtk_vt3g324m_support "1"
resetprop -n ro.mtk_audio_tuning_tool_ver "V1"
resetprop -n ro.mtk_wlan_support "1"
resetprop -n ro.mtk_gps_support "1"
resetprop -n ro.mtk_omacp_support "1"
resetprop -n ro.mtk_search_db_support "1"
resetprop -n ro.mtk_dialer_search_support "1"
resetprop -n ro.mtk_dhcpv6c_wifi "1"
resetprop -n ro.mtk_fd_support "1"
resetprop -n ro.mtk_oma_drm_support "1"
resetprop -n ro.mtk_cta_drm_support "1"
resetprop -n ro.mtk_widevine_drm_l3_support "1"
resetprop -n ro.mtk_eap_sim_aka "1"
resetprop -n ro.mtk_audio_ape_support "1"
resetprop -n ro.mtk_wmv_playback_support "1"
resetprop -n ro.mtk_send_rr_support "1"
resetprop -n ro.mtk_rat_wcdma_preferred "1"
resetprop -n ro.mtk_emmc_support "1"
resetprop -n ro.mtk_tetheringipv6_support "1"
resetprop -n ro.mtk_shared_sdcard "1"
resetprop -n ro.mtk_2sdcard_swap "1"
resetprop -n ro.mtk_enable_md1 "1"
resetprop -n ro.mtk_flight_mode_power_off_md "1"
resetprop -n ro.mtk_pq_support "2"
resetprop -n ro.mtk_pq_color_mode "1"
resetprop -n ro.mtk_miravision_support "1"
resetprop -n ro.mtk_wifi_mcc_support "1"
resetprop -n ro.mtk_bip_scws "1"
resetprop -n ro.mtk_world_phone_policy "0"
resetprop -n ro.mtk_perfservice_support "1"
resetprop -n ro.mtk_cta_set "1"
resetprop -n ro.mtk_cam_mfb_support "0"
resetprop -n ro.mtk_cam_cfb "1"
resetprop -n ro.mtk_external_sim_only_slots "0"
resetprop -n ro.mtk_bg_power_saving_support "1"
resetprop -n ro.mtk_bg_power_saving_ui "1"
resetprop -n ro.mtk_dual_mic_support "0"
resetprop -n ro.mtk_is_tablet "1"
resetprop -n persist.mtk_nlp_switch_support "1"
resetprop -n persist.mtk_vilte_support "0"
resetprop -n ro.mtk_vilte_ut_support "0"
resetprop -n ro.mediatek.project.path "device/mid/mt8321_tb_n"
resetprop -n persist.radio.mtk_ps2_rat "G"
resetprop -n persist.radio.mtk_ps3_rat "G"
resetprop -n ro.expect.recovery_id "0x1f35f4d561bb3381ce60138fdab92424cb83c8a6000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-01-05
