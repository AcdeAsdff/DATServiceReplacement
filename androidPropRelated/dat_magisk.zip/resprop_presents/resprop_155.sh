strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "SOYES XS11"
resetprop -n ro.product.vendor.model "SOYES XS11"
resetprop -n ro.product.vendor_dlkm.marketname "SOYES XS11"
resetprop -n ro.product.product.marketname "SOYES XS11"
resetprop -n ro.product.system.marketname "SOYES XS11"
resetprop -n ro.product.odm_dlkm.marketname "SOYES XS11"
resetprop -n ro.product.system_ext.marketname "SOYES XS11"
resetprop -n ro.product.odm_dlkm.model "SOYES XS11"
resetprop -n ro.product.system.model "SOYES XS11"
resetprop -n ro.product.system_ext.model "SOYES XS11"
resetprop -n ro.product.vendor_dlkm.model "SOYES XS11"
resetprop -n bluetooth.device.default_name "SOYES XS11"
resetprop -n ro.product.bootimage.model "SOYES XS11"
resetprop -n ro.product.vendor.marketname "SOYES XS11"
resetprop -n ro.product.marketname "SOYES XS11"
resetprop -n ro.product.odm.model "SOYES XS11"
resetprop -n ro.product.model "SOYES XS11"
resetprop -n ro.product.product.model "SOYES XS11"
resetprop -n ro.product.odm.marketname "SOYES XS11"
resetprop -n ro.product.vendor.manufacturer "alps"
resetprop -n ro.product.product.manufacturer "alps"
resetprop -n ro.product.bootimage.manufacturer "alps"
resetprop -n ro.product.manufacturer "alps"
resetprop -n ro.product.odm.manufacturer "alps"
resetprop -n ro.product.system.manufacturer "alps"
resetprop -n ro.product.system_ext.manufacturer "alps"
resetprop -n ro.product.vendor_dlkm.manufacturer "alps"
resetprop -n ro.product.vendor.brand "alps"
resetprop -n ro.product.product.brand "alps"
resetprop -n ro.product.vendor_dlkm.brand "alps"
resetprop -n ro.product.system.brand "alps"
resetprop -n ro.product.bootimage.brand "alps"
resetprop -n ro.product.system_ext.brand "alps"
resetprop -n ro.product.odm.brand "alps"
resetprop -n ro.product.odm_dlkm.brand "alps"
resetprop -n ro.product.brand "alps"
resetprop -n ro.vendor_dlkm.build.fingerprint "alps/full_f202_f22_p10/f202_f22_p10:6.0/MRA58K/1637753601:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "alps/full_f202_f22_p10/f202_f22_p10:6.0/MRA58K/1637753601:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "alps/full_f202_f22_p10/f202_f22_p10:6.0/MRA58K/1637753601:user/release-keys"
resetprop -n ro.odm.build.fingerprint "alps/full_f202_f22_p10/f202_f22_p10:6.0/MRA58K/1637753601:user/release-keys"
resetprop -n ro.system.build.fingerprint "alps/full_f202_f22_p10/f202_f22_p10:6.0/MRA58K/1637753601:user/release-keys"
resetprop -n ro.build.fingerprint "alps/full_f202_f22_p10/f202_f22_p10:6.0/MRA58K/1637753601:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "alps/full_f202_f22_p10/f202_f22_p10:6.0/MRA58K/1637753601:user/release-keys"
resetprop -n ro.product.build.fingerprint "alps/full_f202_f22_p10/f202_f22_p10:6.0/MRA58K/1637753601:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "alps/full_f202_f22_p10/f202_f22_p10:6.0/MRA58K/1637753601:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=f811aee5a4
resetprop -n ro.system.build.version.incremental 1637753601
resetprop -n ro.bootimage.build.version.incremental 1637753601
resetprop -n ro.product.build.version.incremental 1637753601
resetprop -n ro.odm.build.version.incremental 1637753601
resetprop -n ro.vendor_dlkm.build.version.incremental 1637753601
resetprop -n ro.system_ext.build.version.incremental 1637753601
resetprop -n ro.build.version.incremental 1637753601
resetprop -n ro.vendor.build.version.incremental 1637753601
resetprop -n ro.odm.build.id "MRA58K"
resetprop -n ro.product.build.id "MRA58K"
resetprop -n ro.bootimage.build.id "MRA58K"
resetprop -n ro.system_ext.build.id "MRA58K"
resetprop -n ro.vendor_dlkm.build.id "MRA58K"
resetprop -n ro.build.id "MRA58K"
resetprop -n ro.system.build.id "MRA58K"
resetprop -n ro.vendor.build.id "MRA58K"
resetprop -n ro.system.build.date "2021年 11月 24日 星期三 19:36:47 CST"
resetprop -n ro.bootimage.build.date "2021年 11月 24日 星期三 19:36:47 CST"
resetprop -n ro.product.build.date "2021年 11月 24日 星期三 19:36:47 CST"
resetprop -n ro.vendor_dlkm.build.date "2021年 11月 24日 星期三 19:36:47 CST"
resetprop -n ro.system_ext.build.date "2021年 11月 24日 星期三 19:36:47 CST"
resetprop -n ro.odm.build.date "2021年 11月 24日 星期三 19:36:47 CST"
resetprop -n ro.build.date "2021年 11月 24日 星期三 19:36:47 CST"
resetprop -n ro.vendor.build.date "2021年 11月 24日 星期三 19:36:47 CST"
resetprop -n ro.product.build.date.utc "1637753807"
resetprop -n ro.system_ext.build.date.utc "1637753807"
resetprop -n ro.system.build.date.utc "1637753807"
resetprop -n ro.vendor.build.date.utc "1637753807"
resetprop -n ro.vendor_dlkm.build.date.utc "1637753807"
resetprop -n ro.build.date.utc "1637753807"
resetprop -n ro.bootimage.build.date.utc "1637753807"
resetprop -n ro.odm.build.date.utc "1637753807"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name full_f202_f22_p10
resetprop -n ro.product.odm.name full_f202_f22_p10
resetprop -n ro.product.vendor.name full_f202_f22_p10
resetprop -n ro.product.system.name full_f202_f22_p10
resetprop -n ro.product.name full_f202_f22_p10
resetprop -n ro.product.bootimage.name full_f202_f22_p10
resetprop -n ro.product.vendor_dlkm.name full_f202_f22_p10
resetprop -n ro.product.system_ext.name full_f202_f22_p10
resetprop -n ro.build.flavor full_f202_f22_p10-user
randomStr="full_f202_f22_p10-user alps MRA58K "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=e69cdc194e8c
resetprop -n ro.build.host ${randomStr}
randomStr=c5449578
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=gyMeOV
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=aaa6f06ac81c6
randomStr2=35
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=b9
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1637753601"
resetprop -n ro.build.description "full_f202_f22_p10-user 6.0 MRA58K 1637753601 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "tianao"
resetprop -n ro.build.host "tianao-Z10PA-D8"
resetprop -n ro.build.product.backup "f202_f22_p10"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n debug.hwui.render_dirty_regions "false"
resetprop -n ro.mediatek.chip_ver "S01"
resetprop -n ro.mediatek.version.release "alps-mp-m0.mp1-V2.39_hy6580.weg.m_P96"
resetprop -n ro.mediatek.platform "MT6580"
resetprop -n ro.mediatek.gemini_support "true"
resetprop -n ro.mediatek.version.branch "alps-mp-m0.mp1"
resetprop -n ro.mediatek.version.sdk "4"
resetprop -n ro.com.google.gmsversion "6.0_r7"
resetprop -n ro.com.google.clientidbase "alps-full_f202_f22_p10-{country}"
resetprop -n ro.com.google.clientidbase.ms "alps-full_f202_f22_p10-{country}"
resetprop -n ro.com.google.clientidbase.yt "alps-full_f202_f22_p10-{country}"
resetprop -n ro.com.google.clientidbase.am "alps-full_f202_f22_p10-{country}"
resetprop -n ro.com.google.clientidbase.gmm "alps-full_f202_f22_p10-{country}"
resetprop -n ro.mtk_gemini_support "1"
resetprop -n ro.mtk_audio_profiles "1"
resetprop -n ro.mtk_audenh_support "1"
resetprop -n ro.mtk_besloudness_support "1"
resetprop -n ro.mtk_bessurround_support "1"
resetprop -n ro.mtk_wapi_support "1"
resetprop -n ro.mtk_bt_support "1"
resetprop -n ro.mtk_wappush_support "1"
resetprop -n ro.mtk_agps_app "1"
resetprop -n ro.mtk_voice_unlock_support "1"
resetprop -n ro.mtk_audio_tuning_tool_ver "V1"
resetprop -n ro.mtk_wlan_support "1"
resetprop -n ro.mtk_ipo_support "1"
resetprop -n ro.mtk_gps_support "1"
resetprop -n ro.mtk_omacp_support "1"
resetprop -n ro.mtk_search_db_support "1"
resetprop -n ro.mtk_dialer_search_support "1"
resetprop -n ro.mtk_dhcpv6c_wifi "1"
resetprop -n ro.mtk_fd_support "1"
resetprop -n ro.mtk_oma_drm_support "1"
resetprop -n ro.mtk_cta_drm_support "1"
resetprop -n ro.mtk_widevine_drm_l3_support "1"
resetprop -n ro.mtk_eap_sim_aka "1"
resetprop -n ro.mtk_fm_recording_support "1"
resetprop -n ro.mtk_audio_ape_support "1"
resetprop -n ro.mtk_flv_playback_support "1"
resetprop -n ro.mtk_wmv_playback_support "1"
resetprop -n ro.mtk_send_rr_support "1"
resetprop -n ro.mtk_rat_wcdma_preferred "1"
resetprop -n ro.mtk_emmc_support "1"
resetprop -n ro.mtk_tetheringipv6_support "1"
resetprop -n ro.mtk_shared_sdcard "1"
resetprop -n ro.mtk_enable_md1 "1"
resetprop -n ro.mtk_flight_mode_power_off_md "1"
resetprop -n ro.mtk_aal_support "1"
resetprop -n ro.mtk_ultra_dimming_support "1"
resetprop -n ro.mtk_pq_support "2"
resetprop -n ro.mtk_miravision_support "1"
resetprop -n ro.mtk_miravision_image_dc "1"
resetprop -n ro.mtk_wifi_mcc_support "1"
resetprop -n ro.mtk_sim_hot_swap "1"
resetprop -n ro.mtk_thumbnail_play_support "1"
resetprop -n ro.mtk_bip_scws "1"
resetprop -n ro.mtk_gmo_ram_optimize "1"
resetprop -n ro.mtk_gmo_rom_optimize "1"
resetprop -n ro.mtk_world_phone_policy "0"
resetprop -n ro.mtk_perfservice_support "1"
resetprop -n ro.mtk_sim_hot_swap_common_slot "1"
resetprop -n ro.mtk_cta_set "1"
resetprop -n ro.mtk_mobile_management "1"
resetprop -n ro.mtk_runtime_permission "1"
resetprop -n ro.mtk_antibricking_level "2"
resetprop -n ro.mtk_cam_mfb_support "0"
resetprop -n ro.mtk_rild_read_imsi "1"
resetprop -n ro.mtk_privacy_protection_lock "1"
resetprop -n ro.mtk_bg_power_saving_support "1"
resetprop -n ro.mtk_bg_power_saving_ui "1"
resetprop -n ro.mtk_dual_mic_support "0"
resetprop -n ro.mtk_is_tablet "0"
resetprop -n ro.mediatek.project.path "device/hongyu/f202_f22_p10"
resetprop -n ro.expect.recovery_id "0xd707e34afab2ca7f861e04bc8779981e304cf7d7000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2020-08-05
