strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "CASIO WSD-F20"
resetprop -n ro.product.vendor.model "CASIO WSD-F20"
resetprop -n ro.product.vendor_dlkm.marketname "CASIO WSD-F20"
resetprop -n ro.product.product.marketname "CASIO WSD-F20"
resetprop -n ro.product.system.marketname "CASIO WSD-F20"
resetprop -n ro.product.odm_dlkm.marketname "CASIO WSD-F20"
resetprop -n ro.product.system_ext.marketname "CASIO WSD-F20"
resetprop -n ro.product.odm_dlkm.model "CASIO WSD-F20"
resetprop -n ro.product.system.model "CASIO WSD-F20"
resetprop -n ro.product.system_ext.model "CASIO WSD-F20"
resetprop -n ro.product.vendor_dlkm.model "CASIO WSD-F20"
resetprop -n bluetooth.device.default_name "CASIO WSD-F20"
resetprop -n ro.product.bootimage.model "CASIO WSD-F20"
resetprop -n ro.product.vendor.marketname "CASIO WSD-F20"
resetprop -n ro.product.marketname "CASIO WSD-F20"
resetprop -n ro.product.odm.model "CASIO WSD-F20"
resetprop -n ro.product.model "CASIO WSD-F20"
resetprop -n ro.product.product.model "CASIO WSD-F20"
resetprop -n ro.product.odm.marketname "CASIO WSD-F20"
resetprop -n ro.product.vendor.manufacturer "CASIO"
resetprop -n ro.product.product.manufacturer "CASIO"
resetprop -n ro.product.bootimage.manufacturer "CASIO"
resetprop -n ro.product.manufacturer "CASIO"
resetprop -n ro.product.odm.manufacturer "CASIO"
resetprop -n ro.product.system.manufacturer "CASIO"
resetprop -n ro.product.system_ext.manufacturer "CASIO"
resetprop -n ro.product.vendor_dlkm.manufacturer "CASIO"
resetprop -n ro.product.vendor.brand "casio"
resetprop -n ro.product.product.brand "casio"
resetprop -n ro.product.vendor_dlkm.brand "casio"
resetprop -n ro.product.system.brand "casio"
resetprop -n ro.product.bootimage.brand "casio"
resetprop -n ro.product.system_ext.brand "casio"
resetprop -n ro.product.odm.brand "casio"
resetprop -n ro.product.odm_dlkm.brand "casio"
resetprop -n ro.product.brand "casio"
resetprop -n ro.vendor_dlkm.build.fingerprint "casio/ayu/ayu:8.0.0/OWD3.180205.016/4710229:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "casio/ayu/ayu:8.0.0/OWD3.180205.016/4710229:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "casio/ayu/ayu:8.0.0/OWD3.180205.016/4710229:user/release-keys"
resetprop -n ro.odm.build.fingerprint "casio/ayu/ayu:8.0.0/OWD3.180205.016/4710229:user/release-keys"
resetprop -n ro.system.build.fingerprint "casio/ayu/ayu:8.0.0/OWD3.180205.016/4710229:user/release-keys"
resetprop -n ro.build.fingerprint "casio/ayu/ayu:8.0.0/OWD3.180205.016/4710229:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "casio/ayu/ayu:8.0.0/OWD3.180205.016/4710229:user/release-keys"
resetprop -n ro.product.build.fingerprint "casio/ayu/ayu:8.0.0/OWD3.180205.016/4710229:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "casio/ayu/ayu:8.0.0/OWD3.180205.016/4710229:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=3813ac04a8
resetprop -n ro.system.build.version.incremental 4710229
resetprop -n ro.bootimage.build.version.incremental 4710229
resetprop -n ro.product.build.version.incremental 4710229
resetprop -n ro.odm.build.version.incremental 4710229
resetprop -n ro.vendor_dlkm.build.version.incremental 4710229
resetprop -n ro.system_ext.build.version.incremental 4710229
resetprop -n ro.build.version.incremental 4710229
resetprop -n ro.vendor.build.version.incremental 4710229
resetprop -n ro.odm.build.id "OWD3.180205.016"
resetprop -n ro.product.build.id "OWD3.180205.016"
resetprop -n ro.bootimage.build.id "OWD3.180205.016"
resetprop -n ro.system_ext.build.id "OWD3.180205.016"
resetprop -n ro.vendor_dlkm.build.id "OWD3.180205.016"
resetprop -n ro.build.id "OWD3.180205.016"
resetprop -n ro.system.build.id "OWD3.180205.016"
resetprop -n ro.vendor.build.id "OWD3.180205.016"
resetprop -n ro.system.build.date "Tue Apr 10 03:30:17 UTC 2018"
resetprop -n ro.bootimage.build.date "Tue Apr 10 03:30:17 UTC 2018"
resetprop -n ro.product.build.date "Tue Apr 10 03:30:17 UTC 2018"
resetprop -n ro.vendor_dlkm.build.date "Tue Apr 10 03:30:17 UTC 2018"
resetprop -n ro.system_ext.build.date "Tue Apr 10 03:30:17 UTC 2018"
resetprop -n ro.odm.build.date "Tue Apr 10 03:30:17 UTC 2018"
resetprop -n ro.build.date "Tue Apr 10 03:30:17 UTC 2018"
resetprop -n ro.vendor.build.date "Tue Apr 10 03:30:17 UTC 2018"
resetprop -n ro.product.build.date.utc "1523331017"
resetprop -n ro.system_ext.build.date.utc "1523331017"
resetprop -n ro.system.build.date.utc "1523331017"
resetprop -n ro.vendor.build.date.utc "1523331017"
resetprop -n ro.vendor_dlkm.build.date.utc "1523331017"
resetprop -n ro.build.date.utc "1523331017"
resetprop -n ro.bootimage.build.date.utc "1523331017"
resetprop -n ro.odm.build.date.utc "1523331017"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name ayu
resetprop -n ro.product.odm.name ayu
resetprop -n ro.product.vendor.name ayu
resetprop -n ro.product.system.name ayu
resetprop -n ro.product.name ayu
resetprop -n ro.product.bootimage.name ayu
resetprop -n ro.product.vendor_dlkm.name ayu
resetprop -n ro.product.system_ext.name ayu
resetprop -n ro.build.flavor ayu-user
randomStr="ayu-user CASIO OWD3.180205.016 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=7f613b189b9a
resetprop -n ro.build.host ${randomStr}
randomStr=2e2d550c
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=vryxsa
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=45802fbe7273d
randomStr2=4b
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=57
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "4710229"
resetprop -n ro.build.description "ayu-user 8.0.0 OWD3.180205.016 4710229 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "android-build"
resetprop -n ro.build.host "wphq8.hot.corp.google.com"
resetprop -n ro.build.product.backup "ayu"
resetprop -n ro.build.characteristics "nosdcard,watch"
resetprop -n ro.hwui.texture_cache_size "9"
resetprop -n ro.hwui.layer_cache_size "6"
resetprop -n ro.hwui.path_cache_size "1.5"
resetprop -n ro.hwui.shape_cache_size "0.375"
resetprop -n ro.hwui.drop_shadow_cache_size "0.75"
resetprop -n ro.hwui.r_buffer_cache_size "0.75"
resetprop -n ro.expect.recovery_id "0x4a8004bb3991453a1da8723ad61d3fc4e4349b9f000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-03-05
