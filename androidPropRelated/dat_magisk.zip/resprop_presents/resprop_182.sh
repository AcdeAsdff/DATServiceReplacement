strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Archos Access 57 4G"
resetprop -n ro.product.vendor.model "Archos Access 57 4G"
resetprop -n ro.product.vendor_dlkm.marketname "Archos Access 57 4G"
resetprop -n ro.product.product.marketname "Archos Access 57 4G"
resetprop -n ro.product.system.marketname "Archos Access 57 4G"
resetprop -n ro.product.odm_dlkm.marketname "Archos Access 57 4G"
resetprop -n ro.product.system_ext.marketname "Archos Access 57 4G"
resetprop -n ro.product.odm_dlkm.model "Archos Access 57 4G"
resetprop -n ro.product.system.model "Archos Access 57 4G"
resetprop -n ro.product.system_ext.model "Archos Access 57 4G"
resetprop -n ro.product.vendor_dlkm.model "Archos Access 57 4G"
resetprop -n bluetooth.device.default_name "Archos Access 57 4G"
resetprop -n ro.product.bootimage.model "Archos Access 57 4G"
resetprop -n ro.product.vendor.marketname "Archos Access 57 4G"
resetprop -n ro.product.marketname "Archos Access 57 4G"
resetprop -n ro.product.odm.model "Archos Access 57 4G"
resetprop -n ro.product.model "Archos Access 57 4G"
resetprop -n ro.product.product.model "Archos Access 57 4G"
resetprop -n ro.product.odm.marketname "Archos Access 57 4G"
resetprop -n ro.product.vendor.manufacturer "Archos"
resetprop -n ro.product.product.manufacturer "Archos"
resetprop -n ro.product.bootimage.manufacturer "Archos"
resetprop -n ro.product.manufacturer "Archos"
resetprop -n ro.product.odm.manufacturer "Archos"
resetprop -n ro.product.system.manufacturer "Archos"
resetprop -n ro.product.system_ext.manufacturer "Archos"
resetprop -n ro.product.vendor_dlkm.manufacturer "Archos"
resetprop -n ro.product.vendor.brand "archos"
resetprop -n ro.product.product.brand "archos"
resetprop -n ro.product.vendor_dlkm.brand "archos"
resetprop -n ro.product.system.brand "archos"
resetprop -n ro.product.bootimage.brand "archos"
resetprop -n ro.product.system_ext.brand "archos"
resetprop -n ro.product.odm.brand "archos"
resetprop -n ro.product.odm_dlkm.brand "archos"
resetprop -n ro.product.brand "archos"
resetprop -n ro.vendor_dlkm.build.fingerprint "archos/SCAC57AS4G/ac57as4g:8.1.0/O21019/1533785009:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "archos/SCAC57AS4G/ac57as4g:8.1.0/O21019/1533785009:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "archos/SCAC57AS4G/ac57as4g:8.1.0/O21019/1533785009:user/release-keys"
resetprop -n ro.odm.build.fingerprint "archos/SCAC57AS4G/ac57as4g:8.1.0/O21019/1533785009:user/release-keys"
resetprop -n ro.system.build.fingerprint "archos/SCAC57AS4G/ac57as4g:8.1.0/O21019/1533785009:user/release-keys"
resetprop -n ro.build.fingerprint "archos/SCAC57AS4G/ac57as4g:8.1.0/O21019/1533785009:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "archos/SCAC57AS4G/ac57as4g:8.1.0/O21019/1533785009:user/release-keys"
resetprop -n ro.product.build.fingerprint "archos/SCAC57AS4G/ac57as4g:8.1.0/O21019/1533785009:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "archos/SCAC57AS4G/ac57as4g:8.1.0/O21019/1533785009:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=1a719dd138
resetprop -n ro.system.build.version.incremental 1533785009
resetprop -n ro.bootimage.build.version.incremental 1533785009
resetprop -n ro.product.build.version.incremental 1533785009
resetprop -n ro.odm.build.version.incremental 1533785009
resetprop -n ro.vendor_dlkm.build.version.incremental 1533785009
resetprop -n ro.system_ext.build.version.incremental 1533785009
resetprop -n ro.build.version.incremental 1533785009
resetprop -n ro.vendor.build.version.incremental 1533785009
resetprop -n ro.odm.build.id "O21019"
resetprop -n ro.product.build.id "O21019"
resetprop -n ro.bootimage.build.id "O21019"
resetprop -n ro.system_ext.build.id "O21019"
resetprop -n ro.vendor_dlkm.build.id "O21019"
resetprop -n ro.build.id "O21019"
resetprop -n ro.system.build.id "O21019"
resetprop -n ro.vendor.build.id "O21019"
resetprop -n ro.system.build.date "Thu Aug  9 11:23:29 CST 2018"
resetprop -n ro.bootimage.build.date "Thu Aug  9 11:23:29 CST 2018"
resetprop -n ro.product.build.date "Thu Aug  9 11:23:29 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Thu Aug  9 11:23:29 CST 2018"
resetprop -n ro.system_ext.build.date "Thu Aug  9 11:23:29 CST 2018"
resetprop -n ro.odm.build.date "Thu Aug  9 11:23:29 CST 2018"
resetprop -n ro.build.date "Thu Aug  9 11:23:29 CST 2018"
resetprop -n ro.vendor.build.date "Thu Aug  9 11:23:29 CST 2018"
resetprop -n ro.product.build.date.utc "1533785009"
resetprop -n ro.system_ext.build.date.utc "1533785009"
resetprop -n ro.system.build.date.utc "1533785009"
resetprop -n ro.vendor.build.date.utc "1533785009"
resetprop -n ro.vendor_dlkm.build.date.utc "1533785009"
resetprop -n ro.build.date.utc "1533785009"
resetprop -n ro.bootimage.build.date.utc "1533785009"
resetprop -n ro.odm.build.date.utc "1533785009"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name SCAC57AS4G
resetprop -n ro.product.odm.name SCAC57AS4G
resetprop -n ro.product.vendor.name SCAC57AS4G
resetprop -n ro.product.system.name SCAC57AS4G
resetprop -n ro.product.name SCAC57AS4G
resetprop -n ro.product.bootimage.name SCAC57AS4G
resetprop -n ro.product.vendor_dlkm.name SCAC57AS4G
resetprop -n ro.product.system_ext.name SCAC57AS4G
resetprop -n ro.build.flavor oversea
randomStr="oversea Archos O21019 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=983608861245
resetprop -n ro.build.host ${randomStr}
randomStr=0fb6b684
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=ixdfvT
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=a9b4f2d222d90
randomStr2=cf
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=78
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1533785009"
resetprop -n ro.build.description "SCAC57AS4G-user 8.1.0 O21019 1533785009 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "jenkins"
resetprop -n ro.build.host "devserverxvi06"
resetprop -n ro.build.product.backup "sp9832e_1h10_go"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.expect.recovery_id "0x810981dc8acdce78b9ff1d2c6fbef5eb6ce52acc000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-07-05
