strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "G55 LITE"
resetprop -n ro.product.vendor.model "G55 LITE"
resetprop -n ro.product.vendor_dlkm.marketname "G55 LITE"
resetprop -n ro.product.product.marketname "G55 LITE"
resetprop -n ro.product.system.marketname "G55 LITE"
resetprop -n ro.product.odm_dlkm.marketname "G55 LITE"
resetprop -n ro.product.system_ext.marketname "G55 LITE"
resetprop -n ro.product.odm_dlkm.model "G55 LITE"
resetprop -n ro.product.system.model "G55 LITE"
resetprop -n ro.product.system_ext.model "G55 LITE"
resetprop -n ro.product.vendor_dlkm.model "G55 LITE"
resetprop -n bluetooth.device.default_name "G55 LITE"
resetprop -n ro.product.bootimage.model "G55 LITE"
resetprop -n ro.product.vendor.marketname "G55 LITE"
resetprop -n ro.product.marketname "G55 LITE"
resetprop -n ro.product.odm.model "G55 LITE"
resetprop -n ro.product.model "G55 LITE"
resetprop -n ro.product.product.model "G55 LITE"
resetprop -n ro.product.odm.marketname "G55 LITE"
resetprop -n ro.product.vendor.manufacturer "ELEVATE"
resetprop -n ro.product.product.manufacturer "ELEVATE"
resetprop -n ro.product.bootimage.manufacturer "ELEVATE"
resetprop -n ro.product.manufacturer "ELEVATE"
resetprop -n ro.product.odm.manufacturer "ELEVATE"
resetprop -n ro.product.system.manufacturer "ELEVATE"
resetprop -n ro.product.system_ext.manufacturer "ELEVATE"
resetprop -n ro.product.vendor_dlkm.manufacturer "ELEVATE"
resetprop -n ro.product.vendor.brand "ELEVATE"
resetprop -n ro.product.product.brand "ELEVATE"
resetprop -n ro.product.vendor_dlkm.brand "ELEVATE"
resetprop -n ro.product.system.brand "ELEVATE"
resetprop -n ro.product.bootimage.brand "ELEVATE"
resetprop -n ro.product.system_ext.brand "ELEVATE"
resetprop -n ro.product.odm.brand "ELEVATE"
resetprop -n ro.product.odm_dlkm.brand "ELEVATE"
resetprop -n ro.product.brand "ELEVATE"
resetprop -n ro.vendor_dlkm.build.fingerprint "ELEVATE/G55_LITE/G55_LITE:8.1.0/ELEVATEG55_LITE/V.13:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "ELEVATE/G55_LITE/G55_LITE:8.1.0/ELEVATEG55_LITE/V.13:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "ELEVATE/G55_LITE/G55_LITE:8.1.0/ELEVATEG55_LITE/V.13:user/release-keys"
resetprop -n ro.odm.build.fingerprint "ELEVATE/G55_LITE/G55_LITE:8.1.0/ELEVATEG55_LITE/V.13:user/release-keys"
resetprop -n ro.system.build.fingerprint "ELEVATE/G55_LITE/G55_LITE:8.1.0/ELEVATEG55_LITE/V.13:user/release-keys"
resetprop -n ro.build.fingerprint "ELEVATE/G55_LITE/G55_LITE:8.1.0/ELEVATEG55_LITE/V.13:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "ELEVATE/G55_LITE/G55_LITE:8.1.0/ELEVATEG55_LITE/V.13:user/release-keys"
resetprop -n ro.product.build.fingerprint "ELEVATE/G55_LITE/G55_LITE:8.1.0/ELEVATEG55_LITE/V.13:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "ELEVATE/G55_LITE/G55_LITE:8.1.0/ELEVATEG55_LITE/V.13:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=68b09ef06c
resetprop -n ro.system.build.version.incremental V.13
resetprop -n ro.bootimage.build.version.incremental V.13
resetprop -n ro.product.build.version.incremental V.13
resetprop -n ro.odm.build.version.incremental V.13
resetprop -n ro.vendor_dlkm.build.version.incremental V.13
resetprop -n ro.system_ext.build.version.incremental V.13
resetprop -n ro.build.version.incremental V.13
resetprop -n ro.vendor.build.version.incremental V.13
resetprop -n ro.odm.build.id "ELEVATEG55_LITE"
resetprop -n ro.product.build.id "ELEVATEG55_LITE"
resetprop -n ro.bootimage.build.id "ELEVATEG55_LITE"
resetprop -n ro.system_ext.build.id "ELEVATEG55_LITE"
resetprop -n ro.vendor_dlkm.build.id "ELEVATEG55_LITE"
resetprop -n ro.build.id "ELEVATEG55_LITE"
resetprop -n ro.system.build.id "ELEVATEG55_LITE"
resetprop -n ro.vendor.build.id "ELEVATEG55_LITE"
resetprop -n ro.system.build.date "2018年 09月 05日 星期三 16:43:53 WIB"
resetprop -n ro.bootimage.build.date "2018年 09月 05日 星期三 16:43:53 WIB"
resetprop -n ro.product.build.date "2018年 09月 05日 星期三 16:43:53 WIB"
resetprop -n ro.vendor_dlkm.build.date "2018年 09月 05日 星期三 16:43:53 WIB"
resetprop -n ro.system_ext.build.date "2018年 09月 05日 星期三 16:43:53 WIB"
resetprop -n ro.odm.build.date "2018年 09月 05日 星期三 16:43:53 WIB"
resetprop -n ro.build.date "2018年 09月 05日 星期三 16:43:53 WIB"
resetprop -n ro.vendor.build.date "2018年 09月 05日 星期三 16:43:53 WIB"
resetprop -n ro.product.build.date.utc "1536140633"
resetprop -n ro.system_ext.build.date.utc "1536140633"
resetprop -n ro.system.build.date.utc "1536140633"
resetprop -n ro.vendor.build.date.utc "1536140633"
resetprop -n ro.vendor_dlkm.build.date.utc "1536140633"
resetprop -n ro.build.date.utc "1536140633"
resetprop -n ro.bootimage.build.date.utc "1536140633"
resetprop -n ro.odm.build.date.utc "1536140633"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name G55_LITE
resetprop -n ro.product.odm.name G55_LITE
resetprop -n ro.product.vendor.name G55_LITE
resetprop -n ro.product.system.name G55_LITE
resetprop -n ro.product.name G55_LITE
resetprop -n ro.product.bootimage.name G55_LITE
resetprop -n ro.product.vendor_dlkm.name G55_LITE
resetprop -n ro.product.system_ext.name G55_LITE
resetprop -n ro.build.flavor G55-user
randomStr="G55-user ELEVATE ELEVATEG55_LITE "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=f9cb48d0416f
resetprop -n ro.build.host ${randomStr}
randomStr=fd5688e3
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=rtjgkD
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=c16212df74d2e
randomStr2=d2
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=3c
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "V.13"
resetprop -n ro.build.description "G55-user 8.1.0 ELEVATEG55_LITE 1536140640 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "elevate"
resetprop -n ro.build.host "android"
resetprop -n ro.build.product.backup "G55_LITE"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.expect.recovery_id "0xec78b73ae64de3b8e05a92832f9ff8e7aea47f55000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-08-05
