strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "SM-E045F"
resetprop -n ro.product.vendor.model "SM-E045F"
resetprop -n ro.product.vendor_dlkm.marketname "SM-E045F"
resetprop -n ro.product.product.marketname "SM-E045F"
resetprop -n ro.product.system.marketname "SM-E045F"
resetprop -n ro.product.odm_dlkm.marketname "SM-E045F"
resetprop -n ro.product.system_ext.marketname "SM-E045F"
resetprop -n ro.product.odm_dlkm.model "SM-E045F"
resetprop -n ro.product.system.model "SM-E045F"
resetprop -n ro.product.system_ext.model "SM-E045F"
resetprop -n ro.product.vendor_dlkm.model "SM-E045F"
resetprop -n bluetooth.device.default_name "SM-E045F"
resetprop -n ro.product.bootimage.model "SM-E045F"
resetprop -n ro.product.vendor.marketname "SM-E045F"
resetprop -n ro.product.marketname "SM-E045F"
resetprop -n ro.product.odm.model "SM-E045F"
resetprop -n ro.product.model "SM-E045F"
resetprop -n ro.product.product.model "SM-E045F"
resetprop -n ro.product.odm.marketname "SM-E045F"
resetprop -n ro.product.vendor.manufacturer "samsung"
resetprop -n ro.product.product.manufacturer "samsung"
resetprop -n ro.product.bootimage.manufacturer "samsung"
resetprop -n ro.product.manufacturer "samsung"
resetprop -n ro.product.odm.manufacturer "samsung"
resetprop -n ro.product.system.manufacturer "samsung"
resetprop -n ro.product.system_ext.manufacturer "samsung"
resetprop -n ro.product.vendor_dlkm.manufacturer "samsung"
resetprop -n ro.product.vendor.brand "samsung"
resetprop -n ro.product.product.brand "samsung"
resetprop -n ro.product.vendor_dlkm.brand "samsung"
resetprop -n ro.product.system.brand "samsung"
resetprop -n ro.product.bootimage.brand "samsung"
resetprop -n ro.product.system_ext.brand "samsung"
resetprop -n ro.product.odm.brand "samsung"
resetprop -n ro.product.odm_dlkm.brand "samsung"
resetprop -n ro.product.brand "samsung"
resetprop -n ro.vendor_dlkm.build.fingerprint "samsung/m04ins/m04:13/TP1A.220624.014/E045FXXS3CWG6:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "samsung/m04ins/m04:13/TP1A.220624.014/E045FXXS3CWG6:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "samsung/m04ins/m04:13/TP1A.220624.014/E045FXXS3CWG6:user/release-keys"
resetprop -n ro.odm.build.fingerprint "samsung/m04ins/m04:13/TP1A.220624.014/E045FXXS3CWG6:user/release-keys"
resetprop -n ro.system.build.fingerprint "samsung/m04ins/m04:13/TP1A.220624.014/E045FXXS3CWG6:user/release-keys"
resetprop -n ro.build.fingerprint "samsung/m04ins/m04:13/TP1A.220624.014/E045FXXS3CWG6:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "samsung/m04ins/m04:13/TP1A.220624.014/E045FXXS3CWG6:user/release-keys"
resetprop -n ro.product.build.fingerprint "samsung/m04ins/m04:13/TP1A.220624.014/E045FXXS3CWG6:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "samsung/m04ins/m04:13/TP1A.220624.014/E045FXXS3CWG6:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=93655629c7
resetprop -n ro.system.build.version.incremental E045FXXS3CWG6
resetprop -n ro.bootimage.build.version.incremental E045FXXS3CWG6
resetprop -n ro.product.build.version.incremental E045FXXS3CWG6
resetprop -n ro.odm.build.version.incremental E045FXXS3CWG6
resetprop -n ro.vendor_dlkm.build.version.incremental E045FXXS3CWG6
resetprop -n ro.system_ext.build.version.incremental E045FXXS3CWG6
resetprop -n ro.build.version.incremental E045FXXS3CWG6
resetprop -n ro.vendor.build.version.incremental E045FXXS3CWG6
resetprop -n ro.odm.build.id "TP1A.220624.014"
resetprop -n ro.product.build.id "TP1A.220624.014"
resetprop -n ro.bootimage.build.id "TP1A.220624.014"
resetprop -n ro.system_ext.build.id "TP1A.220624.014"
resetprop -n ro.vendor_dlkm.build.id "TP1A.220624.014"
resetprop -n ro.build.id "TP1A.220624.014"
resetprop -n ro.system.build.id "TP1A.220624.014"
resetprop -n ro.vendor.build.id "TP1A.220624.014"
resetprop -n ro.system.build.date "Fri Jul 21 19:24:06 KST 2023"
resetprop -n ro.bootimage.build.date "Fri Jul 21 19:24:06 KST 2023"
resetprop -n ro.product.build.date "Fri Jul 21 19:24:06 KST 2023"
resetprop -n ro.vendor_dlkm.build.date "Fri Jul 21 19:24:06 KST 2023"
resetprop -n ro.system_ext.build.date "Fri Jul 21 19:24:06 KST 2023"
resetprop -n ro.odm.build.date "Fri Jul 21 19:24:06 KST 2023"
resetprop -n ro.build.date "Fri Jul 21 19:24:06 KST 2023"
resetprop -n ro.vendor.build.date "Fri Jul 21 19:24:06 KST 2023"
resetprop -n ro.product.build.date.utc "1689935046"
resetprop -n ro.system_ext.build.date.utc "1689935046"
resetprop -n ro.system.build.date.utc "1689935046"
resetprop -n ro.vendor.build.date.utc "1689935046"
resetprop -n ro.vendor_dlkm.build.date.utc "1689935046"
resetprop -n ro.build.date.utc "1689935046"
resetprop -n ro.bootimage.build.date.utc "1689935046"
resetprop -n ro.odm.build.date.utc "1689935046"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name m04ins
resetprop -n ro.product.odm.name m04ins
resetprop -n ro.product.vendor.name m04ins
resetprop -n ro.product.system.name m04ins
resetprop -n ro.product.name m04ins
resetprop -n ro.product.bootimage.name m04ins
resetprop -n ro.product.vendor_dlkm.name m04ins
resetprop -n ro.product.system_ext.name m04ins
resetprop -n ro.build.flavor m04ins-user
randomStr="m04ins-user samsung TP1A.220624.014 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=7cde8ddbc0cd
resetprop -n ro.build.host ${randomStr}
randomStr=d4455c3d
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=toOWoq
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=9f7ba38fbaee4
randomStr2=ef
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=2c
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "E045FXXS3CWG6"
resetprop -n ro.build.description "m04ins-user 13 TP1A.220624.014 E045FXXS3CWG6 release-keys"
resetprop -n ro.build.product.backup "m04"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "dpi"
resetprop -n ro.build.host "21DK7911"
resetprop -n ro.build.characteristics "phone"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.mediatek.version.branch "alps-mp-t0.mssi1.tc10sp"
resetprop -n ro.mediatek.version.release "alps-mp-t0.mp1.tc10sp-hq.V1.74_huaqin.t0mp1.vf.sp.64.ww.tc10_P3"
resetprop -n ro.vendor.mtk_omacp_support "1"
resetprop -n ro.vendor.mtk_flv_playback_support "1"
resetprop -n ro.vendor.mtk_telephony_add_on_policy "0"
resetprop -n media.stagefright.thumbnail.prefer_hw_codecs "true"
resetprop -n vendor.mtk_thumbnail_optimization "true"
resetprop -n ro.vendor.mtk_power_off_alarm_test "1"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2023-06-01
