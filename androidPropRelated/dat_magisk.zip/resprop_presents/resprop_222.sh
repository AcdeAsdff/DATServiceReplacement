strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "G5"
resetprop -n ro.product.vendor.model "G5"
resetprop -n ro.product.vendor_dlkm.marketname "G5"
resetprop -n ro.product.product.marketname "G5"
resetprop -n ro.product.system.marketname "G5"
resetprop -n ro.product.odm_dlkm.marketname "G5"
resetprop -n ro.product.system_ext.marketname "G5"
resetprop -n ro.product.odm_dlkm.model "G5"
resetprop -n ro.product.system.model "G5"
resetprop -n ro.product.system_ext.model "G5"
resetprop -n ro.product.vendor_dlkm.model "G5"
resetprop -n bluetooth.device.default_name "G5"
resetprop -n ro.product.bootimage.model "G5"
resetprop -n ro.product.vendor.marketname "G5"
resetprop -n ro.product.marketname "G5"
resetprop -n ro.product.odm.model "G5"
resetprop -n ro.product.model "G5"
resetprop -n ro.product.product.model "G5"
resetprop -n ro.product.odm.marketname "G5"
resetprop -n ro.product.vendor.manufacturer "BLU"
resetprop -n ro.product.product.manufacturer "BLU"
resetprop -n ro.product.bootimage.manufacturer "BLU"
resetprop -n ro.product.manufacturer "BLU"
resetprop -n ro.product.odm.manufacturer "BLU"
resetprop -n ro.product.system.manufacturer "BLU"
resetprop -n ro.product.system_ext.manufacturer "BLU"
resetprop -n ro.product.vendor_dlkm.manufacturer "BLU"
resetprop -n ro.product.vendor.brand "BLU"
resetprop -n ro.product.product.brand "BLU"
resetprop -n ro.product.vendor_dlkm.brand "BLU"
resetprop -n ro.product.system.brand "BLU"
resetprop -n ro.product.bootimage.brand "BLU"
resetprop -n ro.product.system_ext.brand "BLU"
resetprop -n ro.product.odm.brand "BLU"
resetprop -n ro.product.odm_dlkm.brand "BLU"
resetprop -n ro.product.brand "BLU"
resetprop -n ro.vendor_dlkm.build.fingerprint "BLU/BLU_G5/G0090:9/PPR1.180610.011/34510:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "BLU/BLU_G5/G0090:9/PPR1.180610.011/34510:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "BLU/BLU_G5/G0090:9/PPR1.180610.011/34510:user/release-keys"
resetprop -n ro.odm.build.fingerprint "BLU/BLU_G5/G0090:9/PPR1.180610.011/34510:user/release-keys"
resetprop -n ro.system.build.fingerprint "BLU/BLU_G5/G0090:9/PPR1.180610.011/34510:user/release-keys"
resetprop -n ro.build.fingerprint "BLU/BLU_G5/G0090:9/PPR1.180610.011/34510:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "BLU/BLU_G5/G0090:9/PPR1.180610.011/34510:user/release-keys"
resetprop -n ro.product.build.fingerprint "BLU/BLU_G5/G0090:9/PPR1.180610.011/34510:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "BLU/BLU_G5/G0090:9/PPR1.180610.011/34510:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=6930b0ee55
resetprop -n ro.system.build.version.incremental 34510
resetprop -n ro.bootimage.build.version.incremental 34510
resetprop -n ro.product.build.version.incremental 34510
resetprop -n ro.odm.build.version.incremental 34510
resetprop -n ro.vendor_dlkm.build.version.incremental 34510
resetprop -n ro.system_ext.build.version.incremental 34510
resetprop -n ro.build.version.incremental 34510
resetprop -n ro.vendor.build.version.incremental 34510
resetprop -n ro.odm.build.id "PPR1.180610.011"
resetprop -n ro.product.build.id "PPR1.180610.011"
resetprop -n ro.bootimage.build.id "PPR1.180610.011"
resetprop -n ro.system_ext.build.id "PPR1.180610.011"
resetprop -n ro.vendor_dlkm.build.id "PPR1.180610.011"
resetprop -n ro.build.id "PPR1.180610.011"
resetprop -n ro.system.build.id "PPR1.180610.011"
resetprop -n ro.vendor.build.id "PPR1.180610.011"
resetprop -n ro.system.build.date "Fri Aug 30 10:39:49 CST 2019"
resetprop -n ro.bootimage.build.date "Fri Aug 30 10:39:49 CST 2019"
resetprop -n ro.product.build.date "Fri Aug 30 10:39:49 CST 2019"
resetprop -n ro.vendor_dlkm.build.date "Fri Aug 30 10:39:49 CST 2019"
resetprop -n ro.system_ext.build.date "Fri Aug 30 10:39:49 CST 2019"
resetprop -n ro.odm.build.date "Fri Aug 30 10:39:49 CST 2019"
resetprop -n ro.build.date "Fri Aug 30 10:39:49 CST 2019"
resetprop -n ro.vendor.build.date "Fri Aug 30 10:39:49 CST 2019"
resetprop -n ro.product.build.date.utc "1567132789"
resetprop -n ro.system_ext.build.date.utc "1567132789"
resetprop -n ro.system.build.date.utc "1567132789"
resetprop -n ro.vendor.build.date.utc "1567132789"
resetprop -n ro.vendor_dlkm.build.date.utc "1567132789"
resetprop -n ro.build.date.utc "1567132789"
resetprop -n ro.bootimage.build.date.utc "1567132789"
resetprop -n ro.odm.build.date.utc "1567132789"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name BLU_G5
resetprop -n ro.product.odm.name BLU_G5
resetprop -n ro.product.vendor.name BLU_G5
resetprop -n ro.product.system.name BLU_G5
resetprop -n ro.product.name BLU_G5
resetprop -n ro.product.bootimage.name BLU_G5
resetprop -n ro.product.vendor_dlkm.name BLU_G5
resetprop -n ro.product.system_ext.name BLU_G5
resetprop -n ro.build.flavor s9863a_fs171_project-user
randomStr="s9863a_fs171_project-user BLU PPR1.180610.011 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=85e9eddcf6c6
resetprop -n ro.build.host ${randomStr}
randomStr=170ea53d
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=KtzvZm
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=942b86e913e24
randomStr2=33
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=42
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "34510"
resetprop -n ro.build.description "s9863a_fs171_project-user 9 PPR1.180610.011 34510 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "ckaiwenf2"
resetprop -n ro.build.host "jpjf0"
resetprop -n ro.build.product.backup "BLU_G5"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.com.google.acsa "true"
resetprop -n ro.com.google.clientidbase.ms "android-blu-rev2"
resetprop -n ro.lmk.vmpressurenhanced "true"
resetprop -n ro.expect.recovery_id "0xbc213b6da275ca386671d645805c4b952219351a000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-08-05
