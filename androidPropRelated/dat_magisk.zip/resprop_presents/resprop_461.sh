strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "itel W6002"
resetprop -n ro.product.vendor.model "itel W6002"
resetprop -n ro.product.vendor_dlkm.marketname "itel W6002"
resetprop -n ro.product.product.marketname "itel W6002"
resetprop -n ro.product.system.marketname "itel W6002"
resetprop -n ro.product.odm_dlkm.marketname "itel W6002"
resetprop -n ro.product.system_ext.marketname "itel W6002"
resetprop -n ro.product.odm_dlkm.model "itel W6002"
resetprop -n ro.product.system.model "itel W6002"
resetprop -n ro.product.system_ext.model "itel W6002"
resetprop -n ro.product.vendor_dlkm.model "itel W6002"
resetprop -n bluetooth.device.default_name "itel W6002"
resetprop -n ro.product.bootimage.model "itel W6002"
resetprop -n ro.product.vendor.marketname "itel W6002"
resetprop -n ro.product.marketname "itel W6002"
resetprop -n ro.product.odm.model "itel W6002"
resetprop -n ro.product.model "itel W6002"
resetprop -n ro.product.product.model "itel W6002"
resetprop -n ro.product.odm.marketname "itel W6002"
resetprop -n ro.product.vendor.manufacturer "itel"
resetprop -n ro.product.product.manufacturer "itel"
resetprop -n ro.product.bootimage.manufacturer "itel"
resetprop -n ro.product.manufacturer "itel"
resetprop -n ro.product.odm.manufacturer "itel"
resetprop -n ro.product.system.manufacturer "itel"
resetprop -n ro.product.system_ext.manufacturer "itel"
resetprop -n ro.product.vendor_dlkm.manufacturer "itel"
resetprop -n ro.product.vendor.brand "Itel"
resetprop -n ro.product.product.brand "Itel"
resetprop -n ro.product.vendor_dlkm.brand "Itel"
resetprop -n ro.product.system.brand "Itel"
resetprop -n ro.product.bootimage.brand "Itel"
resetprop -n ro.product.system_ext.brand "Itel"
resetprop -n ro.product.odm.brand "Itel"
resetprop -n ro.product.odm_dlkm.brand "Itel"
resetprop -n ro.product.brand "Itel"
resetprop -n ro.vendor_dlkm.build.fingerprint "Itel/F3108/itel-W6002:9/PPR1.180610.011/OP-V041-20191120:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Itel/F3108/itel-W6002:9/PPR1.180610.011/OP-V041-20191120:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Itel/F3108/itel-W6002:9/PPR1.180610.011/OP-V041-20191120:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Itel/F3108/itel-W6002:9/PPR1.180610.011/OP-V041-20191120:user/release-keys"
resetprop -n ro.system.build.fingerprint "Itel/F3108/itel-W6002:9/PPR1.180610.011/OP-V041-20191120:user/release-keys"
resetprop -n ro.build.fingerprint "Itel/F3108/itel-W6002:9/PPR1.180610.011/OP-V041-20191120:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Itel/F3108/itel-W6002:9/PPR1.180610.011/OP-V041-20191120:user/release-keys"
resetprop -n ro.product.build.fingerprint "Itel/F3108/itel-W6002:9/PPR1.180610.011/OP-V041-20191120:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Itel/F3108/itel-W6002:9/PPR1.180610.011/OP-V041-20191120:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=d4aeec8295
resetprop -n ro.system.build.version.incremental OP-V041-20191120
resetprop -n ro.bootimage.build.version.incremental OP-V041-20191120
resetprop -n ro.product.build.version.incremental OP-V041-20191120
resetprop -n ro.odm.build.version.incremental OP-V041-20191120
resetprop -n ro.vendor_dlkm.build.version.incremental OP-V041-20191120
resetprop -n ro.system_ext.build.version.incremental OP-V041-20191120
resetprop -n ro.build.version.incremental OP-V041-20191120
resetprop -n ro.vendor.build.version.incremental OP-V041-20191120
resetprop -n ro.odm.build.id "PPR1.180610.011"
resetprop -n ro.product.build.id "PPR1.180610.011"
resetprop -n ro.bootimage.build.id "PPR1.180610.011"
resetprop -n ro.system_ext.build.id "PPR1.180610.011"
resetprop -n ro.vendor_dlkm.build.id "PPR1.180610.011"
resetprop -n ro.build.id "PPR1.180610.011"
resetprop -n ro.system.build.id "PPR1.180610.011"
resetprop -n ro.vendor.build.id "PPR1.180610.011"
resetprop -n ro.system.build.date "Wed Nov 20 17:26:36 CST 2019"
resetprop -n ro.bootimage.build.date "Wed Nov 20 17:26:36 CST 2019"
resetprop -n ro.product.build.date "Wed Nov 20 17:26:36 CST 2019"
resetprop -n ro.vendor_dlkm.build.date "Wed Nov 20 17:26:36 CST 2019"
resetprop -n ro.system_ext.build.date "Wed Nov 20 17:26:36 CST 2019"
resetprop -n ro.odm.build.date "Wed Nov 20 17:26:36 CST 2019"
resetprop -n ro.build.date "Wed Nov 20 17:26:36 CST 2019"
resetprop -n ro.vendor.build.date "Wed Nov 20 17:26:36 CST 2019"
resetprop -n ro.product.build.date.utc "1574241996"
resetprop -n ro.system_ext.build.date.utc "1574241996"
resetprop -n ro.system.build.date.utc "1574241996"
resetprop -n ro.vendor.build.date.utc "1574241996"
resetprop -n ro.vendor_dlkm.build.date.utc "1574241996"
resetprop -n ro.build.date.utc "1574241996"
resetprop -n ro.bootimage.build.date.utc "1574241996"
resetprop -n ro.odm.build.date.utc "1574241996"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name F3108
resetprop -n ro.product.odm.name F3108
resetprop -n ro.product.vendor.name F3108
resetprop -n ro.product.system.name F3108
resetprop -n ro.product.name F3108
resetprop -n ro.product.bootimage.name F3108
resetprop -n ro.product.vendor_dlkm.name F3108
resetprop -n ro.product.system_ext.name F3108
resetprop -n ro.build.flavor W6002-user
randomStr="W6002-user itel PPR1.180610.011 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=647bb03bb733
resetprop -n ro.build.host ${randomStr}
randomStr=0bb1ad70
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=rtJHVi
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=0f0375e11202d
randomStr2=62
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=e4
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "OP-V041-20191120"
resetprop -n ro.build.description "W6002-user 9 PPR1.180610.011 521 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "system1"
resetprop -n ro.build.host "ubuntu-101"
resetprop -n ro.build.product.backup "W6002"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.config.google.sound "1"
resetprop -n media.settings.xml  " vendor/etc/media_profiles_turnkey.xml"
resetprop -n ro.lmk.critical_upgrade "true"
resetprop -n ro.lmk.upgrade_pressure "40"
resetprop -n ro.lmk.downgrade_pressure "60"
resetprop -n ro.lmk.kill_heaviest_task "false"
resetprop -n ro.lmk.vmpressurenhanced "true"
resetprop -n ro.expect.recovery_id "0xd296dc0667039362090d6d787b09d36195cc72ff000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-11-05
