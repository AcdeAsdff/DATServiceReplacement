strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "E7446"
resetprop -n ro.product.vendor.model "E7446"
resetprop -n ro.product.vendor_dlkm.marketname "E7446"
resetprop -n ro.product.product.marketname "E7446"
resetprop -n ro.product.system.marketname "E7446"
resetprop -n ro.product.odm_dlkm.marketname "E7446"
resetprop -n ro.product.system_ext.marketname "E7446"
resetprop -n ro.product.odm_dlkm.model "E7446"
resetprop -n ro.product.system.model "E7446"
resetprop -n ro.product.system_ext.model "E7446"
resetprop -n ro.product.vendor_dlkm.model "E7446"
resetprop -n bluetooth.device.default_name "E7446"
resetprop -n ro.product.bootimage.model "E7446"
resetprop -n ro.product.vendor.marketname "E7446"
resetprop -n ro.product.marketname "E7446"
resetprop -n ro.product.odm.model "E7446"
resetprop -n ro.product.model "E7446"
resetprop -n ro.product.product.model "E7446"
resetprop -n ro.product.odm.marketname "E7446"
resetprop -n ro.product.vendor.manufacturer "Micromax"
resetprop -n ro.product.product.manufacturer "Micromax"
resetprop -n ro.product.bootimage.manufacturer "Micromax"
resetprop -n ro.product.manufacturer "Micromax"
resetprop -n ro.product.odm.manufacturer "Micromax"
resetprop -n ro.product.system.manufacturer "Micromax"
resetprop -n ro.product.system_ext.manufacturer "Micromax"
resetprop -n ro.product.vendor_dlkm.manufacturer "Micromax"
resetprop -n ro.product.vendor.brand "Micromax"
resetprop -n ro.product.product.brand "Micromax"
resetprop -n ro.product.vendor_dlkm.brand "Micromax"
resetprop -n ro.product.system.brand "Micromax"
resetprop -n ro.product.bootimage.brand "Micromax"
resetprop -n ro.product.system_ext.brand "Micromax"
resetprop -n ro.product.odm.brand "Micromax"
resetprop -n ro.product.odm_dlkm.brand "Micromax"
resetprop -n ro.product.brand "Micromax"
resetprop -n ro.vendor_dlkm.build.fingerprint "Micromax/E7446/E7446:11/RP1A.200720.011/1637827892:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Micromax/E7446/E7446:11/RP1A.200720.011/1637827892:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Micromax/E7446/E7446:11/RP1A.200720.011/1637827892:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Micromax/E7446/E7446:11/RP1A.200720.011/1637827892:user/release-keys"
resetprop -n ro.system.build.fingerprint "Micromax/E7446/E7446:11/RP1A.200720.011/1637827892:user/release-keys"
resetprop -n ro.build.fingerprint "Micromax/E7446/E7446:11/RP1A.200720.011/1637827892:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Micromax/E7446/E7446:11/RP1A.200720.011/1637827892:user/release-keys"
resetprop -n ro.product.build.fingerprint "Micromax/E7446/E7446:11/RP1A.200720.011/1637827892:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Micromax/E7446/E7446:11/RP1A.200720.011/1637827892:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=bc5e616e31
resetprop -n ro.system.build.version.incremental 1637827892
resetprop -n ro.bootimage.build.version.incremental 1637827892
resetprop -n ro.product.build.version.incremental 1637827892
resetprop -n ro.odm.build.version.incremental 1637827892
resetprop -n ro.vendor_dlkm.build.version.incremental 1637827892
resetprop -n ro.system_ext.build.version.incremental 1637827892
resetprop -n ro.build.version.incremental 1637827892
resetprop -n ro.vendor.build.version.incremental 1637827892
resetprop -n ro.odm.build.id "RP1A.200720.011"
resetprop -n ro.product.build.id "RP1A.200720.011"
resetprop -n ro.bootimage.build.id "RP1A.200720.011"
resetprop -n ro.system_ext.build.id "RP1A.200720.011"
resetprop -n ro.vendor_dlkm.build.id "RP1A.200720.011"
resetprop -n ro.build.id "RP1A.200720.011"
resetprop -n ro.system.build.id "RP1A.200720.011"
resetprop -n ro.vendor.build.id "RP1A.200720.011"
resetprop -n ro.system.build.date "Thu Nov 25 16:19:36 CST 2021"
resetprop -n ro.bootimage.build.date "Thu Nov 25 16:19:36 CST 2021"
resetprop -n ro.product.build.date "Thu Nov 25 16:19:36 CST 2021"
resetprop -n ro.vendor_dlkm.build.date "Thu Nov 25 16:19:36 CST 2021"
resetprop -n ro.system_ext.build.date "Thu Nov 25 16:19:36 CST 2021"
resetprop -n ro.odm.build.date "Thu Nov 25 16:19:36 CST 2021"
resetprop -n ro.build.date "Thu Nov 25 16:19:36 CST 2021"
resetprop -n ro.vendor.build.date "Thu Nov 25 16:19:36 CST 2021"
resetprop -n ro.product.build.date.utc "1637828376"
resetprop -n ro.system_ext.build.date.utc "1637828376"
resetprop -n ro.system.build.date.utc "1637828376"
resetprop -n ro.vendor.build.date.utc "1637828376"
resetprop -n ro.vendor_dlkm.build.date.utc "1637828376"
resetprop -n ro.build.date.utc "1637828376"
resetprop -n ro.bootimage.build.date.utc "1637828376"
resetprop -n ro.odm.build.date.utc "1637828376"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name E7446
resetprop -n ro.product.odm.name E7446
resetprop -n ro.product.vendor.name E7446
resetprop -n ro.product.system.name E7446
resetprop -n ro.product.name E7446
resetprop -n ro.product.bootimage.name E7446
resetprop -n ro.product.vendor_dlkm.name E7446
resetprop -n ro.product.system_ext.name E7446
resetprop -n ro.build.flavor E7446-user
randomStr="E7446-user Micromax RP1A.200720.011 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=22bfde862a2e
resetprop -n ro.build.host ${randomStr}
randomStr=cc9462d4
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=RKZAxE
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=5c43698436979
randomStr2=0f
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=b6
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1637827892"
resetprop -n ro.build.description "E7446-user 11 RP1A.200720.011 1637827892 release-keys"
resetprop -n net.hostname "E7446"
resetprop -n ro.build.host "s12"
resetprop -n ro.build.product.backup "E7446"
resetprop -n ro.build.user "root"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.com.google.rlz_ap_whitelist  " YA"
resetprop -n ro.com.google.rlzbrandcode  " MIIX"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2021-11-05
