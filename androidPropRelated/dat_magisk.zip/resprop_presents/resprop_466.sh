strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "LS1542QW"
resetprop -n ro.product.vendor.model "LS1542QW"
resetprop -n ro.product.vendor_dlkm.marketname "LS1542QW"
resetprop -n ro.product.product.marketname "LS1542QW"
resetprop -n ro.product.system.marketname "LS1542QW"
resetprop -n ro.product.odm_dlkm.marketname "LS1542QW"
resetprop -n ro.product.system_ext.marketname "LS1542QW"
resetprop -n ro.product.odm_dlkm.model "LS1542QW"
resetprop -n ro.product.system.model "LS1542QW"
resetprop -n ro.product.system_ext.model "LS1542QW"
resetprop -n ro.product.vendor_dlkm.model "LS1542QW"
resetprop -n bluetooth.device.default_name "LS1542QW"
resetprop -n ro.product.bootimage.model "LS1542QW"
resetprop -n ro.product.vendor.marketname "LS1542QW"
resetprop -n ro.product.marketname "LS1542QW"
resetprop -n ro.product.odm.model "LS1542QW"
resetprop -n ro.product.model "LS1542QW"
resetprop -n ro.product.product.model "LS1542QW"
resetprop -n ro.product.odm.marketname "LS1542QW"
resetprop -n ro.product.vendor.manufacturer "Wingtech"
resetprop -n ro.product.product.manufacturer "Wingtech"
resetprop -n ro.product.bootimage.manufacturer "Wingtech"
resetprop -n ro.product.manufacturer "Wingtech"
resetprop -n ro.product.odm.manufacturer "Wingtech"
resetprop -n ro.product.system.manufacturer "Wingtech"
resetprop -n ro.product.system_ext.manufacturer "Wingtech"
resetprop -n ro.product.vendor_dlkm.manufacturer "Wingtech"
resetprop -n ro.product.vendor.brand "Jio"
resetprop -n ro.product.product.brand "Jio"
resetprop -n ro.product.vendor_dlkm.brand "Jio"
resetprop -n ro.product.system.brand "Jio"
resetprop -n ro.product.bootimage.brand "Jio"
resetprop -n ro.product.system_ext.brand "Jio"
resetprop -n ro.product.odm.brand "Jio"
resetprop -n ro.product.odm_dlkm.brand "Jio"
resetprop -n ro.product.brand "Jio"
resetprop -n ro.vendor_dlkm.build.fingerprint "Jio/Smartphone/LS1542QW:11/RKQ1.210602.002/B.001.05.001:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Jio/Smartphone/LS1542QW:11/RKQ1.210602.002/B.001.05.001:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Jio/Smartphone/LS1542QW:11/RKQ1.210602.002/B.001.05.001:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Jio/Smartphone/LS1542QW:11/RKQ1.210602.002/B.001.05.001:user/release-keys"
resetprop -n ro.system.build.fingerprint "Jio/Smartphone/LS1542QW:11/RKQ1.210602.002/B.001.05.001:user/release-keys"
resetprop -n ro.build.fingerprint "Jio/Smartphone/LS1542QW:11/RKQ1.210602.002/B.001.05.001:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Jio/Smartphone/LS1542QW:11/RKQ1.210602.002/B.001.05.001:user/release-keys"
resetprop -n ro.product.build.fingerprint "Jio/Smartphone/LS1542QW:11/RKQ1.210602.002/B.001.05.001:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Jio/Smartphone/LS1542QW:11/RKQ1.210602.002/B.001.05.001:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=f91f942648
resetprop -n ro.system.build.version.incremental B.001.05.001
resetprop -n ro.bootimage.build.version.incremental B.001.05.001
resetprop -n ro.product.build.version.incremental B.001.05.001
resetprop -n ro.odm.build.version.incremental B.001.05.001
resetprop -n ro.vendor_dlkm.build.version.incremental B.001.05.001
resetprop -n ro.system_ext.build.version.incremental B.001.05.001
resetprop -n ro.build.version.incremental B.001.05.001
resetprop -n ro.vendor.build.version.incremental B.001.05.001
resetprop -n ro.odm.build.id "RKQ1.210602.002"
resetprop -n ro.product.build.id "RKQ1.210602.002"
resetprop -n ro.bootimage.build.id "RKQ1.210602.002"
resetprop -n ro.system_ext.build.id "RKQ1.210602.002"
resetprop -n ro.vendor_dlkm.build.id "RKQ1.210602.002"
resetprop -n ro.build.id "RKQ1.210602.002"
resetprop -n ro.system.build.id "RKQ1.210602.002"
resetprop -n ro.vendor.build.id "RKQ1.210602.002"
resetprop -n ro.system.build.date "Wed Nov 10 10:46:13 IST 2021"
resetprop -n ro.bootimage.build.date "Wed Nov 10 10:46:13 IST 2021"
resetprop -n ro.product.build.date "Wed Nov 10 10:46:13 IST 2021"
resetprop -n ro.vendor_dlkm.build.date "Wed Nov 10 10:46:13 IST 2021"
resetprop -n ro.system_ext.build.date "Wed Nov 10 10:46:13 IST 2021"
resetprop -n ro.odm.build.date "Wed Nov 10 10:46:13 IST 2021"
resetprop -n ro.build.date "Wed Nov 10 10:46:13 IST 2021"
resetprop -n ro.vendor.build.date "Wed Nov 10 10:46:13 IST 2021"
resetprop -n ro.product.build.date.utc "1636521373"
resetprop -n ro.system_ext.build.date.utc "1636521373"
resetprop -n ro.system.build.date.utc "1636521373"
resetprop -n ro.vendor.build.date.utc "1636521373"
resetprop -n ro.vendor_dlkm.build.date.utc "1636521373"
resetprop -n ro.build.date.utc "1636521373"
resetprop -n ro.bootimage.build.date.utc "1636521373"
resetprop -n ro.odm.build.date.utc "1636521373"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name Smartphone
resetprop -n ro.product.odm.name Smartphone
resetprop -n ro.product.vendor.name Smartphone
resetprop -n ro.product.system.name Smartphone
resetprop -n ro.product.name Smartphone
resetprop -n ro.product.bootimage.name Smartphone
resetprop -n ro.product.vendor_dlkm.name Smartphone
resetprop -n ro.product.system_ext.name Smartphone
resetprop -n ro.build.flavor K89548AA1-user
randomStr="K89548AA1-user Wingtech RKQ1.210602.002 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=01dcf8ad0792
resetprop -n ro.build.host ${randomStr}
randomStr=3fe056d9
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=WkVarv
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=2b4e447fa1547
randomStr2=9a
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=22
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "B.001.05.001"
resetprop -n ro.build.description "aeon6580_weg_l_l300-user 5.1 LMY47I 1555741941 release-keys"
resetprop -n ro.build.product.backup "LS1542QW"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "root"
resetprop -n ro.build.host "dravivar-10771-itfrfn"
resetprop -n media.msm8956hw "0"
resetprop -n media.aac_51_output_enabled "true"
resetprop -n media.settings.xml "/vendor/etc/media_profiles_vendor.xml"
resetprop -n media.stagefright.thumbnail.prefer_hw_codecs "true"
resetprop -n ro.hwui.texture_cache_size "72"
resetprop -n ro.hwui.layer_cache_size "48"
resetprop -n ro.hwui.r_buffer_cache_size "8"
resetprop -n ro.hwui.path_cache_size "32"
resetprop -n ro.hwui.gradient_cache_size "1"
resetprop -n ro.hwui.drop_shadow_cache_size "6"
resetprop -n ro.hwui.texture_cache_flushrate "0.4"
resetprop -n ro.hwui.text_small_cache_width "1024"
resetprop -n ro.hwui.text_small_cache_height "1024"
resetprop -n ro.hwui.text_large_cache_width "2048"
resetprop -n ro.hwui.text_large_cache_height "2048"
resetprop -n ro.com.google.clientidbase "android-jio"
resetprop -n ro.com.google.clientidbase.ms "android-jio-rvc3"
resetprop -n ro.com.google.clientidbase.tx "android-jio-rvc3"
resetprop -n ro.com.google.clientidbase.vs "android-jio-rvc3"
resetprop -n ro.com.google.acsa "true"
resetprop -n ro.lmk.medium "700"
resetprop -n ro.lmk.critical_upgrade "true"
resetprop -n ro.lmk.upgrade_pressure "40"
resetprop -n ro.lmk.downgrade_pressure "60"
resetprop -n ro.lmk.kill_heaviest_task "false"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2021-10-05
