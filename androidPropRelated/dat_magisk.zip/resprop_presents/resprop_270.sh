strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "C558"
resetprop -n ro.product.vendor.model "C558"
resetprop -n ro.product.vendor_dlkm.marketname "C558"
resetprop -n ro.product.product.marketname "C558"
resetprop -n ro.product.system.marketname "C558"
resetprop -n ro.product.odm_dlkm.marketname "C558"
resetprop -n ro.product.system_ext.marketname "C558"
resetprop -n ro.product.odm_dlkm.model "C558"
resetprop -n ro.product.system.model "C558"
resetprop -n ro.product.system_ext.model "C558"
resetprop -n ro.product.vendor_dlkm.model "C558"
resetprop -n bluetooth.device.default_name "C558"
resetprop -n ro.product.bootimage.model "C558"
resetprop -n ro.product.vendor.marketname "C558"
resetprop -n ro.product.marketname "C558"
resetprop -n ro.product.odm.model "C558"
resetprop -n ro.product.model "C558"
resetprop -n ro.product.product.model "C558"
resetprop -n ro.product.odm.marketname "C558"
resetprop -n ro.product.vendor.manufacturer "Coolpad"
resetprop -n ro.product.product.manufacturer "Coolpad"
resetprop -n ro.product.bootimage.manufacturer "Coolpad"
resetprop -n ro.product.manufacturer "Coolpad"
resetprop -n ro.product.odm.manufacturer "Coolpad"
resetprop -n ro.product.system.manufacturer "Coolpad"
resetprop -n ro.product.system_ext.manufacturer "Coolpad"
resetprop -n ro.product.vendor_dlkm.manufacturer "Coolpad"
resetprop -n ro.product.vendor.brand "Coolpad"
resetprop -n ro.product.product.brand "Coolpad"
resetprop -n ro.product.vendor_dlkm.brand "Coolpad"
resetprop -n ro.product.system.brand "Coolpad"
resetprop -n ro.product.bootimage.brand "Coolpad"
resetprop -n ro.product.system_ext.brand "Coolpad"
resetprop -n ro.product.odm.brand "Coolpad"
resetprop -n ro.product.odm_dlkm.brand "Coolpad"
resetprop -n ro.product.brand "Coolpad"
resetprop -n ro.vendor_dlkm.build.fingerprint "Coolpad/C558/C558:8.1.0/O11019/1544695559:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Coolpad/C558/C558:8.1.0/O11019/1544695559:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Coolpad/C558/C558:8.1.0/O11019/1544695559:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Coolpad/C558/C558:8.1.0/O11019/1544695559:user/release-keys"
resetprop -n ro.system.build.fingerprint "Coolpad/C558/C558:8.1.0/O11019/1544695559:user/release-keys"
resetprop -n ro.build.fingerprint "Coolpad/C558/C558:8.1.0/O11019/1544695559:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Coolpad/C558/C558:8.1.0/O11019/1544695559:user/release-keys"
resetprop -n ro.product.build.fingerprint "Coolpad/C558/C558:8.1.0/O11019/1544695559:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Coolpad/C558/C558:8.1.0/O11019/1544695559:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=486c730324
resetprop -n ro.system.build.version.incremental 1544695559
resetprop -n ro.bootimage.build.version.incremental 1544695559
resetprop -n ro.product.build.version.incremental 1544695559
resetprop -n ro.odm.build.version.incremental 1544695559
resetprop -n ro.vendor_dlkm.build.version.incremental 1544695559
resetprop -n ro.system_ext.build.version.incremental 1544695559
resetprop -n ro.build.version.incremental 1544695559
resetprop -n ro.vendor.build.version.incremental 1544695559
resetprop -n ro.odm.build.id "O11019"
resetprop -n ro.product.build.id "O11019"
resetprop -n ro.bootimage.build.id "O11019"
resetprop -n ro.system_ext.build.id "O11019"
resetprop -n ro.vendor_dlkm.build.id "O11019"
resetprop -n ro.build.id "O11019"
resetprop -n ro.system.build.id "O11019"
resetprop -n ro.vendor.build.id "O11019"
resetprop -n ro.system.build.date "Thu Dec 13 18:02:12 CST 2018"
resetprop -n ro.bootimage.build.date "Thu Dec 13 18:02:12 CST 2018"
resetprop -n ro.product.build.date "Thu Dec 13 18:02:12 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Thu Dec 13 18:02:12 CST 2018"
resetprop -n ro.system_ext.build.date "Thu Dec 13 18:02:12 CST 2018"
resetprop -n ro.odm.build.date "Thu Dec 13 18:02:12 CST 2018"
resetprop -n ro.build.date "Thu Dec 13 18:02:12 CST 2018"
resetprop -n ro.vendor.build.date "Thu Dec 13 18:02:12 CST 2018"
resetprop -n ro.product.build.date.utc "1544695332"
resetprop -n ro.system_ext.build.date.utc "1544695332"
resetprop -n ro.system.build.date.utc "1544695332"
resetprop -n ro.vendor.build.date.utc "1544695332"
resetprop -n ro.vendor_dlkm.build.date.utc "1544695332"
resetprop -n ro.build.date.utc "1544695332"
resetprop -n ro.bootimage.build.date.utc "1544695332"
resetprop -n ro.odm.build.date.utc "1544695332"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name C558
resetprop -n ro.product.odm.name C558
resetprop -n ro.product.vendor.name C558
resetprop -n ro.product.system.name C558
resetprop -n ro.product.name C558
resetprop -n ro.product.bootimage.name C558
resetprop -n ro.product.vendor_dlkm.name C558
resetprop -n ro.product.system_ext.name C558
resetprop -n ro.build.flavor full_k39tv1_bsp_512-user
randomStr="full_k39tv1_bsp_512-user Coolpad O11019 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=9bfd4af2bf82
resetprop -n ro.build.host ${randomStr}
randomStr=20f9ec76
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=VYhAAI
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=46fa626fb454c
randomStr2=3e
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=20
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1544695559"
resetprop -n ro.build.description "full_k39tv1_bsp_512-user 8.1.0 O11019 1544695559 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "jiangmin"
resetprop -n ro.build.host "swserver12"
resetprop -n ro.build.product.backup "k39tv1_bsp_512"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.expect.recovery_id "0xef4a6dfd6fc248c0d4c45a2789a77c90dfc5dcc9000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-11-05
