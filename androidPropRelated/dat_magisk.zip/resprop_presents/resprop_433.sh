strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Infinix X657C"
resetprop -n ro.product.vendor.model "Infinix X657C"
resetprop -n ro.product.vendor_dlkm.marketname "Infinix X657C"
resetprop -n ro.product.product.marketname "Infinix X657C"
resetprop -n ro.product.system.marketname "Infinix X657C"
resetprop -n ro.product.odm_dlkm.marketname "Infinix X657C"
resetprop -n ro.product.system_ext.marketname "Infinix X657C"
resetprop -n ro.product.odm_dlkm.model "Infinix X657C"
resetprop -n ro.product.system.model "Infinix X657C"
resetprop -n ro.product.system_ext.model "Infinix X657C"
resetprop -n ro.product.vendor_dlkm.model "Infinix X657C"
resetprop -n bluetooth.device.default_name "Infinix X657C"
resetprop -n ro.product.bootimage.model "Infinix X657C"
resetprop -n ro.product.vendor.marketname "Infinix X657C"
resetprop -n ro.product.marketname "Infinix X657C"
resetprop -n ro.product.odm.model "Infinix X657C"
resetprop -n ro.product.model "Infinix X657C"
resetprop -n ro.product.product.model "Infinix X657C"
resetprop -n ro.product.odm.marketname "Infinix X657C"
resetprop -n ro.product.vendor.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.product.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.bootimage.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.odm.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.system.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.system_ext.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.vendor_dlkm.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.vendor.brand "Infinix"
resetprop -n ro.product.product.brand "Infinix"
resetprop -n ro.product.vendor_dlkm.brand "Infinix"
resetprop -n ro.product.system.brand "Infinix"
resetprop -n ro.product.bootimage.brand "Infinix"
resetprop -n ro.product.system_ext.brand "Infinix"
resetprop -n ro.product.odm.brand "Infinix"
resetprop -n ro.product.odm_dlkm.brand "Infinix"
resetprop -n ro.product.brand "Infinix"
resetprop -n ro.vendor_dlkm.build.fingerprint "Infinix/X657C-GL/Infinix-X657C:10/QP1A.190711.020/GH-GL-220821V327:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Infinix/X657C-GL/Infinix-X657C:10/QP1A.190711.020/GH-GL-220821V327:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Infinix/X657C-GL/Infinix-X657C:10/QP1A.190711.020/GH-GL-220821V327:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Infinix/X657C-GL/Infinix-X657C:10/QP1A.190711.020/GH-GL-220821V327:user/release-keys"
resetprop -n ro.system.build.fingerprint "Infinix/X657C-GL/Infinix-X657C:10/QP1A.190711.020/GH-GL-220821V327:user/release-keys"
resetprop -n ro.build.fingerprint "Infinix/X657C-GL/Infinix-X657C:10/QP1A.190711.020/GH-GL-220821V327:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Infinix/X657C-GL/Infinix-X657C:10/QP1A.190711.020/GH-GL-220821V327:user/release-keys"
resetprop -n ro.product.build.fingerprint "Infinix/X657C-GL/Infinix-X657C:10/QP1A.190711.020/GH-GL-220821V327:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Infinix/X657C-GL/Infinix-X657C:10/QP1A.190711.020/GH-GL-220821V327:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=0231451077
resetprop -n ro.system.build.version.incremental GH-GL-220821V327
resetprop -n ro.bootimage.build.version.incremental GH-GL-220821V327
resetprop -n ro.product.build.version.incremental GH-GL-220821V327
resetprop -n ro.odm.build.version.incremental GH-GL-220821V327
resetprop -n ro.vendor_dlkm.build.version.incremental GH-GL-220821V327
resetprop -n ro.system_ext.build.version.incremental GH-GL-220821V327
resetprop -n ro.build.version.incremental GH-GL-220821V327
resetprop -n ro.vendor.build.version.incremental GH-GL-220821V327
resetprop -n ro.odm.build.id "QP1A.190711.020"
resetprop -n ro.product.build.id "QP1A.190711.020"
resetprop -n ro.bootimage.build.id "QP1A.190711.020"
resetprop -n ro.system_ext.build.id "QP1A.190711.020"
resetprop -n ro.vendor_dlkm.build.id "QP1A.190711.020"
resetprop -n ro.build.id "QP1A.190711.020"
resetprop -n ro.system.build.id "QP1A.190711.020"
resetprop -n ro.vendor.build.id "QP1A.190711.020"
resetprop -n ro.system.build.date "Sun Aug 21 18:00:09 CST 2022"
resetprop -n ro.bootimage.build.date "Sun Aug 21 18:00:09 CST 2022"
resetprop -n ro.product.build.date "Sun Aug 21 18:00:09 CST 2022"
resetprop -n ro.vendor_dlkm.build.date "Sun Aug 21 18:00:09 CST 2022"
resetprop -n ro.system_ext.build.date "Sun Aug 21 18:00:09 CST 2022"
resetprop -n ro.odm.build.date "Sun Aug 21 18:00:09 CST 2022"
resetprop -n ro.build.date "Sun Aug 21 18:00:09 CST 2022"
resetprop -n ro.vendor.build.date "Sun Aug 21 18:00:09 CST 2022"
resetprop -n ro.product.build.date.utc "1661076009"
resetprop -n ro.system_ext.build.date.utc "1661076009"
resetprop -n ro.system.build.date.utc "1661076009"
resetprop -n ro.vendor.build.date.utc "1661076009"
resetprop -n ro.vendor_dlkm.build.date.utc "1661076009"
resetprop -n ro.build.date.utc "1661076009"
resetprop -n ro.bootimage.build.date.utc "1661076009"
resetprop -n ro.odm.build.date.utc "1661076009"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name X657C-GL
resetprop -n ro.product.odm.name X657C-GL
resetprop -n ro.product.vendor.name X657C-GL
resetprop -n ro.product.system.name X657C-GL
resetprop -n ro.product.name X657C-GL
resetprop -n ro.product.bootimage.name X657C-GL
resetprop -n ro.product.vendor_dlkm.name X657C-GL
resetprop -n ro.product.system_ext.name X657C-GL
resetprop -n ro.build.flavor full_x657c_h6117-user
randomStr="full_x657c_h6117-user INFINIX MOBILITY LIMITED QP1A.190711.020 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=8cf22dd7223c
resetprop -n ro.build.host ${randomStr}
randomStr=bc97f1f9
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=PEaLmj
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=ae5966ae8bfc0
randomStr2=97
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=a9
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "GH-GL-220821V327"
resetprop -n ro.build.description "full_x657c_h6117-user 10 QP1A.190711.020 62333 release-keys"
resetprop -n ro.build.product.backup "x657c_h6117"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "buildsrv-ci"
resetprop -n ro.build.host "buildsrv-184"
resetprop -n ro.lmk.kill_heaviest_task "false"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2022-08-01
