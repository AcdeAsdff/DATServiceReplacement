strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Redmi 6A"
resetprop -n ro.product.vendor.model "Redmi 6A"
resetprop -n ro.product.vendor_dlkm.marketname "Redmi 6A"
resetprop -n ro.product.product.marketname "Redmi 6A"
resetprop -n ro.product.system.marketname "Redmi 6A"
resetprop -n ro.product.odm_dlkm.marketname "Redmi 6A"
resetprop -n ro.product.system_ext.marketname "Redmi 6A"
resetprop -n ro.product.odm_dlkm.model "Redmi 6A"
resetprop -n ro.product.system.model "Redmi 6A"
resetprop -n ro.product.system_ext.model "Redmi 6A"
resetprop -n ro.product.vendor_dlkm.model "Redmi 6A"
resetprop -n bluetooth.device.default_name "Redmi 6A"
resetprop -n ro.product.bootimage.model "Redmi 6A"
resetprop -n ro.product.vendor.marketname "Redmi 6A"
resetprop -n ro.product.marketname "Redmi 6A"
resetprop -n ro.product.odm.model "Redmi 6A"
resetprop -n ro.product.model "Redmi 6A"
resetprop -n ro.product.product.model "Redmi 6A"
resetprop -n ro.product.odm.marketname "Redmi 6A"
resetprop -n ro.product.vendor.manufacturer "Xiaomi"
resetprop -n ro.product.product.manufacturer "Xiaomi"
resetprop -n ro.product.bootimage.manufacturer "Xiaomi"
resetprop -n ro.product.manufacturer "Xiaomi"
resetprop -n ro.product.odm.manufacturer "Xiaomi"
resetprop -n ro.product.system.manufacturer "Xiaomi"
resetprop -n ro.product.system_ext.manufacturer "Xiaomi"
resetprop -n ro.product.vendor_dlkm.manufacturer "Xiaomi"
resetprop -n ro.product.vendor.brand "xiaomi"
resetprop -n ro.product.product.brand "xiaomi"
resetprop -n ro.product.vendor_dlkm.brand "xiaomi"
resetprop -n ro.product.system.brand "xiaomi"
resetprop -n ro.product.bootimage.brand "xiaomi"
resetprop -n ro.product.system_ext.brand "xiaomi"
resetprop -n ro.product.odm.brand "xiaomi"
resetprop -n ro.product.odm_dlkm.brand "xiaomi"
resetprop -n ro.product.brand "xiaomi"
resetprop -n ro.vendor_dlkm.build.fingerprint "xiaomi/cactus/cactus:9/PPR1.180610.011/V12.0.2.0.PCBCNXM:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "xiaomi/cactus/cactus:9/PPR1.180610.011/V12.0.2.0.PCBCNXM:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "xiaomi/cactus/cactus:9/PPR1.180610.011/V12.0.2.0.PCBCNXM:user/release-keys"
resetprop -n ro.odm.build.fingerprint "xiaomi/cactus/cactus:9/PPR1.180610.011/V12.0.2.0.PCBCNXM:user/release-keys"
resetprop -n ro.system.build.fingerprint "xiaomi/cactus/cactus:9/PPR1.180610.011/V12.0.2.0.PCBCNXM:user/release-keys"
resetprop -n ro.build.fingerprint "xiaomi/cactus/cactus:9/PPR1.180610.011/V12.0.2.0.PCBCNXM:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "xiaomi/cactus/cactus:9/PPR1.180610.011/V12.0.2.0.PCBCNXM:user/release-keys"
resetprop -n ro.product.build.fingerprint "xiaomi/cactus/cactus:9/PPR1.180610.011/V12.0.2.0.PCBCNXM:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "xiaomi/cactus/cactus:9/PPR1.180610.011/V12.0.2.0.PCBCNXM:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=2e0937cfda
resetprop -n ro.system.build.version.incremental V12.0.2.0.PCBCNXM
resetprop -n ro.bootimage.build.version.incremental V12.0.2.0.PCBCNXM
resetprop -n ro.product.build.version.incremental V12.0.2.0.PCBCNXM
resetprop -n ro.odm.build.version.incremental V12.0.2.0.PCBCNXM
resetprop -n ro.vendor_dlkm.build.version.incremental V12.0.2.0.PCBCNXM
resetprop -n ro.system_ext.build.version.incremental V12.0.2.0.PCBCNXM
resetprop -n ro.build.version.incremental V12.0.2.0.PCBCNXM
resetprop -n ro.vendor.build.version.incremental V12.0.2.0.PCBCNXM
resetprop -n ro.odm.build.id "PPR1.180610.011"
resetprop -n ro.product.build.id "PPR1.180610.011"
resetprop -n ro.bootimage.build.id "PPR1.180610.011"
resetprop -n ro.system_ext.build.id "PPR1.180610.011"
resetprop -n ro.vendor_dlkm.build.id "PPR1.180610.011"
resetprop -n ro.build.id "PPR1.180610.011"
resetprop -n ro.system.build.id "PPR1.180610.011"
resetprop -n ro.vendor.build.id "PPR1.180610.011"
resetprop -n ro.system.build.date "Thu Jun 17 23:07:49 CST 2021"
resetprop -n ro.bootimage.build.date "Thu Jun 17 23:07:49 CST 2021"
resetprop -n ro.product.build.date "Thu Jun 17 23:07:49 CST 2021"
resetprop -n ro.vendor_dlkm.build.date "Thu Jun 17 23:07:49 CST 2021"
resetprop -n ro.system_ext.build.date "Thu Jun 17 23:07:49 CST 2021"
resetprop -n ro.odm.build.date "Thu Jun 17 23:07:49 CST 2021"
resetprop -n ro.build.date "Thu Jun 17 23:07:49 CST 2021"
resetprop -n ro.vendor.build.date "Thu Jun 17 23:07:49 CST 2021"
resetprop -n ro.product.build.date.utc "1623942469"
resetprop -n ro.system_ext.build.date.utc "1623942469"
resetprop -n ro.system.build.date.utc "1623942469"
resetprop -n ro.vendor.build.date.utc "1623942469"
resetprop -n ro.vendor_dlkm.build.date.utc "1623942469"
resetprop -n ro.build.date.utc "1623942469"
resetprop -n ro.bootimage.build.date.utc "1623942469"
resetprop -n ro.odm.build.date.utc "1623942469"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name cactus
resetprop -n ro.product.odm.name cactus
resetprop -n ro.product.vendor.name cactus
resetprop -n ro.product.system.name cactus
resetprop -n ro.product.name cactus
resetprop -n ro.product.bootimage.name cactus
resetprop -n ro.product.vendor_dlkm.name cactus
resetprop -n ro.product.system_ext.name cactus
resetprop -n ro.build.flavor cactus-user
randomStr="cactus-user Xiaomi PPR1.180610.011 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=bd1a8da5ac65
resetprop -n ro.build.host ${randomStr}
randomStr=7fb52b1f
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=lLxKRj
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=359c50374a01b
randomStr2=0d
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=4b
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "V12.0.2.0.PCBCNXM"
resetprop -n ro.build.description "cactus-user 9 PPR1.180610.011 V12.0.2.0.PCBCNXM release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "builder"
resetprop -n ro.build.host "c5-miui-ota-bd132.bj"
resetprop -n ro.build.product.backup "cactus"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.fota.oem "Xiaomi"
resetprop -n ro.mi.development "false"
resetprop -n ro.miui.version.code_time "1560528000"
resetprop -n ro.miui.ui.version.code "10"
resetprop -n ro.miui.ui.version.name "V12"
resetprop -n ro.miui.has_security_keyboard "1"
resetprop -n ro.miui.support_miui_ime_bottom "1"
resetprop -n ro.miui.remove_uri_80_flag "1"
resetprop -n ro.miui.ui.fonttype "mipro"
resetprop -n ro.miui.ui.font.theme_apply "true"
resetprop -n sys.miui.shutdown.waittime "500"
resetprop -n ro.com.google.clientidbase "android-xiaomi"
resetprop -n ro.miui.has_real_blur "1"
resetprop -n ro.miui.has_handy_mode_sf "1"
resetprop -n ro.expect.recovery_id "0x1ee39217df5b918dca81f1d2051d1e63454d347a000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2021-03-01
