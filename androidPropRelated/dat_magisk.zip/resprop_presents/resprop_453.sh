strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "itel L5502"
resetprop -n ro.product.vendor.model "itel L5502"
resetprop -n ro.product.vendor_dlkm.marketname "itel L5502"
resetprop -n ro.product.product.marketname "itel L5502"
resetprop -n ro.product.system.marketname "itel L5502"
resetprop -n ro.product.odm_dlkm.marketname "itel L5502"
resetprop -n ro.product.system_ext.marketname "itel L5502"
resetprop -n ro.product.odm_dlkm.model "itel L5502"
resetprop -n ro.product.system.model "itel L5502"
resetprop -n ro.product.system_ext.model "itel L5502"
resetprop -n ro.product.vendor_dlkm.model "itel L5502"
resetprop -n bluetooth.device.default_name "itel L5502"
resetprop -n ro.product.bootimage.model "itel L5502"
resetprop -n ro.product.vendor.marketname "itel L5502"
resetprop -n ro.product.marketname "itel L5502"
resetprop -n ro.product.odm.model "itel L5502"
resetprop -n ro.product.model "itel L5502"
resetprop -n ro.product.product.model "itel L5502"
resetprop -n ro.product.odm.marketname "itel L5502"
resetprop -n ro.product.vendor.manufacturer "ITEL MOBILE LIMITED"
resetprop -n ro.product.product.manufacturer "ITEL MOBILE LIMITED"
resetprop -n ro.product.bootimage.manufacturer "ITEL MOBILE LIMITED"
resetprop -n ro.product.manufacturer "ITEL MOBILE LIMITED"
resetprop -n ro.product.odm.manufacturer "ITEL MOBILE LIMITED"
resetprop -n ro.product.system.manufacturer "ITEL MOBILE LIMITED"
resetprop -n ro.product.system_ext.manufacturer "ITEL MOBILE LIMITED"
resetprop -n ro.product.vendor_dlkm.manufacturer "ITEL MOBILE LIMITED"
resetprop -n ro.product.vendor.brand "Itel"
resetprop -n ro.product.product.brand "Itel"
resetprop -n ro.product.vendor_dlkm.brand "Itel"
resetprop -n ro.product.system.brand "Itel"
resetprop -n ro.product.bootimage.brand "Itel"
resetprop -n ro.product.system_ext.brand "Itel"
resetprop -n ro.product.odm.brand "Itel"
resetprop -n ro.product.odm_dlkm.brand "Itel"
resetprop -n ro.product.brand "Itel"
resetprop -n ro.vendor_dlkm.build.fingerprint "Itel/SU375/itel-L5502:8.1.0/OPM2.171019.012/IN-V007-20181023:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Itel/SU375/itel-L5502:8.1.0/OPM2.171019.012/IN-V007-20181023:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Itel/SU375/itel-L5502:8.1.0/OPM2.171019.012/IN-V007-20181023:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Itel/SU375/itel-L5502:8.1.0/OPM2.171019.012/IN-V007-20181023:user/release-keys"
resetprop -n ro.system.build.fingerprint "Itel/SU375/itel-L5502:8.1.0/OPM2.171019.012/IN-V007-20181023:user/release-keys"
resetprop -n ro.build.fingerprint "Itel/SU375/itel-L5502:8.1.0/OPM2.171019.012/IN-V007-20181023:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Itel/SU375/itel-L5502:8.1.0/OPM2.171019.012/IN-V007-20181023:user/release-keys"
resetprop -n ro.product.build.fingerprint "Itel/SU375/itel-L5502:8.1.0/OPM2.171019.012/IN-V007-20181023:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Itel/SU375/itel-L5502:8.1.0/OPM2.171019.012/IN-V007-20181023:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=66862ae67b
resetprop -n ro.system.build.version.incremental IN-V007-20181023
resetprop -n ro.bootimage.build.version.incremental IN-V007-20181023
resetprop -n ro.product.build.version.incremental IN-V007-20181023
resetprop -n ro.odm.build.version.incremental IN-V007-20181023
resetprop -n ro.vendor_dlkm.build.version.incremental IN-V007-20181023
resetprop -n ro.system_ext.build.version.incremental IN-V007-20181023
resetprop -n ro.build.version.incremental IN-V007-20181023
resetprop -n ro.vendor.build.version.incremental IN-V007-20181023
resetprop -n ro.odm.build.id "OPM2.171019.012"
resetprop -n ro.product.build.id "OPM2.171019.012"
resetprop -n ro.bootimage.build.id "OPM2.171019.012"
resetprop -n ro.system_ext.build.id "OPM2.171019.012"
resetprop -n ro.vendor_dlkm.build.id "OPM2.171019.012"
resetprop -n ro.build.id "OPM2.171019.012"
resetprop -n ro.system.build.id "OPM2.171019.012"
resetprop -n ro.vendor.build.id "OPM2.171019.012"
resetprop -n ro.system.build.date "2018年 10月 23日 星期二 18:43:17 CST"
resetprop -n ro.bootimage.build.date "2018年 10月 23日 星期二 18:43:17 CST"
resetprop -n ro.product.build.date "2018年 10月 23日 星期二 18:43:17 CST"
resetprop -n ro.vendor_dlkm.build.date "2018年 10月 23日 星期二 18:43:17 CST"
resetprop -n ro.system_ext.build.date "2018年 10月 23日 星期二 18:43:17 CST"
resetprop -n ro.odm.build.date "2018年 10月 23日 星期二 18:43:17 CST"
resetprop -n ro.build.date "2018年 10月 23日 星期二 18:43:17 CST"
resetprop -n ro.vendor.build.date "2018年 10月 23日 星期二 18:43:17 CST"
resetprop -n ro.product.build.date.utc "1540291397"
resetprop -n ro.system_ext.build.date.utc "1540291397"
resetprop -n ro.system.build.date.utc "1540291397"
resetprop -n ro.vendor.build.date.utc "1540291397"
resetprop -n ro.vendor_dlkm.build.date.utc "1540291397"
resetprop -n ro.build.date.utc "1540291397"
resetprop -n ro.bootimage.build.date.utc "1540291397"
resetprop -n ro.odm.build.date.utc "1540291397"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name SU375
resetprop -n ro.product.odm.name SU375
resetprop -n ro.product.vendor.name SU375
resetprop -n ro.product.system.name SU375
resetprop -n ro.product.name SU375
resetprop -n ro.product.bootimage.name SU375
resetprop -n ro.product.vendor_dlkm.name SU375
resetprop -n ro.product.system_ext.name SU375
resetprop -n ro.build.flavor oversea
randomStr="oversea ITEL MOBILE LIMITED OPM2.171019.012 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=c3691edf65ce
resetprop -n ro.build.host ${randomStr}
randomStr=da4e4108
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=cmrNVV
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=c3034c815250d
randomStr2=da
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=1f
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "IN-V007-20181023"
resetprop -n ro.build.description "L5502-SU375-8.1-IN-V007-20181023"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "server126"
resetprop -n ro.build.host "server126"
resetprop -n ro.build.product.backup "itel L5502"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.com.google.acsa "true"
resetprop -n ro.expect.recovery_id "0x7ae8c0f687dae572e9dda819b09502e55933c16f000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-10-05
