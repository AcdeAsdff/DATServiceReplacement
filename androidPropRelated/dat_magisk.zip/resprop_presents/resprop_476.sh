strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "iris51"
resetprop -n ro.product.vendor.model "iris51"
resetprop -n ro.product.vendor_dlkm.marketname "iris51"
resetprop -n ro.product.product.marketname "iris51"
resetprop -n ro.product.system.marketname "iris51"
resetprop -n ro.product.odm_dlkm.marketname "iris51"
resetprop -n ro.product.system_ext.marketname "iris51"
resetprop -n ro.product.odm_dlkm.model "iris51"
resetprop -n ro.product.system.model "iris51"
resetprop -n ro.product.system_ext.model "iris51"
resetprop -n ro.product.vendor_dlkm.model "iris51"
resetprop -n bluetooth.device.default_name "iris51"
resetprop -n ro.product.bootimage.model "iris51"
resetprop -n ro.product.vendor.marketname "iris51"
resetprop -n ro.product.marketname "iris51"
resetprop -n ro.product.odm.model "iris51"
resetprop -n ro.product.model "iris51"
resetprop -n ro.product.product.model "iris51"
resetprop -n ro.product.odm.marketname "iris51"
resetprop -n ro.product.vendor.manufacturer "LAVA"
resetprop -n ro.product.product.manufacturer "LAVA"
resetprop -n ro.product.bootimage.manufacturer "LAVA"
resetprop -n ro.product.manufacturer "LAVA"
resetprop -n ro.product.odm.manufacturer "LAVA"
resetprop -n ro.product.system.manufacturer "LAVA"
resetprop -n ro.product.system_ext.manufacturer "LAVA"
resetprop -n ro.product.vendor_dlkm.manufacturer "LAVA"
resetprop -n ro.product.vendor.brand "LAVA"
resetprop -n ro.product.product.brand "LAVA"
resetprop -n ro.product.vendor_dlkm.brand "LAVA"
resetprop -n ro.product.system.brand "LAVA"
resetprop -n ro.product.bootimage.brand "LAVA"
resetprop -n ro.product.system_ext.brand "LAVA"
resetprop -n ro.product.odm.brand "LAVA"
resetprop -n ro.product.odm_dlkm.brand "LAVA"
resetprop -n ro.product.brand "LAVA"
resetprop -n ro.vendor_dlkm.build.fingerprint "LAVA/iris51/iris51:8.1.0/OPM2.171019.012/44418:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "LAVA/iris51/iris51:8.1.0/OPM2.171019.012/44418:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "LAVA/iris51/iris51:8.1.0/OPM2.171019.012/44418:user/release-keys"
resetprop -n ro.odm.build.fingerprint "LAVA/iris51/iris51:8.1.0/OPM2.171019.012/44418:user/release-keys"
resetprop -n ro.system.build.fingerprint "LAVA/iris51/iris51:8.1.0/OPM2.171019.012/44418:user/release-keys"
resetprop -n ro.build.fingerprint "LAVA/iris51/iris51:8.1.0/OPM2.171019.012/44418:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "LAVA/iris51/iris51:8.1.0/OPM2.171019.012/44418:user/release-keys"
resetprop -n ro.product.build.fingerprint "LAVA/iris51/iris51:8.1.0/OPM2.171019.012/44418:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "LAVA/iris51/iris51:8.1.0/OPM2.171019.012/44418:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=b88a38d14e
resetprop -n ro.system.build.version.incremental 44418
resetprop -n ro.bootimage.build.version.incremental 44418
resetprop -n ro.product.build.version.incremental 44418
resetprop -n ro.odm.build.version.incremental 44418
resetprop -n ro.vendor_dlkm.build.version.incremental 44418
resetprop -n ro.system_ext.build.version.incremental 44418
resetprop -n ro.build.version.incremental 44418
resetprop -n ro.vendor.build.version.incremental 44418
resetprop -n ro.odm.build.id "OPM2.171019.012"
resetprop -n ro.product.build.id "OPM2.171019.012"
resetprop -n ro.bootimage.build.id "OPM2.171019.012"
resetprop -n ro.system_ext.build.id "OPM2.171019.012"
resetprop -n ro.vendor_dlkm.build.id "OPM2.171019.012"
resetprop -n ro.build.id "OPM2.171019.012"
resetprop -n ro.system.build.id "OPM2.171019.012"
resetprop -n ro.vendor.build.id "OPM2.171019.012"
resetprop -n ro.system.build.date "Thu Nov  1 18:02:18 CST 2018"
resetprop -n ro.bootimage.build.date "Thu Nov  1 18:02:18 CST 2018"
resetprop -n ro.product.build.date "Thu Nov  1 18:02:18 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Thu Nov  1 18:02:18 CST 2018"
resetprop -n ro.system_ext.build.date "Thu Nov  1 18:02:18 CST 2018"
resetprop -n ro.odm.build.date "Thu Nov  1 18:02:18 CST 2018"
resetprop -n ro.build.date "Thu Nov  1 18:02:18 CST 2018"
resetprop -n ro.vendor.build.date "Thu Nov  1 18:02:18 CST 2018"
resetprop -n ro.product.build.date.utc "1541066538"
resetprop -n ro.system_ext.build.date.utc "1541066538"
resetprop -n ro.system.build.date.utc "1541066538"
resetprop -n ro.vendor.build.date.utc "1541066538"
resetprop -n ro.vendor_dlkm.build.date.utc "1541066538"
resetprop -n ro.build.date.utc "1541066538"
resetprop -n ro.bootimage.build.date.utc "1541066538"
resetprop -n ro.odm.build.date.utc "1541066538"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name iris51
resetprop -n ro.product.odm.name iris51
resetprop -n ro.product.vendor.name iris51
resetprop -n ro.product.system.name iris51
resetprop -n ro.product.name iris51
resetprop -n ro.product.bootimage.name iris51
resetprop -n ro.product.vendor_dlkm.name iris51
resetprop -n ro.product.system_ext.name iris51
resetprop -n ro.build.flavor cm05_64v8_native-user
randomStr="cm05_64v8_native-user LAVA OPM2.171019.012 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=a8618104733a
resetprop -n ro.build.host ${randomStr}
randomStr=f73e4955
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=XsRWYF
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=99de3e409f856
randomStr2=6e
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=5a
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "44418"
resetprop -n ro.build.description "cm05_64v8_native-user 8.1.0 OPM2.171019.012 44418 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "lvhaiqing"
resetprop -n ro.build.host "caron"
resetprop -n ro.build.product.backup "cm05_64v8"
resetprop -n ro.build.characteristics "default"
resetprop -n media.settings.xml  " vendor/etc/media_profiles_turnkey.xml"
resetprop -n ro.expect.recovery_id "0x64d8ab9e81c49bc05a664f128f016fbde368d754000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-11-05
