strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "sdk_gwear_arm64"
resetprop -n ro.product.vendor.model "sdk_gwear_arm64"
resetprop -n ro.product.vendor_dlkm.marketname "sdk_gwear_arm64"
resetprop -n ro.product.product.marketname "sdk_gwear_arm64"
resetprop -n ro.product.system.marketname "sdk_gwear_arm64"
resetprop -n ro.product.odm_dlkm.marketname "sdk_gwear_arm64"
resetprop -n ro.product.system_ext.marketname "sdk_gwear_arm64"
resetprop -n ro.product.odm_dlkm.model "sdk_gwear_arm64"
resetprop -n ro.product.system.model "sdk_gwear_arm64"
resetprop -n ro.product.system_ext.model "sdk_gwear_arm64"
resetprop -n ro.product.vendor_dlkm.model "sdk_gwear_arm64"
resetprop -n bluetooth.device.default_name "sdk_gwear_arm64"
resetprop -n ro.product.bootimage.model "sdk_gwear_arm64"
resetprop -n ro.product.vendor.marketname "sdk_gwear_arm64"
resetprop -n ro.product.marketname "sdk_gwear_arm64"
resetprop -n ro.product.odm.model "sdk_gwear_arm64"
resetprop -n ro.product.model "sdk_gwear_arm64"
resetprop -n ro.product.product.model "sdk_gwear_arm64"
resetprop -n ro.product.odm.marketname "sdk_gwear_arm64"
resetprop -n ro.product.vendor.manufacturer "unknown"
resetprop -n ro.product.product.manufacturer "unknown"
resetprop -n ro.product.bootimage.manufacturer "unknown"
resetprop -n ro.product.manufacturer "unknown"
resetprop -n ro.product.odm.manufacturer "unknown"
resetprop -n ro.product.system.manufacturer "unknown"
resetprop -n ro.product.system_ext.manufacturer "unknown"
resetprop -n ro.product.vendor_dlkm.manufacturer "unknown"
resetprop -n ro.product.vendor.brand "google"
resetprop -n ro.product.product.brand "google"
resetprop -n ro.product.vendor_dlkm.brand "google"
resetprop -n ro.product.system.brand "google"
resetprop -n ro.product.bootimage.brand "google"
resetprop -n ro.product.system_ext.brand "google"
resetprop -n ro.product.odm.brand "google"
resetprop -n ro.product.odm_dlkm.brand "google"
resetprop -n ro.product.brand "google"
resetprop -n ro.vendor_dlkm.build.fingerprint "google/sdk_gwear_arm64/emulator_arm64:11/RWD7.220207.002/8175913:userdebug/dev-keys"
resetprop -n ro.bootimage.build.fingerprint "google/sdk_gwear_arm64/emulator_arm64:11/RWD7.220207.002/8175913:userdebug/dev-keys"
resetprop -n ro.vendor.build.fingerprint "google/sdk_gwear_arm64/emulator_arm64:11/RWD7.220207.002/8175913:userdebug/dev-keys"
resetprop -n ro.odm.build.fingerprint "google/sdk_gwear_arm64/emulator_arm64:11/RWD7.220207.002/8175913:userdebug/dev-keys"
resetprop -n ro.system.build.fingerprint "google/sdk_gwear_arm64/emulator_arm64:11/RWD7.220207.002/8175913:userdebug/dev-keys"
resetprop -n ro.build.fingerprint "google/sdk_gwear_arm64/emulator_arm64:11/RWD7.220207.002/8175913:userdebug/dev-keys"
resetprop -n ro.system_ext.build.fingerprint "google/sdk_gwear_arm64/emulator_arm64:11/RWD7.220207.002/8175913:userdebug/dev-keys"
resetprop -n ro.product.build.fingerprint "google/sdk_gwear_arm64/emulator_arm64:11/RWD7.220207.002/8175913:userdebug/dev-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "google/sdk_gwear_arm64/emulator_arm64:11/RWD7.220207.002/8175913:userdebug/dev-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=d49a157601
resetprop -n ro.system.build.version.incremental 8175913
resetprop -n ro.bootimage.build.version.incremental 8175913
resetprop -n ro.product.build.version.incremental 8175913
resetprop -n ro.odm.build.version.incremental 8175913
resetprop -n ro.vendor_dlkm.build.version.incremental 8175913
resetprop -n ro.system_ext.build.version.incremental 8175913
resetprop -n ro.build.version.incremental 8175913
resetprop -n ro.vendor.build.version.incremental 8175913
resetprop -n ro.odm.build.id "RWD7.220207.002"
resetprop -n ro.product.build.id "RWD7.220207.002"
resetprop -n ro.bootimage.build.id "RWD7.220207.002"
resetprop -n ro.system_ext.build.id "RWD7.220207.002"
resetprop -n ro.vendor_dlkm.build.id "RWD7.220207.002"
resetprop -n ro.build.id "RWD7.220207.002"
resetprop -n ro.system.build.id "RWD7.220207.002"
resetprop -n ro.vendor.build.id "RWD7.220207.002"
resetprop -n ro.system.build.date "Fri Feb 11 19:37:17 UTC 2022"
resetprop -n ro.bootimage.build.date "Fri Feb 11 19:37:17 UTC 2022"
resetprop -n ro.product.build.date "Fri Feb 11 19:37:17 UTC 2022"
resetprop -n ro.vendor_dlkm.build.date "Fri Feb 11 19:37:17 UTC 2022"
resetprop -n ro.system_ext.build.date "Fri Feb 11 19:37:17 UTC 2022"
resetprop -n ro.odm.build.date "Fri Feb 11 19:37:17 UTC 2022"
resetprop -n ro.build.date "Fri Feb 11 19:37:17 UTC 2022"
resetprop -n ro.vendor.build.date "Fri Feb 11 19:37:17 UTC 2022"
resetprop -n ro.product.build.date.utc "1644608237"
resetprop -n ro.system_ext.build.date.utc "1644608237"
resetprop -n ro.system.build.date.utc "1644608237"
resetprop -n ro.vendor.build.date.utc "1644608237"
resetprop -n ro.vendor_dlkm.build.date.utc "1644608237"
resetprop -n ro.build.date.utc "1644608237"
resetprop -n ro.bootimage.build.date.utc "1644608237"
resetprop -n ro.odm.build.date.utc "1644608237"
resetprop -n ro.product.build.tags "dev-keys"
resetprop -n ro.build.tags "dev-keys"
resetprop -n ro.odm.build.tags "dev-keys"
resetprop -n ro.bootimage.build.tags "dev-keys"
resetprop -n ro.vendor_dlkm.build.tags "dev-keys"
resetprop -n ro.system_ext.build.tags "dev-keys"
resetprop -n ro.vendor.build.tags "dev-keys"
resetprop -n ro.system.build.tags "dev-keys"
resetprop -n ro.system.build.type "userdebug"
resetprop -n ro.system_ext.build.type "userdebug"
resetprop -n ro.vendor_dlkm.build.type "userdebug"
resetprop -n ro.bootimage.build.type "userdebug"
resetprop -n ro.product.build.type "userdebug"
resetprop -n ro.odm.build.type "userdebug"
resetprop -n ro.vendor.build.type "userdebug"
resetprop -n ro.product.product.name sdk_gwear_arm64
resetprop -n ro.product.odm.name sdk_gwear_arm64
resetprop -n ro.product.vendor.name sdk_gwear_arm64
resetprop -n ro.product.system.name sdk_gwear_arm64
resetprop -n ro.product.name sdk_gwear_arm64
resetprop -n ro.product.bootimage.name sdk_gwear_arm64
resetprop -n ro.product.vendor_dlkm.name sdk_gwear_arm64
resetprop -n ro.product.system_ext.name sdk_gwear_arm64
resetprop -n ro.build.flavor sdk_gwear_arm64-userdebug
randomStr="sdk_gwear_arm64-userdebug unknown RWD7.220207.002 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=4d4d643530a3
resetprop -n ro.build.host ${randomStr}
randomStr=00baefa0
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=kwCLBE
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=f283b0f7ab24f
randomStr2=b7
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=93
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "8175913"
resetprop -n ro.build.description "sdk_gwear_arm64-userdebug 11 RWD7.220207.002 8175913 dev-keys"
resetprop -n ro.build.product.backup "emulator_arm64"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "android-build"
resetprop -n ro.build.host "abfarm777"
resetprop -n ro.lmk.critical_upgrade "true"
resetprop -n ro.lmk.upgrade_pressure "40"
resetprop -n ro.lmk.downgrade_pressure "60"
resetprop -n ro.lmk.kill_heaviest_task "false"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2022-03-01
