strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "R19"
resetprop -n ro.product.vendor.model "R19"
resetprop -n ro.product.vendor_dlkm.marketname "R19"
resetprop -n ro.product.product.marketname "R19"
resetprop -n ro.product.system.marketname "R19"
resetprop -n ro.product.odm_dlkm.marketname "R19"
resetprop -n ro.product.system_ext.marketname "R19"
resetprop -n ro.product.odm_dlkm.model "R19"
resetprop -n ro.product.system.model "R19"
resetprop -n ro.product.system_ext.model "R19"
resetprop -n ro.product.vendor_dlkm.model "R19"
resetprop -n bluetooth.device.default_name "R19"
resetprop -n ro.product.bootimage.model "R19"
resetprop -n ro.product.vendor.marketname "R19"
resetprop -n ro.product.marketname "R19"
resetprop -n ro.product.odm.model "R19"
resetprop -n ro.product.model "R19"
resetprop -n ro.product.product.model "R19"
resetprop -n ro.product.odm.marketname "R19"
resetprop -n ro.product.vendor.manufacturer "CUBOT"
resetprop -n ro.product.product.manufacturer "CUBOT"
resetprop -n ro.product.bootimage.manufacturer "CUBOT"
resetprop -n ro.product.manufacturer "CUBOT"
resetprop -n ro.product.odm.manufacturer "CUBOT"
resetprop -n ro.product.system.manufacturer "CUBOT"
resetprop -n ro.product.system_ext.manufacturer "CUBOT"
resetprop -n ro.product.vendor_dlkm.manufacturer "CUBOT"
resetprop -n ro.product.vendor.brand "CUBOT"
resetprop -n ro.product.product.brand "CUBOT"
resetprop -n ro.product.vendor_dlkm.brand "CUBOT"
resetprop -n ro.product.system.brand "CUBOT"
resetprop -n ro.product.bootimage.brand "CUBOT"
resetprop -n ro.product.system_ext.brand "CUBOT"
resetprop -n ro.product.odm.brand "CUBOT"
resetprop -n ro.product.odm_dlkm.brand "CUBOT"
resetprop -n ro.product.brand "CUBOT"
resetprop -n ro.vendor_dlkm.build.fingerprint "CUBOT/R19_EEA/R19:9/P00610/1565594044:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "CUBOT/R19_EEA/R19:9/P00610/1565594044:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "CUBOT/R19_EEA/R19:9/P00610/1565594044:user/release-keys"
resetprop -n ro.odm.build.fingerprint "CUBOT/R19_EEA/R19:9/P00610/1565594044:user/release-keys"
resetprop -n ro.system.build.fingerprint "CUBOT/R19_EEA/R19:9/P00610/1565594044:user/release-keys"
resetprop -n ro.build.fingerprint "CUBOT/R19_EEA/R19:9/P00610/1565594044:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "CUBOT/R19_EEA/R19:9/P00610/1565594044:user/release-keys"
resetprop -n ro.product.build.fingerprint "CUBOT/R19_EEA/R19:9/P00610/1565594044:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "CUBOT/R19_EEA/R19:9/P00610/1565594044:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=6513fb99ae
resetprop -n ro.system.build.version.incremental 1565594044
resetprop -n ro.bootimage.build.version.incremental 1565594044
resetprop -n ro.product.build.version.incremental 1565594044
resetprop -n ro.odm.build.version.incremental 1565594044
resetprop -n ro.vendor_dlkm.build.version.incremental 1565594044
resetprop -n ro.system_ext.build.version.incremental 1565594044
resetprop -n ro.build.version.incremental 1565594044
resetprop -n ro.vendor.build.version.incremental 1565594044
resetprop -n ro.odm.build.id "P00610"
resetprop -n ro.product.build.id "P00610"
resetprop -n ro.bootimage.build.id "P00610"
resetprop -n ro.system_ext.build.id "P00610"
resetprop -n ro.vendor_dlkm.build.id "P00610"
resetprop -n ro.build.id "P00610"
resetprop -n ro.system.build.id "P00610"
resetprop -n ro.vendor.build.id "P00610"
resetprop -n ro.system.build.date "Mon Aug 12 15:13:12 CST 2019"
resetprop -n ro.bootimage.build.date "Mon Aug 12 15:13:12 CST 2019"
resetprop -n ro.product.build.date "Mon Aug 12 15:13:12 CST 2019"
resetprop -n ro.vendor_dlkm.build.date "Mon Aug 12 15:13:12 CST 2019"
resetprop -n ro.system_ext.build.date "Mon Aug 12 15:13:12 CST 2019"
resetprop -n ro.odm.build.date "Mon Aug 12 15:13:12 CST 2019"
resetprop -n ro.build.date "Mon Aug 12 15:13:12 CST 2019"
resetprop -n ro.vendor.build.date "Mon Aug 12 15:13:12 CST 2019"
resetprop -n ro.product.build.date.utc "1565593992"
resetprop -n ro.system_ext.build.date.utc "1565593992"
resetprop -n ro.system.build.date.utc "1565593992"
resetprop -n ro.vendor.build.date.utc "1565593992"
resetprop -n ro.vendor_dlkm.build.date.utc "1565593992"
resetprop -n ro.build.date.utc "1565593992"
resetprop -n ro.bootimage.build.date.utc "1565593992"
resetprop -n ro.odm.build.date.utc "1565593992"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name R19_EEA
resetprop -n ro.product.odm.name R19_EEA
resetprop -n ro.product.vendor.name R19_EEA
resetprop -n ro.product.system.name R19_EEA
resetprop -n ro.product.name R19_EEA
resetprop -n ro.product.bootimage.name R19_EEA
resetprop -n ro.product.vendor_dlkm.name R19_EEA
resetprop -n ro.product.system_ext.name R19_EEA
resetprop -n ro.build.flavor full_e557_cq_9052c_61_p0-user
randomStr="full_e557_cq_9052c_61_p0-user CUBOT P00610 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=7e737f1b2791
resetprop -n ro.build.host ${randomStr}
randomStr=66389aa8
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=OcJuNy
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=346b347e163d8
randomStr2=29
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=36
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1565594044"
resetprop -n ro.build.description "R19_EEA-user 9 P00610 1565594044 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "jenkins"
resetprop -n ro.build.host "80-29"
resetprop -n ro.build.product.backup "R19"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mtk_trustkernel_tee_support "1"
resetprop -n ro.mtk_platform "MT6761"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.fota.platform "MT6761_9"
resetprop -n ro.fota.type "phone"
resetprop -n ro.fota.app "5"
resetprop -n ro.fota.battery "30"
resetprop -n ro.fota.oem "odm6761_9"
resetprop -n ro.fota.device "R19"
resetprop -n ro.fota.version "CUBOT_R19_9052C_V05_20190812_20190812-1517"
resetprop -n ro.expect.recovery_id "0xe7265f0afcec7f5983050098f32df4dfec804694000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-07-05
