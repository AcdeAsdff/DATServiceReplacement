strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Z82"
resetprop -n ro.product.vendor.model "Z82"
resetprop -n ro.product.vendor_dlkm.marketname "Z82"
resetprop -n ro.product.product.marketname "Z82"
resetprop -n ro.product.system.marketname "Z82"
resetprop -n ro.product.odm_dlkm.marketname "Z82"
resetprop -n ro.product.system_ext.marketname "Z82"
resetprop -n ro.product.odm_dlkm.model "Z82"
resetprop -n ro.product.system.model "Z82"
resetprop -n ro.product.system_ext.model "Z82"
resetprop -n ro.product.vendor_dlkm.model "Z82"
resetprop -n bluetooth.device.default_name "Z82"
resetprop -n ro.product.bootimage.model "Z82"
resetprop -n ro.product.vendor.marketname "Z82"
resetprop -n ro.product.marketname "Z82"
resetprop -n ro.product.odm.model "Z82"
resetprop -n ro.product.model "Z82"
resetprop -n ro.product.product.model "Z82"
resetprop -n ro.product.odm.marketname "Z82"
resetprop -n ro.product.vendor.manufacturer "LAVA"
resetprop -n ro.product.product.manufacturer "LAVA"
resetprop -n ro.product.bootimage.manufacturer "LAVA"
resetprop -n ro.product.manufacturer "LAVA"
resetprop -n ro.product.odm.manufacturer "LAVA"
resetprop -n ro.product.system.manufacturer "LAVA"
resetprop -n ro.product.system_ext.manufacturer "LAVA"
resetprop -n ro.product.vendor_dlkm.manufacturer "LAVA"
resetprop -n ro.product.vendor.brand "LAVA"
resetprop -n ro.product.product.brand "LAVA"
resetprop -n ro.product.vendor_dlkm.brand "LAVA"
resetprop -n ro.product.system.brand "LAVA"
resetprop -n ro.product.bootimage.brand "LAVA"
resetprop -n ro.product.system_ext.brand "LAVA"
resetprop -n ro.product.odm.brand "LAVA"
resetprop -n ro.product.odm_dlkm.brand "LAVA"
resetprop -n ro.product.brand "LAVA"
resetprop -n ro.vendor_dlkm.build.fingerprint "LAVA/Z82/Z82:9/PPR1.180610.011/1543249592:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "LAVA/Z82/Z82:9/PPR1.180610.011/1543249592:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "LAVA/Z82/Z82:9/PPR1.180610.011/1543249592:user/release-keys"
resetprop -n ro.odm.build.fingerprint "LAVA/Z82/Z82:9/PPR1.180610.011/1543249592:user/release-keys"
resetprop -n ro.system.build.fingerprint "LAVA/Z82/Z82:9/PPR1.180610.011/1543249592:user/release-keys"
resetprop -n ro.build.fingerprint "LAVA/Z82/Z82:9/PPR1.180610.011/1543249592:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "LAVA/Z82/Z82:9/PPR1.180610.011/1543249592:user/release-keys"
resetprop -n ro.product.build.fingerprint "LAVA/Z82/Z82:9/PPR1.180610.011/1543249592:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "LAVA/Z82/Z82:9/PPR1.180610.011/1543249592:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=757b385509
resetprop -n ro.system.build.version.incremental 1543249592
resetprop -n ro.bootimage.build.version.incremental 1543249592
resetprop -n ro.product.build.version.incremental 1543249592
resetprop -n ro.odm.build.version.incremental 1543249592
resetprop -n ro.vendor_dlkm.build.version.incremental 1543249592
resetprop -n ro.system_ext.build.version.incremental 1543249592
resetprop -n ro.build.version.incremental 1543249592
resetprop -n ro.vendor.build.version.incremental 1543249592
resetprop -n ro.odm.build.id "PPR1.180610.011"
resetprop -n ro.product.build.id "PPR1.180610.011"
resetprop -n ro.bootimage.build.id "PPR1.180610.011"
resetprop -n ro.system_ext.build.id "PPR1.180610.011"
resetprop -n ro.vendor_dlkm.build.id "PPR1.180610.011"
resetprop -n ro.build.id "PPR1.180610.011"
resetprop -n ro.system.build.id "PPR1.180610.011"
resetprop -n ro.vendor.build.id "PPR1.180610.011"
resetprop -n ro.system.build.date "Mon Nov 26 16:14:45 UTC 2018"
resetprop -n ro.bootimage.build.date "Mon Nov 26 16:14:45 UTC 2018"
resetprop -n ro.product.build.date "Mon Nov 26 16:14:45 UTC 2018"
resetprop -n ro.vendor_dlkm.build.date "Mon Nov 26 16:14:45 UTC 2018"
resetprop -n ro.system_ext.build.date "Mon Nov 26 16:14:45 UTC 2018"
resetprop -n ro.odm.build.date "Mon Nov 26 16:14:45 UTC 2018"
resetprop -n ro.build.date "Mon Nov 26 16:14:45 UTC 2018"
resetprop -n ro.vendor.build.date "Mon Nov 26 16:14:45 UTC 2018"
resetprop -n ro.product.build.date.utc "1543248885"
resetprop -n ro.system_ext.build.date.utc "1543248885"
resetprop -n ro.system.build.date.utc "1543248885"
resetprop -n ro.vendor.build.date.utc "1543248885"
resetprop -n ro.vendor_dlkm.build.date.utc "1543248885"
resetprop -n ro.build.date.utc "1543248885"
resetprop -n ro.bootimage.build.date.utc "1543248885"
resetprop -n ro.odm.build.date.utc "1543248885"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name Z82
resetprop -n ro.product.odm.name Z82
resetprop -n ro.product.vendor.name Z82
resetprop -n ro.product.system.name Z82
resetprop -n ro.product.name Z82
resetprop -n ro.product.bootimage.name Z82
resetprop -n ro.product.vendor_dlkm.name Z82
resetprop -n ro.product.system_ext.name Z82
resetprop -n ro.build.flavor full_k62v_op66-user
randomStr="full_k62v_op66-user LAVA PPR1.180610.011 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=4afca0856359
resetprop -n ro.build.host ${randomStr}
randomStr=dd7cbaf4
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=YjAuhg
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=cfb2a12e23ca4
randomStr2=26
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=37
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1543249592"
resetprop -n ro.build.description "full_lava6762_op66-user 9 PPR1.180610.011 1543249592 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "lava"
resetprop -n ro.build.host "4f8d1420c710"
resetprop -n ro.build.product.backup "Z82"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.expect.recovery_id "0xcb64d1910afc6ee5a06950053e3997051c0d1489000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-11-05
