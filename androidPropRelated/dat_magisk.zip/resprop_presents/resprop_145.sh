strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "B1-780"
resetprop -n ro.product.vendor.model "B1-780"
resetprop -n ro.product.vendor_dlkm.marketname "B1-780"
resetprop -n ro.product.product.marketname "B1-780"
resetprop -n ro.product.system.marketname "B1-780"
resetprop -n ro.product.odm_dlkm.marketname "B1-780"
resetprop -n ro.product.system_ext.marketname "B1-780"
resetprop -n ro.product.odm_dlkm.model "B1-780"
resetprop -n ro.product.system.model "B1-780"
resetprop -n ro.product.system_ext.model "B1-780"
resetprop -n ro.product.vendor_dlkm.model "B1-780"
resetprop -n bluetooth.device.default_name "B1-780"
resetprop -n ro.product.bootimage.model "B1-780"
resetprop -n ro.product.vendor.marketname "B1-780"
resetprop -n ro.product.marketname "B1-780"
resetprop -n ro.product.odm.model "B1-780"
resetprop -n ro.product.model "B1-780"
resetprop -n ro.product.product.model "B1-780"
resetprop -n ro.product.odm.marketname "B1-780"
resetprop -n ro.product.vendor.manufacturer "Acer"
resetprop -n ro.product.product.manufacturer "Acer"
resetprop -n ro.product.bootimage.manufacturer "Acer"
resetprop -n ro.product.manufacturer "Acer"
resetprop -n ro.product.odm.manufacturer "Acer"
resetprop -n ro.product.system.manufacturer "Acer"
resetprop -n ro.product.system_ext.manufacturer "Acer"
resetprop -n ro.product.vendor_dlkm.manufacturer "Acer"
resetprop -n ro.product.vendor.brand "acer"
resetprop -n ro.product.product.brand "acer"
resetprop -n ro.product.vendor_dlkm.brand "acer"
resetprop -n ro.product.system.brand "acer"
resetprop -n ro.product.bootimage.brand "acer"
resetprop -n ro.product.system_ext.brand "acer"
resetprop -n ro.product.odm.brand "acer"
resetprop -n ro.product.odm_dlkm.brand "acer"
resetprop -n ro.product.brand "acer"
resetprop -n ro.vendor_dlkm.build.fingerprint "acer/b1-780_ww_gen1/acer_barricadewifi:6.0/MRA58K/1481784106:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "acer/b1-780_ww_gen1/acer_barricadewifi:6.0/MRA58K/1481784106:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "acer/b1-780_ww_gen1/acer_barricadewifi:6.0/MRA58K/1481784106:user/release-keys"
resetprop -n ro.odm.build.fingerprint "acer/b1-780_ww_gen1/acer_barricadewifi:6.0/MRA58K/1481784106:user/release-keys"
resetprop -n ro.system.build.fingerprint "acer/b1-780_ww_gen1/acer_barricadewifi:6.0/MRA58K/1481784106:user/release-keys"
resetprop -n ro.build.fingerprint "acer/b1-780_ww_gen1/acer_barricadewifi:6.0/MRA58K/1481784106:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "acer/b1-780_ww_gen1/acer_barricadewifi:6.0/MRA58K/1481784106:user/release-keys"
resetprop -n ro.product.build.fingerprint "acer/b1-780_ww_gen1/acer_barricadewifi:6.0/MRA58K/1481784106:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "acer/b1-780_ww_gen1/acer_barricadewifi:6.0/MRA58K/1481784106:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=6beae577d8
resetprop -n ro.system.build.version.incremental 1481784106
resetprop -n ro.bootimage.build.version.incremental 1481784106
resetprop -n ro.product.build.version.incremental 1481784106
resetprop -n ro.odm.build.version.incremental 1481784106
resetprop -n ro.vendor_dlkm.build.version.incremental 1481784106
resetprop -n ro.system_ext.build.version.incremental 1481784106
resetprop -n ro.build.version.incremental 1481784106
resetprop -n ro.vendor.build.version.incremental 1481784106
resetprop -n ro.odm.build.id "MRA58K"
resetprop -n ro.product.build.id "MRA58K"
resetprop -n ro.bootimage.build.id "MRA58K"
resetprop -n ro.system_ext.build.id "MRA58K"
resetprop -n ro.vendor_dlkm.build.id "MRA58K"
resetprop -n ro.build.id "MRA58K"
resetprop -n ro.system.build.id "MRA58K"
resetprop -n ro.vendor.build.id "MRA58K"
resetprop -n ro.system.build.date "Thu Dec 15 14:46:08 HKT 2016"
resetprop -n ro.bootimage.build.date "Thu Dec 15 14:46:08 HKT 2016"
resetprop -n ro.product.build.date "Thu Dec 15 14:46:08 HKT 2016"
resetprop -n ro.vendor_dlkm.build.date "Thu Dec 15 14:46:08 HKT 2016"
resetprop -n ro.system_ext.build.date "Thu Dec 15 14:46:08 HKT 2016"
resetprop -n ro.odm.build.date "Thu Dec 15 14:46:08 HKT 2016"
resetprop -n ro.build.date "Thu Dec 15 14:46:08 HKT 2016"
resetprop -n ro.vendor.build.date "Thu Dec 15 14:46:08 HKT 2016"
resetprop -n ro.product.build.date.utc "1481784368"
resetprop -n ro.system_ext.build.date.utc "1481784368"
resetprop -n ro.system.build.date.utc "1481784368"
resetprop -n ro.vendor.build.date.utc "1481784368"
resetprop -n ro.vendor_dlkm.build.date.utc "1481784368"
resetprop -n ro.build.date.utc "1481784368"
resetprop -n ro.bootimage.build.date.utc "1481784368"
resetprop -n ro.odm.build.date.utc "1481784368"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name b1-780_ww_gen1
resetprop -n ro.product.odm.name b1-780_ww_gen1
resetprop -n ro.product.vendor.name b1-780_ww_gen1
resetprop -n ro.product.system.name b1-780_ww_gen1
resetprop -n ro.product.name b1-780_ww_gen1
resetprop -n ro.product.bootimage.name b1-780_ww_gen1
resetprop -n ro.product.vendor_dlkm.name b1-780_ww_gen1
resetprop -n ro.product.system_ext.name b1-780_ww_gen1
resetprop -n ro.build.flavor full_neostra8163_tb_m-user
randomStr="full_neostra8163_tb_m-user Acer MRA58K "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=cc2a55c42685
resetprop -n ro.build.host ${randomStr}
randomStr=cd5c3077
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=WjRqNN
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=f3088316419da
randomStr2=67
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=2a
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1481784106"
resetprop -n ro.build.description "full_neostra8163_tb_m-user 6.0 MRA58K 1481784106 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "zuotao"
resetprop -n ro.build.host "server22"
resetprop -n ro.build.product.backup "acer_barricadewifi"
resetprop -n ro.build.characteristics "tablet"
resetprop -n ro.acer.iafw_version  " F9.E1"
resetprop -n ro.acer.android_version  " AV0M0"
resetprop -n ro.acer.product_sku  " WiFi"
resetprop -n ro.acer.device_info_version  " 1.0"
resetprop -n ro.acer.touch_fw_version " Goodix FW:1050 & CFG:72"
resetprop -n ro.acer.manufacturer  " Acer"
resetprop -n ro.acer.modelid  " B1-780"
resetprop -n ro.acer.cpu_vendor  " MTK"
resetprop -n ro.acer.cpu_speed  " 1.3GHz"
resetprop -n ro.acer.cpu_version  " MTK8163"
resetprop -n ro.acer.cpu_core  " 4 cores"
resetprop -n ro.acer.rom_size  " 8GB"
resetprop -n ro.acer.ram_size  " 1GB"
resetprop -n ro.acer.horizontal_pixels  " 720"
resetprop -n ro.acer.vertical_pixels  " 1280"
resetprop -n ro.acer.code_sn  " NTL5ZCN0015180000CNS00"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n debug.hwui.render_dirty_regions "false"
resetprop -n ro.mediatek.chip_ver "S01"
resetprop -n ro.mediatek.version.release "alps-mp-m0.mp8-V1.4.3_neostra8163.tb.m_P58"
resetprop -n ro.mediatek.platform "MT8163"
resetprop -n ro.mtk_key_manager_kb_path "1"
resetprop -n ro.mediatek.gemini_support "false"
resetprop -n ro.mediatek.version.branch "alps-mp-m0.mp8"
resetprop -n ro.mediatek.version.sdk "4"
resetprop -n ro.com.google.gmsversion "6.0_r10"
resetprop -n ro.com.google.clientidbase "android-acer"
resetprop -n ro.com.google.clientidbase.ms "android-acer"
resetprop -n ro.com.google.clientidbase.yt "android-acer"
resetprop -n ro.com.google.clientidbase.am "android-acer"
resetprop -n ro.com.google.clientidbase.gmm "android-acer"
resetprop -n ro.mtk_audio_profiles "1"
resetprop -n ro.mtk_audenh_support "1"
resetprop -n ro.mtk_besloudness_support "1"
resetprop -n ro.mtk_bessurround_support "1"
resetprop -n ro.mtk_bt_support "1"
resetprop -n ro.mtk_wappush_support "1"
resetprop -n ro.mtk_voice_contact_support "1"
resetprop -n ro.mtk_audio_tuning_tool_ver "V1"
resetprop -n ro.mtk_matv_analog_support "1"
resetprop -n ro.mtk_wlan_support "1"
resetprop -n ro.mtk_gps_support "1"
resetprop -n ro.mtk_search_db_support "1"
resetprop -n ro.mtk_dialer_search_support "1"
resetprop -n ro.mtk_dhcpv6c_wifi "1"
resetprop -n ro.mtk_widevine_drm_l3_support "1"
resetprop -n ro.mtk_fm_recording_support "1"
resetprop -n ro.mtk_audio_ape_support "1"
resetprop -n ro.mtk_flv_playback_support "1"
resetprop -n ro.mtk_wmv_playback_support "1"
resetprop -n ro.mtk_hdmi_support "1"
resetprop -n ro.mtk_mtkps_playback_support "1"
resetprop -n ro.mtk_send_rr_support "1"
resetprop -n ro.mtk_emmc_support "1"
resetprop -n ro.mtk_tetheringipv6_support "1"
resetprop -n ro.mtk_shared_sdcard "1"
resetprop -n ro.mtk_flight_mode_power_off_md "1"
resetprop -n ro.mtk_aal_support "1"
resetprop -n ro.mtk_pq_support "2"
resetprop -n ro.mtk_pq_color_mode "1"
resetprop -n ro.mtk_miravision_support "1"
resetprop -n ro.mtk_miravision_image_dc "1"
resetprop -n ro.mtk_wfd_support "1"
resetprop -n ro.mtk_wfd_sink_support "1"
resetprop -n ro.mtk_wfd_sink_uibc_support "1"
resetprop -n ro.mtk_wifi_mcc_support "1"
resetprop -n ro.mtk_thumbnail_play_support "1"
resetprop -n ro.mtk_bip_scws "1"
resetprop -n ro.mtk_wfd_hdcp_tx_support "1"
resetprop -n ro.mtk_wfd_hdcp_rx_support "1"
resetprop -n ro.mtk_world_phone "1"
resetprop -n ro.mtk_world_phone_policy "0"
resetprop -n ro.mtk_md_world_mode_support "0"
resetprop -n ro.mtk_perfservice_support "1"
resetprop -n ro.mtk_audio_change_support "1"
resetprop -n ro.mtk_hdmi_hdcp_support "1"
resetprop -n ro.mtk_internal_hdmi_support "1"
resetprop -n ro.mtk_owner_sdcard_support "1"
resetprop -n ro.mtk_owner_sim_support "1"
resetprop -n ro.mtk_cta_set "1"
resetprop -n ro.mtk_multi_patition "1"
resetprop -n ro.mtk_key_manager_support "1"
resetprop -n ro.mtk_mobile_management "1"
resetprop -n ro.mtk_antibricking_level "2"
resetprop -n ro.mtk_cam_mfb_support "3"
resetprop -n ro.mtk_uipq_support "1"
resetprop -n ro.mtk_safemedia_support "1"
resetprop -n ro.mtk_subtitle_support "1"
resetprop -n ro.mtk_slidevideo_support "1"
resetprop -n ro.mtk_bg_power_saving_support "1"
resetprop -n ro.mtk_bg_power_saving_ui "1"
resetprop -n ro.mtk_a1_feature "1"
resetprop -n ro.mtk_dual_mic_support "0"
resetprop -n ro.mtk_is_tablet "1"
resetprop -n ro.mediatek.project.path "device/neostra/neostra8163_tb_m"
resetprop -n ro.mtk_sec_video_path_support "1"
resetprop -n ro.mtk_deinterlace_support "1"
resetprop -n ro.expect.recovery_id "0xd68c3d1eff8d73b67da4028cf5ac63efec472af2000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2016-12-05
