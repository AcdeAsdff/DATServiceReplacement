strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "LINX JOY 3G LT5048MG"
resetprop -n ro.product.vendor.model "LINX JOY 3G LT5048MG"
resetprop -n ro.product.vendor_dlkm.marketname "LINX JOY 3G LT5048MG"
resetprop -n ro.product.product.marketname "LINX JOY 3G LT5048MG"
resetprop -n ro.product.system.marketname "LINX JOY 3G LT5048MG"
resetprop -n ro.product.odm_dlkm.marketname "LINX JOY 3G LT5048MG"
resetprop -n ro.product.system_ext.marketname "LINX JOY 3G LT5048MG"
resetprop -n ro.product.odm_dlkm.model "LINX JOY 3G LT5048MG"
resetprop -n ro.product.system.model "LINX JOY 3G LT5048MG"
resetprop -n ro.product.system_ext.model "LINX JOY 3G LT5048MG"
resetprop -n ro.product.vendor_dlkm.model "LINX JOY 3G LT5048MG"
resetprop -n bluetooth.device.default_name "LINX JOY 3G LT5048MG"
resetprop -n ro.product.bootimage.model "LINX JOY 3G LT5048MG"
resetprop -n ro.product.vendor.marketname "LINX JOY 3G LT5048MG"
resetprop -n ro.product.marketname "LINX JOY 3G LT5048MG"
resetprop -n ro.product.odm.model "LINX JOY 3G LT5048MG"
resetprop -n ro.product.model "LINX JOY 3G LT5048MG"
resetprop -n ro.product.product.model "LINX JOY 3G LT5048MG"
resetprop -n ro.product.odm.marketname "LINX JOY 3G LT5048MG"
resetprop -n ro.product.vendor.manufacturer "DIGMA"
resetprop -n ro.product.product.manufacturer "DIGMA"
resetprop -n ro.product.bootimage.manufacturer "DIGMA"
resetprop -n ro.product.manufacturer "DIGMA"
resetprop -n ro.product.odm.manufacturer "DIGMA"
resetprop -n ro.product.system.manufacturer "DIGMA"
resetprop -n ro.product.system_ext.manufacturer "DIGMA"
resetprop -n ro.product.vendor_dlkm.manufacturer "DIGMA"
resetprop -n ro.product.vendor.brand "DIGMA"
resetprop -n ro.product.product.brand "DIGMA"
resetprop -n ro.product.vendor_dlkm.brand "DIGMA"
resetprop -n ro.product.system.brand "DIGMA"
resetprop -n ro.product.bootimage.brand "DIGMA"
resetprop -n ro.product.system_ext.brand "DIGMA"
resetprop -n ro.product.odm.brand "DIGMA"
resetprop -n ro.product.odm_dlkm.brand "DIGMA"
resetprop -n ro.product.brand "DIGMA"
resetprop -n ro.vendor_dlkm.build.fingerprint "DIGMA/LINX_JOY_3G/LT5048MG:8.1.0/O11019/1532159573:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "DIGMA/LINX_JOY_3G/LT5048MG:8.1.0/O11019/1532159573:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "DIGMA/LINX_JOY_3G/LT5048MG:8.1.0/O11019/1532159573:user/release-keys"
resetprop -n ro.odm.build.fingerprint "DIGMA/LINX_JOY_3G/LT5048MG:8.1.0/O11019/1532159573:user/release-keys"
resetprop -n ro.system.build.fingerprint "DIGMA/LINX_JOY_3G/LT5048MG:8.1.0/O11019/1532159573:user/release-keys"
resetprop -n ro.build.fingerprint "DIGMA/LINX_JOY_3G/LT5048MG:8.1.0/O11019/1532159573:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "DIGMA/LINX_JOY_3G/LT5048MG:8.1.0/O11019/1532159573:user/release-keys"
resetprop -n ro.product.build.fingerprint "DIGMA/LINX_JOY_3G/LT5048MG:8.1.0/O11019/1532159573:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "DIGMA/LINX_JOY_3G/LT5048MG:8.1.0/O11019/1532159573:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=7d516b2569
resetprop -n ro.system.build.version.incremental 1532159573
resetprop -n ro.bootimage.build.version.incremental 1532159573
resetprop -n ro.product.build.version.incremental 1532159573
resetprop -n ro.odm.build.version.incremental 1532159573
resetprop -n ro.vendor_dlkm.build.version.incremental 1532159573
resetprop -n ro.system_ext.build.version.incremental 1532159573
resetprop -n ro.build.version.incremental 1532159573
resetprop -n ro.vendor.build.version.incremental 1532159573
resetprop -n ro.odm.build.id "O11019"
resetprop -n ro.product.build.id "O11019"
resetprop -n ro.bootimage.build.id "O11019"
resetprop -n ro.system_ext.build.id "O11019"
resetprop -n ro.vendor_dlkm.build.id "O11019"
resetprop -n ro.build.id "O11019"
resetprop -n ro.system.build.id "O11019"
resetprop -n ro.vendor.build.id "O11019"
resetprop -n ro.system.build.date "Sat Jul 21 15:52:48 CST 2018"
resetprop -n ro.bootimage.build.date "Sat Jul 21 15:52:48 CST 2018"
resetprop -n ro.product.build.date "Sat Jul 21 15:52:48 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Sat Jul 21 15:52:48 CST 2018"
resetprop -n ro.system_ext.build.date "Sat Jul 21 15:52:48 CST 2018"
resetprop -n ro.odm.build.date "Sat Jul 21 15:52:48 CST 2018"
resetprop -n ro.build.date "Sat Jul 21 15:52:48 CST 2018"
resetprop -n ro.vendor.build.date "Sat Jul 21 15:52:48 CST 2018"
resetprop -n ro.product.build.date.utc "1532159568"
resetprop -n ro.system_ext.build.date.utc "1532159568"
resetprop -n ro.system.build.date.utc "1532159568"
resetprop -n ro.vendor.build.date.utc "1532159568"
resetprop -n ro.vendor_dlkm.build.date.utc "1532159568"
resetprop -n ro.build.date.utc "1532159568"
resetprop -n ro.bootimage.build.date.utc "1532159568"
resetprop -n ro.odm.build.date.utc "1532159568"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name LINX_JOY_3G
resetprop -n ro.product.odm.name LINX_JOY_3G
resetprop -n ro.product.vendor.name LINX_JOY_3G
resetprop -n ro.product.system.name LINX_JOY_3G
resetprop -n ro.product.name LINX_JOY_3G
resetprop -n ro.product.bootimage.name LINX_JOY_3G
resetprop -n ro.product.vendor_dlkm.name LINX_JOY_3G
resetprop -n ro.product.system_ext.name LINX_JOY_3G
resetprop -n ro.build.flavor full_bird_o1mp2_k80_bsp_512m-user
randomStr="full_bird_o1mp2_k80_bsp_512m-user DIGMA O11019 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=ac9ea51701d4
resetprop -n ro.build.host ${randomStr}
randomStr=9e016c99
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=mFPqCy
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=a3b5d58705787
randomStr2=01
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=ed
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1532159573"
resetprop -n ro.build.description "full_bird_o1mp2_k80_bsp_512m-user 8.1.0 O11019 1532159573 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "birdjyun"
resetprop -n ro.build.product.backup "LT5048MG"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.build.host "birdjyun"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n debug.hwui.render_dirty_regions "false"
resetprop -n ro.expect.recovery_id "0x3c48c91949b7f2cb88faab68ce1e3ea7510c0642000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-07-05
