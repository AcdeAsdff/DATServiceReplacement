strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Amazfit Smartwatch2"
resetprop -n ro.product.vendor.model "Amazfit Smartwatch2"
resetprop -n ro.product.vendor_dlkm.marketname "Amazfit Smartwatch2"
resetprop -n ro.product.product.marketname "Amazfit Smartwatch2"
resetprop -n ro.product.system.marketname "Amazfit Smartwatch2"
resetprop -n ro.product.odm_dlkm.marketname "Amazfit Smartwatch2"
resetprop -n ro.product.system_ext.marketname "Amazfit Smartwatch2"
resetprop -n ro.product.odm_dlkm.model "Amazfit Smartwatch2"
resetprop -n ro.product.system.model "Amazfit Smartwatch2"
resetprop -n ro.product.system_ext.model "Amazfit Smartwatch2"
resetprop -n ro.product.vendor_dlkm.model "Amazfit Smartwatch2"
resetprop -n bluetooth.device.default_name "Amazfit Smartwatch2"
resetprop -n ro.product.bootimage.model "Amazfit Smartwatch2"
resetprop -n ro.product.vendor.marketname "Amazfit Smartwatch2"
resetprop -n ro.product.marketname "Amazfit Smartwatch2"
resetprop -n ro.product.odm.model "Amazfit Smartwatch2"
resetprop -n ro.product.model "Amazfit Smartwatch2"
resetprop -n ro.product.product.model "Amazfit Smartwatch2"
resetprop -n ro.product.odm.marketname "Amazfit Smartwatch2"
resetprop -n ro.product.vendor.manufacturer "Huami"
resetprop -n ro.product.product.manufacturer "Huami"
resetprop -n ro.product.bootimage.manufacturer "Huami"
resetprop -n ro.product.manufacturer "Huami"
resetprop -n ro.product.odm.manufacturer "Huami"
resetprop -n ro.product.system.manufacturer "Huami"
resetprop -n ro.product.system_ext.manufacturer "Huami"
resetprop -n ro.product.vendor_dlkm.manufacturer "Huami"
resetprop -n ro.product.vendor.brand "Huami"
resetprop -n ro.product.product.brand "Huami"
resetprop -n ro.product.vendor_dlkm.brand "Huami"
resetprop -n ro.product.system.brand "Huami"
resetprop -n ro.product.bootimage.brand "Huami"
resetprop -n ro.product.system_ext.brand "Huami"
resetprop -n ro.product.odm.brand "Huami"
resetprop -n ro.product.odm_dlkm.brand "Huami"
resetprop -n ro.product.brand "Huami"
resetprop -n ro.vendor_dlkm.build.fingerprint "Huami/xihu/msm8909w:8.1.0/OPM1.171019.011/ubuntu06171908:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Huami/xihu/msm8909w:8.1.0/OPM1.171019.011/ubuntu06171908:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Huami/xihu/msm8909w:8.1.0/OPM1.171019.011/ubuntu06171908:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Huami/xihu/msm8909w:8.1.0/OPM1.171019.011/ubuntu06171908:user/release-keys"
resetprop -n ro.system.build.fingerprint "Huami/xihu/msm8909w:8.1.0/OPM1.171019.011/ubuntu06171908:user/release-keys"
resetprop -n ro.build.fingerprint "Huami/xihu/msm8909w:8.1.0/OPM1.171019.011/ubuntu06171908:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Huami/xihu/msm8909w:8.1.0/OPM1.171019.011/ubuntu06171908:user/release-keys"
resetprop -n ro.product.build.fingerprint "Huami/xihu/msm8909w:8.1.0/OPM1.171019.011/ubuntu06171908:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Huami/xihu/msm8909w:8.1.0/OPM1.171019.011/ubuntu06171908:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=cbc279dc49
resetprop -n ro.system.build.version.incremental eng.ubuntu.20190617.190836
resetprop -n ro.bootimage.build.version.incremental eng.ubuntu.20190617.190836
resetprop -n ro.product.build.version.incremental eng.ubuntu.20190617.190836
resetprop -n ro.odm.build.version.incremental eng.ubuntu.20190617.190836
resetprop -n ro.vendor_dlkm.build.version.incremental eng.ubuntu.20190617.190836
resetprop -n ro.system_ext.build.version.incremental eng.ubuntu.20190617.190836
resetprop -n ro.build.version.incremental eng.ubuntu.20190617.190836
resetprop -n ro.vendor.build.version.incremental eng.ubuntu.20190617.190836
resetprop -n ro.odm.build.id "OPM1.171019.011"
resetprop -n ro.product.build.id "OPM1.171019.011"
resetprop -n ro.bootimage.build.id "OPM1.171019.011"
resetprop -n ro.system_ext.build.id "OPM1.171019.011"
resetprop -n ro.vendor_dlkm.build.id "OPM1.171019.011"
resetprop -n ro.build.id "OPM1.171019.011"
resetprop -n ro.system.build.id "OPM1.171019.011"
resetprop -n ro.vendor.build.id "OPM1.171019.011"
resetprop -n ro.system.build.date "Mon Jun 17 19:08:36 CST 2019"
resetprop -n ro.bootimage.build.date "Mon Jun 17 19:08:36 CST 2019"
resetprop -n ro.product.build.date "Mon Jun 17 19:08:36 CST 2019"
resetprop -n ro.vendor_dlkm.build.date "Mon Jun 17 19:08:36 CST 2019"
resetprop -n ro.system_ext.build.date "Mon Jun 17 19:08:36 CST 2019"
resetprop -n ro.odm.build.date "Mon Jun 17 19:08:36 CST 2019"
resetprop -n ro.build.date "Mon Jun 17 19:08:36 CST 2019"
resetprop -n ro.vendor.build.date "Mon Jun 17 19:08:36 CST 2019"
resetprop -n ro.product.build.date.utc "1560769716"
resetprop -n ro.system_ext.build.date.utc "1560769716"
resetprop -n ro.system.build.date.utc "1560769716"
resetprop -n ro.vendor.build.date.utc "1560769716"
resetprop -n ro.vendor_dlkm.build.date.utc "1560769716"
resetprop -n ro.build.date.utc "1560769716"
resetprop -n ro.bootimage.build.date.utc "1560769716"
resetprop -n ro.odm.build.date.utc "1560769716"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name xihu
resetprop -n ro.product.odm.name xihu
resetprop -n ro.product.vendor.name xihu
resetprop -n ro.product.system.name xihu
resetprop -n ro.product.name xihu
resetprop -n ro.product.bootimage.name xihu
resetprop -n ro.product.vendor_dlkm.name xihu
resetprop -n ro.product.system_ext.name xihu
resetprop -n ro.build.flavor xihu-user
randomStr="xihu-user Huami OPM1.171019.011 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=f92861078c39
resetprop -n ro.build.host ${randomStr}
randomStr=6e74c77d
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=LtIWSn
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=d683dafce00dd
randomStr2=94
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=1e
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "eng.ubuntu.20190617.190836"
resetprop -n ro.build.description "xihu-user 8.1.0 OPM1.171019.011 eng.ubuntu.20190617.190836 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "ubuntu"
resetprop -n ro.build.host "vm10-254-107-57.ksc.com"
resetprop -n ro.build.product.backup "msm8909w"
resetprop -n ro.build.characteristics "nosdcard,watch"
resetprop -n media.stagefright.enable-player "true"
resetprop -n media.stagefright.enable-http "true"
resetprop -n media.stagefright.enable-aac "true"
resetprop -n media.stagefright.enable-qcp "true"
resetprop -n media.stagefright.enable-fma2dp "true"
resetprop -n media.stagefright.enable-scan "true"
resetprop -n media.aac_51_output_enabled "true"
resetprop -n media.settings.xml "/vendor/etc/media_profiles_vendor.xml"
resetprop -n media.stagefright.use-awesome "false"
resetprop -n ro.hwui.text_large_cache_height "2048"
resetprop -n debug.hwui.use_buffer_age "false"
resetprop -n ro.expect.recovery_id "0xe344bda98c6835e18aad26aa2e6ae40b39331bad000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2017-12-05
