strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "ALIGATOR S6500"
resetprop -n ro.product.vendor.model "ALIGATOR S6500"
resetprop -n ro.product.vendor_dlkm.marketname "ALIGATOR S6500"
resetprop -n ro.product.product.marketname "ALIGATOR S6500"
resetprop -n ro.product.system.marketname "ALIGATOR S6500"
resetprop -n ro.product.odm_dlkm.marketname "ALIGATOR S6500"
resetprop -n ro.product.system_ext.marketname "ALIGATOR S6500"
resetprop -n ro.product.odm_dlkm.model "ALIGATOR S6500"
resetprop -n ro.product.system.model "ALIGATOR S6500"
resetprop -n ro.product.system_ext.model "ALIGATOR S6500"
resetprop -n ro.product.vendor_dlkm.model "ALIGATOR S6500"
resetprop -n bluetooth.device.default_name "ALIGATOR S6500"
resetprop -n ro.product.bootimage.model "ALIGATOR S6500"
resetprop -n ro.product.vendor.marketname "ALIGATOR S6500"
resetprop -n ro.product.marketname "ALIGATOR S6500"
resetprop -n ro.product.odm.model "ALIGATOR S6500"
resetprop -n ro.product.model "ALIGATOR S6500"
resetprop -n ro.product.product.model "ALIGATOR S6500"
resetprop -n ro.product.odm.marketname "ALIGATOR S6500"
resetprop -n ro.product.vendor.manufacturer "magcomm"
resetprop -n ro.product.product.manufacturer "magcomm"
resetprop -n ro.product.bootimage.manufacturer "magcomm"
resetprop -n ro.product.manufacturer "magcomm"
resetprop -n ro.product.odm.manufacturer "magcomm"
resetprop -n ro.product.system.manufacturer "magcomm"
resetprop -n ro.product.system_ext.manufacturer "magcomm"
resetprop -n ro.product.vendor_dlkm.manufacturer "magcomm"
resetprop -n ro.product.vendor.brand "ALIGATOR"
resetprop -n ro.product.product.brand "ALIGATOR"
resetprop -n ro.product.vendor_dlkm.brand "ALIGATOR"
resetprop -n ro.product.system.brand "ALIGATOR"
resetprop -n ro.product.bootimage.brand "ALIGATOR"
resetprop -n ro.product.system_ext.brand "ALIGATOR"
resetprop -n ro.product.odm.brand "ALIGATOR"
resetprop -n ro.product.odm_dlkm.brand "ALIGATOR"
resetprop -n ro.product.brand "ALIGATOR"
resetprop -n ro.vendor_dlkm.build.fingerprint "ALIGATOR/ALIGATOR_S6500_EEA/ALIGATOR_S6500:10/QP1A.190711.020/mp1V977:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "ALIGATOR/ALIGATOR_S6500_EEA/ALIGATOR_S6500:10/QP1A.190711.020/mp1V977:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "ALIGATOR/ALIGATOR_S6500_EEA/ALIGATOR_S6500:10/QP1A.190711.020/mp1V977:user/release-keys"
resetprop -n ro.odm.build.fingerprint "ALIGATOR/ALIGATOR_S6500_EEA/ALIGATOR_S6500:10/QP1A.190711.020/mp1V977:user/release-keys"
resetprop -n ro.system.build.fingerprint "ALIGATOR/ALIGATOR_S6500_EEA/ALIGATOR_S6500:10/QP1A.190711.020/mp1V977:user/release-keys"
resetprop -n ro.build.fingerprint "ALIGATOR/ALIGATOR_S6500_EEA/ALIGATOR_S6500:10/QP1A.190711.020/mp1V977:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "ALIGATOR/ALIGATOR_S6500_EEA/ALIGATOR_S6500:10/QP1A.190711.020/mp1V977:user/release-keys"
resetprop -n ro.product.build.fingerprint "ALIGATOR/ALIGATOR_S6500_EEA/ALIGATOR_S6500:10/QP1A.190711.020/mp1V977:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "ALIGATOR/ALIGATOR_S6500_EEA/ALIGATOR_S6500:10/QP1A.190711.020/mp1V977:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=2907cd8bce
resetprop -n ro.system.build.version.incremental mp1V977
resetprop -n ro.bootimage.build.version.incremental mp1V977
resetprop -n ro.product.build.version.incremental mp1V977
resetprop -n ro.odm.build.version.incremental mp1V977
resetprop -n ro.vendor_dlkm.build.version.incremental mp1V977
resetprop -n ro.system_ext.build.version.incremental mp1V977
resetprop -n ro.build.version.incremental mp1V977
resetprop -n ro.vendor.build.version.incremental mp1V977
resetprop -n ro.odm.build.id "QP1A.190711.020"
resetprop -n ro.product.build.id "QP1A.190711.020"
resetprop -n ro.bootimage.build.id "QP1A.190711.020"
resetprop -n ro.system_ext.build.id "QP1A.190711.020"
resetprop -n ro.vendor_dlkm.build.id "QP1A.190711.020"
resetprop -n ro.build.id "QP1A.190711.020"
resetprop -n ro.system.build.id "QP1A.190711.020"
resetprop -n ro.vendor.build.id "QP1A.190711.020"
resetprop -n ro.system.build.date "Wed Jun 24 19:47:26 CST 2020"
resetprop -n ro.bootimage.build.date "Wed Jun 24 19:47:26 CST 2020"
resetprop -n ro.product.build.date "Wed Jun 24 19:47:26 CST 2020"
resetprop -n ro.vendor_dlkm.build.date "Wed Jun 24 19:47:26 CST 2020"
resetprop -n ro.system_ext.build.date "Wed Jun 24 19:47:26 CST 2020"
resetprop -n ro.odm.build.date "Wed Jun 24 19:47:26 CST 2020"
resetprop -n ro.build.date "Wed Jun 24 19:47:26 CST 2020"
resetprop -n ro.vendor.build.date "Wed Jun 24 19:47:26 CST 2020"
resetprop -n ro.product.build.date.utc "1592999246"
resetprop -n ro.system_ext.build.date.utc "1592999246"
resetprop -n ro.system.build.date.utc "1592999246"
resetprop -n ro.vendor.build.date.utc "1592999246"
resetprop -n ro.vendor_dlkm.build.date.utc "1592999246"
resetprop -n ro.build.date.utc "1592999246"
resetprop -n ro.bootimage.build.date.utc "1592999246"
resetprop -n ro.odm.build.date.utc "1592999246"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name ALIGATOR_S6500_EEA
resetprop -n ro.product.odm.name ALIGATOR_S6500_EEA
resetprop -n ro.product.vendor.name ALIGATOR_S6500_EEA
resetprop -n ro.product.system.name ALIGATOR_S6500_EEA
resetprop -n ro.product.name ALIGATOR_S6500_EEA
resetprop -n ro.product.bootimage.name ALIGATOR_S6500_EEA
resetprop -n ro.product.vendor_dlkm.name ALIGATOR_S6500_EEA
resetprop -n ro.product.system_ext.name ALIGATOR_S6500_EEA
resetprop -n ro.build.flavor full_k37mv1_bsp-user
randomStr="full_k37mv1_bsp-user magcomm QP1A.190711.020 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=76026b987384
resetprop -n ro.build.host ${randomStr}
randomStr=c51a1369
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=YWuYWj
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=726cce8b868e5
randomStr2=fa
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=cd
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "mp1V977"
resetprop -n ro.build.description "full_k37mv1_bsp-user 10 QP1A.190711.020 mp1V977 release-keys"
resetprop -n ro.build.product.backup "ALIGATOR_S6500"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "android"
resetprop -n ro.build.host "kst-08"
resetprop -n ro.lmk.medium "700"
resetprop -n ro.lmk.kill_heaviest_task "false"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.fota.platform "MTK6737_10.0"
resetprop -n ro.fota.type "phone"
resetprop -n ro.fota.app "5"
resetprop -n ro.fota.battery "30"
resetprop -n ro.fota.oem "magcomm6737m_10.0"
resetprop -n ro.fota.device "Q1585033548299V699F3_V30D5_ALIGATOR_S6500"
resetprop -n ro.fota.version "Q1585033548299V699F3_V30D5_ALIGATOR_S6500_20200624-2143"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2020-06-05
