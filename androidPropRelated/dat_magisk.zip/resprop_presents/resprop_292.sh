strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "N570"
resetprop -n ro.product.vendor.model "N570"
resetprop -n ro.product.vendor_dlkm.marketname "N570"
resetprop -n ro.product.product.marketname "N570"
resetprop -n ro.product.system.marketname "N570"
resetprop -n ro.product.odm_dlkm.marketname "N570"
resetprop -n ro.product.system_ext.marketname "N570"
resetprop -n ro.product.odm_dlkm.model "N570"
resetprop -n ro.product.system.model "N570"
resetprop -n ro.product.system_ext.model "N570"
resetprop -n ro.product.vendor_dlkm.model "N570"
resetprop -n bluetooth.device.default_name "N570"
resetprop -n ro.product.bootimage.model "N570"
resetprop -n ro.product.vendor.marketname "N570"
resetprop -n ro.product.marketname "N570"
resetprop -n ro.product.odm.model "N570"
resetprop -n ro.product.model "N570"
resetprop -n ro.product.product.model "N570"
resetprop -n ro.product.odm.marketname "N570"
resetprop -n ro.product.vendor.manufacturer "DEXP"
resetprop -n ro.product.product.manufacturer "DEXP"
resetprop -n ro.product.bootimage.manufacturer "DEXP"
resetprop -n ro.product.manufacturer "DEXP"
resetprop -n ro.product.odm.manufacturer "DEXP"
resetprop -n ro.product.system.manufacturer "DEXP"
resetprop -n ro.product.system_ext.manufacturer "DEXP"
resetprop -n ro.product.vendor_dlkm.manufacturer "DEXP"
resetprop -n ro.product.vendor.brand "DEXP"
resetprop -n ro.product.product.brand "DEXP"
resetprop -n ro.product.vendor_dlkm.brand "DEXP"
resetprop -n ro.product.system.brand "DEXP"
resetprop -n ro.product.bootimage.brand "DEXP"
resetprop -n ro.product.system_ext.brand "DEXP"
resetprop -n ro.product.odm.brand "DEXP"
resetprop -n ro.product.odm_dlkm.brand "DEXP"
resetprop -n ro.product.brand "DEXP"
resetprop -n ro.vendor_dlkm.build.fingerprint "DEXP/N570/N570:8.1.0/OPM2.171019.012/22418:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "DEXP/N570/N570:8.1.0/OPM2.171019.012/22418:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "DEXP/N570/N570:8.1.0/OPM2.171019.012/22418:user/release-keys"
resetprop -n ro.odm.build.fingerprint "DEXP/N570/N570:8.1.0/OPM2.171019.012/22418:user/release-keys"
resetprop -n ro.system.build.fingerprint "DEXP/N570/N570:8.1.0/OPM2.171019.012/22418:user/release-keys"
resetprop -n ro.build.fingerprint "DEXP/N570/N570:8.1.0/OPM2.171019.012/22418:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "DEXP/N570/N570:8.1.0/OPM2.171019.012/22418:user/release-keys"
resetprop -n ro.product.build.fingerprint "DEXP/N570/N570:8.1.0/OPM2.171019.012/22418:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "DEXP/N570/N570:8.1.0/OPM2.171019.012/22418:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=e2827cd9f7
resetprop -n ro.system.build.version.incremental 22418
resetprop -n ro.bootimage.build.version.incremental 22418
resetprop -n ro.product.build.version.incremental 22418
resetprop -n ro.odm.build.version.incremental 22418
resetprop -n ro.vendor_dlkm.build.version.incremental 22418
resetprop -n ro.system_ext.build.version.incremental 22418
resetprop -n ro.build.version.incremental 22418
resetprop -n ro.vendor.build.version.incremental 22418
resetprop -n ro.odm.build.id "OPM2.171019.012"
resetprop -n ro.product.build.id "OPM2.171019.012"
resetprop -n ro.bootimage.build.id "OPM2.171019.012"
resetprop -n ro.system_ext.build.id "OPM2.171019.012"
resetprop -n ro.vendor_dlkm.build.id "OPM2.171019.012"
resetprop -n ro.build.id "OPM2.171019.012"
resetprop -n ro.system.build.id "OPM2.171019.012"
resetprop -n ro.vendor.build.id "OPM2.171019.012"
resetprop -n ro.system.build.date "Thu Jun  6 18:02:52 HKT 2019"
resetprop -n ro.bootimage.build.date "Thu Jun  6 18:02:52 HKT 2019"
resetprop -n ro.product.build.date "Thu Jun  6 18:02:52 HKT 2019"
resetprop -n ro.vendor_dlkm.build.date "Thu Jun  6 18:02:52 HKT 2019"
resetprop -n ro.system_ext.build.date "Thu Jun  6 18:02:52 HKT 2019"
resetprop -n ro.odm.build.date "Thu Jun  6 18:02:52 HKT 2019"
resetprop -n ro.build.date "Thu Jun  6 18:02:52 HKT 2019"
resetprop -n ro.vendor.build.date "Thu Jun  6 18:02:52 HKT 2019"
resetprop -n ro.product.build.date.utc "1559815372"
resetprop -n ro.system_ext.build.date.utc "1559815372"
resetprop -n ro.system.build.date.utc "1559815372"
resetprop -n ro.vendor.build.date.utc "1559815372"
resetprop -n ro.vendor_dlkm.build.date.utc "1559815372"
resetprop -n ro.build.date.utc "1559815372"
resetprop -n ro.bootimage.build.date.utc "1559815372"
resetprop -n ro.odm.build.date.utc "1559815372"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name N570
resetprop -n ro.product.odm.name N570
resetprop -n ro.product.vendor.name N570
resetprop -n ro.product.system.name N570
resetprop -n ro.product.name N570
resetprop -n ro.product.bootimage.name N570
resetprop -n ro.product.vendor_dlkm.name N570
resetprop -n ro.product.system_ext.name N570
resetprop -n ro.build.flavor oversea
randomStr="oversea DEXP OPM2.171019.012 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=f5df7ca3b4f6
resetprop -n ro.build.host ${randomStr}
randomStr=dc731ced
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=dEArKj
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=ea4bb4ad577f4
randomStr2=d8
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=17
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "22418"
resetprop -n ro.build.description "s7182e_2g-user 8.1.0 OPM2.171019.012 22418 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "yhg"
resetprop -n ro.build.host "ubuntu"
resetprop -n ro.build.product.backup "N570"
resetprop -n ro.build.characteristics "tablet"
resetprop -n ro.fota.platform "Sprd9832_8.1"
resetprop -n ro.fota.type "phone"
resetprop -n ro.fota.app "5"
resetprop -n ro.fota.oem "incartech9832_8.1"
resetprop -n ro.fota.device "N570"
resetprop -n ro.fota.version "N570_T1_190606_20190606-1808"
resetprop -n ro.expect.recovery_id "0x66089d41b7b1a7fefdb9b172012f88d8e8651d32000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-05-05
