strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "LAVA LE9830"
resetprop -n ro.product.vendor.model "LAVA LE9830"
resetprop -n ro.product.vendor_dlkm.marketname "LAVA LE9830"
resetprop -n ro.product.product.marketname "LAVA LE9830"
resetprop -n ro.product.system.marketname "LAVA LE9830"
resetprop -n ro.product.odm_dlkm.marketname "LAVA LE9830"
resetprop -n ro.product.system_ext.marketname "LAVA LE9830"
resetprop -n ro.product.odm_dlkm.model "LAVA LE9830"
resetprop -n ro.product.system.model "LAVA LE9830"
resetprop -n ro.product.system_ext.model "LAVA LE9830"
resetprop -n ro.product.vendor_dlkm.model "LAVA LE9830"
resetprop -n bluetooth.device.default_name "LAVA LE9830"
resetprop -n ro.product.bootimage.model "LAVA LE9830"
resetprop -n ro.product.vendor.marketname "LAVA LE9830"
resetprop -n ro.product.marketname "LAVA LE9830"
resetprop -n ro.product.odm.model "LAVA LE9830"
resetprop -n ro.product.model "LAVA LE9830"
resetprop -n ro.product.product.model "LAVA LE9830"
resetprop -n ro.product.odm.marketname "LAVA LE9830"
resetprop -n ro.product.vendor.manufacturer "LAVA"
resetprop -n ro.product.product.manufacturer "LAVA"
resetprop -n ro.product.bootimage.manufacturer "LAVA"
resetprop -n ro.product.manufacturer "LAVA"
resetprop -n ro.product.odm.manufacturer "LAVA"
resetprop -n ro.product.system.manufacturer "LAVA"
resetprop -n ro.product.system_ext.manufacturer "LAVA"
resetprop -n ro.product.vendor_dlkm.manufacturer "LAVA"
resetprop -n ro.product.vendor.brand "LAVA"
resetprop -n ro.product.product.brand "LAVA"
resetprop -n ro.product.vendor_dlkm.brand "LAVA"
resetprop -n ro.product.system.brand "LAVA"
resetprop -n ro.product.bootimage.brand "LAVA"
resetprop -n ro.product.system_ext.brand "LAVA"
resetprop -n ro.product.odm.brand "LAVA"
resetprop -n ro.product.odm_dlkm.brand "LAVA"
resetprop -n ro.product.brand "LAVA"
resetprop -n ro.vendor_dlkm.build.fingerprint "LAVA/LE9830/LE9830:9/PPR1.180610.011/1560428847:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "LAVA/LE9830/LE9830:9/PPR1.180610.011/1560428847:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "LAVA/LE9830/LE9830:9/PPR1.180610.011/1560428847:user/release-keys"
resetprop -n ro.odm.build.fingerprint "LAVA/LE9830/LE9830:9/PPR1.180610.011/1560428847:user/release-keys"
resetprop -n ro.system.build.fingerprint "LAVA/LE9830/LE9830:9/PPR1.180610.011/1560428847:user/release-keys"
resetprop -n ro.build.fingerprint "LAVA/LE9830/LE9830:9/PPR1.180610.011/1560428847:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "LAVA/LE9830/LE9830:9/PPR1.180610.011/1560428847:user/release-keys"
resetprop -n ro.product.build.fingerprint "LAVA/LE9830/LE9830:9/PPR1.180610.011/1560428847:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "LAVA/LE9830/LE9830:9/PPR1.180610.011/1560428847:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=e4140d728e
resetprop -n ro.system.build.version.incremental 1560428847
resetprop -n ro.bootimage.build.version.incremental 1560428847
resetprop -n ro.product.build.version.incremental 1560428847
resetprop -n ro.odm.build.version.incremental 1560428847
resetprop -n ro.vendor_dlkm.build.version.incremental 1560428847
resetprop -n ro.system_ext.build.version.incremental 1560428847
resetprop -n ro.build.version.incremental 1560428847
resetprop -n ro.vendor.build.version.incremental 1560428847
resetprop -n ro.odm.build.id "PPR1.180610.011"
resetprop -n ro.product.build.id "PPR1.180610.011"
resetprop -n ro.bootimage.build.id "PPR1.180610.011"
resetprop -n ro.system_ext.build.id "PPR1.180610.011"
resetprop -n ro.vendor_dlkm.build.id "PPR1.180610.011"
resetprop -n ro.build.id "PPR1.180610.011"
resetprop -n ro.system.build.id "PPR1.180610.011"
resetprop -n ro.vendor.build.id "PPR1.180610.011"
resetprop -n ro.system.build.date "Thu Jun 13 12:26:47 UTC 2019"
resetprop -n ro.bootimage.build.date "Thu Jun 13 12:26:47 UTC 2019"
resetprop -n ro.product.build.date "Thu Jun 13 12:26:47 UTC 2019"
resetprop -n ro.vendor_dlkm.build.date "Thu Jun 13 12:26:47 UTC 2019"
resetprop -n ro.system_ext.build.date "Thu Jun 13 12:26:47 UTC 2019"
resetprop -n ro.odm.build.date "Thu Jun 13 12:26:47 UTC 2019"
resetprop -n ro.build.date "Thu Jun 13 12:26:47 UTC 2019"
resetprop -n ro.vendor.build.date "Thu Jun 13 12:26:47 UTC 2019"
resetprop -n ro.product.build.date.utc "1560428807"
resetprop -n ro.system_ext.build.date.utc "1560428807"
resetprop -n ro.system.build.date.utc "1560428807"
resetprop -n ro.vendor.build.date.utc "1560428807"
resetprop -n ro.vendor_dlkm.build.date.utc "1560428807"
resetprop -n ro.build.date.utc "1560428807"
resetprop -n ro.bootimage.build.date.utc "1560428807"
resetprop -n ro.odm.build.date.utc "1560428807"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name LE9830
resetprop -n ro.product.odm.name LE9830
resetprop -n ro.product.vendor.name LE9830
resetprop -n ro.product.system.name LE9830
resetprop -n ro.product.name LE9830
resetprop -n ro.product.bootimage.name LE9830
resetprop -n ro.product.vendor_dlkm.name LE9830
resetprop -n ro.product.system_ext.name LE9830
resetprop -n ro.build.flavor full_k62v_op66-user
randomStr="full_k62v_op66-user LAVA PPR1.180610.011 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=38d07c4aea63
resetprop -n ro.build.host ${randomStr}
randomStr=798181f3
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=IRGgbg
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=e2ec873ef2ea1
randomStr2=cb
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=bb
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1560428847"
resetprop -n ro.build.description "full_k62v_op66-user 9 PPR1.180610.011 1560428847 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "lava"
resetprop -n ro.build.host "8475225a6a7c"
resetprop -n ro.build.product.backup "LE9830"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.expect.recovery_id "0x1a5ba53cf842ac338ad741b5c27c1d5ad90034ce000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-05-05
