strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "DX170"
resetprop -n ro.product.vendor.model "DX170"
resetprop -n ro.product.vendor_dlkm.marketname "DX170"
resetprop -n ro.product.product.marketname "DX170"
resetprop -n ro.product.system.marketname "DX170"
resetprop -n ro.product.odm_dlkm.marketname "DX170"
resetprop -n ro.product.system_ext.marketname "DX170"
resetprop -n ro.product.odm_dlkm.model "DX170"
resetprop -n ro.product.system.model "DX170"
resetprop -n ro.product.system_ext.model "DX170"
resetprop -n ro.product.vendor_dlkm.model "DX170"
resetprop -n bluetooth.device.default_name "DX170"
resetprop -n ro.product.bootimage.model "DX170"
resetprop -n ro.product.vendor.marketname "DX170"
resetprop -n ro.product.marketname "DX170"
resetprop -n ro.product.odm.model "DX170"
resetprop -n ro.product.model "DX170"
resetprop -n ro.product.product.model "DX170"
resetprop -n ro.product.odm.marketname "DX170"
resetprop -n ro.product.vendor.manufacturer "iBasso"
resetprop -n ro.product.product.manufacturer "iBasso"
resetprop -n ro.product.bootimage.manufacturer "iBasso"
resetprop -n ro.product.manufacturer "iBasso"
resetprop -n ro.product.odm.manufacturer "iBasso"
resetprop -n ro.product.system.manufacturer "iBasso"
resetprop -n ro.product.system_ext.manufacturer "iBasso"
resetprop -n ro.product.vendor_dlkm.manufacturer "iBasso"
resetprop -n ro.product.vendor.brand "iBasso"
resetprop -n ro.product.product.brand "iBasso"
resetprop -n ro.product.vendor_dlkm.brand "iBasso"
resetprop -n ro.product.system.brand "iBasso"
resetprop -n ro.product.bootimage.brand "iBasso"
resetprop -n ro.product.system_ext.brand "iBasso"
resetprop -n ro.product.odm.brand "iBasso"
resetprop -n ro.product.odm_dlkm.brand "iBasso"
resetprop -n ro.product.brand "iBasso"
resetprop -n ro.vendor_dlkm.build.fingerprint "iBasso/DX170/DX170:11/RQ3A.210705.001/iBasso12081906:userdebug/release-keys"
resetprop -n ro.bootimage.build.fingerprint "iBasso/DX170/DX170:11/RQ3A.210705.001/iBasso12081906:userdebug/release-keys"
resetprop -n ro.vendor.build.fingerprint "iBasso/DX170/DX170:11/RQ3A.210705.001/iBasso12081906:userdebug/release-keys"
resetprop -n ro.odm.build.fingerprint "iBasso/DX170/DX170:11/RQ3A.210705.001/iBasso12081906:userdebug/release-keys"
resetprop -n ro.system.build.fingerprint "iBasso/DX170/DX170:11/RQ3A.210705.001/iBasso12081906:userdebug/release-keys"
resetprop -n ro.build.fingerprint "iBasso/DX170/DX170:11/RQ3A.210705.001/iBasso12081906:userdebug/release-keys"
resetprop -n ro.system_ext.build.fingerprint "iBasso/DX170/DX170:11/RQ3A.210705.001/iBasso12081906:userdebug/release-keys"
resetprop -n ro.product.build.fingerprint "iBasso/DX170/DX170:11/RQ3A.210705.001/iBasso12081906:userdebug/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "iBasso/DX170/DX170:11/RQ3A.210705.001/iBasso12081906:userdebug/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=4488495267
resetprop -n ro.system.build.version.incremental eng.iBasso.20221208.191327
resetprop -n ro.bootimage.build.version.incremental eng.iBasso.20221208.191327
resetprop -n ro.product.build.version.incremental eng.iBasso.20221208.191327
resetprop -n ro.odm.build.version.incremental eng.iBasso.20221208.191327
resetprop -n ro.vendor_dlkm.build.version.incremental eng.iBasso.20221208.191327
resetprop -n ro.system_ext.build.version.incremental eng.iBasso.20221208.191327
resetprop -n ro.build.version.incremental eng.iBasso.20221208.191327
resetprop -n ro.vendor.build.version.incremental eng.iBasso.20221208.191327
resetprop -n ro.odm.build.id "RQ3A.210705.001"
resetprop -n ro.product.build.id "RQ3A.210705.001"
resetprop -n ro.bootimage.build.id "RQ3A.210705.001"
resetprop -n ro.system_ext.build.id "RQ3A.210705.001"
resetprop -n ro.vendor_dlkm.build.id "RQ3A.210705.001"
resetprop -n ro.build.id "RQ3A.210705.001"
resetprop -n ro.system.build.id "RQ3A.210705.001"
resetprop -n ro.vendor.build.id "RQ3A.210705.001"
resetprop -n ro.system.build.date "Thu Dec  8 19:06:42 CST 2022"
resetprop -n ro.bootimage.build.date "Thu Dec  8 19:06:42 CST 2022"
resetprop -n ro.product.build.date "Thu Dec  8 19:06:42 CST 2022"
resetprop -n ro.vendor_dlkm.build.date "Thu Dec  8 19:06:42 CST 2022"
resetprop -n ro.system_ext.build.date "Thu Dec  8 19:06:42 CST 2022"
resetprop -n ro.odm.build.date "Thu Dec  8 19:06:42 CST 2022"
resetprop -n ro.build.date "Thu Dec  8 19:06:42 CST 2022"
resetprop -n ro.vendor.build.date "Thu Dec  8 19:06:42 CST 2022"
resetprop -n ro.product.build.date.utc "1670497602"
resetprop -n ro.system_ext.build.date.utc "1670497602"
resetprop -n ro.system.build.date.utc "1670497602"
resetprop -n ro.vendor.build.date.utc "1670497602"
resetprop -n ro.vendor_dlkm.build.date.utc "1670497602"
resetprop -n ro.build.date.utc "1670497602"
resetprop -n ro.bootimage.build.date.utc "1670497602"
resetprop -n ro.odm.build.date.utc "1670497602"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "userdebug"
resetprop -n ro.system_ext.build.type "userdebug"
resetprop -n ro.vendor_dlkm.build.type "userdebug"
resetprop -n ro.bootimage.build.type "userdebug"
resetprop -n ro.product.build.type "userdebug"
resetprop -n ro.odm.build.type "userdebug"
resetprop -n ro.vendor.build.type "userdebug"
resetprop -n ro.product.product.name DX170
resetprop -n ro.product.odm.name DX170
resetprop -n ro.product.vendor.name DX170
resetprop -n ro.product.system.name DX170
resetprop -n ro.product.name DX170
resetprop -n ro.product.bootimage.name DX170
resetprop -n ro.product.vendor_dlkm.name DX170
resetprop -n ro.product.system_ext.name DX170
resetprop -n ro.build.flavor DX170-userdebug
randomStr="DX170-userdebug iBasso RQ3A.210705.001 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=7b49a67d910a
resetprop -n ro.build.host ${randomStr}
randomStr=4258027e
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=ZXcZSv
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=c94aeec835f32
randomStr2=9b
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=86
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "eng.iBasso.20221208.191327"
resetprop -n ro.build.description "DX170-userdebug 11 RQ3A.210705.001 eng.iBasso.20221208.191327 release-keys"
resetprop -n ro.build.product.backup "DX170"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "iBasso"
resetprop -n ro.build.host "tomato"
resetprop -n ro.lmk.medium "700"
resetprop -n ro.lmk.critical_upgrade "true"
resetprop -n ro.lmk.upgrade_pressure "40"
resetprop -n ro.lmk.downgrade_pressure "60"
resetprop -n ro.lmk.kill_heaviest_task "false"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2021-08-05
