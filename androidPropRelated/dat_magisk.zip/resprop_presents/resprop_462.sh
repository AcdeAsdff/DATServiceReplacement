strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Neon"
resetprop -n ro.product.vendor.model "Neon"
resetprop -n ro.product.vendor_dlkm.marketname "Neon"
resetprop -n ro.product.product.marketname "Neon"
resetprop -n ro.product.system.marketname "Neon"
resetprop -n ro.product.odm_dlkm.marketname "Neon"
resetprop -n ro.product.system_ext.marketname "Neon"
resetprop -n ro.product.odm_dlkm.model "Neon"
resetprop -n ro.product.system.model "Neon"
resetprop -n ro.product.system_ext.model "Neon"
resetprop -n ro.product.vendor_dlkm.model "Neon"
resetprop -n bluetooth.device.default_name "Neon"
resetprop -n ro.product.bootimage.model "Neon"
resetprop -n ro.product.vendor.marketname "Neon"
resetprop -n ro.product.marketname "Neon"
resetprop -n ro.product.odm.model "Neon"
resetprop -n ro.product.model "Neon"
resetprop -n ro.product.product.model "Neon"
resetprop -n ro.product.odm.marketname "Neon"
resetprop -n ro.product.vendor.manufacturer "Jinga"
resetprop -n ro.product.product.manufacturer "Jinga"
resetprop -n ro.product.bootimage.manufacturer "Jinga"
resetprop -n ro.product.manufacturer "Jinga"
resetprop -n ro.product.odm.manufacturer "Jinga"
resetprop -n ro.product.system.manufacturer "Jinga"
resetprop -n ro.product.system_ext.manufacturer "Jinga"
resetprop -n ro.product.vendor_dlkm.manufacturer "Jinga"
resetprop -n ro.product.vendor.brand "Jinga"
resetprop -n ro.product.product.brand "Jinga"
resetprop -n ro.product.vendor_dlkm.brand "Jinga"
resetprop -n ro.product.system.brand "Jinga"
resetprop -n ro.product.bootimage.brand "Jinga"
resetprop -n ro.product.system_ext.brand "Jinga"
resetprop -n ro.product.odm.brand "Jinga"
resetprop -n ro.product.odm_dlkm.brand "Jinga"
resetprop -n ro.product.brand "Jinga"
resetprop -n ro.vendor_dlkm.build.fingerprint "Jinga/Neon/Neon:8.1.0/OPM2.171019.012/15122018200203:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Jinga/Neon/Neon:8.1.0/OPM2.171019.012/15122018200203:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Jinga/Neon/Neon:8.1.0/OPM2.171019.012/15122018200203:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Jinga/Neon/Neon:8.1.0/OPM2.171019.012/15122018200203:user/release-keys"
resetprop -n ro.system.build.fingerprint "Jinga/Neon/Neon:8.1.0/OPM2.171019.012/15122018200203:user/release-keys"
resetprop -n ro.build.fingerprint "Jinga/Neon/Neon:8.1.0/OPM2.171019.012/15122018200203:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Jinga/Neon/Neon:8.1.0/OPM2.171019.012/15122018200203:user/release-keys"
resetprop -n ro.product.build.fingerprint "Jinga/Neon/Neon:8.1.0/OPM2.171019.012/15122018200203:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Jinga/Neon/Neon:8.1.0/OPM2.171019.012/15122018200203:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=2e1afe23b9
resetprop -n ro.system.build.version.incremental 15122018200203
resetprop -n ro.bootimage.build.version.incremental 15122018200203
resetprop -n ro.product.build.version.incremental 15122018200203
resetprop -n ro.odm.build.version.incremental 15122018200203
resetprop -n ro.vendor_dlkm.build.version.incremental 15122018200203
resetprop -n ro.system_ext.build.version.incremental 15122018200203
resetprop -n ro.build.version.incremental 15122018200203
resetprop -n ro.vendor.build.version.incremental 15122018200203
resetprop -n ro.odm.build.id "OPM2.171019.012"
resetprop -n ro.product.build.id "OPM2.171019.012"
resetprop -n ro.bootimage.build.id "OPM2.171019.012"
resetprop -n ro.system_ext.build.id "OPM2.171019.012"
resetprop -n ro.vendor_dlkm.build.id "OPM2.171019.012"
resetprop -n ro.build.id "OPM2.171019.012"
resetprop -n ro.system.build.id "OPM2.171019.012"
resetprop -n ro.vendor.build.id "OPM2.171019.012"
resetprop -n ro.system.build.date "Sat Dec 15 20:02:03 CST 2018"
resetprop -n ro.bootimage.build.date "Sat Dec 15 20:02:03 CST 2018"
resetprop -n ro.product.build.date "Sat Dec 15 20:02:03 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Sat Dec 15 20:02:03 CST 2018"
resetprop -n ro.system_ext.build.date "Sat Dec 15 20:02:03 CST 2018"
resetprop -n ro.odm.build.date "Sat Dec 15 20:02:03 CST 2018"
resetprop -n ro.build.date "Sat Dec 15 20:02:03 CST 2018"
resetprop -n ro.vendor.build.date "Sat Dec 15 20:02:03 CST 2018"
resetprop -n ro.product.build.date.utc "1544875323"
resetprop -n ro.system_ext.build.date.utc "1544875323"
resetprop -n ro.system.build.date.utc "1544875323"
resetprop -n ro.vendor.build.date.utc "1544875323"
resetprop -n ro.vendor_dlkm.build.date.utc "1544875323"
resetprop -n ro.build.date.utc "1544875323"
resetprop -n ro.bootimage.build.date.utc "1544875323"
resetprop -n ro.odm.build.date.utc "1544875323"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name Neon
resetprop -n ro.product.odm.name Neon
resetprop -n ro.product.vendor.name Neon
resetprop -n ro.product.system.name Neon
resetprop -n ro.product.name Neon
resetprop -n ro.product.bootimage.name Neon
resetprop -n ro.product.vendor_dlkm.name Neon
resetprop -n ro.product.system_ext.name Neon
resetprop -n ro.build.flavor oversea
randomStr="oversea Jinga OPM2.171019.012 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=f306f3f14ad2
resetprop -n ro.build.host ${randomStr}
randomStr=8b2ac173
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=nhpdkq
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=2318aa1ad03e9
randomStr2=d5
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=36
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "15122018200203"
resetprop -n ro.build.description "Neon-user 8.1.0 OPM2.171019.012 15122018200203 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "android"
resetprop -n ro.build.host "ubuntu"
resetprop -n ro.build.product.backup "Neon"
resetprop -n ro.build.characteristics "default"
resetprop -n media.settings.xml  " vendor/etc/media_profiles_turnkey.xml"
resetprop -n ro.expect.recovery_id "0x78bd18181abc38a639f472f727c4f0665bc9f770000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-12-05
