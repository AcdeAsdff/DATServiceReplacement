strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "16th"
resetprop -n ro.product.vendor.model "16th"
resetprop -n ro.product.vendor_dlkm.marketname "16th"
resetprop -n ro.product.product.marketname "16th"
resetprop -n ro.product.system.marketname "16th"
resetprop -n ro.product.odm_dlkm.marketname "16th"
resetprop -n ro.product.system_ext.marketname "16th"
resetprop -n ro.product.odm_dlkm.model "16th"
resetprop -n ro.product.system.model "16th"
resetprop -n ro.product.system_ext.model "16th"
resetprop -n ro.product.vendor_dlkm.model "16th"
resetprop -n bluetooth.device.default_name "16th"
resetprop -n ro.product.bootimage.model "16th"
resetprop -n ro.product.vendor.marketname "16th"
resetprop -n ro.product.marketname "16th"
resetprop -n ro.product.odm.model "16th"
resetprop -n ro.product.model "16th"
resetprop -n ro.product.product.model "16th"
resetprop -n ro.product.odm.marketname "16th"
resetprop -n ro.product.vendor.manufacturer "Meizu"
resetprop -n ro.product.product.manufacturer "Meizu"
resetprop -n ro.product.bootimage.manufacturer "Meizu"
resetprop -n ro.product.manufacturer "Meizu"
resetprop -n ro.product.odm.manufacturer "Meizu"
resetprop -n ro.product.system.manufacturer "Meizu"
resetprop -n ro.product.system_ext.manufacturer "Meizu"
resetprop -n ro.product.vendor_dlkm.manufacturer "Meizu"
resetprop -n ro.product.vendor.brand "Meizu"
resetprop -n ro.product.product.brand "Meizu"
resetprop -n ro.product.vendor_dlkm.brand "Meizu"
resetprop -n ro.product.system.brand "Meizu"
resetprop -n ro.product.bootimage.brand "Meizu"
resetprop -n ro.product.system_ext.brand "Meizu"
resetprop -n ro.product.odm.brand "Meizu"
resetprop -n ro.product.odm_dlkm.brand "Meizu"
resetprop -n ro.product.brand "Meizu"
resetprop -n ro.vendor_dlkm.build.fingerprint "Meizu/meizu_16th_CN/16th:8.1.0/OPM1.171019.026/1533779885:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Meizu/meizu_16th_CN/16th:8.1.0/OPM1.171019.026/1533779885:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Meizu/meizu_16th_CN/16th:8.1.0/OPM1.171019.026/1533779885:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Meizu/meizu_16th_CN/16th:8.1.0/OPM1.171019.026/1533779885:user/release-keys"
resetprop -n ro.system.build.fingerprint "Meizu/meizu_16th_CN/16th:8.1.0/OPM1.171019.026/1533779885:user/release-keys"
resetprop -n ro.build.fingerprint "Meizu/meizu_16th_CN/16th:8.1.0/OPM1.171019.026/1533779885:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Meizu/meizu_16th_CN/16th:8.1.0/OPM1.171019.026/1533779885:user/release-keys"
resetprop -n ro.product.build.fingerprint "Meizu/meizu_16th_CN/16th:8.1.0/OPM1.171019.026/1533779885:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Meizu/meizu_16th_CN/16th:8.1.0/OPM1.171019.026/1533779885:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=2fa0267cbe
resetprop -n ro.system.build.version.incremental 1533779885
resetprop -n ro.bootimage.build.version.incremental 1533779885
resetprop -n ro.product.build.version.incremental 1533779885
resetprop -n ro.odm.build.version.incremental 1533779885
resetprop -n ro.vendor_dlkm.build.version.incremental 1533779885
resetprop -n ro.system_ext.build.version.incremental 1533779885
resetprop -n ro.build.version.incremental 1533779885
resetprop -n ro.vendor.build.version.incremental 1533779885
resetprop -n ro.odm.build.id "OPM1.171019.026"
resetprop -n ro.product.build.id "OPM1.171019.026"
resetprop -n ro.bootimage.build.id "OPM1.171019.026"
resetprop -n ro.system_ext.build.id "OPM1.171019.026"
resetprop -n ro.vendor_dlkm.build.id "OPM1.171019.026"
resetprop -n ro.build.id "OPM1.171019.026"
resetprop -n ro.system.build.id "OPM1.171019.026"
resetprop -n ro.vendor.build.id "OPM1.171019.026"
resetprop -n ro.system.build.date "Sun Aug 19 10:59:32 CST 2018"
resetprop -n ro.bootimage.build.date "Sun Aug 19 10:59:32 CST 2018"
resetprop -n ro.product.build.date "Sun Aug 19 10:59:32 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Sun Aug 19 10:59:32 CST 2018"
resetprop -n ro.system_ext.build.date "Sun Aug 19 10:59:32 CST 2018"
resetprop -n ro.odm.build.date "Sun Aug 19 10:59:32 CST 2018"
resetprop -n ro.build.date "Sun Aug 19 10:59:32 CST 2018"
resetprop -n ro.vendor.build.date "Sun Aug 19 10:59:32 CST 2018"
resetprop -n ro.product.build.date.utc "1534647572"
resetprop -n ro.system_ext.build.date.utc "1534647572"
resetprop -n ro.system.build.date.utc "1534647572"
resetprop -n ro.vendor.build.date.utc "1534647572"
resetprop -n ro.vendor_dlkm.build.date.utc "1534647572"
resetprop -n ro.build.date.utc "1534647572"
resetprop -n ro.bootimage.build.date.utc "1534647572"
resetprop -n ro.odm.build.date.utc "1534647572"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name meizu_16th_CN
resetprop -n ro.product.odm.name meizu_16th_CN
resetprop -n ro.product.vendor.name meizu_16th_CN
resetprop -n ro.product.system.name meizu_16th_CN
resetprop -n ro.product.name meizu_16th_CN
resetprop -n ro.product.bootimage.name meizu_16th_CN
resetprop -n ro.product.vendor_dlkm.name meizu_16th_CN
resetprop -n ro.product.system_ext.name meizu_16th_CN
resetprop -n ro.build.flavor sdm845-user
randomStr="sdm845-user Meizu OPM1.171019.026 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=04208d49f680
resetprop -n ro.build.host ${randomStr}
randomStr=68bf1367
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=AqYIMg
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=6de06c2e123ca
randomStr2=d1
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=9e
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1533779885"
resetprop -n ro.build.description "meizu_16th_CN-user 8.1.0 OPM1.171019.026 1533779885 release-keys"
resetprop -n ro.meizu.build.spt "0"
resetprop -n ro.build.host "Mz-Builder-L30"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "flyme"
resetprop -n ro.build.characteristics "nosdcard"
resetprop -n ro.meizu.product.model "16th"
resetprop -n ro.build.product.backup "16th"
resetprop -n ro.flyme.version.id "Flyme 7.1.1.1A"
resetprop -n ro.meizu.project.id "M1882-7"
resetprop -n ro.product.flyme.model "M1882"
resetprop -n ro.flyme.published  " true"
resetprop -n ro.flyme.ctsbackup  " false"
resetprop -n ro.meizu.build.number "M1882_20180819105742"
resetprop -n media.stagefright.enable-player "true"
resetprop -n media.stagefright.enable-http "true"
resetprop -n media.stagefright.enable-aac "true"
resetprop -n media.stagefright.enable-qcp "true"
resetprop -n media.stagefright.enable-fma2dp "true"
resetprop -n media.stagefright.enable-scan "true"
resetprop -n media.stagefright.audio.deep "true"
resetprop -n media.aac_51_output_enabled "true"
resetprop -n media.settings.xml "/vendor/etc/media_profiles_vendor.xml"
resetprop -n ro.hwui.texture_cache_size "72"
resetprop -n ro.hwui.layer_cache_size "48"
resetprop -n ro.hwui.r_buffer_cache_size "8"
resetprop -n ro.hwui.path_cache_size "32"
resetprop -n ro.hwui.gradient_cache_size "1"
resetprop -n ro.hwui.drop_shadow_cache_size "6"
resetprop -n ro.hwui.texture_cache_flushrate "0.4"
resetprop -n ro.hwui.text_small_cache_width "1024"
resetprop -n ro.hwui.text_small_cache_height "1024"
resetprop -n ro.hwui.text_large_cache_width "2048"
resetprop -n ro.hwui.text_large_cache_height "4096"
resetprop -n ro.expect.recovery_id "0x70e53ca1e156a6dca68751d3a51916042b958afb000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-06-01
