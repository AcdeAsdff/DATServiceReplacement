strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "G9 PRO"
resetprop -n ro.product.vendor.model "G9 PRO"
resetprop -n ro.product.vendor_dlkm.marketname "G9 PRO"
resetprop -n ro.product.product.marketname "G9 PRO"
resetprop -n ro.product.system.marketname "G9 PRO"
resetprop -n ro.product.odm_dlkm.marketname "G9 PRO"
resetprop -n ro.product.system_ext.marketname "G9 PRO"
resetprop -n ro.product.odm_dlkm.model "G9 PRO"
resetprop -n ro.product.system.model "G9 PRO"
resetprop -n ro.product.system_ext.model "G9 PRO"
resetprop -n ro.product.vendor_dlkm.model "G9 PRO"
resetprop -n bluetooth.device.default_name "G9 PRO"
resetprop -n ro.product.bootimage.model "G9 PRO"
resetprop -n ro.product.vendor.marketname "G9 PRO"
resetprop -n ro.product.marketname "G9 PRO"
resetprop -n ro.product.odm.model "G9 PRO"
resetprop -n ro.product.model "G9 PRO"
resetprop -n ro.product.product.model "G9 PRO"
resetprop -n ro.product.odm.marketname "G9 PRO"
resetprop -n ro.product.vendor.manufacturer "BLU"
resetprop -n ro.product.product.manufacturer "BLU"
resetprop -n ro.product.bootimage.manufacturer "BLU"
resetprop -n ro.product.manufacturer "BLU"
resetprop -n ro.product.odm.manufacturer "BLU"
resetprop -n ro.product.system.manufacturer "BLU"
resetprop -n ro.product.system_ext.manufacturer "BLU"
resetprop -n ro.product.vendor_dlkm.manufacturer "BLU"
resetprop -n ro.product.vendor.brand "BLU"
resetprop -n ro.product.product.brand "BLU"
resetprop -n ro.product.vendor_dlkm.brand "BLU"
resetprop -n ro.product.system.brand "BLU"
resetprop -n ro.product.bootimage.brand "BLU"
resetprop -n ro.product.system_ext.brand "BLU"
resetprop -n ro.product.odm.brand "BLU"
resetprop -n ro.product.odm_dlkm.brand "BLU"
resetprop -n ro.product.brand "BLU"
resetprop -n ro.vendor_dlkm.build.fingerprint "BLU/G9_PRO/G0230WW:9/PPR1.180610.011/1563446938:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "BLU/G9_PRO/G0230WW:9/PPR1.180610.011/1563446938:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "BLU/G9_PRO/G0230WW:9/PPR1.180610.011/1563446938:user/release-keys"
resetprop -n ro.odm.build.fingerprint "BLU/G9_PRO/G0230WW:9/PPR1.180610.011/1563446938:user/release-keys"
resetprop -n ro.system.build.fingerprint "BLU/G9_PRO/G0230WW:9/PPR1.180610.011/1563446938:user/release-keys"
resetprop -n ro.build.fingerprint "BLU/G9_PRO/G0230WW:9/PPR1.180610.011/1563446938:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "BLU/G9_PRO/G0230WW:9/PPR1.180610.011/1563446938:user/release-keys"
resetprop -n ro.product.build.fingerprint "BLU/G9_PRO/G0230WW:9/PPR1.180610.011/1563446938:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "BLU/G9_PRO/G0230WW:9/PPR1.180610.011/1563446938:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=a47f73d1cd
resetprop -n ro.system.build.version.incremental 1563446938
resetprop -n ro.bootimage.build.version.incremental 1563446938
resetprop -n ro.product.build.version.incremental 1563446938
resetprop -n ro.odm.build.version.incremental 1563446938
resetprop -n ro.vendor_dlkm.build.version.incremental 1563446938
resetprop -n ro.system_ext.build.version.incremental 1563446938
resetprop -n ro.build.version.incremental 1563446938
resetprop -n ro.vendor.build.version.incremental 1563446938
resetprop -n ro.odm.build.id "PPR1.180610.011"
resetprop -n ro.product.build.id "PPR1.180610.011"
resetprop -n ro.bootimage.build.id "PPR1.180610.011"
resetprop -n ro.system_ext.build.id "PPR1.180610.011"
resetprop -n ro.vendor_dlkm.build.id "PPR1.180610.011"
resetprop -n ro.build.id "PPR1.180610.011"
resetprop -n ro.system.build.id "PPR1.180610.011"
resetprop -n ro.vendor.build.id "PPR1.180610.011"
resetprop -n ro.system.build.date "Thu Jul 18 18:44:12 CST 2019"
resetprop -n ro.bootimage.build.date "Thu Jul 18 18:44:12 CST 2019"
resetprop -n ro.product.build.date "Thu Jul 18 18:44:12 CST 2019"
resetprop -n ro.vendor_dlkm.build.date "Thu Jul 18 18:44:12 CST 2019"
resetprop -n ro.system_ext.build.date "Thu Jul 18 18:44:12 CST 2019"
resetprop -n ro.odm.build.date "Thu Jul 18 18:44:12 CST 2019"
resetprop -n ro.build.date "Thu Jul 18 18:44:12 CST 2019"
resetprop -n ro.vendor.build.date "Thu Jul 18 18:44:12 CST 2019"
resetprop -n ro.product.build.date.utc "1563446652"
resetprop -n ro.system_ext.build.date.utc "1563446652"
resetprop -n ro.system.build.date.utc "1563446652"
resetprop -n ro.vendor.build.date.utc "1563446652"
resetprop -n ro.vendor_dlkm.build.date.utc "1563446652"
resetprop -n ro.build.date.utc "1563446652"
resetprop -n ro.bootimage.build.date.utc "1563446652"
resetprop -n ro.odm.build.date.utc "1563446652"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name G9_PRO
resetprop -n ro.product.odm.name G9_PRO
resetprop -n ro.product.vendor.name G9_PRO
resetprop -n ro.product.system.name G9_PRO
resetprop -n ro.product.name G9_PRO
resetprop -n ro.product.bootimage.name G9_PRO
resetprop -n ro.product.vendor_dlkm.name G9_PRO
resetprop -n ro.product.system_ext.name G9_PRO
resetprop -n ro.build.flavor full_k71v1_64_bsp-user
randomStr="full_k71v1_64_bsp-user BLU PPR1.180610.011 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=20df2bb073b3
resetprop -n ro.build.host ${randomStr}
randomStr=064d085a
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=BFaZfJ
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=0fd0630d1f538
randomStr2=b3
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=0b
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1563446938"
resetprop -n ro.build.description "full_k71v1_64_bsp-user 9 PPR1.180610.011 1563446938 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "wuliang"
resetprop -n ro.build.host "pri"
resetprop -n ro.build.product.backup "G0230WW"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.expect.recovery_id "0x8259a3c8cf0cdc7df8a9d82a4b5a51ede112ab9e000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-06-05
