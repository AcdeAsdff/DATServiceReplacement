strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Chromecast HD"
resetprop -n ro.product.vendor.model "Chromecast HD"
resetprop -n ro.product.vendor_dlkm.marketname "Chromecast HD"
resetprop -n ro.product.product.marketname "Chromecast HD"
resetprop -n ro.product.system.marketname "Chromecast HD"
resetprop -n ro.product.odm_dlkm.marketname "Chromecast HD"
resetprop -n ro.product.system_ext.marketname "Chromecast HD"
resetprop -n ro.product.odm_dlkm.model "Chromecast HD"
resetprop -n ro.product.system.model "Chromecast HD"
resetprop -n ro.product.system_ext.model "Chromecast HD"
resetprop -n ro.product.vendor_dlkm.model "Chromecast HD"
resetprop -n bluetooth.device.default_name "Chromecast HD"
resetprop -n ro.product.bootimage.model "Chromecast HD"
resetprop -n ro.product.vendor.marketname "Chromecast HD"
resetprop -n ro.product.marketname "Chromecast HD"
resetprop -n ro.product.odm.model "Chromecast HD"
resetprop -n ro.product.model "Chromecast HD"
resetprop -n ro.product.product.model "Chromecast HD"
resetprop -n ro.product.odm.marketname "Chromecast HD"
resetprop -n ro.product.vendor.manufacturer "Google"
resetprop -n ro.product.product.manufacturer "Google"
resetprop -n ro.product.bootimage.manufacturer "Google"
resetprop -n ro.product.manufacturer "Google"
resetprop -n ro.product.odm.manufacturer "Google"
resetprop -n ro.product.system.manufacturer "Google"
resetprop -n ro.product.system_ext.manufacturer "Google"
resetprop -n ro.product.vendor_dlkm.manufacturer "Google"
resetprop -n ro.product.vendor.brand "google"
resetprop -n ro.product.product.brand "google"
resetprop -n ro.product.vendor_dlkm.brand "google"
resetprop -n ro.product.system.brand "google"
resetprop -n ro.product.bootimage.brand "google"
resetprop -n ro.product.system_ext.brand "google"
resetprop -n ro.product.odm.brand "google"
resetprop -n ro.product.odm_dlkm.brand "google"
resetprop -n ro.product.brand "google"
resetprop -n ro.vendor_dlkm.build.fingerprint "google/boreal/boreal:12/STTE.230915.005.T1/11052325:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "google/boreal/boreal:12/STTE.230915.005.T1/11052325:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "google/boreal/boreal:12/STTE.230915.005.T1/11052325:user/release-keys"
resetprop -n ro.odm.build.fingerprint "google/boreal/boreal:12/STTE.230915.005.T1/11052325:user/release-keys"
resetprop -n ro.system.build.fingerprint "google/boreal/boreal:12/STTE.230915.005.T1/11052325:user/release-keys"
resetprop -n ro.build.fingerprint "google/boreal/boreal:12/STTE.230915.005.T1/11052325:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "google/boreal/boreal:12/STTE.230915.005.T1/11052325:user/release-keys"
resetprop -n ro.product.build.fingerprint "google/boreal/boreal:12/STTE.230915.005.T1/11052325:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "google/boreal/boreal:12/STTE.230915.005.T1/11052325:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=8f0da88157
resetprop -n ro.system.build.version.incremental 11052325
resetprop -n ro.bootimage.build.version.incremental 11052325
resetprop -n ro.product.build.version.incremental 11052325
resetprop -n ro.odm.build.version.incremental 11052325
resetprop -n ro.vendor_dlkm.build.version.incremental 11052325
resetprop -n ro.system_ext.build.version.incremental 11052325
resetprop -n ro.build.version.incremental 11052325
resetprop -n ro.vendor.build.version.incremental 11052325
resetprop -n ro.odm.build.id "STTE.230915.005.T1"
resetprop -n ro.product.build.id "STTE.230915.005.T1"
resetprop -n ro.bootimage.build.id "STTE.230915.005.T1"
resetprop -n ro.system_ext.build.id "STTE.230915.005.T1"
resetprop -n ro.vendor_dlkm.build.id "STTE.230915.005.T1"
resetprop -n ro.build.id "STTE.230915.005.T1"
resetprop -n ro.system.build.id "STTE.230915.005.T1"
resetprop -n ro.vendor.build.id "STTE.230915.005.T1"
resetprop -n ro.system.build.date "Sat Nov  4 13:06:05 UTC 2023"
resetprop -n ro.bootimage.build.date "Sat Nov  4 13:06:05 UTC 2023"
resetprop -n ro.product.build.date "Sat Nov  4 13:06:05 UTC 2023"
resetprop -n ro.vendor_dlkm.build.date "Sat Nov  4 13:06:05 UTC 2023"
resetprop -n ro.system_ext.build.date "Sat Nov  4 13:06:05 UTC 2023"
resetprop -n ro.odm.build.date "Sat Nov  4 13:06:05 UTC 2023"
resetprop -n ro.build.date "Sat Nov  4 13:06:05 UTC 2023"
resetprop -n ro.vendor.build.date "Sat Nov  4 13:06:05 UTC 2023"
resetprop -n ro.product.build.date.utc "1699103165"
resetprop -n ro.system_ext.build.date.utc "1699103165"
resetprop -n ro.system.build.date.utc "1699103165"
resetprop -n ro.vendor.build.date.utc "1699103165"
resetprop -n ro.vendor_dlkm.build.date.utc "1699103165"
resetprop -n ro.build.date.utc "1699103165"
resetprop -n ro.bootimage.build.date.utc "1699103165"
resetprop -n ro.odm.build.date.utc "1699103165"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name boreal
resetprop -n ro.product.odm.name boreal
resetprop -n ro.product.vendor.name boreal
resetprop -n ro.product.system.name boreal
resetprop -n ro.product.name boreal
resetprop -n ro.product.bootimage.name boreal
resetprop -n ro.product.vendor_dlkm.name boreal
resetprop -n ro.product.system_ext.name boreal
resetprop -n ro.build.flavor boreal-user
randomStr="boreal-user Google STTE.230915.005.T1 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=4ffba01dc609
resetprop -n ro.build.host ${randomStr}
randomStr=1a16f70d
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=YpTTyL
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=0e42b61ebf0a0
randomStr2=f8
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=b6
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "11052325"
resetprop -n ro.build.description "boreal-user 12 STTE.230915.005.T1 11052325 release-keys"
resetprop -n ro.build.product.backup "boreal"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "android-build"
resetprop -n ro.build.host "abfarm-release-2004-0115"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2023-10-01
