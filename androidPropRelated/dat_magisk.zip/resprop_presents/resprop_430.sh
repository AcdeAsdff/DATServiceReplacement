strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Infinix X650C"
resetprop -n ro.product.vendor.model "Infinix X650C"
resetprop -n ro.product.vendor_dlkm.marketname "Infinix X650C"
resetprop -n ro.product.product.marketname "Infinix X650C"
resetprop -n ro.product.system.marketname "Infinix X650C"
resetprop -n ro.product.odm_dlkm.marketname "Infinix X650C"
resetprop -n ro.product.system_ext.marketname "Infinix X650C"
resetprop -n ro.product.odm_dlkm.model "Infinix X650C"
resetprop -n ro.product.system.model "Infinix X650C"
resetprop -n ro.product.system_ext.model "Infinix X650C"
resetprop -n ro.product.vendor_dlkm.model "Infinix X650C"
resetprop -n bluetooth.device.default_name "Infinix X650C"
resetprop -n ro.product.bootimage.model "Infinix X650C"
resetprop -n ro.product.vendor.marketname "Infinix X650C"
resetprop -n ro.product.marketname "Infinix X650C"
resetprop -n ro.product.odm.model "Infinix X650C"
resetprop -n ro.product.model "Infinix X650C"
resetprop -n ro.product.product.model "Infinix X650C"
resetprop -n ro.product.odm.marketname "Infinix X650C"
resetprop -n ro.product.vendor.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.product.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.bootimage.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.odm.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.system.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.system_ext.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.vendor_dlkm.manufacturer "INFINIX MOBILITY LIMITED"
resetprop -n ro.product.vendor.brand "Infinix"
resetprop -n ro.product.product.brand "Infinix"
resetprop -n ro.product.vendor_dlkm.brand "Infinix"
resetprop -n ro.product.system.brand "Infinix"
resetprop -n ro.product.bootimage.brand "Infinix"
resetprop -n ro.product.system_ext.brand "Infinix"
resetprop -n ro.product.odm.brand "Infinix"
resetprop -n ro.product.odm_dlkm.brand "Infinix"
resetprop -n ro.product.brand "Infinix"
resetprop -n ro.vendor_dlkm.build.fingerprint "Infinix/H626/Infinix-X650C:9/PPR1.180610.011/DE-190807V174:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Infinix/H626/Infinix-X650C:9/PPR1.180610.011/DE-190807V174:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Infinix/H626/Infinix-X650C:9/PPR1.180610.011/DE-190807V174:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Infinix/H626/Infinix-X650C:9/PPR1.180610.011/DE-190807V174:user/release-keys"
resetprop -n ro.system.build.fingerprint "Infinix/H626/Infinix-X650C:9/PPR1.180610.011/DE-190807V174:user/release-keys"
resetprop -n ro.build.fingerprint "Infinix/H626/Infinix-X650C:9/PPR1.180610.011/DE-190807V174:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Infinix/H626/Infinix-X650C:9/PPR1.180610.011/DE-190807V174:user/release-keys"
resetprop -n ro.product.build.fingerprint "Infinix/H626/Infinix-X650C:9/PPR1.180610.011/DE-190807V174:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Infinix/H626/Infinix-X650C:9/PPR1.180610.011/DE-190807V174:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=5ad66ae23e
resetprop -n ro.system.build.version.incremental DE-190807V174
resetprop -n ro.bootimage.build.version.incremental DE-190807V174
resetprop -n ro.product.build.version.incremental DE-190807V174
resetprop -n ro.odm.build.version.incremental DE-190807V174
resetprop -n ro.vendor_dlkm.build.version.incremental DE-190807V174
resetprop -n ro.system_ext.build.version.incremental DE-190807V174
resetprop -n ro.build.version.incremental DE-190807V174
resetprop -n ro.vendor.build.version.incremental DE-190807V174
resetprop -n ro.odm.build.id "PPR1.180610.011"
resetprop -n ro.product.build.id "PPR1.180610.011"
resetprop -n ro.bootimage.build.id "PPR1.180610.011"
resetprop -n ro.system_ext.build.id "PPR1.180610.011"
resetprop -n ro.vendor_dlkm.build.id "PPR1.180610.011"
resetprop -n ro.build.id "PPR1.180610.011"
resetprop -n ro.system.build.id "PPR1.180610.011"
resetprop -n ro.vendor.build.id "PPR1.180610.011"
resetprop -n ro.system.build.date "Wed Aug  7 18:40:44 CST 2019"
resetprop -n ro.bootimage.build.date "Wed Aug  7 18:40:44 CST 2019"
resetprop -n ro.product.build.date "Wed Aug  7 18:40:44 CST 2019"
resetprop -n ro.vendor_dlkm.build.date "Wed Aug  7 18:40:44 CST 2019"
resetprop -n ro.system_ext.build.date "Wed Aug  7 18:40:44 CST 2019"
resetprop -n ro.odm.build.date "Wed Aug  7 18:40:44 CST 2019"
resetprop -n ro.build.date "Wed Aug  7 18:40:44 CST 2019"
resetprop -n ro.vendor.build.date "Wed Aug  7 18:40:44 CST 2019"
resetprop -n ro.product.build.date.utc "1565174444"
resetprop -n ro.system_ext.build.date.utc "1565174444"
resetprop -n ro.system.build.date.utc "1565174444"
resetprop -n ro.vendor.build.date.utc "1565174444"
resetprop -n ro.vendor_dlkm.build.date.utc "1565174444"
resetprop -n ro.build.date.utc "1565174444"
resetprop -n ro.bootimage.build.date.utc "1565174444"
resetprop -n ro.odm.build.date.utc "1565174444"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name H626
resetprop -n ro.product.odm.name H626
resetprop -n ro.product.vendor.name H626
resetprop -n ro.product.system.name H626
resetprop -n ro.product.name H626
resetprop -n ro.product.bootimage.name H626
resetprop -n ro.product.vendor_dlkm.name H626
resetprop -n ro.product.system_ext.name H626
resetprop -n ro.build.flavor full_x650c_h626-user
randomStr="full_x650c_h626-user INFINIX MOBILITY LIMITED PPR1.180610.011 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=d9ccf21ebdf9
resetprop -n ro.build.host ${randomStr}
randomStr=8be39e48
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=FOqYnY
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=47c4444849bac
randomStr2=0d
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=3f
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "DE-190807V174"
resetprop -n ro.build.description "full_x650c_h626-user 9 PPR1.180610.011 38028 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "buildsrv-95"
resetprop -n ro.build.host "buildsrv-95"
resetprop -n ro.build.product.backup "x650c_h626"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.mediatek.version.release "X650C-H626DE-P-190807V174"
resetprop -n ro.expect.recovery_id "0xe17dd34e68888a85cbece95b9be3e5650869dfb6000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-08-05
