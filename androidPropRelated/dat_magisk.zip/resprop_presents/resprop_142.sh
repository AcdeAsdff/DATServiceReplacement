strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "E"
resetprop -n ro.product.vendor.model "E"
resetprop -n ro.product.vendor_dlkm.marketname "E"
resetprop -n ro.product.product.marketname "E"
resetprop -n ro.product.system.marketname "E"
resetprop -n ro.product.odm_dlkm.marketname "E"
resetprop -n ro.product.system_ext.marketname "E"
resetprop -n ro.product.odm_dlkm.model "E"
resetprop -n ro.product.system.model "E"
resetprop -n ro.product.system_ext.model "E"
resetprop -n ro.product.vendor_dlkm.model "E"
resetprop -n bluetooth.device.default_name "E"
resetprop -n ro.product.bootimage.model "E"
resetprop -n ro.product.vendor.marketname "E"
resetprop -n ro.product.marketname "E"
resetprop -n ro.product.odm.model "E"
resetprop -n ro.product.model "E"
resetprop -n ro.product.product.model "E"
resetprop -n ro.product.odm.marketname "E"
resetprop -n ro.product.vendor.manufacturer "10or"
resetprop -n ro.product.product.manufacturer "10or"
resetprop -n ro.product.bootimage.manufacturer "10or"
resetprop -n ro.product.manufacturer "10or"
resetprop -n ro.product.odm.manufacturer "10or"
resetprop -n ro.product.system.manufacturer "10or"
resetprop -n ro.product.system_ext.manufacturer "10or"
resetprop -n ro.product.vendor_dlkm.manufacturer "10or"
resetprop -n ro.product.vendor.brand "10or"
resetprop -n ro.product.product.brand "10or"
resetprop -n ro.product.vendor_dlkm.brand "10or"
resetprop -n ro.product.system.brand "10or"
resetprop -n ro.product.bootimage.brand "10or"
resetprop -n ro.product.system_ext.brand "10or"
resetprop -n ro.product.odm.brand "10or"
resetprop -n ro.product.odm_dlkm.brand "10or"
resetprop -n ro.product.brand "10or"
resetprop -n ro.vendor_dlkm.build.fingerprint "10or/E/E:8.1.0/OPM1.171019.019/10or_E_V1_0_109:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "10or/E/E:8.1.0/OPM1.171019.019/10or_E_V1_0_109:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "10or/E/E:8.1.0/OPM1.171019.019/10or_E_V1_0_109:user/release-keys"
resetprop -n ro.odm.build.fingerprint "10or/E/E:8.1.0/OPM1.171019.019/10or_E_V1_0_109:user/release-keys"
resetprop -n ro.system.build.fingerprint "10or/E/E:8.1.0/OPM1.171019.019/10or_E_V1_0_109:user/release-keys"
resetprop -n ro.build.fingerprint "10or/E/E:8.1.0/OPM1.171019.019/10or_E_V1_0_109:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "10or/E/E:8.1.0/OPM1.171019.019/10or_E_V1_0_109:user/release-keys"
resetprop -n ro.product.build.fingerprint "10or/E/E:8.1.0/OPM1.171019.019/10or_E_V1_0_109:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "10or/E/E:8.1.0/OPM1.171019.019/10or_E_V1_0_109:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=b1204d80c4
resetprop -n ro.system.build.version.incremental 10or_E_V1_0_109
resetprop -n ro.bootimage.build.version.incremental 10or_E_V1_0_109
resetprop -n ro.product.build.version.incremental 10or_E_V1_0_109
resetprop -n ro.odm.build.version.incremental 10or_E_V1_0_109
resetprop -n ro.vendor_dlkm.build.version.incremental 10or_E_V1_0_109
resetprop -n ro.system_ext.build.version.incremental 10or_E_V1_0_109
resetprop -n ro.build.version.incremental 10or_E_V1_0_109
resetprop -n ro.vendor.build.version.incremental 10or_E_V1_0_109
resetprop -n ro.odm.build.id "OPM1.171019.019"
resetprop -n ro.product.build.id "OPM1.171019.019"
resetprop -n ro.bootimage.build.id "OPM1.171019.019"
resetprop -n ro.system_ext.build.id "OPM1.171019.019"
resetprop -n ro.vendor_dlkm.build.id "OPM1.171019.019"
resetprop -n ro.build.id "OPM1.171019.019"
resetprop -n ro.system.build.id "OPM1.171019.019"
resetprop -n ro.vendor.build.id "OPM1.171019.019"
resetprop -n ro.system.build.date "Wed Jan 30 15:04:02 CST 2019"
resetprop -n ro.bootimage.build.date "Wed Jan 30 15:04:02 CST 2019"
resetprop -n ro.product.build.date "Wed Jan 30 15:04:02 CST 2019"
resetprop -n ro.vendor_dlkm.build.date "Wed Jan 30 15:04:02 CST 2019"
resetprop -n ro.system_ext.build.date "Wed Jan 30 15:04:02 CST 2019"
resetprop -n ro.odm.build.date "Wed Jan 30 15:04:02 CST 2019"
resetprop -n ro.build.date "Wed Jan 30 15:04:02 CST 2019"
resetprop -n ro.vendor.build.date "Wed Jan 30 15:04:02 CST 2019"
resetprop -n ro.product.build.date.utc "1548831842"
resetprop -n ro.system_ext.build.date.utc "1548831842"
resetprop -n ro.system.build.date.utc "1548831842"
resetprop -n ro.vendor.build.date.utc "1548831842"
resetprop -n ro.vendor_dlkm.build.date.utc "1548831842"
resetprop -n ro.build.date.utc "1548831842"
resetprop -n ro.bootimage.build.date.utc "1548831842"
resetprop -n ro.odm.build.date.utc "1548831842"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name E
resetprop -n ro.product.odm.name E
resetprop -n ro.product.vendor.name E
resetprop -n ro.product.system.name E
resetprop -n ro.product.name E
resetprop -n ro.product.bootimage.name E
resetprop -n ro.product.vendor_dlkm.name E
resetprop -n ro.product.system_ext.name E
resetprop -n ro.build.flavor zql1520-user
randomStr="zql1520-user 10or OPM1.171019.019 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=d4fab8247d68
resetprop -n ro.build.host ${randomStr}
randomStr=cdad4265
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=PchFZi
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=9c5c925596be8
randomStr2=c4
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=87
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "10or_E_V1_0_109"
resetprop -n ro.build.description "E-user 8.1.0 OPM1.171019.019 10or_E_V1_0_109 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "queen"
resetprop -n ro.build.host "64a35b447466"
resetprop -n ro.build.product.backup "E"
resetprop -n ro.build.characteristics "nosdcard"
resetprop -n media.msm8956hw "0"
resetprop -n media.aac_51_output_enabled "true"
resetprop -n media.settings.xml "/vendor/etc/media_profiles_vendor.xml"
resetprop -n ro.hwui.texture_cache_size "72"
resetprop -n ro.hwui.layer_cache_size "48"
resetprop -n ro.hwui.r_buffer_cache_size "8"
resetprop -n ro.hwui.path_cache_size "32"
resetprop -n ro.hwui.gradient_cache_size "1"
resetprop -n ro.hwui.drop_shadow_cache_size "6"
resetprop -n ro.hwui.texture_cache_flushrate "0.4"
resetprop -n ro.hwui.text_small_cache_width "1024"
resetprop -n ro.hwui.text_small_cache_height "1024"
resetprop -n ro.hwui.text_large_cache_width "2048"
resetprop -n ro.hwui.text_large_cache_height "2048"
resetprop -n ro.com.google.clientidbase "android-huaqin"
resetprop -n ro.com.google.gmsversion "8.1_201812"
resetprop -n ro.expect.recovery_id "0x52a3859a5ee7fbd036f632d5e11464edb62a9240000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-02-01
