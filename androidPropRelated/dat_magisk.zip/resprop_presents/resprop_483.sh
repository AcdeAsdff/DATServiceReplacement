strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "LAVA LXX503"
resetprop -n ro.product.vendor.model "LAVA LXX503"
resetprop -n ro.product.vendor_dlkm.marketname "LAVA LXX503"
resetprop -n ro.product.product.marketname "LAVA LXX503"
resetprop -n ro.product.system.marketname "LAVA LXX503"
resetprop -n ro.product.odm_dlkm.marketname "LAVA LXX503"
resetprop -n ro.product.system_ext.marketname "LAVA LXX503"
resetprop -n ro.product.odm_dlkm.model "LAVA LXX503"
resetprop -n ro.product.system.model "LAVA LXX503"
resetprop -n ro.product.system_ext.model "LAVA LXX503"
resetprop -n ro.product.vendor_dlkm.model "LAVA LXX503"
resetprop -n bluetooth.device.default_name "LAVA LXX503"
resetprop -n ro.product.bootimage.model "LAVA LXX503"
resetprop -n ro.product.vendor.marketname "LAVA LXX503"
resetprop -n ro.product.marketname "LAVA LXX503"
resetprop -n ro.product.odm.model "LAVA LXX503"
resetprop -n ro.product.model "LAVA LXX503"
resetprop -n ro.product.product.model "LAVA LXX503"
resetprop -n ro.product.odm.marketname "LAVA LXX503"
resetprop -n ro.product.vendor.manufacturer "LAVA"
resetprop -n ro.product.product.manufacturer "LAVA"
resetprop -n ro.product.bootimage.manufacturer "LAVA"
resetprop -n ro.product.manufacturer "LAVA"
resetprop -n ro.product.odm.manufacturer "LAVA"
resetprop -n ro.product.system.manufacturer "LAVA"
resetprop -n ro.product.system_ext.manufacturer "LAVA"
resetprop -n ro.product.vendor_dlkm.manufacturer "LAVA"
resetprop -n ro.product.vendor.brand "LAVA"
resetprop -n ro.product.product.brand "LAVA"
resetprop -n ro.product.vendor_dlkm.brand "LAVA"
resetprop -n ro.product.system.brand "LAVA"
resetprop -n ro.product.bootimage.brand "LAVA"
resetprop -n ro.product.system_ext.brand "LAVA"
resetprop -n ro.product.odm.brand "LAVA"
resetprop -n ro.product.odm_dlkm.brand "LAVA"
resetprop -n ro.product.brand "LAVA"
resetprop -n ro.vendor_dlkm.build.fingerprint "LAVA/LXX503/LXX503:13/TP1A.220624.014/1706942229:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "LAVA/LXX503/LXX503:13/TP1A.220624.014/1706942229:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "LAVA/LXX503/LXX503:13/TP1A.220624.014/1706942229:user/release-keys"
resetprop -n ro.odm.build.fingerprint "LAVA/LXX503/LXX503:13/TP1A.220624.014/1706942229:user/release-keys"
resetprop -n ro.system.build.fingerprint "LAVA/LXX503/LXX503:13/TP1A.220624.014/1706942229:user/release-keys"
resetprop -n ro.build.fingerprint "LAVA/LXX503/LXX503:13/TP1A.220624.014/1706942229:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "LAVA/LXX503/LXX503:13/TP1A.220624.014/1706942229:user/release-keys"
resetprop -n ro.product.build.fingerprint "LAVA/LXX503/LXX503:13/TP1A.220624.014/1706942229:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "LAVA/LXX503/LXX503:13/TP1A.220624.014/1706942229:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=3a9f716e3e
resetprop -n ro.system.build.version.incremental 1706942229
resetprop -n ro.bootimage.build.version.incremental 1706942229
resetprop -n ro.product.build.version.incremental 1706942229
resetprop -n ro.odm.build.version.incremental 1706942229
resetprop -n ro.vendor_dlkm.build.version.incremental 1706942229
resetprop -n ro.system_ext.build.version.incremental 1706942229
resetprop -n ro.build.version.incremental 1706942229
resetprop -n ro.vendor.build.version.incremental 1706942229
resetprop -n ro.odm.build.id "TP1A.220624.014"
resetprop -n ro.product.build.id "TP1A.220624.014"
resetprop -n ro.bootimage.build.id "TP1A.220624.014"
resetprop -n ro.system_ext.build.id "TP1A.220624.014"
resetprop -n ro.vendor_dlkm.build.id "TP1A.220624.014"
resetprop -n ro.build.id "TP1A.220624.014"
resetprop -n ro.system.build.id "TP1A.220624.014"
resetprop -n ro.vendor.build.id "TP1A.220624.014"
resetprop -n ro.system.build.date "Sat Feb  3 14:37:09 CST 2024"
resetprop -n ro.bootimage.build.date "Sat Feb  3 14:37:09 CST 2024"
resetprop -n ro.product.build.date "Sat Feb  3 14:37:09 CST 2024"
resetprop -n ro.vendor_dlkm.build.date "Sat Feb  3 14:37:09 CST 2024"
resetprop -n ro.system_ext.build.date "Sat Feb  3 14:37:09 CST 2024"
resetprop -n ro.odm.build.date "Sat Feb  3 14:37:09 CST 2024"
resetprop -n ro.build.date "Sat Feb  3 14:37:09 CST 2024"
resetprop -n ro.vendor.build.date "Sat Feb  3 14:37:09 CST 2024"
resetprop -n ro.product.build.date.utc "1706942229"
resetprop -n ro.system_ext.build.date.utc "1706942229"
resetprop -n ro.system.build.date.utc "1706942229"
resetprop -n ro.vendor.build.date.utc "1706942229"
resetprop -n ro.vendor_dlkm.build.date.utc "1706942229"
resetprop -n ro.build.date.utc "1706942229"
resetprop -n ro.bootimage.build.date.utc "1706942229"
resetprop -n ro.odm.build.date.utc "1706942229"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name LXX503
resetprop -n ro.product.odm.name LXX503
resetprop -n ro.product.vendor.name LXX503
resetprop -n ro.product.system.name LXX503
resetprop -n ro.product.name LXX503
resetprop -n ro.product.bootimage.name LXX503
resetprop -n ro.product.vendor_dlkm.name LXX503
resetprop -n ro.product.system_ext.name LXX503
resetprop -n ro.build.flavor sys_mssi_64_ww_armv82-user
randomStr="sys_mssi_64_ww_armv82-user LAVA TP1A.220624.014 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=4af067c1ca50
resetprop -n ro.build.host ${randomStr}
randomStr=c4a854eb
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=pqEZSP
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=aab6abf9e9ef4
randomStr2=37
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=90
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1706942229"
resetprop -n ro.build.description "LXX503-user 13 TP1A.220624.014 1706944073 release-keys"
resetprop -n ro.build.product.backup "LXX503"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "pri"
resetprop -n ro.build.host "bs"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.vendor.mtk_miravision_support "1"
resetprop -n ro.mediatek.version.branch "alps-mp-t0.mssi1"
resetprop -n ro.mediatek.version.release "alps-mp-t0.mp1.rc-V11.40.t0mp1rc.k6985v1.64_P14"
resetprop -n ro.vendor.mtk_omacp_support "1"
resetprop -n ro.vendor.mtk_flv_playback_support "1"
resetprop -n ro.vendor.mtk_telephony_add_on_policy "0"
resetprop -n persist.vendor.mtk_rcs_single_reg_support "1"
resetprop -n media.stagefright.thumbnail.prefer_hw_codecs "true"
resetprop -n vendor.mtk_thumbnail_optimization "true"
resetprop -n ro.vendor.mtk_power_off_alarm_test "1"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2024-01-05
