strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "M5 Note"
resetprop -n ro.product.vendor.model "M5 Note"
resetprop -n ro.product.vendor_dlkm.marketname "M5 Note"
resetprop -n ro.product.product.marketname "M5 Note"
resetprop -n ro.product.system.marketname "M5 Note"
resetprop -n ro.product.odm_dlkm.marketname "M5 Note"
resetprop -n ro.product.system_ext.marketname "M5 Note"
resetprop -n ro.product.odm_dlkm.model "M5 Note"
resetprop -n ro.product.system.model "M5 Note"
resetprop -n ro.product.system_ext.model "M5 Note"
resetprop -n ro.product.vendor_dlkm.model "M5 Note"
resetprop -n bluetooth.device.default_name "M5 Note"
resetprop -n ro.product.bootimage.model "M5 Note"
resetprop -n ro.product.vendor.marketname "M5 Note"
resetprop -n ro.product.marketname "M5 Note"
resetprop -n ro.product.odm.model "M5 Note"
resetprop -n ro.product.model "M5 Note"
resetprop -n ro.product.product.model "M5 Note"
resetprop -n ro.product.odm.marketname "M5 Note"
resetprop -n ro.product.vendor.manufacturer "Meizu"
resetprop -n ro.product.product.manufacturer "Meizu"
resetprop -n ro.product.bootimage.manufacturer "Meizu"
resetprop -n ro.product.manufacturer "Meizu"
resetprop -n ro.product.odm.manufacturer "Meizu"
resetprop -n ro.product.system.manufacturer "Meizu"
resetprop -n ro.product.system_ext.manufacturer "Meizu"
resetprop -n ro.product.vendor_dlkm.manufacturer "Meizu"
resetprop -n ro.product.vendor.brand "Meizu"
resetprop -n ro.product.product.brand "Meizu"
resetprop -n ro.product.vendor_dlkm.brand "Meizu"
resetprop -n ro.product.system.brand "Meizu"
resetprop -n ro.product.bootimage.brand "Meizu"
resetprop -n ro.product.system_ext.brand "Meizu"
resetprop -n ro.product.odm.brand "Meizu"
resetprop -n ro.product.odm_dlkm.brand "Meizu"
resetprop -n ro.product.brand "Meizu"
resetprop -n ro.vendor_dlkm.build.fingerprint "Meizu/M1621/M1621:6.0/MRA58K/1490176951:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Meizu/M1621/M1621:6.0/MRA58K/1490176951:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Meizu/M1621/M1621:6.0/MRA58K/1490176951:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Meizu/M1621/M1621:6.0/MRA58K/1490176951:user/release-keys"
resetprop -n ro.system.build.fingerprint "Meizu/M1621/M1621:6.0/MRA58K/1490176951:user/release-keys"
resetprop -n ro.build.fingerprint "Meizu/M1621/M1621:6.0/MRA58K/1490176951:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Meizu/M1621/M1621:6.0/MRA58K/1490176951:user/release-keys"
resetprop -n ro.product.build.fingerprint "Meizu/M1621/M1621:6.0/MRA58K/1490176951:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Meizu/M1621/M1621:6.0/MRA58K/1490176951:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=eebc6b2406
resetprop -n ro.system.build.version.incremental 1490176951
resetprop -n ro.bootimage.build.version.incremental 1490176951
resetprop -n ro.product.build.version.incremental 1490176951
resetprop -n ro.odm.build.version.incremental 1490176951
resetprop -n ro.vendor_dlkm.build.version.incremental 1490176951
resetprop -n ro.system_ext.build.version.incremental 1490176951
resetprop -n ro.build.version.incremental 1490176951
resetprop -n ro.vendor.build.version.incremental 1490176951
resetprop -n ro.odm.build.id "MRA58K"
resetprop -n ro.product.build.id "MRA58K"
resetprop -n ro.bootimage.build.id "MRA58K"
resetprop -n ro.system_ext.build.id "MRA58K"
resetprop -n ro.vendor_dlkm.build.id "MRA58K"
resetprop -n ro.build.id "MRA58K"
resetprop -n ro.system.build.id "MRA58K"
resetprop -n ro.vendor.build.id "MRA58K"
resetprop -n ro.system.build.date "2017年 03月 22日 星期三 18:09:33 CST"
resetprop -n ro.bootimage.build.date "2017年 03月 22日 星期三 18:09:33 CST"
resetprop -n ro.product.build.date "2017年 03月 22日 星期三 18:09:33 CST"
resetprop -n ro.vendor_dlkm.build.date "2017年 03月 22日 星期三 18:09:33 CST"
resetprop -n ro.system_ext.build.date "2017年 03月 22日 星期三 18:09:33 CST"
resetprop -n ro.odm.build.date "2017年 03月 22日 星期三 18:09:33 CST"
resetprop -n ro.build.date "2017年 03月 22日 星期三 18:09:33 CST"
resetprop -n ro.vendor.build.date "2017年 03月 22日 星期三 18:09:33 CST"
resetprop -n ro.product.build.date.utc "1490177373"
resetprop -n ro.system_ext.build.date.utc "1490177373"
resetprop -n ro.system.build.date.utc "1490177373"
resetprop -n ro.vendor.build.date.utc "1490177373"
resetprop -n ro.vendor_dlkm.build.date.utc "1490177373"
resetprop -n ro.build.date.utc "1490177373"
resetprop -n ro.bootimage.build.date.utc "1490177373"
resetprop -n ro.odm.build.date.utc "1490177373"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name meizu_M5 Note
resetprop -n ro.product.odm.name meizu_M5 Note
resetprop -n ro.product.vendor.name meizu_M5 Note
resetprop -n ro.product.system.name meizu_M5 Note
resetprop -n ro.product.name meizu_M5 Note
resetprop -n ro.product.bootimage.name meizu_M5 Note
resetprop -n ro.product.vendor_dlkm.name meizu_M5 Note
resetprop -n ro.product.system_ext.name meizu_M5 Note
resetprop -n ro.build.flavor full_wt6755_66_n5_m-user
randomStr="full_wt6755_66_n5_m-user Meizu MRA58K "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=6cd014a208ce
resetprop -n ro.build.host ${randomStr}
randomStr=bb4da2e8
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=JNtXYO
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=d615684112dba
randomStr2=97
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=99
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1490176951"
resetprop -n ro.build.description "M1621-user 6.0 MRA58K 1490176951 release-keys"
resetprop -n ro.meizu.build.spt "0"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "flyme"
resetprop -n ro.build.host "Mz-Builder-l7"
resetprop -n ro.product.flyme.model "1621"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.build.product.backup "M5 Note"
resetprop -n ro.meizu.product.model "M5 Note"
resetprop -n ro.flyme.published  " true"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.mediatek.chip_ver "S01"
resetprop -n ro.mediatek.platform "MT6755"
resetprop -n ro.mtk_cam_lomo_support "1"
resetprop -n ro.mediatek.gemini_support "true"
resetprop -n ro.mediatek.version.branch "alps-mp-m0.mp7"
resetprop -n ro.mediatek.version.release "alps-mp-m0.mp7-V2.3.1_wt6755.66.n5.m_P92"
resetprop -n ro.mediatek.version.sdk "4"
resetprop -n ro.mtk_gemini_support "1"
resetprop -n ro.mtk_audenh_support "1"
resetprop -n ro.mtk_besloudness_support "1"
resetprop -n ro.mtk_bessurround_support "1"
resetprop -n ro.mtk_wapi_support "1"
resetprop -n ro.mtk_bt_support "1"
resetprop -n ro.mtk_wappush_support "1"
resetprop -n ro.mtk_agps_app "1"
resetprop -n ro.mtk_audio_tuning_tool_ver "V2.2"
resetprop -n ro.mtk_matv_analog_support "1"
resetprop -n ro.mtk_wlan_support "1"
resetprop -n ro.mtk_gps_support "1"
resetprop -n ro.mtk_omacp_support "1"
resetprop -n ro.mtk_search_db_support "1"
resetprop -n ro.mtk_dialer_search_support "1"
resetprop -n ro.mtk_dhcpv6c_wifi "1"
resetprop -n ro.mtk_fd_support "1"
resetprop -n ro.mtk_oma_drm_support "1"
resetprop -n ro.mtk_cta_drm_support "1"
resetprop -n ro.mtk_widevine_drm_l3_support "1"
resetprop -n ro.mtk_eap_sim_aka "1"
resetprop -n ro.mtk_fm_recording_support "1"
resetprop -n ro.mtk_audio_ape_support "1"
resetprop -n ro.mtk_flv_playback_support "1"
resetprop -n ro.mtk_wmv_playback_support "1"
resetprop -n ro.mtk_send_rr_support "1"
resetprop -n ro.mtk_emmc_support "1"
resetprop -n ro.mtk_tetheringipv6_support "1"
resetprop -n ro.mtk_c2k_support "1"
resetprop -n ro.mtk_srlte_support "1"
resetprop -n ro.mtk_shared_sdcard "1"
resetprop -n ro.mtk_enable_md1 "1"
resetprop -n ro.mtk_enable_md3 "1"
resetprop -n ro.mtk_afw_support "1"
resetprop -n ro.mtk_soter_support "1"
resetprop -n ro.mtk_benchmark_boost_tp "1"
resetprop -n ro.mtk_aal_support "1"
resetprop -n ro.mtk_pq_support "2"
resetprop -n ro.mtk_pq_color_mode "1"
resetprop -n ro.mtk_miravision_support "1"
resetprop -n ro.mtk_miravision_image_dc "1"
resetprop -n ro.mtk_blulight_def_support "1"
resetprop -n ro.mtk_wfd_support "1"
resetprop -n ro.mtk_wfd_sink_support "1"
resetprop -n ro.mtk_wfd_sink_uibc_support "1"
resetprop -n ro.mtk_wifi_mcc_support "1"
resetprop -n ro.mtk_sim_hot_swap "1"
resetprop -n ro.mtk_thumbnail_play_support "1"
resetprop -n ro.mtk_bip_scws "1"
resetprop -n ro.mtk_world_phone_policy "0"
resetprop -n ro.mtk_md_world_mode_support "1"
resetprop -n ro.mtk_perfservice_support "1"
resetprop -n ro.mtk_sim_hot_swap_common_slot "1"
resetprop -n ro.mtk_cta_set "1"
resetprop -n ro.mtk_ct4greg_app "1"
resetprop -n ro.mtk_mobile_management "1"
resetprop -n ro.mtk_antibricking_level "2"
resetprop -n ro.mtk_cam_mfb_support "3"
resetprop -n ro.mtk_slow_motion_support "1"
resetprop -n ro.mtk_lte_support "1"
resetprop -n ro.mtk_safemedia_support "1"
resetprop -n ro.mtk_cam_vfb "1"
resetprop -n ro.mtk_rild_read_imsi "1"
resetprop -n ro.mtk_external_sim_support "1"
resetprop -n ro.mtk_slidevideo_support "1"
resetprop -n ro.mtk_passpoint_r1_support "1"
resetprop -n ro.mtk_privacy_protection_lock "1"
resetprop -n ro.mtk_bg_power_saving_support "1"
resetprop -n ro.mtk_bg_power_saving_ui "1"
resetprop -n ro.mtk_dual_mic_support "1"
resetprop -n ro.mtk_is_tablet "0"
resetprop -n ro.mtk_vilte_support "0"
resetprop -n ro.mtk_vilte_ut_support "0"
resetprop -n ro.mtk_voice_extension_support "1"
resetprop -n ro.mediatek.project.path "device/wingtechsz/wt6755_66_n5_m"
resetprop -n ro.mtk_microtrust_tee_support "1"
resetprop -n ro.mtk_hetcomm_support "1"
resetprop -n ro.mtk_deinterlace_support "1"
resetprop -n ro.mtk_md_sbp_custom_value "0"
resetprop -n ro.mtk_modem_monitor_support "1"
resetprop -n ro.mtk_embms_support "1"
resetprop -n persist.radio.mtk_ps2_rat "C/G"
resetprop -n debug.hwui.render_dirty_regions "true"
resetprop -n ro.hwui.disable_asset_atlas "true"
resetprop -n ro.hwui.texture_cache_size "48"
resetprop -n ro.hwui.layer_cache_size "32"
resetprop -n ro.hwui.r_buffer_cache_size "8"
resetprop -n ro.hwui.path_cache_size "32"
resetprop -n ro.hwui.gradient_cache_size "3"
resetprop -n ro.hwui.drop_shadow_cache_size "6"
resetprop -n ro.hwui.fbo_cache_size "25"
resetprop -n ro.hwui.texture_cache_flushrate "0.4"
resetprop -n ro.hwui.text_small_cache_width "1024"
resetprop -n ro.hwui.text_small_cache_height "1024"
resetprop -n ro.hwui.text_large_cache_width "2048"
resetprop -n ro.hwui.text_large_cache_height "1024"
resetprop -n persist.sys.meizu.region "cn"
resetprop -n persist.sys.meizu.codepage "gbk"
resetprop -n ro.meizu.setupwizard.flyme "true"
resetprop -n ro.meizu.setupwizard.setlang "true"
resetprop -n ro.meizu.region.enable "true"
resetprop -n ro.meizu.contactmsg.auth "false"
resetprop -n ro.meizu.customize.pccw "false"
resetprop -n ro.meizu.autorecorder "true"
resetprop -n ro.meizu.visualvoicemail "true"
resetprop -n ro.meizu.security "false"
resetprop -n ro.meizu.permanentkey "false"
resetprop -n ro.meizu.sip.support "true"
resetprop -n ro.meizu.voip.support "false"
resetprop -n sys.meizu.m35x.white.config "false"
resetprop -n sys.meizu.white.config "false"
resetprop -n persist.sys.use.flyme.icon "true"
resetprop -n ro.meizu.published.type "prd"
resetprop -n ro.meizu.carrier.model "M621H"
resetprop -n ro.expect.recovery_id "0x67bf584146fec7cff42244d4dc26536be7705991000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2017-01-05
