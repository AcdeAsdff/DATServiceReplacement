strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "JBL LINK BAR"
resetprop -n ro.product.vendor.model "JBL LINK BAR"
resetprop -n ro.product.vendor_dlkm.marketname "JBL LINK BAR"
resetprop -n ro.product.product.marketname "JBL LINK BAR"
resetprop -n ro.product.system.marketname "JBL LINK BAR"
resetprop -n ro.product.odm_dlkm.marketname "JBL LINK BAR"
resetprop -n ro.product.system_ext.marketname "JBL LINK BAR"
resetprop -n ro.product.odm_dlkm.model "JBL LINK BAR"
resetprop -n ro.product.system.model "JBL LINK BAR"
resetprop -n ro.product.system_ext.model "JBL LINK BAR"
resetprop -n ro.product.vendor_dlkm.model "JBL LINK BAR"
resetprop -n bluetooth.device.default_name "JBL LINK BAR"
resetprop -n ro.product.bootimage.model "JBL LINK BAR"
resetprop -n ro.product.vendor.marketname "JBL LINK BAR"
resetprop -n ro.product.marketname "JBL LINK BAR"
resetprop -n ro.product.odm.model "JBL LINK BAR"
resetprop -n ro.product.model "JBL LINK BAR"
resetprop -n ro.product.product.model "JBL LINK BAR"
resetprop -n ro.product.odm.marketname "JBL LINK BAR"
resetprop -n ro.product.vendor.manufacturer "Harman TV"
resetprop -n ro.product.product.manufacturer "Harman TV"
resetprop -n ro.product.bootimage.manufacturer "Harman TV"
resetprop -n ro.product.manufacturer "Harman TV"
resetprop -n ro.product.odm.manufacturer "Harman TV"
resetprop -n ro.product.system.manufacturer "Harman TV"
resetprop -n ro.product.system_ext.manufacturer "Harman TV"
resetprop -n ro.product.vendor_dlkm.manufacturer "Harman TV"
resetprop -n ro.product.vendor.brand "google"
resetprop -n ro.product.product.brand "google"
resetprop -n ro.product.vendor_dlkm.brand "google"
resetprop -n ro.product.system.brand "google"
resetprop -n ro.product.bootimage.brand "google"
resetprop -n ro.product.system_ext.brand "google"
resetprop -n ro.product.odm.brand "google"
resetprop -n ro.product.odm_dlkm.brand "google"
resetprop -n ro.product.brand "google"
resetprop -n ro.vendor_dlkm.build.fingerprint "google/atom/atom:9/PTD1.190610.002.A9/5803026:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "google/atom/atom:9/PTD1.190610.002.A9/5803026:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "google/atom/atom:9/PTD1.190610.002.A9/5803026:user/release-keys"
resetprop -n ro.odm.build.fingerprint "google/atom/atom:9/PTD1.190610.002.A9/5803026:user/release-keys"
resetprop -n ro.system.build.fingerprint "google/atom/atom:9/PTD1.190610.002.A9/5803026:user/release-keys"
resetprop -n ro.build.fingerprint "google/atom/atom:9/PTD1.190610.002.A9/5803026:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "google/atom/atom:9/PTD1.190610.002.A9/5803026:user/release-keys"
resetprop -n ro.product.build.fingerprint "google/atom/atom:9/PTD1.190610.002.A9/5803026:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "google/atom/atom:9/PTD1.190610.002.A9/5803026:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=85ffed88dc
resetprop -n ro.system.build.version.incremental 5803026
resetprop -n ro.bootimage.build.version.incremental 5803026
resetprop -n ro.product.build.version.incremental 5803026
resetprop -n ro.odm.build.version.incremental 5803026
resetprop -n ro.vendor_dlkm.build.version.incremental 5803026
resetprop -n ro.system_ext.build.version.incremental 5803026
resetprop -n ro.build.version.incremental 5803026
resetprop -n ro.vendor.build.version.incremental 5803026
resetprop -n ro.odm.build.id "PTD1.190610.002.A9"
resetprop -n ro.product.build.id "PTD1.190610.002.A9"
resetprop -n ro.bootimage.build.id "PTD1.190610.002.A9"
resetprop -n ro.system_ext.build.id "PTD1.190610.002.A9"
resetprop -n ro.vendor_dlkm.build.id "PTD1.190610.002.A9"
resetprop -n ro.build.id "PTD1.190610.002.A9"
resetprop -n ro.system.build.id "PTD1.190610.002.A9"
resetprop -n ro.vendor.build.id "PTD1.190610.002.A9"
resetprop -n ro.system.build.date "Wed Aug 14 22:11:22 UTC 2019"
resetprop -n ro.bootimage.build.date "Wed Aug 14 22:11:22 UTC 2019"
resetprop -n ro.product.build.date "Wed Aug 14 22:11:22 UTC 2019"
resetprop -n ro.vendor_dlkm.build.date "Wed Aug 14 22:11:22 UTC 2019"
resetprop -n ro.system_ext.build.date "Wed Aug 14 22:11:22 UTC 2019"
resetprop -n ro.odm.build.date "Wed Aug 14 22:11:22 UTC 2019"
resetprop -n ro.build.date "Wed Aug 14 22:11:22 UTC 2019"
resetprop -n ro.vendor.build.date "Wed Aug 14 22:11:22 UTC 2019"
resetprop -n ro.product.build.date.utc "1565820682"
resetprop -n ro.system_ext.build.date.utc "1565820682"
resetprop -n ro.system.build.date.utc "1565820682"
resetprop -n ro.vendor.build.date.utc "1565820682"
resetprop -n ro.vendor_dlkm.build.date.utc "1565820682"
resetprop -n ro.build.date.utc "1565820682"
resetprop -n ro.bootimage.build.date.utc "1565820682"
resetprop -n ro.odm.build.date.utc "1565820682"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name atom
resetprop -n ro.product.odm.name atom
resetprop -n ro.product.vendor.name atom
resetprop -n ro.product.system.name atom
resetprop -n ro.product.name atom
resetprop -n ro.product.bootimage.name atom
resetprop -n ro.product.vendor_dlkm.name atom
resetprop -n ro.product.system_ext.name atom
resetprop -n ro.build.flavor atom-user
randomStr="atom-user Harman TV PTD1.190610.002.A9 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=dde328c9d819
resetprop -n ro.build.host ${randomStr}
randomStr=dff2503a
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=AKdmuV
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=aac3d3e1b0fe1
randomStr2=00
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=8f
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "5803026"
resetprop -n ro.build.description "atom-user 9 PTD1.190610.002.A9 5803026 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "android-build"
resetprop -n ro.build.host "wprf8.hot.corp.google.com"
resetprop -n ro.build.product.backup "atom"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.expect.recovery_id "0xd9454c648b704847aa5de541a0cc4ae988ad208e000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-07-05
