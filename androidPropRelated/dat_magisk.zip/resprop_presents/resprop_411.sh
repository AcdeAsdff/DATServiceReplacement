strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Hisense Infinity E30 Lite"
resetprop -n ro.product.vendor.model "Hisense Infinity E30 Lite"
resetprop -n ro.product.vendor_dlkm.marketname "Hisense Infinity E30 Lite"
resetprop -n ro.product.product.marketname "Hisense Infinity E30 Lite"
resetprop -n ro.product.system.marketname "Hisense Infinity E30 Lite"
resetprop -n ro.product.odm_dlkm.marketname "Hisense Infinity E30 Lite"
resetprop -n ro.product.system_ext.marketname "Hisense Infinity E30 Lite"
resetprop -n ro.product.odm_dlkm.model "Hisense Infinity E30 Lite"
resetprop -n ro.product.system.model "Hisense Infinity E30 Lite"
resetprop -n ro.product.system_ext.model "Hisense Infinity E30 Lite"
resetprop -n ro.product.vendor_dlkm.model "Hisense Infinity E30 Lite"
resetprop -n bluetooth.device.default_name "Hisense Infinity E30 Lite"
resetprop -n ro.product.bootimage.model "Hisense Infinity E30 Lite"
resetprop -n ro.product.vendor.marketname "Hisense Infinity E30 Lite"
resetprop -n ro.product.marketname "Hisense Infinity E30 Lite"
resetprop -n ro.product.odm.model "Hisense Infinity E30 Lite"
resetprop -n ro.product.model "Hisense Infinity E30 Lite"
resetprop -n ro.product.product.model "Hisense Infinity E30 Lite"
resetprop -n ro.product.odm.marketname "Hisense Infinity E30 Lite"
resetprop -n ro.product.vendor.manufacturer "Hisense"
resetprop -n ro.product.product.manufacturer "Hisense"
resetprop -n ro.product.bootimage.manufacturer "Hisense"
resetprop -n ro.product.manufacturer "Hisense"
resetprop -n ro.product.odm.manufacturer "Hisense"
resetprop -n ro.product.system.manufacturer "Hisense"
resetprop -n ro.product.system_ext.manufacturer "Hisense"
resetprop -n ro.product.vendor_dlkm.manufacturer "Hisense"
resetprop -n ro.product.vendor.brand "Hisense"
resetprop -n ro.product.product.brand "Hisense"
resetprop -n ro.product.vendor_dlkm.brand "Hisense"
resetprop -n ro.product.system.brand "Hisense"
resetprop -n ro.product.bootimage.brand "Hisense"
resetprop -n ro.product.system_ext.brand "Hisense"
resetprop -n ro.product.odm.brand "Hisense"
resetprop -n ro.product.odm_dlkm.brand "Hisense"
resetprop -n ro.product.brand "Hisense"
resetprop -n ro.vendor_dlkm.build.fingerprint "Hisense/HLTE102E_10/SC9832E:9/PPR1.180610.011/Hisense_HLTE102E_10_2106:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Hisense/HLTE102E_10/SC9832E:9/PPR1.180610.011/Hisense_HLTE102E_10_2106:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Hisense/HLTE102E_10/SC9832E:9/PPR1.180610.011/Hisense_HLTE102E_10_2106:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Hisense/HLTE102E_10/SC9832E:9/PPR1.180610.011/Hisense_HLTE102E_10_2106:user/release-keys"
resetprop -n ro.system.build.fingerprint "Hisense/HLTE102E_10/SC9832E:9/PPR1.180610.011/Hisense_HLTE102E_10_2106:user/release-keys"
resetprop -n ro.build.fingerprint "Hisense/HLTE102E_10/SC9832E:9/PPR1.180610.011/Hisense_HLTE102E_10_2106:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Hisense/HLTE102E_10/SC9832E:9/PPR1.180610.011/Hisense_HLTE102E_10_2106:user/release-keys"
resetprop -n ro.product.build.fingerprint "Hisense/HLTE102E_10/SC9832E:9/PPR1.180610.011/Hisense_HLTE102E_10_2106:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Hisense/HLTE102E_10/SC9832E:9/PPR1.180610.011/Hisense_HLTE102E_10_2106:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=f9f63d0c1b
resetprop -n ro.system.build.version.incremental Hisense_HLTE102E_10_2106
resetprop -n ro.bootimage.build.version.incremental Hisense_HLTE102E_10_2106
resetprop -n ro.product.build.version.incremental Hisense_HLTE102E_10_2106
resetprop -n ro.odm.build.version.incremental Hisense_HLTE102E_10_2106
resetprop -n ro.vendor_dlkm.build.version.incremental Hisense_HLTE102E_10_2106
resetprop -n ro.system_ext.build.version.incremental Hisense_HLTE102E_10_2106
resetprop -n ro.build.version.incremental Hisense_HLTE102E_10_2106
resetprop -n ro.vendor.build.version.incremental Hisense_HLTE102E_10_2106
resetprop -n ro.odm.build.id "PPR1.180610.011"
resetprop -n ro.product.build.id "PPR1.180610.011"
resetprop -n ro.bootimage.build.id "PPR1.180610.011"
resetprop -n ro.system_ext.build.id "PPR1.180610.011"
resetprop -n ro.vendor_dlkm.build.id "PPR1.180610.011"
resetprop -n ro.build.id "PPR1.180610.011"
resetprop -n ro.system.build.id "PPR1.180610.011"
resetprop -n ro.vendor.build.id "PPR1.180610.011"
resetprop -n ro.system.build.date "Fri Jun 18 15:27:15 CST 2021"
resetprop -n ro.bootimage.build.date "Fri Jun 18 15:27:15 CST 2021"
resetprop -n ro.product.build.date "Fri Jun 18 15:27:15 CST 2021"
resetprop -n ro.vendor_dlkm.build.date "Fri Jun 18 15:27:15 CST 2021"
resetprop -n ro.system_ext.build.date "Fri Jun 18 15:27:15 CST 2021"
resetprop -n ro.odm.build.date "Fri Jun 18 15:27:15 CST 2021"
resetprop -n ro.build.date "Fri Jun 18 15:27:15 CST 2021"
resetprop -n ro.vendor.build.date "Fri Jun 18 15:27:15 CST 2021"
resetprop -n ro.product.build.date.utc "1624001235"
resetprop -n ro.system_ext.build.date.utc "1624001235"
resetprop -n ro.system.build.date.utc "1624001235"
resetprop -n ro.vendor.build.date.utc "1624001235"
resetprop -n ro.vendor_dlkm.build.date.utc "1624001235"
resetprop -n ro.build.date.utc "1624001235"
resetprop -n ro.bootimage.build.date.utc "1624001235"
resetprop -n ro.odm.build.date.utc "1624001235"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name HLTE102E_10
resetprop -n ro.product.odm.name HLTE102E_10
resetprop -n ro.product.vendor.name HLTE102E_10
resetprop -n ro.product.system.name HLTE102E_10
resetprop -n ro.product.name HLTE102E_10
resetprop -n ro.product.bootimage.name HLTE102E_10
resetprop -n ro.product.vendor_dlkm.name HLTE102E_10
resetprop -n ro.product.system_ext.name HLTE102E_10
resetprop -n ro.build.flavor sp9832e_fs277_go_project-user
randomStr="sp9832e_fs277_go_project-user Hisense PPR1.180610.011 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=fe9177bbf628
resetprop -n ro.build.host ${randomStr}
randomStr=a9c8274b
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=BsqbGJ
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=a4e0391209f3d
randomStr2=3a
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=d1
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "Hisense_HLTE102E_10_2106"
resetprop -n ro.build.description "sp9832e_fs277_go_project-user 9 PPR1.180610.011 24515 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "comuser"
resetprop -n ro.build.host "serverf1"
resetprop -n ro.build.product.backup "HLTE102E_10"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.lmk.critical "210"
resetprop -n ro.lmk.critical_upgrade "true"
resetprop -n ro.lmk.downgrade_pressure "60"
resetprop -n ro.lmk.medium "700"
resetprop -n ro.lmk.upgrade_pressure "40"
resetprop -n ro.lmk.watermarkenhanced "true"
resetprop -n ro.lmk.vmpressurenhanced "true"
resetprop -n ro.fota.platform "Sprd9832_9.0"
resetprop -n ro.fota.hide.shake "1"
resetprop -n ro.fota.type "phone"
resetprop -n ro.fota.app "5"
resetprop -n ro.fota.battery "30"
resetprop -n ro.fota.oem "waterworld69863_9.0"
resetprop -n ro.fota.device "HLTE102E_12"
resetprop -n ro.fota.version.display "Hisense_HLTE102E_12_S03_03_01_ZA04"
resetprop -n ro.fota.version "Hisense_HLTE102E_12_S03_03_01_ZA04_20210618-1529"
resetprop -n ro.expect.recovery_id "0xfb35449894001e09e59e766425f046a61dc40c85000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2021-06-05
