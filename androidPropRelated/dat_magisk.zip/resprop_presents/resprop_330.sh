strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "N10"
resetprop -n ro.product.vendor.model "N10"
resetprop -n ro.product.vendor_dlkm.marketname "N10"
resetprop -n ro.product.product.marketname "N10"
resetprop -n ro.product.system.marketname "N10"
resetprop -n ro.product.odm_dlkm.marketname "N10"
resetprop -n ro.product.system_ext.marketname "N10"
resetprop -n ro.product.odm_dlkm.model "N10"
resetprop -n ro.product.system.model "N10"
resetprop -n ro.product.system_ext.model "N10"
resetprop -n ro.product.vendor_dlkm.model "N10"
resetprop -n bluetooth.device.default_name "N10"
resetprop -n ro.product.bootimage.model "N10"
resetprop -n ro.product.vendor.marketname "N10"
resetprop -n ro.product.marketname "N10"
resetprop -n ro.product.odm.model "N10"
resetprop -n ro.product.model "N10"
resetprop -n ro.product.product.model "N10"
resetprop -n ro.product.odm.marketname "N10"
resetprop -n ro.product.vendor.manufacturer "DOOGEE"
resetprop -n ro.product.product.manufacturer "DOOGEE"
resetprop -n ro.product.bootimage.manufacturer "DOOGEE"
resetprop -n ro.product.manufacturer "DOOGEE"
resetprop -n ro.product.odm.manufacturer "DOOGEE"
resetprop -n ro.product.system.manufacturer "DOOGEE"
resetprop -n ro.product.system_ext.manufacturer "DOOGEE"
resetprop -n ro.product.vendor_dlkm.manufacturer "DOOGEE"
resetprop -n ro.product.vendor.brand "DOOGEE"
resetprop -n ro.product.product.brand "DOOGEE"
resetprop -n ro.product.vendor_dlkm.brand "DOOGEE"
resetprop -n ro.product.system.brand "DOOGEE"
resetprop -n ro.product.bootimage.brand "DOOGEE"
resetprop -n ro.product.system_ext.brand "DOOGEE"
resetprop -n ro.product.odm.brand "DOOGEE"
resetprop -n ro.product.odm_dlkm.brand "DOOGEE"
resetprop -n ro.product.brand "DOOGEE"
resetprop -n ro.vendor_dlkm.build.fingerprint "DOOGEE/N10/Y7:8.1.0/OPM2.171019.012/20190321:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "DOOGEE/N10/Y7:8.1.0/OPM2.171019.012/20190321:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "DOOGEE/N10/Y7:8.1.0/OPM2.171019.012/20190321:user/release-keys"
resetprop -n ro.odm.build.fingerprint "DOOGEE/N10/Y7:8.1.0/OPM2.171019.012/20190321:user/release-keys"
resetprop -n ro.system.build.fingerprint "DOOGEE/N10/Y7:8.1.0/OPM2.171019.012/20190321:user/release-keys"
resetprop -n ro.build.fingerprint "DOOGEE/N10/Y7:8.1.0/OPM2.171019.012/20190321:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "DOOGEE/N10/Y7:8.1.0/OPM2.171019.012/20190321:user/release-keys"
resetprop -n ro.product.build.fingerprint "DOOGEE/N10/Y7:8.1.0/OPM2.171019.012/20190321:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "DOOGEE/N10/Y7:8.1.0/OPM2.171019.012/20190321:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=69d39ef76b
resetprop -n ro.system.build.version.incremental 20190321
resetprop -n ro.bootimage.build.version.incremental 20190321
resetprop -n ro.product.build.version.incremental 20190321
resetprop -n ro.odm.build.version.incremental 20190321
resetprop -n ro.vendor_dlkm.build.version.incremental 20190321
resetprop -n ro.system_ext.build.version.incremental 20190321
resetprop -n ro.build.version.incremental 20190321
resetprop -n ro.vendor.build.version.incremental 20190321
resetprop -n ro.odm.build.id "OPM2.171019.012"
resetprop -n ro.product.build.id "OPM2.171019.012"
resetprop -n ro.bootimage.build.id "OPM2.171019.012"
resetprop -n ro.system_ext.build.id "OPM2.171019.012"
resetprop -n ro.vendor_dlkm.build.id "OPM2.171019.012"
resetprop -n ro.build.id "OPM2.171019.012"
resetprop -n ro.system.build.id "OPM2.171019.012"
resetprop -n ro.vendor.build.id "OPM2.171019.012"
resetprop -n ro.system.build.date "Tue Apr 16 18:39:09 CST 2019"
resetprop -n ro.bootimage.build.date "Tue Apr 16 18:39:09 CST 2019"
resetprop -n ro.product.build.date "Tue Apr 16 18:39:09 CST 2019"
resetprop -n ro.vendor_dlkm.build.date "Tue Apr 16 18:39:09 CST 2019"
resetprop -n ro.system_ext.build.date "Tue Apr 16 18:39:09 CST 2019"
resetprop -n ro.odm.build.date "Tue Apr 16 18:39:09 CST 2019"
resetprop -n ro.build.date "Tue Apr 16 18:39:09 CST 2019"
resetprop -n ro.vendor.build.date "Tue Apr 16 18:39:09 CST 2019"
resetprop -n ro.product.build.date.utc "1555411149"
resetprop -n ro.system_ext.build.date.utc "1555411149"
resetprop -n ro.system.build.date.utc "1555411149"
resetprop -n ro.vendor.build.date.utc "1555411149"
resetprop -n ro.vendor_dlkm.build.date.utc "1555411149"
resetprop -n ro.build.date.utc "1555411149"
resetprop -n ro.bootimage.build.date.utc "1555411149"
resetprop -n ro.odm.build.date.utc "1555411149"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name N10
resetprop -n ro.product.odm.name N10
resetprop -n ro.product.vendor.name N10
resetprop -n ro.product.system.name N10
resetprop -n ro.product.name N10
resetprop -n ro.product.bootimage.name N10
resetprop -n ro.product.vendor_dlkm.name N10
resetprop -n ro.product.system_ext.name N10
resetprop -n ro.build.flavor sp9863ao_z622bq_a76-n10_doogee_cc_256gbitp24d3_o1_lte_3m-fdd-cs_mul
randomStr="sp9863ao_z622bq_a76-n10_doogee_cc_256gbitp24d3_o1_lte_3m-fdd-cs_mul DOOGEE OPM2.171019.012 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=dbac7c984692
resetprop -n ro.build.host ${randomStr}
randomStr=18a053e6
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=BGWlFw
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=c7781e720d8e0
randomStr2=d1
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=70
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "20190321"
resetprop -n ro.build.description "s9863a1h10_Natv-user 8.1.0 OPM2.171019.012 20190321 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "scm"
resetprop -n ro.build.host "v117"
resetprop -n ro.build.product.backup "N10"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.com.google.apphider "off"
resetprop -n ro.fota.pp "1"
resetprop -n ro.fota.platform "Sprd9863_8.1"
resetprop -n ro.fota.type "phone"
resetprop -n ro.fota.app "5"
resetprop -n ro.fota.battery "30"
resetprop -n ro.fota.oem "vanzo9863_8.1"
resetprop -n ro.fota.device "N10"
resetprop -n ro.fota.version "DOOGEE_N10_Android8.1-20190321_20190416-1842"
resetprop -n ro.expect.recovery_id "0x42cb1530bcd660a3e70426d689b6756e9b001e56000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-03-05
