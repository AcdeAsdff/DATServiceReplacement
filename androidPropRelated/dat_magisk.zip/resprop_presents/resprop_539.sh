strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "MITO_A37_Z1plus"
resetprop -n ro.product.vendor.model "MITO_A37_Z1plus"
resetprop -n ro.product.vendor_dlkm.marketname "MITO_A37_Z1plus"
resetprop -n ro.product.product.marketname "MITO_A37_Z1plus"
resetprop -n ro.product.system.marketname "MITO_A37_Z1plus"
resetprop -n ro.product.odm_dlkm.marketname "MITO_A37_Z1plus"
resetprop -n ro.product.system_ext.marketname "MITO_A37_Z1plus"
resetprop -n ro.product.odm_dlkm.model "MITO_A37_Z1plus"
resetprop -n ro.product.system.model "MITO_A37_Z1plus"
resetprop -n ro.product.system_ext.model "MITO_A37_Z1plus"
resetprop -n ro.product.vendor_dlkm.model "MITO_A37_Z1plus"
resetprop -n bluetooth.device.default_name "MITO_A37_Z1plus"
resetprop -n ro.product.bootimage.model "MITO_A37_Z1plus"
resetprop -n ro.product.vendor.marketname "MITO_A37_Z1plus"
resetprop -n ro.product.marketname "MITO_A37_Z1plus"
resetprop -n ro.product.odm.model "MITO_A37_Z1plus"
resetprop -n ro.product.model "MITO_A37_Z1plus"
resetprop -n ro.product.product.model "MITO_A37_Z1plus"
resetprop -n ro.product.odm.marketname "MITO_A37_Z1plus"
resetprop -n ro.product.vendor.manufacturer "MITO"
resetprop -n ro.product.product.manufacturer "MITO"
resetprop -n ro.product.bootimage.manufacturer "MITO"
resetprop -n ro.product.manufacturer "MITO"
resetprop -n ro.product.odm.manufacturer "MITO"
resetprop -n ro.product.system.manufacturer "MITO"
resetprop -n ro.product.system_ext.manufacturer "MITO"
resetprop -n ro.product.vendor_dlkm.manufacturer "MITO"
resetprop -n ro.product.vendor.brand "MITO"
resetprop -n ro.product.product.brand "MITO"
resetprop -n ro.product.vendor_dlkm.brand "MITO"
resetprop -n ro.product.system.brand "MITO"
resetprop -n ro.product.bootimage.brand "MITO"
resetprop -n ro.product.system_ext.brand "MITO"
resetprop -n ro.product.odm.brand "MITO"
resetprop -n ro.product.odm_dlkm.brand "MITO"
resetprop -n ro.product.brand "MITO"
resetprop -n ro.vendor_dlkm.build.fingerprint "MITO/MITO_A37_Z1plus/MITO_A37_Z1plus:8.1.0/O21019/1544688505:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "MITO/MITO_A37_Z1plus/MITO_A37_Z1plus:8.1.0/O21019/1544688505:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "MITO/MITO_A37_Z1plus/MITO_A37_Z1plus:8.1.0/O21019/1544688505:user/release-keys"
resetprop -n ro.odm.build.fingerprint "MITO/MITO_A37_Z1plus/MITO_A37_Z1plus:8.1.0/O21019/1544688505:user/release-keys"
resetprop -n ro.system.build.fingerprint "MITO/MITO_A37_Z1plus/MITO_A37_Z1plus:8.1.0/O21019/1544688505:user/release-keys"
resetprop -n ro.build.fingerprint "MITO/MITO_A37_Z1plus/MITO_A37_Z1plus:8.1.0/O21019/1544688505:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "MITO/MITO_A37_Z1plus/MITO_A37_Z1plus:8.1.0/O21019/1544688505:user/release-keys"
resetprop -n ro.product.build.fingerprint "MITO/MITO_A37_Z1plus/MITO_A37_Z1plus:8.1.0/O21019/1544688505:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "MITO/MITO_A37_Z1plus/MITO_A37_Z1plus:8.1.0/O21019/1544688505:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=86d7654a16
resetprop -n ro.system.build.version.incremental 1544688505
resetprop -n ro.bootimage.build.version.incremental 1544688505
resetprop -n ro.product.build.version.incremental 1544688505
resetprop -n ro.odm.build.version.incremental 1544688505
resetprop -n ro.vendor_dlkm.build.version.incremental 1544688505
resetprop -n ro.system_ext.build.version.incremental 1544688505
resetprop -n ro.build.version.incremental 1544688505
resetprop -n ro.vendor.build.version.incremental 1544688505
resetprop -n ro.odm.build.id "O21019"
resetprop -n ro.product.build.id "O21019"
resetprop -n ro.bootimage.build.id "O21019"
resetprop -n ro.system_ext.build.id "O21019"
resetprop -n ro.vendor_dlkm.build.id "O21019"
resetprop -n ro.build.id "O21019"
resetprop -n ro.system.build.id "O21019"
resetprop -n ro.vendor.build.id "O21019"
resetprop -n ro.system.build.date "Thu Dec 13 16:08:25 CST 2018"
resetprop -n ro.bootimage.build.date "Thu Dec 13 16:08:25 CST 2018"
resetprop -n ro.product.build.date "Thu Dec 13 16:08:25 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Thu Dec 13 16:08:25 CST 2018"
resetprop -n ro.system_ext.build.date "Thu Dec 13 16:08:25 CST 2018"
resetprop -n ro.odm.build.date "Thu Dec 13 16:08:25 CST 2018"
resetprop -n ro.build.date "Thu Dec 13 16:08:25 CST 2018"
resetprop -n ro.vendor.build.date "Thu Dec 13 16:08:25 CST 2018"
resetprop -n ro.product.build.date.utc "1544688505"
resetprop -n ro.system_ext.build.date.utc "1544688505"
resetprop -n ro.system.build.date.utc "1544688505"
resetprop -n ro.vendor.build.date.utc "1544688505"
resetprop -n ro.vendor_dlkm.build.date.utc "1544688505"
resetprop -n ro.build.date.utc "1544688505"
resetprop -n ro.bootimage.build.date.utc "1544688505"
resetprop -n ro.odm.build.date.utc "1544688505"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name MITO_A37_Z1plus
resetprop -n ro.product.odm.name MITO_A37_Z1plus
resetprop -n ro.product.vendor.name MITO_A37_Z1plus
resetprop -n ro.product.system.name MITO_A37_Z1plus
resetprop -n ro.product.name MITO_A37_Z1plus
resetprop -n ro.product.bootimage.name MITO_A37_Z1plus
resetprop -n ro.product.vendor_dlkm.name MITO_A37_Z1plus
resetprop -n ro.product.system_ext.name MITO_A37_Z1plus
resetprop -n ro.build.flavor oversea
randomStr="oversea MITO O21019 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=0ab3e4fd9118
resetprop -n ro.build.host ${randomStr}
randomStr=8e6263e2
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=RTQYyC
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=efa9b86b9e4e3
randomStr2=e3
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=45
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1544688505"
resetprop -n ro.build.description "Mito_A37_Z1plus_8085T_V04_20181215"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "jenkins"
resetprop -n ro.build.host "relserverxiii"
resetprop -n ro.build.product.backup "MITO_A37_Z1plus"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.fota.platform "Sprd9832_8.1"
resetprop -n ro.fota.type "phone"
resetprop -n ro.fota.app "5"
resetprop -n ro.fota.oem "revoview9832_8.1"
resetprop -n ro.fota.device "MITO_A37_Z1plus"
resetprop -n ro.fota.version "Mito_A37_Z1plus_8085T_V04_20181215_20181215-1538"
resetprop -n ro.expect.recovery_id "0x491a1b86bc937b825d3b0be139668322e6decc97000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-12-05
