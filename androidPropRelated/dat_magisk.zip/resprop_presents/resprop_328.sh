strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "X90"
resetprop -n ro.product.vendor.model "X90"
resetprop -n ro.product.vendor_dlkm.marketname "X90"
resetprop -n ro.product.product.marketname "X90"
resetprop -n ro.product.system.marketname "X90"
resetprop -n ro.product.odm_dlkm.marketname "X90"
resetprop -n ro.product.system_ext.marketname "X90"
resetprop -n ro.product.odm_dlkm.model "X90"
resetprop -n ro.product.system.model "X90"
resetprop -n ro.product.system_ext.model "X90"
resetprop -n ro.product.vendor_dlkm.model "X90"
resetprop -n bluetooth.device.default_name "X90"
resetprop -n ro.product.bootimage.model "X90"
resetprop -n ro.product.vendor.marketname "X90"
resetprop -n ro.product.marketname "X90"
resetprop -n ro.product.odm.model "X90"
resetprop -n ro.product.model "X90"
resetprop -n ro.product.product.model "X90"
resetprop -n ro.product.odm.marketname "X90"
resetprop -n ro.product.vendor.manufacturer "DOOGEE"
resetprop -n ro.product.product.manufacturer "DOOGEE"
resetprop -n ro.product.bootimage.manufacturer "DOOGEE"
resetprop -n ro.product.manufacturer "DOOGEE"
resetprop -n ro.product.odm.manufacturer "DOOGEE"
resetprop -n ro.product.system.manufacturer "DOOGEE"
resetprop -n ro.product.system_ext.manufacturer "DOOGEE"
resetprop -n ro.product.vendor_dlkm.manufacturer "DOOGEE"
resetprop -n ro.product.vendor.brand "DOOGEE"
resetprop -n ro.product.product.brand "DOOGEE"
resetprop -n ro.product.vendor_dlkm.brand "DOOGEE"
resetprop -n ro.product.system.brand "DOOGEE"
resetprop -n ro.product.bootimage.brand "DOOGEE"
resetprop -n ro.product.system_ext.brand "DOOGEE"
resetprop -n ro.product.odm.brand "DOOGEE"
resetprop -n ro.product.odm_dlkm.brand "DOOGEE"
resetprop -n ro.product.brand "DOOGEE"
resetprop -n ro.vendor_dlkm.build.fingerprint "DOOGEE/X90/X90:8.1.0/O11019/1558407864:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "DOOGEE/X90/X90:8.1.0/O11019/1558407864:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "DOOGEE/X90/X90:8.1.0/O11019/1558407864:user/release-keys"
resetprop -n ro.odm.build.fingerprint "DOOGEE/X90/X90:8.1.0/O11019/1558407864:user/release-keys"
resetprop -n ro.system.build.fingerprint "DOOGEE/X90/X90:8.1.0/O11019/1558407864:user/release-keys"
resetprop -n ro.build.fingerprint "DOOGEE/X90/X90:8.1.0/O11019/1558407864:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "DOOGEE/X90/X90:8.1.0/O11019/1558407864:user/release-keys"
resetprop -n ro.product.build.fingerprint "DOOGEE/X90/X90:8.1.0/O11019/1558407864:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "DOOGEE/X90/X90:8.1.0/O11019/1558407864:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=2692c76078
resetprop -n ro.system.build.version.incremental 1558407864
resetprop -n ro.bootimage.build.version.incremental 1558407864
resetprop -n ro.product.build.version.incremental 1558407864
resetprop -n ro.odm.build.version.incremental 1558407864
resetprop -n ro.vendor_dlkm.build.version.incremental 1558407864
resetprop -n ro.system_ext.build.version.incremental 1558407864
resetprop -n ro.build.version.incremental 1558407864
resetprop -n ro.vendor.build.version.incremental 1558407864
resetprop -n ro.odm.build.id "O11019"
resetprop -n ro.product.build.id "O11019"
resetprop -n ro.bootimage.build.id "O11019"
resetprop -n ro.system_ext.build.id "O11019"
resetprop -n ro.vendor_dlkm.build.id "O11019"
resetprop -n ro.build.id "O11019"
resetprop -n ro.system.build.id "O11019"
resetprop -n ro.vendor.build.id "O11019"
resetprop -n ro.system.build.date "2019年 05月 27日 星期一 10:05:40 CST"
resetprop -n ro.bootimage.build.date "2019年 05月 27日 星期一 10:05:40 CST"
resetprop -n ro.product.build.date "2019年 05月 27日 星期一 10:05:40 CST"
resetprop -n ro.vendor_dlkm.build.date "2019年 05月 27日 星期一 10:05:40 CST"
resetprop -n ro.system_ext.build.date "2019年 05月 27日 星期一 10:05:40 CST"
resetprop -n ro.odm.build.date "2019年 05月 27日 星期一 10:05:40 CST"
resetprop -n ro.build.date "2019年 05月 27日 星期一 10:05:40 CST"
resetprop -n ro.vendor.build.date "2019年 05月 27日 星期一 10:05:40 CST"
resetprop -n ro.product.build.date.utc "1558922740"
resetprop -n ro.system_ext.build.date.utc "1558922740"
resetprop -n ro.system.build.date.utc "1558922740"
resetprop -n ro.vendor.build.date.utc "1558922740"
resetprop -n ro.vendor_dlkm.build.date.utc "1558922740"
resetprop -n ro.build.date.utc "1558922740"
resetprop -n ro.bootimage.build.date.utc "1558922740"
resetprop -n ro.odm.build.date.utc "1558922740"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name X90
resetprop -n ro.product.odm.name X90
resetprop -n ro.product.vendor.name X90
resetprop -n ro.product.system.name X90
resetprop -n ro.product.name X90
resetprop -n ro.product.bootimage.name X90
resetprop -n ro.product.vendor_dlkm.name X90
resetprop -n ro.product.system_ext.name X90
resetprop -n ro.build.flavor full_k80hd_bsp_fwv_512m-user
randomStr="full_k80hd_bsp_fwv_512m-user DOOGEE O11019 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=946b945e8755
resetprop -n ro.build.host ${randomStr}
randomStr=beebee09
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=nuClBn
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=cdcb46ac78794
randomStr2=21
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=e6
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1558407864"
resetprop -n ro.build.description "full_k80hd_bsp_fwv_512m-user 8.1.0 O11019 1558923087 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "release"
resetprop -n ro.build.host "release40"
resetprop -n ro.build.product.backup "X90"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n debug.hwui.render_dirty_regions "false"
resetprop -n ro.hct_modify_phone_info "1"
resetprop -n ro.expect.recovery_id "0xbb9b69130f6fdb2e3dcffb5002852b0a2b1b598f000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2019-05-05
