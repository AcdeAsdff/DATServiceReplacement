strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "msm8937 for arm64"
resetprop -n ro.product.vendor.model "msm8937 for arm64"
resetprop -n ro.product.vendor_dlkm.marketname "msm8937 for arm64"
resetprop -n ro.product.product.marketname "msm8937 for arm64"
resetprop -n ro.product.system.marketname "msm8937 for arm64"
resetprop -n ro.product.odm_dlkm.marketname "msm8937 for arm64"
resetprop -n ro.product.system_ext.marketname "msm8937 for arm64"
resetprop -n ro.product.odm_dlkm.model "msm8937 for arm64"
resetprop -n ro.product.system.model "msm8937 for arm64"
resetprop -n ro.product.system_ext.model "msm8937 for arm64"
resetprop -n ro.product.vendor_dlkm.model "msm8937 for arm64"
resetprop -n bluetooth.device.default_name "msm8937 for arm64"
resetprop -n ro.product.bootimage.model "msm8937 for arm64"
resetprop -n ro.product.vendor.marketname "msm8937 for arm64"
resetprop -n ro.product.marketname "msm8937 for arm64"
resetprop -n ro.product.odm.model "msm8937 for arm64"
resetprop -n ro.product.model "msm8937 for arm64"
resetprop -n ro.product.product.model "msm8937 for arm64"
resetprop -n ro.product.odm.marketname "msm8937 for arm64"
resetprop -n ro.product.vendor.manufacturer "KYOCERA"
resetprop -n ro.product.product.manufacturer "KYOCERA"
resetprop -n ro.product.bootimage.manufacturer "KYOCERA"
resetprop -n ro.product.manufacturer "KYOCERA"
resetprop -n ro.product.odm.manufacturer "KYOCERA"
resetprop -n ro.product.system.manufacturer "KYOCERA"
resetprop -n ro.product.system_ext.manufacturer "KYOCERA"
resetprop -n ro.product.vendor_dlkm.manufacturer "KYOCERA"
resetprop -n ro.product.vendor.brand "Android"
resetprop -n ro.product.product.brand "Android"
resetprop -n ro.product.vendor_dlkm.brand "Android"
resetprop -n ro.product.system.brand "Android"
resetprop -n ro.product.bootimage.brand "Android"
resetprop -n ro.product.system_ext.brand "Android"
resetprop -n ro.product.odm.brand "Android"
resetprop -n ro.product.odm_dlkm.brand "Android"
resetprop -n ro.product.brand "Android"
resetprop -n ro.vendor_dlkm.build.fingerprint "KYOCERA/S2/S2_sprout:9/5.120VE.29.a/5.120VE.29.a:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "KYOCERA/S2/S2_sprout:9/5.120VE.29.a/5.120VE.29.a:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "KYOCERA/S2/S2_sprout:9/5.120VE.29.a/5.120VE.29.a:user/release-keys"
resetprop -n ro.odm.build.fingerprint "KYOCERA/S2/S2_sprout:9/5.120VE.29.a/5.120VE.29.a:user/release-keys"
resetprop -n ro.system.build.fingerprint "KYOCERA/S2/S2_sprout:9/5.120VE.29.a/5.120VE.29.a:user/release-keys"
resetprop -n ro.build.fingerprint "KYOCERA/S2/S2_sprout:9/5.120VE.29.a/5.120VE.29.a:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "KYOCERA/S2/S2_sprout:9/5.120VE.29.a/5.120VE.29.a:user/release-keys"
resetprop -n ro.product.build.fingerprint "KYOCERA/S2/S2_sprout:9/5.120VE.29.a/5.120VE.29.a:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "KYOCERA/S2/S2_sprout:9/5.120VE.29.a/5.120VE.29.a:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=6b1803c20c
resetprop -n ro.system.build.version.incremental 5.120VE.29.a
resetprop -n ro.bootimage.build.version.incremental 5.120VE.29.a
resetprop -n ro.product.build.version.incremental 5.120VE.29.a
resetprop -n ro.odm.build.version.incremental 5.120VE.29.a
resetprop -n ro.vendor_dlkm.build.version.incremental 5.120VE.29.a
resetprop -n ro.system_ext.build.version.incremental 5.120VE.29.a
resetprop -n ro.build.version.incremental 5.120VE.29.a
resetprop -n ro.vendor.build.version.incremental 5.120VE.29.a
resetprop -n ro.odm.build.id "5.120VE.29.a"
resetprop -n ro.product.build.id "5.120VE.29.a"
resetprop -n ro.bootimage.build.id "5.120VE.29.a"
resetprop -n ro.system_ext.build.id "5.120VE.29.a"
resetprop -n ro.vendor_dlkm.build.id "5.120VE.29.a"
resetprop -n ro.build.id "5.120VE.29.a"
resetprop -n ro.system.build.id "5.120VE.29.a"
resetprop -n ro.vendor.build.id "5.120VE.29.a"
resetprop -n ro.system.build.date "Wed Dec  5 10:45:20 JST 2018"
resetprop -n ro.bootimage.build.date "Wed Dec  5 10:45:20 JST 2018"
resetprop -n ro.product.build.date "Wed Dec  5 10:45:20 JST 2018"
resetprop -n ro.vendor_dlkm.build.date "Wed Dec  5 10:45:20 JST 2018"
resetprop -n ro.system_ext.build.date "Wed Dec  5 10:45:20 JST 2018"
resetprop -n ro.odm.build.date "Wed Dec  5 10:45:20 JST 2018"
resetprop -n ro.build.date "Wed Dec  5 10:45:20 JST 2018"
resetprop -n ro.vendor.build.date "Wed Dec  5 10:45:20 JST 2018"
resetprop -n ro.product.build.date.utc "1543974405"
resetprop -n ro.system_ext.build.date.utc "1543974405"
resetprop -n ro.system.build.date.utc "1543974405"
resetprop -n ro.vendor.build.date.utc "1543974405"
resetprop -n ro.vendor_dlkm.build.date.utc "1543974405"
resetprop -n ro.build.date.utc "1543974405"
resetprop -n ro.bootimage.build.date.utc "1543974405"
resetprop -n ro.odm.build.date.utc "1543974405"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name msm8937_64
resetprop -n ro.product.odm.name msm8937_64
resetprop -n ro.product.vendor.name msm8937_64
resetprop -n ro.product.system.name msm8937_64
resetprop -n ro.product.name msm8937_64
resetprop -n ro.product.bootimage.name msm8937_64
resetprop -n ro.product.vendor_dlkm.name msm8937_64
resetprop -n ro.product.system_ext.name msm8937_64
resetprop -n ro.build.flavor msm8937_64-user
randomStr="msm8937_64-user KYOCERA 5.120VE.29.a "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=5cd56c854241
resetprop -n ro.build.host ${randomStr}
randomStr=ef221a22
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=flqCjk
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=09d75f167cfd2
randomStr2=50
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=bd
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "5.120VE.29.a"
resetprop -n ro.build.description "S2-user 9 5.120VE.29.a 5.120VE.29.a release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "build"
resetprop -n ro.build.host "AMATERAS"
resetprop -n ro.build.product.backup "msm8937_64"
resetprop -n ro.build.characteristics "default"
resetprop -n media.msm8956hw "0"
resetprop -n media.aac_51_output_enabled "true"
resetprop -n media.settings.xml "/vendor/etc/media_profiles_vendor.xml"
resetprop -n ro.hwui.texture_cache_size "72"
resetprop -n ro.hwui.layer_cache_size "48"
resetprop -n ro.hwui.r_buffer_cache_size "8"
resetprop -n ro.hwui.path_cache_size "32"
resetprop -n ro.hwui.gradient_cache_size "1"
resetprop -n ro.hwui.drop_shadow_cache_size "6"
resetprop -n ro.hwui.texture_cache_flushrate "0.4"
resetprop -n ro.hwui.text_small_cache_width "1024"
resetprop -n ro.hwui.text_small_cache_height "1024"
resetprop -n ro.hwui.text_large_cache_width "2048"
resetprop -n ro.hwui.text_large_cache_height "2048"
resetprop -n ro.com.google.acsa "true"
resetprop -n ro.expect.recovery_id "0x0644fd458299576127c64443e0b546004675ce5f000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-12-01
