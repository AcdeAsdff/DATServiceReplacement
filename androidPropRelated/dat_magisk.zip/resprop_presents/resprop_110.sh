strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "SM-A326B"
resetprop -n ro.product.vendor.model "SM-A326B"
resetprop -n ro.product.vendor_dlkm.marketname "SM-A326B"
resetprop -n ro.product.product.marketname "SM-A326B"
resetprop -n ro.product.system.marketname "SM-A326B"
resetprop -n ro.product.odm_dlkm.marketname "SM-A326B"
resetprop -n ro.product.system_ext.marketname "SM-A326B"
resetprop -n ro.product.odm_dlkm.model "SM-A326B"
resetprop -n ro.product.system.model "SM-A326B"
resetprop -n ro.product.system_ext.model "SM-A326B"
resetprop -n ro.product.vendor_dlkm.model "SM-A326B"
resetprop -n bluetooth.device.default_name "SM-A326B"
resetprop -n ro.product.bootimage.model "SM-A326B"
resetprop -n ro.product.vendor.marketname "SM-A326B"
resetprop -n ro.product.marketname "SM-A326B"
resetprop -n ro.product.odm.model "SM-A326B"
resetprop -n ro.product.model "SM-A326B"
resetprop -n ro.product.product.model "SM-A326B"
resetprop -n ro.product.odm.marketname "SM-A326B"
resetprop -n ro.product.vendor.manufacturer "samsung"
resetprop -n ro.product.product.manufacturer "samsung"
resetprop -n ro.product.bootimage.manufacturer "samsung"
resetprop -n ro.product.manufacturer "samsung"
resetprop -n ro.product.odm.manufacturer "samsung"
resetprop -n ro.product.system.manufacturer "samsung"
resetprop -n ro.product.system_ext.manufacturer "samsung"
resetprop -n ro.product.vendor_dlkm.manufacturer "samsung"
resetprop -n ro.product.vendor.brand "samsung"
resetprop -n ro.product.product.brand "samsung"
resetprop -n ro.product.vendor_dlkm.brand "samsung"
resetprop -n ro.product.system.brand "samsung"
resetprop -n ro.product.bootimage.brand "samsung"
resetprop -n ro.product.system_ext.brand "samsung"
resetprop -n ro.product.odm.brand "samsung"
resetprop -n ro.product.odm_dlkm.brand "samsung"
resetprop -n ro.product.brand "samsung"
resetprop -n ro.vendor_dlkm.build.fingerprint "samsung/a32xxx/a32x:13/TP1A.220624.014/A326BXXU5CWB7:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "samsung/a32xxx/a32x:13/TP1A.220624.014/A326BXXU5CWB7:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "samsung/a32xxx/a32x:13/TP1A.220624.014/A326BXXU5CWB7:user/release-keys"
resetprop -n ro.odm.build.fingerprint "samsung/a32xxx/a32x:13/TP1A.220624.014/A326BXXU5CWB7:user/release-keys"
resetprop -n ro.system.build.fingerprint "samsung/a32xxx/a32x:13/TP1A.220624.014/A326BXXU5CWB7:user/release-keys"
resetprop -n ro.build.fingerprint "samsung/a32xxx/a32x:13/TP1A.220624.014/A326BXXU5CWB7:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "samsung/a32xxx/a32x:13/TP1A.220624.014/A326BXXU5CWB7:user/release-keys"
resetprop -n ro.product.build.fingerprint "samsung/a32xxx/a32x:13/TP1A.220624.014/A326BXXU5CWB7:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "samsung/a32xxx/a32x:13/TP1A.220624.014/A326BXXU5CWB7:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=26893b05f8
resetprop -n ro.system.build.version.incremental A326BXXU5CWB7
resetprop -n ro.bootimage.build.version.incremental A326BXXU5CWB7
resetprop -n ro.product.build.version.incremental A326BXXU5CWB7
resetprop -n ro.odm.build.version.incremental A326BXXU5CWB7
resetprop -n ro.vendor_dlkm.build.version.incremental A326BXXU5CWB7
resetprop -n ro.system_ext.build.version.incremental A326BXXU5CWB7
resetprop -n ro.build.version.incremental A326BXXU5CWB7
resetprop -n ro.vendor.build.version.incremental A326BXXU5CWB7
resetprop -n ro.odm.build.id "TP1A.220624.014"
resetprop -n ro.product.build.id "TP1A.220624.014"
resetprop -n ro.bootimage.build.id "TP1A.220624.014"
resetprop -n ro.system_ext.build.id "TP1A.220624.014"
resetprop -n ro.vendor_dlkm.build.id "TP1A.220624.014"
resetprop -n ro.build.id "TP1A.220624.014"
resetprop -n ro.system.build.id "TP1A.220624.014"
resetprop -n ro.vendor.build.id "TP1A.220624.014"
resetprop -n ro.system.build.date "Mon Feb 20 14:47:40 KST 2023"
resetprop -n ro.bootimage.build.date "Mon Feb 20 14:47:40 KST 2023"
resetprop -n ro.product.build.date "Mon Feb 20 14:47:40 KST 2023"
resetprop -n ro.vendor_dlkm.build.date "Mon Feb 20 14:47:40 KST 2023"
resetprop -n ro.system_ext.build.date "Mon Feb 20 14:47:40 KST 2023"
resetprop -n ro.odm.build.date "Mon Feb 20 14:47:40 KST 2023"
resetprop -n ro.build.date "Mon Feb 20 14:47:40 KST 2023"
resetprop -n ro.vendor.build.date "Mon Feb 20 14:47:40 KST 2023"
resetprop -n ro.product.build.date.utc "1676872060"
resetprop -n ro.system_ext.build.date.utc "1676872060"
resetprop -n ro.system.build.date.utc "1676872060"
resetprop -n ro.vendor.build.date.utc "1676872060"
resetprop -n ro.vendor_dlkm.build.date.utc "1676872060"
resetprop -n ro.build.date.utc "1676872060"
resetprop -n ro.bootimage.build.date.utc "1676872060"
resetprop -n ro.odm.build.date.utc "1676872060"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name a32xxx
resetprop -n ro.product.odm.name a32xxx
resetprop -n ro.product.vendor.name a32xxx
resetprop -n ro.product.system.name a32xxx
resetprop -n ro.product.name a32xxx
resetprop -n ro.product.bootimage.name a32xxx
resetprop -n ro.product.vendor_dlkm.name a32xxx
resetprop -n ro.product.system_ext.name a32xxx
resetprop -n ro.build.flavor a32xxx-user
randomStr="a32xxx-user samsung TP1A.220624.014 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=869206e372b4
resetprop -n ro.build.host ${randomStr}
randomStr=b6808e5b
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=kIWONP
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=cc7d79ad33cd8
randomStr2=09
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=87
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "A326BXXU5CWB7"
resetprop -n ro.build.description "a32xxx-user 13 TP1A.220624.014 A326BXXU5CWB7 release-keys"
resetprop -n ro.build.product.backup "a32x"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "dpi"
resetprop -n ro.build.host "SWDK6610"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n ro.mediatek.version.branch "alps-mp-t0.mssi1.tc10sp"
resetprop -n ro.mediatek.version.release "alps-mp-t0.mp1.tc10sp-V1.74"
resetprop -n ro.vendor.mtk_omacp_support "1"
resetprop -n ro.vendor.mtk_flv_playback_support "1"
resetprop -n ro.vendor.mtk_telephony_add_on_policy "0"
resetprop -n media.stagefright.thumbnail.prefer_hw_codecs "true"
resetprop -n vendor.mtk_thumbnail_optimization "true"
resetprop -n ro.vendor.system.mtk_dmc_support "1"
resetprop -n ro.vendor.mtk_power_off_alarm_test "1"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2023-02-01
