strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "V551 Aura"
resetprop -n ro.product.vendor.model "V551 Aura"
resetprop -n ro.product.vendor_dlkm.marketname "V551 Aura"
resetprop -n ro.product.product.marketname "V551 Aura"
resetprop -n ro.product.system.marketname "V551 Aura"
resetprop -n ro.product.odm_dlkm.marketname "V551 Aura"
resetprop -n ro.product.system_ext.marketname "V551 Aura"
resetprop -n ro.product.odm_dlkm.model "V551 Aura"
resetprop -n ro.product.system.model "V551 Aura"
resetprop -n ro.product.system_ext.model "V551 Aura"
resetprop -n ro.product.vendor_dlkm.model "V551 Aura"
resetprop -n bluetooth.device.default_name "V551 Aura"
resetprop -n ro.product.bootimage.model "V551 Aura"
resetprop -n ro.product.vendor.marketname "V551 Aura"
resetprop -n ro.product.marketname "V551 Aura"
resetprop -n ro.product.odm.model "V551 Aura"
resetprop -n ro.product.model "V551 Aura"
resetprop -n ro.product.product.model "V551 Aura"
resetprop -n ro.product.odm.marketname "V551 Aura"
resetprop -n ro.product.vendor.manufacturer "ERGO"
resetprop -n ro.product.product.manufacturer "ERGO"
resetprop -n ro.product.bootimage.manufacturer "ERGO"
resetprop -n ro.product.manufacturer "ERGO"
resetprop -n ro.product.odm.manufacturer "ERGO"
resetprop -n ro.product.system.manufacturer "ERGO"
resetprop -n ro.product.system_ext.manufacturer "ERGO"
resetprop -n ro.product.vendor_dlkm.manufacturer "ERGO"
resetprop -n ro.product.vendor.brand "ERGO"
resetprop -n ro.product.product.brand "ERGO"
resetprop -n ro.product.vendor_dlkm.brand "ERGO"
resetprop -n ro.product.system.brand "ERGO"
resetprop -n ro.product.bootimage.brand "ERGO"
resetprop -n ro.product.system_ext.brand "ERGO"
resetprop -n ro.product.odm.brand "ERGO"
resetprop -n ro.product.odm_dlkm.brand "ERGO"
resetprop -n ro.product.brand "ERGO"
resetprop -n ro.vendor_dlkm.build.fingerprint "ERGO/V551_Aura/V551_Aura:8.1.0/O11019/1525180903:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "ERGO/V551_Aura/V551_Aura:8.1.0/O11019/1525180903:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "ERGO/V551_Aura/V551_Aura:8.1.0/O11019/1525180903:user/release-keys"
resetprop -n ro.odm.build.fingerprint "ERGO/V551_Aura/V551_Aura:8.1.0/O11019/1525180903:user/release-keys"
resetprop -n ro.system.build.fingerprint "ERGO/V551_Aura/V551_Aura:8.1.0/O11019/1525180903:user/release-keys"
resetprop -n ro.build.fingerprint "ERGO/V551_Aura/V551_Aura:8.1.0/O11019/1525180903:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "ERGO/V551_Aura/V551_Aura:8.1.0/O11019/1525180903:user/release-keys"
resetprop -n ro.product.build.fingerprint "ERGO/V551_Aura/V551_Aura:8.1.0/O11019/1525180903:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "ERGO/V551_Aura/V551_Aura:8.1.0/O11019/1525180903:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=4d7c621db3
resetprop -n ro.system.build.version.incremental 1525180903
resetprop -n ro.bootimage.build.version.incremental 1525180903
resetprop -n ro.product.build.version.incremental 1525180903
resetprop -n ro.odm.build.version.incremental 1525180903
resetprop -n ro.vendor_dlkm.build.version.incremental 1525180903
resetprop -n ro.system_ext.build.version.incremental 1525180903
resetprop -n ro.build.version.incremental 1525180903
resetprop -n ro.vendor.build.version.incremental 1525180903
resetprop -n ro.odm.build.id "O11019"
resetprop -n ro.product.build.id "O11019"
resetprop -n ro.bootimage.build.id "O11019"
resetprop -n ro.system_ext.build.id "O11019"
resetprop -n ro.vendor_dlkm.build.id "O11019"
resetprop -n ro.build.id "O11019"
resetprop -n ro.system.build.id "O11019"
resetprop -n ro.vendor.build.id "O11019"
resetprop -n ro.system.build.date "Mon Sep 17 11:02:54 CST 2018"
resetprop -n ro.bootimage.build.date "Mon Sep 17 11:02:54 CST 2018"
resetprop -n ro.product.build.date "Mon Sep 17 11:02:54 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Mon Sep 17 11:02:54 CST 2018"
resetprop -n ro.system_ext.build.date "Mon Sep 17 11:02:54 CST 2018"
resetprop -n ro.odm.build.date "Mon Sep 17 11:02:54 CST 2018"
resetprop -n ro.build.date "Mon Sep 17 11:02:54 CST 2018"
resetprop -n ro.vendor.build.date "Mon Sep 17 11:02:54 CST 2018"
resetprop -n ro.product.build.date.utc "1537153374"
resetprop -n ro.system_ext.build.date.utc "1537153374"
resetprop -n ro.system.build.date.utc "1537153374"
resetprop -n ro.vendor.build.date.utc "1537153374"
resetprop -n ro.vendor_dlkm.build.date.utc "1537153374"
resetprop -n ro.build.date.utc "1537153374"
resetprop -n ro.bootimage.build.date.utc "1537153374"
resetprop -n ro.odm.build.date.utc "1537153374"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name V551_Aura
resetprop -n ro.product.odm.name V551_Aura
resetprop -n ro.product.vendor.name V551_Aura
resetprop -n ro.product.system.name V551_Aura
resetprop -n ro.product.name V551_Aura
resetprop -n ro.product.bootimage.name V551_Aura
resetprop -n ro.product.vendor_dlkm.name V551_Aura
resetprop -n ro.product.system_ext.name V551_Aura
resetprop -n ro.build.flavor full_d8098-user
randomStr="full_d8098-user ERGO O11019 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=a32d791daf1b
resetprop -n ro.build.host ${randomStr}
randomStr=228e20f6
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=FbFiqS
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=3ee8a4892905b
randomStr2=d3
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=24
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "1525180903"
resetprop -n ro.build.description "full_d8098-user 8.1.0 O11019 1525180903 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "ycl"
resetprop -n ro.build.host "sunvov-218"
resetprop -n ro.build.product.backup "d8098"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n debug.hwui.render_dirty_regions "false"
resetprop -n ro.fota.platform "MTK6580_8.1"
resetprop -n ro.fota.type "phone"
resetprop -n ro.fota.app "5"
resetprop -n ro.fota.oem "sunvov6580_8.1"
resetprop -n ro.fota.device "V551 Aura"
resetprop -n ro.fota.version "ERGO_V551_Aura_V9.0_20180917_20180917-1106"
resetprop -n ro.fota.version.display "ERGO_V551_Aura_V9.0_20180917"
resetprop -n ro.expect.recovery_id "0x59c82712621b16628f14c9b068e480ff18a7db9a000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-08-05
