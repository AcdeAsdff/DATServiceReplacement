strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "vivo 1901"
resetprop -n ro.product.vendor.model "vivo 1901"
resetprop -n ro.product.vendor_dlkm.marketname "vivo 1901"
resetprop -n ro.product.product.marketname "vivo 1901"
resetprop -n ro.product.system.marketname "vivo 1901"
resetprop -n ro.product.odm_dlkm.marketname "vivo 1901"
resetprop -n ro.product.system_ext.marketname "vivo 1901"
resetprop -n ro.product.odm_dlkm.model "vivo 1901"
resetprop -n ro.product.system.model "vivo 1901"
resetprop -n ro.product.system_ext.model "vivo 1901"
resetprop -n ro.product.vendor_dlkm.model "vivo 1901"
resetprop -n bluetooth.device.default_name "vivo 1901"
resetprop -n ro.product.bootimage.model "vivo 1901"
resetprop -n ro.product.vendor.marketname "vivo 1901"
resetprop -n ro.product.marketname "vivo 1901"
resetprop -n ro.product.odm.model "vivo 1901"
resetprop -n ro.product.model "vivo 1901"
resetprop -n ro.product.product.model "vivo 1901"
resetprop -n ro.product.odm.marketname "vivo 1901"
resetprop -n ro.product.vendor.manufacturer "vivo"
resetprop -n ro.product.product.manufacturer "vivo"
resetprop -n ro.product.bootimage.manufacturer "vivo"
resetprop -n ro.product.manufacturer "vivo"
resetprop -n ro.product.odm.manufacturer "vivo"
resetprop -n ro.product.system.manufacturer "vivo"
resetprop -n ro.product.system_ext.manufacturer "vivo"
resetprop -n ro.product.vendor_dlkm.manufacturer "vivo"
resetprop -n ro.product.vendor.brand "vivo"
resetprop -n ro.product.product.brand "vivo"
resetprop -n ro.product.vendor_dlkm.brand "vivo"
resetprop -n ro.product.system.brand "vivo"
resetprop -n ro.product.bootimage.brand "vivo"
resetprop -n ro.product.system_ext.brand "vivo"
resetprop -n ro.product.odm.brand "vivo"
resetprop -n ro.product.odm_dlkm.brand "vivo"
resetprop -n ro.product.brand "vivo"
resetprop -n ro.vendor_dlkm.build.fingerprint "vivo/1901/1901:11/RP1A.200720.012/compiler1009184113:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "vivo/1901/1901:11/RP1A.200720.012/compiler1009184113:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "vivo/1901/1901:11/RP1A.200720.012/compiler1009184113:user/release-keys"
resetprop -n ro.odm.build.fingerprint "vivo/1901/1901:11/RP1A.200720.012/compiler1009184113:user/release-keys"
resetprop -n ro.system.build.fingerprint "vivo/1901/1901:11/RP1A.200720.012/compiler1009184113:user/release-keys"
resetprop -n ro.build.fingerprint "vivo/1901/1901:11/RP1A.200720.012/compiler1009184113:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "vivo/1901/1901:11/RP1A.200720.012/compiler1009184113:user/release-keys"
resetprop -n ro.product.build.fingerprint "vivo/1901/1901:11/RP1A.200720.012/compiler1009184113:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "vivo/1901/1901:11/RP1A.200720.012/compiler1009184113:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=bf608976ed
resetprop -n ro.system.build.version.incremental eng.compil.20211009.184437
resetprop -n ro.bootimage.build.version.incremental eng.compil.20211009.184437
resetprop -n ro.product.build.version.incremental eng.compil.20211009.184437
resetprop -n ro.odm.build.version.incremental eng.compil.20211009.184437
resetprop -n ro.vendor_dlkm.build.version.incremental eng.compil.20211009.184437
resetprop -n ro.system_ext.build.version.incremental eng.compil.20211009.184437
resetprop -n ro.build.version.incremental eng.compil.20211009.184437
resetprop -n ro.vendor.build.version.incremental eng.compil.20211009.184437
resetprop -n ro.odm.build.id "RP1A.200720.012"
resetprop -n ro.product.build.id "RP1A.200720.012"
resetprop -n ro.bootimage.build.id "RP1A.200720.012"
resetprop -n ro.system_ext.build.id "RP1A.200720.012"
resetprop -n ro.vendor_dlkm.build.id "RP1A.200720.012"
resetprop -n ro.build.id "RP1A.200720.012"
resetprop -n ro.system.build.id "RP1A.200720.012"
resetprop -n ro.vendor.build.id "RP1A.200720.012"
resetprop -n ro.system.build.date "Sat Oct  9 18:41:13 CST 2021"
resetprop -n ro.bootimage.build.date "Sat Oct  9 18:41:13 CST 2021"
resetprop -n ro.product.build.date "Sat Oct  9 18:41:13 CST 2021"
resetprop -n ro.vendor_dlkm.build.date "Sat Oct  9 18:41:13 CST 2021"
resetprop -n ro.system_ext.build.date "Sat Oct  9 18:41:13 CST 2021"
resetprop -n ro.odm.build.date "Sat Oct  9 18:41:13 CST 2021"
resetprop -n ro.build.date "Sat Oct  9 18:41:13 CST 2021"
resetprop -n ro.vendor.build.date "Sat Oct  9 18:41:13 CST 2021"
resetprop -n ro.product.build.date.utc "1633776073"
resetprop -n ro.system_ext.build.date.utc "1633776073"
resetprop -n ro.system.build.date.utc "1633776073"
resetprop -n ro.vendor.build.date.utc "1633776073"
resetprop -n ro.vendor_dlkm.build.date.utc "1633776073"
resetprop -n ro.build.date.utc "1633776073"
resetprop -n ro.bootimage.build.date.utc "1633776073"
resetprop -n ro.odm.build.date.utc "1633776073"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name 1901
resetprop -n ro.product.odm.name 1901
resetprop -n ro.product.vendor.name 1901
resetprop -n ro.product.system.name 1901
resetprop -n ro.product.name 1901
resetprop -n ro.product.bootimage.name 1901
resetprop -n ro.product.vendor_dlkm.name 1901
resetprop -n ro.product.system_ext.name 1901
resetprop -n ro.build.flavor full_k62v1_64_bsp-user
randomStr="full_k62v1_64_bsp-user vivo RP1A.200720.012 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=945b9555c80f
resetprop -n ro.build.host ${randomStr}
randomStr=6f131f1e
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=fITXOo
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=14e6936b948ea
randomStr2=c9
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=bc
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "eng.compil.20211009.184437"
resetprop -n ro.build.description "full_k62v1_64_bsp-user 11 RP1A.200720.012 eng.compil.20211009.184437 release-keys"
resetprop -n ro.build.product.backup "k62v1_64_bsp"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "compiler"
resetprop -n ro.build.host "comsz01078169"
resetprop -n ro.vivo.os.build.display.id "Funtouch OS_9"
resetprop -n ro.vivo.product.release.name "1901"
resetprop -n ro.vivo.product.release.model "1901"
resetprop -n ro.mediatek.wlan.wsc "1"
resetprop -n ro.mediatek.wlan.p2p "1"
resetprop -n ro.mtk_perf_simple_start_win "1"
resetprop -n ro.mtk_perf_fast_start_win "1"
resetprop -n ro.mtk_perf_response_time "1"
resetprop -n persist.vivo.compass.no_return "true"
resetprop -n persist.vivo.motion_raise2wake "enable"
resetprop -n persist.vivo.displayp3.support "0"
resetprop -n persist.vivo.phone.panel_type "tft"
resetprop -n persist.vivo.phone.sarpower "Have_sarpower"
resetprop -n persist.vivo.proxcovernotice "screen_widows_pick_without_ai"
resetprop -n ro.vivo.low_ram "true"
resetprop -n persist.vivo.sar "1.007;0.752"
resetprop -n persist.vivo.phone.wfd "Have_wfd"
resetprop -n persist.vivo.mtk.networkstate_tcp_parameter.enable "true"
resetprop -n persist.vivo.charge_type.map_scheme "1"
resetprop -n persist.vivo.charge.logo "1"
resetprop -n persist.vivo.phone.screen_size "60"
resetprop -n persist.vivo.smartkey.enable "true"
resetprop -n persist.vivo.phone.usb_otg "Have_usb_otg"
resetprop -n persist.vivo.check_fast_charge "1"
resetprop -n persist.vivo.enable_fast_charge "1"
resetprop -n persist.vivo.charge.version "1"
resetprop -n persist.vivo.disable_chg_switch "1"
resetprop -n persist.vivo.calling_state "0"
resetprop -n persist.vivo.phone.panel_max_nit "0"
resetprop -n persist.vivo.phone.super_lcd "false"
resetprop -n persist.system.vivo.enable_color_mode_id "0"
resetprop -n persist.vivo.phone.fps_default "1"
resetprop -n persist.vivo.phone.fps_max "60"
resetprop -n persist.vendor.camera.vivo.p3.support "1"
resetprop -n persist.vivo.feiyu.enable "true"
resetprop -n persist.vivo.weixin_calling_state "0"
resetprop -n persist.vivo.service.model "1"
resetprop -n ro.vivo.motor.vibrate "1"
resetprop -n ro.vivo.settings.search "1"
resetprop -n ro.com.google.ime.theme_id "5"
resetprop -n ro.com.google.ime.key_border "true"
resetprop -n ro.com.google.ime.corner_key_r "25"
resetprop -n ro.com.google.ime.corner_key_l "25"
resetprop -n ro.com.google.ime.kb_pad_port_r "5"
resetprop -n ro.com.google.ime.kb_pad_port_l "5"
resetprop -n ro.com.google.ime.kb_pad_port_b "2"
resetprop -n ro.com.google.ime.kb_pad_land_r "55"
resetprop -n ro.com.google.ime.kb_pad_land_l "55"
resetprop -n ro.com.google.ime.kb_pad_land_b "2"
resetprop -n ro.com.google.ime.key_popup "false"
resetprop -n ro.com.google.ime.system_lm_dir "/system/media/ime/google/d3_lms/"
resetprop -n ro.persist.vivo.sar "1.007;0.752"
resetprop -n ro.com.google.clientidbase "android-vivo"
resetprop -n ro.com.google.clientidbase.ms "android-vivo-rev1"
resetprop -n ro.com.google.clientidbase.cr "android-vivo"
resetprop -n ro.com.google.ime.number_row "true"
resetprop -n ro.vivo.oem.support "yes"
resetprop -n persist.vivo.radio.type.list "WCDMA,TDD-LTE,FDD-LTE,GSM"
resetprop -n ro.vivo.lcm.xhd "HD_19x3_9"
resetprop -n persist.vivo.support_close_gp "1"
resetprop -n ro.vivo.lte.voice.type "CSFB"
resetprop -n ro.vivo.net.entry "no"
resetprop -n ro.vivo.op.entry "no"
resetprop -n ro.vivo.hardware.version "PD1901BF_EXMA"
resetprop -n ro.vivo.product.solution "MTK"
resetprop -n ro.vivo.product.platform "MTK6765"
resetprop -n ro.vivo.board.version "MA"
resetprop -n ro.vivo.os.name "Funtouch"
resetprop -n ro.vivo.os.version "9.0"
resetprop -n ro.vivo.build.version.sdk "1"
resetprop -n persist.vivo.support.wallet.icon "true"
resetprop -n ro.vivo.rom.style "vigour"
resetprop -n ro.vivo.product.overseas "yes"
resetprop -n ro.vivo.build.version.incremental "6.12.12"
resetprop -n ro.vivo.product.series "VIVO"
resetprop -n ro.vivo.product.res.series "Y"
resetprop -n persist.vivo.face.assistant "0"
resetprop -n persist.system.vivo.face.unlock.strong "1"
resetprop -n persist.system.vivo.face.unlock.convenience.scheme "0"
resetprop -n persist.system.vivo.face.wallpaper.brightness.adjustment "0"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2021-10-01
