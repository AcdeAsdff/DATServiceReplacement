strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "Nexus 6P"
resetprop -n ro.product.vendor.model "Nexus 6P"
resetprop -n ro.product.vendor_dlkm.marketname "Nexus 6P"
resetprop -n ro.product.product.marketname "Nexus 6P"
resetprop -n ro.product.system.marketname "Nexus 6P"
resetprop -n ro.product.odm_dlkm.marketname "Nexus 6P"
resetprop -n ro.product.system_ext.marketname "Nexus 6P"
resetprop -n ro.product.odm_dlkm.model "Nexus 6P"
resetprop -n ro.product.system.model "Nexus 6P"
resetprop -n ro.product.system_ext.model "Nexus 6P"
resetprop -n ro.product.vendor_dlkm.model "Nexus 6P"
resetprop -n bluetooth.device.default_name "Nexus 6P"
resetprop -n ro.product.bootimage.model "Nexus 6P"
resetprop -n ro.product.vendor.marketname "Nexus 6P"
resetprop -n ro.product.marketname "Nexus 6P"
resetprop -n ro.product.odm.model "Nexus 6P"
resetprop -n ro.product.model "Nexus 6P"
resetprop -n ro.product.product.model "Nexus 6P"
resetprop -n ro.product.odm.marketname "Nexus 6P"
resetprop -n ro.product.vendor.manufacturer "Huawei"
resetprop -n ro.product.product.manufacturer "Huawei"
resetprop -n ro.product.bootimage.manufacturer "Huawei"
resetprop -n ro.product.manufacturer "Huawei"
resetprop -n ro.product.odm.manufacturer "Huawei"
resetprop -n ro.product.system.manufacturer "Huawei"
resetprop -n ro.product.system_ext.manufacturer "Huawei"
resetprop -n ro.product.vendor_dlkm.manufacturer "Huawei"
resetprop -n ro.product.vendor.brand "google"
resetprop -n ro.product.product.brand "google"
resetprop -n ro.product.vendor_dlkm.brand "google"
resetprop -n ro.product.system.brand "google"
resetprop -n ro.product.bootimage.brand "google"
resetprop -n ro.product.system_ext.brand "google"
resetprop -n ro.product.odm.brand "google"
resetprop -n ro.product.odm_dlkm.brand "google"
resetprop -n ro.product.brand "google"
resetprop -n ro.vendor_dlkm.build.fingerprint "google/angler/angler:7.0/NPD90G/3051502:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "google/angler/angler:7.0/NPD90G/3051502:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "google/angler/angler:7.0/NPD90G/3051502:user/release-keys"
resetprop -n ro.odm.build.fingerprint "google/angler/angler:7.0/NPD90G/3051502:user/release-keys"
resetprop -n ro.system.build.fingerprint "google/angler/angler:7.0/NPD90G/3051502:user/release-keys"
resetprop -n ro.build.fingerprint "google/angler/angler:7.0/NPD90G/3051502:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "google/angler/angler:7.0/NPD90G/3051502:user/release-keys"
resetprop -n ro.product.build.fingerprint "google/angler/angler:7.0/NPD90G/3051502:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "google/angler/angler:7.0/NPD90G/3051502:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=f1647e7a2f
resetprop -n ro.system.build.version.incremental 3051502
resetprop -n ro.bootimage.build.version.incremental 3051502
resetprop -n ro.product.build.version.incremental 3051502
resetprop -n ro.odm.build.version.incremental 3051502
resetprop -n ro.vendor_dlkm.build.version.incremental 3051502
resetprop -n ro.system_ext.build.version.incremental 3051502
resetprop -n ro.build.version.incremental 3051502
resetprop -n ro.vendor.build.version.incremental 3051502
resetprop -n ro.odm.build.id "NPD90G"
resetprop -n ro.product.build.id "NPD90G"
resetprop -n ro.bootimage.build.id "NPD90G"
resetprop -n ro.system_ext.build.id "NPD90G"
resetprop -n ro.vendor_dlkm.build.id "NPD90G"
resetprop -n ro.build.id "NPD90G"
resetprop -n ro.system.build.id "NPD90G"
resetprop -n ro.vendor.build.id "NPD90G"
resetprop -n ro.system.build.date "Tue Jul 12 17:54:21 UTC 2016"
resetprop -n ro.bootimage.build.date "Tue Jul 12 17:54:21 UTC 2016"
resetprop -n ro.product.build.date "Tue Jul 12 17:54:21 UTC 2016"
resetprop -n ro.vendor_dlkm.build.date "Tue Jul 12 17:54:21 UTC 2016"
resetprop -n ro.system_ext.build.date "Tue Jul 12 17:54:21 UTC 2016"
resetprop -n ro.odm.build.date "Tue Jul 12 17:54:21 UTC 2016"
resetprop -n ro.build.date "Tue Jul 12 17:54:21 UTC 2016"
resetprop -n ro.vendor.build.date "Tue Jul 12 17:54:21 UTC 2016"
resetprop -n ro.product.build.date.utc "1468346061"
resetprop -n ro.system_ext.build.date.utc "1468346061"
resetprop -n ro.system.build.date.utc "1468346061"
resetprop -n ro.vendor.build.date.utc "1468346061"
resetprop -n ro.vendor_dlkm.build.date.utc "1468346061"
resetprop -n ro.build.date.utc "1468346061"
resetprop -n ro.bootimage.build.date.utc "1468346061"
resetprop -n ro.odm.build.date.utc "1468346061"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name angler
resetprop -n ro.product.odm.name angler
resetprop -n ro.product.vendor.name angler
resetprop -n ro.product.system.name angler
resetprop -n ro.product.name angler
resetprop -n ro.product.bootimage.name angler
resetprop -n ro.product.vendor_dlkm.name angler
resetprop -n ro.product.system_ext.name angler
resetprop -n ro.build.flavor angler-user
randomStr="angler-user Huawei NPD90G "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=445b3519e5f8
resetprop -n ro.build.host ${randomStr}
randomStr=04de475c
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=PZXdVP
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=8d669de5d77e2
randomStr2=ef
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=19
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "3051502"
resetprop -n ro.build.description "angler-user 7.0 NPD90G 3051502 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "android-build"
resetprop -n ro.build.host "wpds2.hot.corp.google.com"
resetprop -n ro.build.product.backup "angler"
resetprop -n ro.build.characteristics "nosdcard"
resetprop -n ro.com.google.clientidbase "android-google"
resetprop -n ro.hwui.texture_cache_size "72"
resetprop -n ro.hwui.layer_cache_size "48"
resetprop -n ro.hwui.r_buffer_cache_size "8"
resetprop -n ro.hwui.path_cache_size "32"
resetprop -n ro.hwui.gradient_cache_size "1"
resetprop -n ro.hwui.drop_shadow_cache_size "6"
resetprop -n ro.hwui.texture_cache_flushrate "0.4"
resetprop -n ro.hwui.text_small_cache_width "1024"
resetprop -n ro.hwui.text_small_cache_height "1024"
resetprop -n ro.hwui.text_large_cache_width "2048"
resetprop -n ro.hwui.text_large_cache_height "1024"
resetprop -n media.aac_51_output_enabled "true"
resetprop -n ro.expect.recovery_id "0x7a4dc5a271bb24793ddcee080ac2eb6a4cd8a5ce000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2016-07-05
