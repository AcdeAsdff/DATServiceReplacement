strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "HiSmart TV"
resetprop -n ro.product.vendor.model "HiSmart TV"
resetprop -n ro.product.vendor_dlkm.marketname "HiSmart TV"
resetprop -n ro.product.product.marketname "HiSmart TV"
resetprop -n ro.product.system.marketname "HiSmart TV"
resetprop -n ro.product.odm_dlkm.marketname "HiSmart TV"
resetprop -n ro.product.system_ext.marketname "HiSmart TV"
resetprop -n ro.product.odm_dlkm.model "HiSmart TV"
resetprop -n ro.product.system.model "HiSmart TV"
resetprop -n ro.product.system_ext.model "HiSmart TV"
resetprop -n ro.product.vendor_dlkm.model "HiSmart TV"
resetprop -n bluetooth.device.default_name "HiSmart TV"
resetprop -n ro.product.bootimage.model "HiSmart TV"
resetprop -n ro.product.vendor.marketname "HiSmart TV"
resetprop -n ro.product.marketname "HiSmart TV"
resetprop -n ro.product.odm.model "HiSmart TV"
resetprop -n ro.product.model "HiSmart TV"
resetprop -n ro.product.product.model "HiSmart TV"
resetprop -n ro.product.odm.marketname "HiSmart TV"
resetprop -n ro.product.vendor.manufacturer "Hisense"
resetprop -n ro.product.product.manufacturer "Hisense"
resetprop -n ro.product.bootimage.manufacturer "Hisense"
resetprop -n ro.product.manufacturer "Hisense"
resetprop -n ro.product.odm.manufacturer "Hisense"
resetprop -n ro.product.system.manufacturer "Hisense"
resetprop -n ro.product.system_ext.manufacturer "Hisense"
resetprop -n ro.product.vendor_dlkm.manufacturer "Hisense"
resetprop -n ro.product.vendor.brand "Hisense"
resetprop -n ro.product.product.brand "Hisense"
resetprop -n ro.product.vendor_dlkm.brand "Hisense"
resetprop -n ro.product.system.brand "Hisense"
resetprop -n ro.product.bootimage.brand "Hisense"
resetprop -n ro.product.system_ext.brand "Hisense"
resetprop -n ro.product.odm.brand "Hisense"
resetprop -n ro.product.odm_dlkm.brand "Hisense"
resetprop -n ro.product.brand "Hisense"
resetprop -n ro.vendor_dlkm.build.fingerprint "Hisense/fushan_2/hamamatsucho:9/PTO4.210210.001/7136508:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Hisense/fushan_2/hamamatsucho:9/PTO4.210210.001/7136508:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Hisense/fushan_2/hamamatsucho:9/PTO4.210210.001/7136508:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Hisense/fushan_2/hamamatsucho:9/PTO4.210210.001/7136508:user/release-keys"
resetprop -n ro.system.build.fingerprint "Hisense/fushan_2/hamamatsucho:9/PTO4.210210.001/7136508:user/release-keys"
resetprop -n ro.build.fingerprint "Hisense/fushan_2/hamamatsucho:9/PTO4.210210.001/7136508:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Hisense/fushan_2/hamamatsucho:9/PTO4.210210.001/7136508:user/release-keys"
resetprop -n ro.product.build.fingerprint "Hisense/fushan_2/hamamatsucho:9/PTO4.210210.001/7136508:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Hisense/fushan_2/hamamatsucho:9/PTO4.210210.001/7136508:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=5f9858c5be
resetprop -n ro.system.build.version.incremental 7136508
resetprop -n ro.bootimage.build.version.incremental 7136508
resetprop -n ro.product.build.version.incremental 7136508
resetprop -n ro.odm.build.version.incremental 7136508
resetprop -n ro.vendor_dlkm.build.version.incremental 7136508
resetprop -n ro.system_ext.build.version.incremental 7136508
resetprop -n ro.build.version.incremental 7136508
resetprop -n ro.vendor.build.version.incremental 7136508
resetprop -n ro.odm.build.id "PTO4.210210.001"
resetprop -n ro.product.build.id "PTO4.210210.001"
resetprop -n ro.bootimage.build.id "PTO4.210210.001"
resetprop -n ro.system_ext.build.id "PTO4.210210.001"
resetprop -n ro.vendor_dlkm.build.id "PTO4.210210.001"
resetprop -n ro.build.id "PTO4.210210.001"
resetprop -n ro.system.build.id "PTO4.210210.001"
resetprop -n ro.vendor.build.id "PTO4.210210.001"
resetprop -n ro.system.build.date "Wed Feb 10 09:27:43 UTC 2021"
resetprop -n ro.bootimage.build.date "Wed Feb 10 09:27:43 UTC 2021"
resetprop -n ro.product.build.date "Wed Feb 10 09:27:43 UTC 2021"
resetprop -n ro.vendor_dlkm.build.date "Wed Feb 10 09:27:43 UTC 2021"
resetprop -n ro.system_ext.build.date "Wed Feb 10 09:27:43 UTC 2021"
resetprop -n ro.odm.build.date "Wed Feb 10 09:27:43 UTC 2021"
resetprop -n ro.build.date "Wed Feb 10 09:27:43 UTC 2021"
resetprop -n ro.vendor.build.date "Wed Feb 10 09:27:43 UTC 2021"
resetprop -n ro.product.build.date.utc "1612949263"
resetprop -n ro.system_ext.build.date.utc "1612949263"
resetprop -n ro.system.build.date.utc "1612949263"
resetprop -n ro.vendor.build.date.utc "1612949263"
resetprop -n ro.vendor_dlkm.build.date.utc "1612949263"
resetprop -n ro.build.date.utc "1612949263"
resetprop -n ro.bootimage.build.date.utc "1612949263"
resetprop -n ro.odm.build.date.utc "1612949263"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name fushan_2
resetprop -n ro.product.odm.name fushan_2
resetprop -n ro.product.vendor.name fushan_2
resetprop -n ro.product.system.name fushan_2
resetprop -n ro.product.name fushan_2
resetprop -n ro.product.bootimage.name fushan_2
resetprop -n ro.product.vendor_dlkm.name fushan_2
resetprop -n ro.product.system_ext.name fushan_2
resetprop -n ro.build.flavor fushan_2-user
randomStr="fushan_2-user Hisense PTO4.210210.001 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=1d6755b3bd70
resetprop -n ro.build.host ${randomStr}
randomStr=687e0c0a
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=GGTdTh
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=2f7b1773feb25
randomStr2=eb
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=a7
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "7136508"
resetprop -n ro.build.description "fushan_2-user 9 PTO4.210210.001 7136508 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "android-build"
resetprop -n ro.build.host "abfarm-us-west1-c-0059"
resetprop -n ro.build.product.backup "hamamatsucho"
resetprop -n ro.build.characteristics "tv"
resetprop -n ro.expect.recovery_id "0x3830f7577d1eeba568dbcfd5a60fc421229bc06b000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2021-02-05
