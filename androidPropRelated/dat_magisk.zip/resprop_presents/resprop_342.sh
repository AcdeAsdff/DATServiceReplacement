strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "S45A"
resetprop -n ro.product.vendor.model "S45A"
resetprop -n ro.product.vendor_dlkm.marketname "S45A"
resetprop -n ro.product.product.marketname "S45A"
resetprop -n ro.product.system.marketname "S45A"
resetprop -n ro.product.odm_dlkm.marketname "S45A"
resetprop -n ro.product.system_ext.marketname "S45A"
resetprop -n ro.product.odm_dlkm.model "S45A"
resetprop -n ro.product.system.model "S45A"
resetprop -n ro.product.system_ext.model "S45A"
resetprop -n ro.product.vendor_dlkm.model "S45A"
resetprop -n bluetooth.device.default_name "S45A"
resetprop -n ro.product.bootimage.model "S45A"
resetprop -n ro.product.vendor.marketname "S45A"
resetprop -n ro.product.marketname "S45A"
resetprop -n ro.product.odm.model "S45A"
resetprop -n ro.product.model "S45A"
resetprop -n ro.product.product.model "S45A"
resetprop -n ro.product.odm.marketname "S45A"
resetprop -n ro.product.vendor.manufacturer "EVERCOSS"
resetprop -n ro.product.product.manufacturer "EVERCOSS"
resetprop -n ro.product.bootimage.manufacturer "EVERCOSS"
resetprop -n ro.product.manufacturer "EVERCOSS"
resetprop -n ro.product.odm.manufacturer "EVERCOSS"
resetprop -n ro.product.system.manufacturer "EVERCOSS"
resetprop -n ro.product.system_ext.manufacturer "EVERCOSS"
resetprop -n ro.product.vendor_dlkm.manufacturer "EVERCOSS"
resetprop -n ro.product.vendor.brand "EVERCOSS"
resetprop -n ro.product.product.brand "EVERCOSS"
resetprop -n ro.product.vendor_dlkm.brand "EVERCOSS"
resetprop -n ro.product.system.brand "EVERCOSS"
resetprop -n ro.product.bootimage.brand "EVERCOSS"
resetprop -n ro.product.system_ext.brand "EVERCOSS"
resetprop -n ro.product.odm.brand "EVERCOSS"
resetprop -n ro.product.odm_dlkm.brand "EVERCOSS"
resetprop -n ro.product.brand "EVERCOSS"
resetprop -n ro.vendor_dlkm.build.fingerprint "EVERCOSS/S45A/S45A:8.1.0/OPM2.171019.012/35310:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "EVERCOSS/S45A/S45A:8.1.0/OPM2.171019.012/35310:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "EVERCOSS/S45A/S45A:8.1.0/OPM2.171019.012/35310:user/release-keys"
resetprop -n ro.odm.build.fingerprint "EVERCOSS/S45A/S45A:8.1.0/OPM2.171019.012/35310:user/release-keys"
resetprop -n ro.system.build.fingerprint "EVERCOSS/S45A/S45A:8.1.0/OPM2.171019.012/35310:user/release-keys"
resetprop -n ro.build.fingerprint "EVERCOSS/S45A/S45A:8.1.0/OPM2.171019.012/35310:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "EVERCOSS/S45A/S45A:8.1.0/OPM2.171019.012/35310:user/release-keys"
resetprop -n ro.product.build.fingerprint "EVERCOSS/S45A/S45A:8.1.0/OPM2.171019.012/35310:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "EVERCOSS/S45A/S45A:8.1.0/OPM2.171019.012/35310:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=b2d44f2411
resetprop -n ro.system.build.version.incremental 35310
resetprop -n ro.bootimage.build.version.incremental 35310
resetprop -n ro.product.build.version.incremental 35310
resetprop -n ro.odm.build.version.incremental 35310
resetprop -n ro.vendor_dlkm.build.version.incremental 35310
resetprop -n ro.system_ext.build.version.incremental 35310
resetprop -n ro.build.version.incremental 35310
resetprop -n ro.vendor.build.version.incremental 35310
resetprop -n ro.odm.build.id "OPM2.171019.012"
resetprop -n ro.product.build.id "OPM2.171019.012"
resetprop -n ro.bootimage.build.id "OPM2.171019.012"
resetprop -n ro.system_ext.build.id "OPM2.171019.012"
resetprop -n ro.vendor_dlkm.build.id "OPM2.171019.012"
resetprop -n ro.build.id "OPM2.171019.012"
resetprop -n ro.system.build.id "OPM2.171019.012"
resetprop -n ro.vendor.build.id "OPM2.171019.012"
resetprop -n ro.system.build.date "Wed Aug 29 10:27:49 CST 2018"
resetprop -n ro.bootimage.build.date "Wed Aug 29 10:27:49 CST 2018"
resetprop -n ro.product.build.date "Wed Aug 29 10:27:49 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Wed Aug 29 10:27:49 CST 2018"
resetprop -n ro.system_ext.build.date "Wed Aug 29 10:27:49 CST 2018"
resetprop -n ro.odm.build.date "Wed Aug 29 10:27:49 CST 2018"
resetprop -n ro.build.date "Wed Aug 29 10:27:49 CST 2018"
resetprop -n ro.vendor.build.date "Wed Aug 29 10:27:49 CST 2018"
resetprop -n ro.product.build.date.utc "1535509669"
resetprop -n ro.system_ext.build.date.utc "1535509669"
resetprop -n ro.system.build.date.utc "1535509669"
resetprop -n ro.vendor.build.date.utc "1535509669"
resetprop -n ro.vendor_dlkm.build.date.utc "1535509669"
resetprop -n ro.build.date.utc "1535509669"
resetprop -n ro.bootimage.build.date.utc "1535509669"
resetprop -n ro.odm.build.date.utc "1535509669"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name S45A
resetprop -n ro.product.odm.name S45A
resetprop -n ro.product.vendor.name S45A
resetprop -n ro.product.system.name S45A
resetprop -n ro.product.name S45A
resetprop -n ro.product.bootimage.name S45A
resetprop -n ro.product.vendor_dlkm.name S45A
resetprop -n ro.product.system_ext.name S45A
resetprop -n ro.build.flavor oversea
randomStr="oversea EVERCOSS OPM2.171019.012 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=97dca85dc05d
resetprop -n ro.build.host ${randomStr}
randomStr=2c08aaa4
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=IIaIYA
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=5d74675f91ef4
randomStr2=c2
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=d2
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "35310"
resetprop -n ro.build.description "sp9832e_1h10_gofu_osll-user 8.1.0 OPM2.171019.012 35310 release-keys"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "builder"
resetprop -n ro.build.host "freecom8"
resetprop -n ro.build.product.backup "sp9832e_1h10_go"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.expect.recovery_id "0xb87b3ee56630f8f84d9e3086222f9797d2cb2654000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-08-05
