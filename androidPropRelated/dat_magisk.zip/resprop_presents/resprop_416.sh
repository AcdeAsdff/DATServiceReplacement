strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "magic"
resetprop -n ro.product.vendor.model "magic"
resetprop -n ro.product.vendor_dlkm.marketname "magic"
resetprop -n ro.product.product.marketname "magic"
resetprop -n ro.product.system.marketname "magic"
resetprop -n ro.product.odm_dlkm.marketname "magic"
resetprop -n ro.product.system_ext.marketname "magic"
resetprop -n ro.product.odm_dlkm.model "magic"
resetprop -n ro.product.system.model "magic"
resetprop -n ro.product.system_ext.model "magic"
resetprop -n ro.product.vendor_dlkm.model "magic"
resetprop -n bluetooth.device.default_name "magic"
resetprop -n ro.product.bootimage.model "magic"
resetprop -n ro.product.vendor.marketname "magic"
resetprop -n ro.product.marketname "magic"
resetprop -n ro.product.odm.model "magic"
resetprop -n ro.product.model "magic"
resetprop -n ro.product.product.model "magic"
resetprop -n ro.product.odm.marketname "magic"
resetprop -n ro.product.vendor.manufacturer "unknown"
resetprop -n ro.product.product.manufacturer "unknown"
resetprop -n ro.product.bootimage.manufacturer "unknown"
resetprop -n ro.product.manufacturer "unknown"
resetprop -n ro.product.odm.manufacturer "unknown"
resetprop -n ro.product.system.manufacturer "unknown"
resetprop -n ro.product.system_ext.manufacturer "unknown"
resetprop -n ro.product.vendor_dlkm.manufacturer "unknown"
resetprop -n ro.product.vendor.brand "Honor"
resetprop -n ro.product.product.brand "Honor"
resetprop -n ro.product.vendor_dlkm.brand "Honor"
resetprop -n ro.product.system.brand "Honor"
resetprop -n ro.product.bootimage.brand "Honor"
resetprop -n ro.product.system_ext.brand "Honor"
resetprop -n ro.product.odm.brand "Honor"
resetprop -n ro.product.odm_dlkm.brand "Honor"
resetprop -n ro.product.brand "Honor"
resetprop -n ro.vendor_dlkm.build.fingerprint "Honor/magic/magic:12/SP1A.210812.016/root12011546:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "Honor/magic/magic:12/SP1A.210812.016/root12011546:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "Honor/magic/magic:12/SP1A.210812.016/root12011546:user/release-keys"
resetprop -n ro.odm.build.fingerprint "Honor/magic/magic:12/SP1A.210812.016/root12011546:user/release-keys"
resetprop -n ro.system.build.fingerprint "Honor/magic/magic:12/SP1A.210812.016/root12011546:user/release-keys"
resetprop -n ro.build.fingerprint "Honor/magic/magic:12/SP1A.210812.016/root12011546:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "Honor/magic/magic:12/SP1A.210812.016/root12011546:user/release-keys"
resetprop -n ro.product.build.fingerprint "Honor/magic/magic:12/SP1A.210812.016/root12011546:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "Honor/magic/magic:12/SP1A.210812.016/root12011546:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=7dbb663164
resetprop -n ro.system.build.version.incremental V13.0.2.1.37.DEV
resetprop -n ro.bootimage.build.version.incremental V13.0.2.1.37.DEV
resetprop -n ro.product.build.version.incremental V13.0.2.1.37.DEV
resetprop -n ro.odm.build.version.incremental V13.0.2.1.37.DEV
resetprop -n ro.vendor_dlkm.build.version.incremental V13.0.2.1.37.DEV
resetprop -n ro.system_ext.build.version.incremental V13.0.2.1.37.DEV
resetprop -n ro.build.version.incremental V13.0.2.1.37.DEV
resetprop -n ro.vendor.build.version.incremental V13.0.2.1.37.DEV
resetprop -n ro.odm.build.id "SP1A.210812.016"
resetprop -n ro.product.build.id "SP1A.210812.016"
resetprop -n ro.bootimage.build.id "SP1A.210812.016"
resetprop -n ro.system_ext.build.id "SP1A.210812.016"
resetprop -n ro.vendor_dlkm.build.id "SP1A.210812.016"
resetprop -n ro.build.id "SP1A.210812.016"
resetprop -n ro.system.build.id "SP1A.210812.016"
resetprop -n ro.vendor.build.id "SP1A.210812.016"
resetprop -n ro.system.build.date "Thu Dec  1 15:46:57 CST 2022"
resetprop -n ro.bootimage.build.date "Thu Dec  1 15:46:57 CST 2022"
resetprop -n ro.product.build.date "Thu Dec  1 15:46:57 CST 2022"
resetprop -n ro.vendor_dlkm.build.date "Thu Dec  1 15:46:57 CST 2022"
resetprop -n ro.system_ext.build.date "Thu Dec  1 15:46:57 CST 2022"
resetprop -n ro.odm.build.date "Thu Dec  1 15:46:57 CST 2022"
resetprop -n ro.build.date "Thu Dec  1 15:46:57 CST 2022"
resetprop -n ro.vendor.build.date "Thu Dec  1 15:46:57 CST 2022"
resetprop -n ro.product.build.date.utc "1669880817"
resetprop -n ro.system_ext.build.date.utc "1669880817"
resetprop -n ro.system.build.date.utc "1669880817"
resetprop -n ro.vendor.build.date.utc "1669880817"
resetprop -n ro.vendor_dlkm.build.date.utc "1669880817"
resetprop -n ro.build.date.utc "1669880817"
resetprop -n ro.bootimage.build.date.utc "1669880817"
resetprop -n ro.odm.build.date.utc "1669880817"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name magic
resetprop -n ro.product.odm.name magic
resetprop -n ro.product.vendor.name magic
resetprop -n ro.product.system.name magic
resetprop -n ro.product.name magic
resetprop -n ro.product.bootimage.name magic
resetprop -n ro.product.vendor_dlkm.name magic
resetprop -n ro.product.system_ext.name magic
resetprop -n ro.build.flavor magic-user
randomStr="magic-user unknown SP1A.210812.016 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=5eacef05ee52
resetprop -n ro.build.host ${randomStr}
randomStr=1560a7d8
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=XOiTgR
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=2c706a2ac92d6
randomStr2=a3
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=fe
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "V13.0.2.1.37.DEV"
resetprop -n ro.build.description "magic-user 12 SP1A.210812.016 eng.root.20221201.154839 release-keys"
resetprop -n ro.build.product.backup "magic"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.host "cn-snxy1c-5e10340341669880497850-775c87b8b-77vj9"
resetprop -n ro.build.characteristics "default"
resetprop -n ro.build.user "test"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2022-11-01
