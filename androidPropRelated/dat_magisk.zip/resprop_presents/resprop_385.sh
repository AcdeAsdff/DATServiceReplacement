strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "GO505"
resetprop -n ro.product.vendor.model "GO505"
resetprop -n ro.product.vendor_dlkm.marketname "GO505"
resetprop -n ro.product.product.marketname "GO505"
resetprop -n ro.product.system.marketname "GO505"
resetprop -n ro.product.odm_dlkm.marketname "GO505"
resetprop -n ro.product.system_ext.marketname "GO505"
resetprop -n ro.product.odm_dlkm.model "GO505"
resetprop -n ro.product.system.model "GO505"
resetprop -n ro.product.system_ext.model "GO505"
resetprop -n ro.product.vendor_dlkm.model "GO505"
resetprop -n bluetooth.device.default_name "GO505"
resetprop -n ro.product.bootimage.model "GO505"
resetprop -n ro.product.vendor.marketname "GO505"
resetprop -n ro.product.marketname "GO505"
resetprop -n ro.product.odm.model "GO505"
resetprop -n ro.product.model "GO505"
resetprop -n ro.product.product.model "GO505"
resetprop -n ro.product.odm.marketname "GO505"
resetprop -n ro.product.vendor.manufacturer "GOMOBILE"
resetprop -n ro.product.product.manufacturer "GOMOBILE"
resetprop -n ro.product.bootimage.manufacturer "GOMOBILE"
resetprop -n ro.product.manufacturer "GOMOBILE"
resetprop -n ro.product.odm.manufacturer "GOMOBILE"
resetprop -n ro.product.system.manufacturer "GOMOBILE"
resetprop -n ro.product.system_ext.manufacturer "GOMOBILE"
resetprop -n ro.product.vendor_dlkm.manufacturer "GOMOBILE"
resetprop -n ro.product.vendor.brand "GOMOBILE"
resetprop -n ro.product.product.brand "GOMOBILE"
resetprop -n ro.product.vendor_dlkm.brand "GOMOBILE"
resetprop -n ro.product.system.brand "GOMOBILE"
resetprop -n ro.product.bootimage.brand "GOMOBILE"
resetprop -n ro.product.system_ext.brand "GOMOBILE"
resetprop -n ro.product.odm.brand "GOMOBILE"
resetprop -n ro.product.odm_dlkm.brand "GOMOBILE"
resetprop -n ro.product.brand "GOMOBILE"
resetprop -n ro.vendor_dlkm.build.fingerprint "GOMOBILE/GO505/GO505:8.1.0/OPM2.171019.012/32114:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "GOMOBILE/GO505/GO505:8.1.0/OPM2.171019.012/32114:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "GOMOBILE/GO505/GO505:8.1.0/OPM2.171019.012/32114:user/release-keys"
resetprop -n ro.odm.build.fingerprint "GOMOBILE/GO505/GO505:8.1.0/OPM2.171019.012/32114:user/release-keys"
resetprop -n ro.system.build.fingerprint "GOMOBILE/GO505/GO505:8.1.0/OPM2.171019.012/32114:user/release-keys"
resetprop -n ro.build.fingerprint "GOMOBILE/GO505/GO505:8.1.0/OPM2.171019.012/32114:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "GOMOBILE/GO505/GO505:8.1.0/OPM2.171019.012/32114:user/release-keys"
resetprop -n ro.product.build.fingerprint "GOMOBILE/GO505/GO505:8.1.0/OPM2.171019.012/32114:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "GOMOBILE/GO505/GO505:8.1.0/OPM2.171019.012/32114:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=cb1bce3592
resetprop -n ro.system.build.version.incremental 32114
resetprop -n ro.bootimage.build.version.incremental 32114
resetprop -n ro.product.build.version.incremental 32114
resetprop -n ro.odm.build.version.incremental 32114
resetprop -n ro.vendor_dlkm.build.version.incremental 32114
resetprop -n ro.system_ext.build.version.incremental 32114
resetprop -n ro.build.version.incremental 32114
resetprop -n ro.vendor.build.version.incremental 32114
resetprop -n ro.odm.build.id "OPM2.171019.012"
resetprop -n ro.product.build.id "OPM2.171019.012"
resetprop -n ro.bootimage.build.id "OPM2.171019.012"
resetprop -n ro.system_ext.build.id "OPM2.171019.012"
resetprop -n ro.vendor_dlkm.build.id "OPM2.171019.012"
resetprop -n ro.build.id "OPM2.171019.012"
resetprop -n ro.system.build.id "OPM2.171019.012"
resetprop -n ro.vendor.build.id "OPM2.171019.012"
resetprop -n ro.system.build.date "Mon Aug  6 14:24:49 CST 2018"
resetprop -n ro.bootimage.build.date "Mon Aug  6 14:24:49 CST 2018"
resetprop -n ro.product.build.date "Mon Aug  6 14:24:49 CST 2018"
resetprop -n ro.vendor_dlkm.build.date "Mon Aug  6 14:24:49 CST 2018"
resetprop -n ro.system_ext.build.date "Mon Aug  6 14:24:49 CST 2018"
resetprop -n ro.odm.build.date "Mon Aug  6 14:24:49 CST 2018"
resetprop -n ro.build.date "Mon Aug  6 14:24:49 CST 2018"
resetprop -n ro.vendor.build.date "Mon Aug  6 14:24:49 CST 2018"
resetprop -n ro.product.build.date.utc "1533536689"
resetprop -n ro.system_ext.build.date.utc "1533536689"
resetprop -n ro.system.build.date.utc "1533536689"
resetprop -n ro.vendor.build.date.utc "1533536689"
resetprop -n ro.vendor_dlkm.build.date.utc "1533536689"
resetprop -n ro.build.date.utc "1533536689"
resetprop -n ro.bootimage.build.date.utc "1533536689"
resetprop -n ro.odm.build.date.utc "1533536689"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name GO505
resetprop -n ro.product.odm.name GO505
resetprop -n ro.product.vendor.name GO505
resetprop -n ro.product.system.name GO505
resetprop -n ro.product.name GO505
resetprop -n ro.product.bootimage.name GO505
resetprop -n ro.product.vendor_dlkm.name GO505
resetprop -n ro.product.system_ext.name GO505
resetprop -n ro.build.flavor oversea
randomStr="oversea GOMOBILE OPM2.171019.012 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=69a93b8805d1
resetprop -n ro.build.host ${randomStr}
randomStr=72e78488
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=CAvsLM
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=eecd9d3f7bbeb
randomStr2=a8
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=de
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "32114"
resetprop -n ro.build.description "sp7731e_fs286_project-user 8.1.0 OPM2.171019.012 32114 release-keys"
resetprop -n ro.fota.version.display "GO505_SS_NSL_DG_ES_V02"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "cwjf4"
resetprop -n ro.build.host "ww-linuxf4"
resetprop -n ro.build.product.backup "sp7731e_fs286"
resetprop -n ro.build.characteristics "default"
resetprop -n media.settings.xml  " vendor/etc/media_profiles_turnkey.xml"
resetprop -n ro.fota.platform "Sprd7731_8.1"
resetprop -n ro.fota.type "phone"
resetprop -n ro.fota.app "5"
resetprop -n ro.fota.oem "waterworld67731_8.1"
resetprop -n ro.fota.device "GO505"
resetprop -n ro.fota.version "GO505_SS_NSL_DG_ES_V02_20180806-1427"
resetprop -n ro.expect.recovery_id "0x05d875051fae1b7c27c5076829f73626a225e133000000000000000000000000"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2018-07-05
