strs=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "A" "B" "C" "D" "E" "F")
strsLower=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9" "a" "b" "c" "d" "e" "f")
chars=("z" "x" "c" "v" "b" "n" "m" "a" "s" "d" "f" "g" "h" "j" "k" "l" "q" "w" "e" "r" "t" "y" "u" "i" "o" "p" "Z" "X" "C" "V" "B" "N" "M" "A" "S" "D" "F" "G" "H" "J" "K" "L" "Q" "W" "E" "R" "T" "Y" "U" "I" "O" "P")
resetprop -n vendor.usb.product_string "MP17"
resetprop -n ro.product.vendor.model "MP17"
resetprop -n ro.product.vendor_dlkm.marketname "MP17"
resetprop -n ro.product.product.marketname "MP17"
resetprop -n ro.product.system.marketname "MP17"
resetprop -n ro.product.odm_dlkm.marketname "MP17"
resetprop -n ro.product.system_ext.marketname "MP17"
resetprop -n ro.product.odm_dlkm.model "MP17"
resetprop -n ro.product.system.model "MP17"
resetprop -n ro.product.system_ext.model "MP17"
resetprop -n ro.product.vendor_dlkm.model "MP17"
resetprop -n bluetooth.device.default_name "MP17"
resetprop -n ro.product.bootimage.model "MP17"
resetprop -n ro.product.vendor.marketname "MP17"
resetprop -n ro.product.marketname "MP17"
resetprop -n ro.product.odm.model "MP17"
resetprop -n ro.product.model "MP17"
resetprop -n ro.product.product.model "MP17"
resetprop -n ro.product.odm.marketname "MP17"
resetprop -n ro.product.vendor.manufacturer "HXY"
resetprop -n ro.product.product.manufacturer "HXY"
resetprop -n ro.product.bootimage.manufacturer "HXY"
resetprop -n ro.product.manufacturer "HXY"
resetprop -n ro.product.odm.manufacturer "HXY"
resetprop -n ro.product.system.manufacturer "HXY"
resetprop -n ro.product.system_ext.manufacturer "HXY"
resetprop -n ro.product.vendor_dlkm.manufacturer "HXY"
resetprop -n ro.product.vendor.brand "UMIDIGI"
resetprop -n ro.product.product.brand "UMIDIGI"
resetprop -n ro.product.vendor_dlkm.brand "UMIDIGI"
resetprop -n ro.product.system.brand "UMIDIGI"
resetprop -n ro.product.bootimage.brand "UMIDIGI"
resetprop -n ro.product.system_ext.brand "UMIDIGI"
resetprop -n ro.product.odm.brand "UMIDIGI"
resetprop -n ro.product.odm_dlkm.brand "UMIDIGI"
resetprop -n ro.product.brand "UMIDIGI"
resetprop -n ro.vendor_dlkm.build.fingerprint "UMIDIGI/C1_Max/C1_Max:12/SP1A.210812.016/2211231730:user/release-keys"
resetprop -n ro.bootimage.build.fingerprint "UMIDIGI/C1_Max/C1_Max:12/SP1A.210812.016/2211231730:user/release-keys"
resetprop -n ro.vendor.build.fingerprint "UMIDIGI/C1_Max/C1_Max:12/SP1A.210812.016/2211231730:user/release-keys"
resetprop -n ro.odm.build.fingerprint "UMIDIGI/C1_Max/C1_Max:12/SP1A.210812.016/2211231730:user/release-keys"
resetprop -n ro.system.build.fingerprint "UMIDIGI/C1_Max/C1_Max:12/SP1A.210812.016/2211231730:user/release-keys"
resetprop -n ro.build.fingerprint "UMIDIGI/C1_Max/C1_Max:12/SP1A.210812.016/2211231730:user/release-keys"
resetprop -n ro.system_ext.build.fingerprint "UMIDIGI/C1_Max/C1_Max:12/SP1A.210812.016/2211231730:user/release-keys"
resetprop -n ro.product.build.fingerprint "UMIDIGI/C1_Max/C1_Max:12/SP1A.210812.016/2211231730:user/release-keys"
resetprop -n ro.odm_dlkm.build.fingerprint "UMIDIGI/C1_Max/C1_Max:12/SP1A.210812.016/2211231730:user/release-keys"
resetprop -n --delete ro.lineage.build.version.plat.rev
resetprop -n --delete ro.modversion
resetprop -n --delete ro.lineagelegal.url
resetprop -n --delete ro.lineage.display.version
resetprop -n --delete ro.lineage.version
resetprop -n --delete persist.vendor.camera.rearDepth.info
resetprop -n --delete init.svc_debug_pid.vendor.lineage_health
resetprop -n --delete persist.vendor.camera.frontMain.info
resetprop -n --delete persist.vendor.camera.rearMain.info
resetprop -n --delete persist.vendor.camera.rearUltra.info
resetprop -n --delete init.svc.vendor.lineage_health
resetprop -n --delete ro.lineage.build.version
resetprop -n --delete persist.vendor.camera.rearMacro.info
resetprop -n --delete ro.lineage.build.version.plat.sdk
resetprop -n --delete ro.boottime.vendor.lineage_health
resetprop -n --delete ro.lineage.releasetype
resetprop -n --delete ro.lineage.device
resetprop -n --delete ro.com.google.clientidbase
randomStr=9e2509c859
resetprop -n ro.system.build.version.incremental 2211231730
resetprop -n ro.bootimage.build.version.incremental 2211231730
resetprop -n ro.product.build.version.incremental 2211231730
resetprop -n ro.odm.build.version.incremental 2211231730
resetprop -n ro.vendor_dlkm.build.version.incremental 2211231730
resetprop -n ro.system_ext.build.version.incremental 2211231730
resetprop -n ro.build.version.incremental 2211231730
resetprop -n ro.vendor.build.version.incremental 2211231730
resetprop -n ro.odm.build.id "SP1A.210812.016"
resetprop -n ro.product.build.id "SP1A.210812.016"
resetprop -n ro.bootimage.build.id "SP1A.210812.016"
resetprop -n ro.system_ext.build.id "SP1A.210812.016"
resetprop -n ro.vendor_dlkm.build.id "SP1A.210812.016"
resetprop -n ro.build.id "SP1A.210812.016"
resetprop -n ro.system.build.id "SP1A.210812.016"
resetprop -n ro.vendor.build.id "SP1A.210812.016"
resetprop -n ro.system.build.date "Tue Feb  7 12:41:06 CST 2023"
resetprop -n ro.bootimage.build.date "Tue Feb  7 12:41:06 CST 2023"
resetprop -n ro.product.build.date "Tue Feb  7 12:41:06 CST 2023"
resetprop -n ro.vendor_dlkm.build.date "Tue Feb  7 12:41:06 CST 2023"
resetprop -n ro.system_ext.build.date "Tue Feb  7 12:41:06 CST 2023"
resetprop -n ro.odm.build.date "Tue Feb  7 12:41:06 CST 2023"
resetprop -n ro.build.date "Tue Feb  7 12:41:06 CST 2023"
resetprop -n ro.vendor.build.date "Tue Feb  7 12:41:06 CST 2023"
resetprop -n ro.product.build.date.utc "1675744866"
resetprop -n ro.system_ext.build.date.utc "1675744866"
resetprop -n ro.system.build.date.utc "1675744866"
resetprop -n ro.vendor.build.date.utc "1675744866"
resetprop -n ro.vendor_dlkm.build.date.utc "1675744866"
resetprop -n ro.build.date.utc "1675744866"
resetprop -n ro.bootimage.build.date.utc "1675744866"
resetprop -n ro.odm.build.date.utc "1675744866"
resetprop -n ro.product.build.tags "release-keys"
resetprop -n ro.build.tags "release-keys"
resetprop -n ro.odm.build.tags "release-keys"
resetprop -n ro.bootimage.build.tags "release-keys"
resetprop -n ro.vendor_dlkm.build.tags "release-keys"
resetprop -n ro.system_ext.build.tags "release-keys"
resetprop -n ro.vendor.build.tags "release-keys"
resetprop -n ro.system.build.tags "release-keys"
resetprop -n ro.system.build.type "user"
resetprop -n ro.system_ext.build.type "user"
resetprop -n ro.vendor_dlkm.build.type "user"
resetprop -n ro.bootimage.build.type "user"
resetprop -n ro.product.build.type "user"
resetprop -n ro.odm.build.type "user"
resetprop -n ro.vendor.build.type "user"
resetprop -n ro.product.product.name g2239hua_v1_6ja_ym_c1max_s_Natv
resetprop -n ro.product.odm.name g2239hua_v1_6ja_ym_c1max_s_Natv
resetprop -n ro.product.vendor.name g2239hua_v1_6ja_ym_c1max_s_Natv
resetprop -n ro.product.system.name g2239hua_v1_6ja_ym_c1max_s_Natv
resetprop -n ro.product.name g2239hua_v1_6ja_ym_c1max_s_Natv
resetprop -n ro.product.bootimage.name g2239hua_v1_6ja_ym_c1max_s_Natv
resetprop -n ro.product.vendor_dlkm.name g2239hua_v1_6ja_ym_c1max_s_Natv
resetprop -n ro.product.system_ext.name g2239hua_v1_6ja_ym_c1max_s_Natv
resetprop -n ro.build.flavor g2239hua_v1_6ja_ym_c1max_s_Natv-user
randomStr="g2239hua_v1_6ja_ym_c1max_s_Natv-user HXY SP1A.210812.016 "${randomStr}
resetprop -n ro.build.display.id "${randomStr}"
resetprop -n ro.soc.manufacturer unset
resetprop -n ro.soc.model unset
resetprop -n vendor.camera.aux.packagelist com.android.camera
randomStr=af1787da01a9
resetprop -n ro.build.host ${randomStr}
randomStr=e5900586
resetprop -n ro.serialno ${randomStr}
resetprop -n ro.boot.serialno ${randomStr}
randomStr2=wczDab
resetprop -n persist.adb.wifi.guid "adb-"${randomStr}"-"${randomStr2}
randomStr=df05c0bf44f93
randomStr2=ae
resetprop -n persist.vendor.radio.imei ${randomStr}${randomStr2}
resetprop -n persist.vendor.radio.imei1 ${randomStr}${randomStr2}
randomStr2=c3
resetprop -n persist.vendor.radio.imei2 ${randomStr}${randomStr2}

resetprop -n ro.product.locale zh-CN
resetprop -n ro.product.locale.language zh
resetprop -n ro.product.locale.region CN
resetprop -n ro.hw.country cn
resetprop -n ro.secure 0
resetprop -n ro.debuggable 0
resetprop -n ro.build.type user
resetprop -n ro.build.version.incremental "2211231730"
resetprop -n ro.build.description "UMIDIGI_C1_Max_V1.0_20230207"
resetprop -n ro.build.product.backup "C1_Max"
resetprop -n ro.build.version.preview_sdk_fingerprint "REL"
resetprop -n ro.build.version.codename "REL"
resetprop -n ro.build.version.all_codenames "REL"
resetprop -n ro.build.user "he_fj"
resetprop -n ro.build.host "User"
resetprop -n ro.fota.platform "Sprd_12.0"
resetprop -n ro.fota.type "phone"
resetprop -n ro.fota.app "5"
resetprop -n ro.fota.battery "30"
resetprop -n ro.fota.oem "hongxiangyuan_Sprd_12.0"
resetprop -n ro.fota.device "C1 Max"
resetprop -n ro.fota.version "UMIDIGI_C1_Max_V1.0_20221123_20230207-1244"
resetprop -n --delete ro.soc.manufacturer
resetprop -n --delete gsm.version.ril-impl
resetprop -n --delete ro.soc.model
resetprop -n ro.vendor.build.security_patch 2022-10-05
