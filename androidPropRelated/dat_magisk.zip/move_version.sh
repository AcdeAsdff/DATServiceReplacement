MODDIR=${0%/*}
touch ${MODDIR}/version
if [ -e ${MODDIR}/version ]
then
	mv /proc/version ${MODDIR}/version
fi