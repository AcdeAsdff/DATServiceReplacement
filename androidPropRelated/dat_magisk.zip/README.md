# magisk-module-installer

This repo only for magisk module template, please read [Developer Guides](https://topjohnwu.github.io/Magisk/guides.html) for instruction on how to create a Magisk Module Installer!.

- Updated repo at     : 20200117
- Magisk Compatibilty : 20.3+

